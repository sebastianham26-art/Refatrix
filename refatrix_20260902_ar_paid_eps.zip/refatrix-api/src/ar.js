// 담당고객 오픈 인보이스(미수/연체) 계산 — 순수 함수(단위 테스트 가능)
// node-pg는 NUMERIC을 문자열로 반환하므로 모든 금액 Number() 변환.

export function r2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }

// ── 완납(반제 완료) 판정 공통 허용치 ──────────────────────────────────────────
// 화면 금액은 toLocaleString(maximumFractionDigits:0) 으로 **정수 페소 반올림**해 보여준다.
// 그래서 판정 기준도 같은 눈금(0.5 페소 미만 = 화면상 0)에 맞춘다.
// 이 값보다 작게 남은 잔액은 IVA 16% 센타보 반올림 잔여이지 미수가 아니다.
// (2026-08-27 세션 결정 · 2026-09-02 현재 main 에 재적용)
export const AR_PAID_EPS = 0.5;
export function arIsPaid(outstanding) { return Number(outstanding || 0) < AR_PAID_EPS; }
export function arIsOpen(outstanding) { return !arIsPaid(outstanding); }

function d10(v) { if (!v) return null; if (v instanceof Date) return v.toISOString().slice(0, 10); return String(v).slice(0, 10); }

// 한 인보이스의 미수/연체 상태.
//  inv: { total, paid, due_date }, todayStr: 'YYYY-MM-DD'
//  반환: { total, paid, outstanding, open, overdue, overdue_days, days_to_due }
export function arInvoiceStatus(inv, todayStr) {
  const total = r2(Number(inv.total) || 0);
  const paid = r2(Number(inv.paid) || 0);
  const outstanding = r2(total - paid);
  const open = arIsOpen(outstanding);
  const due = d10(inv.due_date);
  let overdue = false, overdue_days = null, days_to_due = null;
  if (due && todayStr) {
    const diff = Math.round((Date.parse(due + 'T00:00:00Z') - Date.parse(todayStr + 'T00:00:00Z')) / 86400000);
    // diff = 만기 − 오늘 (음수=이미 지남)
    if (open) {
      if (diff < 0) { overdue = true; overdue_days = -diff; }
      else { days_to_due = diff; } // D-n (만기까지 남은 일, 0=오늘 만기)
    }
  }
  return { total, paid, outstanding, open, overdue, overdue_days, days_to_due };
}

// 미수(open) 인보이스를 만기월(due_date 'YYYY-MM')로 버킷. 최신 만기월 먼저.
//  invoices: [{ due_date, outstanding, overdue }]
//  반환: [{ ym, count, outstanding, overdue }]   (overdue = 그 달의 연체 미수액 합)
export function bucketByDueMonth(invoices) {
  const map = {};
  for (const inv of invoices) {
    const due = d10(inv.due_date);
    const ym = due ? due.slice(0, 7) : '미정';
    if (!map[ym]) map[ym] = { ym, count: 0, outstanding: 0, overdue: 0 };
    const o = Number(inv.outstanding) || 0;
    map[ym].count += 1;
    map[ym].outstanding = r2(map[ym].outstanding + o);
    if (inv.overdue) map[ym].overdue = r2(map[ym].overdue + o);
  }
  return Object.values(map).sort((a, b) => (a.ym < b.ym ? 1 : a.ym > b.ym ? -1 : 0));
}

// 입금증(증빙) data URL 검증 — 순수 함수(단위 테스트 가능).
//  허용: image/*  또는 application/pdf, base64 인코딩만.
//  반환: { ok:true, mime, bytes } 또는 { ok:false, error }
export function validateReceiptDataUrl(dataUrl, maxBytes = 8 * 1024 * 1024) {
  if (typeof dataUrl !== 'string' || !dataUrl) return { ok: false, error: 'empty' };
  const m = dataUrl.match(/^data:([^;,]+);base64,([A-Za-z0-9+/=\s]+)$/);
  if (!m) return { ok: false, error: 'bad_format' };
  const mime = m[1].toLowerCase();
  if (!(mime.startsWith('image/') || mime === 'application/pdf')) return { ok: false, error: 'bad_mime' };
  const b64 = m[2].replace(/\s+/g, '');
  if (!b64) return { ok: false, error: 'empty_data' };
  const bytes = Math.floor((b64.length * 3) / 4);
  if (bytes > maxBytes) return { ok: false, error: 'too_large' };
  return { ok: true, mime, bytes };
}

// 오픈 인보이스 요약(건수·총 미수·연체 미수).
export function arSummary(openInvoices) {
  return openInvoices.reduce((s, v) => {
    const o = Number(v.outstanding) || 0;
    s.open_count += 1; s.outstanding = r2(s.outstanding + o);
    if (v.overdue) s.overdue = r2(s.overdue + o);
    return s;
  }, { open_count: 0, outstanding: 0, overdue: 0 });
}
