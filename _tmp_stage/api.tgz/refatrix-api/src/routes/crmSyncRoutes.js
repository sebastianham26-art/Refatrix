// CRM 전송 이력 — 디렉터 전용.
//   전송이 실패했는데 아무도 모르는 상황을 막는 화면의 뒷단이다.
//   조회 · 재전송 · 수동 전송 · 즉시 드레인. 연동 설정·계약서는 integrationRoutes.js.
import { query } from '../db.js';
import { authGuard, requireDirector } from '../middleware/authGuard.js';
import { crmTableReady, drainOutbox, enqueueCustomerSync, crmStatus, MAX_ATTEMPTS, scheduleDrain } from '../crmSync.js';

// 0203 인증 추적 컬럼(있을 때만 조회에 싣는다)
let hasAuthCols = false;
let authProbe = 0;
async function authCols() {
  if (hasAuthCols) return true;
  if (Date.now() - authProbe < 30000) return false;
  authProbe = Date.now();
  try {
    const r = await query(
      `SELECT 1 FROM information_schema.columns
        WHERE table_name='crm_customer_outbox' AND column_name='auth_sent' LIMIT 1`);
    hasAuthCols = r.rows.length > 0;
  } catch (_) { hasAuthCols = false; }
  return hasAuthCols;
}

// 0201 이전 DB(엔드포인트 컬럼 없음)에서도 조회가 죽지 않게 확인한다.
//   없을 때만 30초마다 다시 본다 — 서버 기동 후 migrate 해도 재시작 없이 반영되도록.
let hasEpCols = false;
let epProbe = 0;
async function epCols() {
  if (hasEpCols) return true;
  if (Date.now() - epProbe < 30000) return false;
  epProbe = Date.now();
  try {
    const r = await query(
      `SELECT 1 FROM information_schema.columns
        WHERE table_name='crm_customer_outbox' AND column_name='endpoint_key' LIMIT 1`);
    hasEpCols = r.rows.length > 0;
  } catch (_) { hasEpCols = false; }
  return hasEpCols;
}

export default async function crmSyncRoutes(app) {
  const guard = { preHandler: [authGuard, requireDirector] };

  // 감사로그는 있으면 남기고 없으면 조용히 지나간다(전송 자체를 막지 않는다).
  async function safeAudit(req, { action, detail }) {
    try {
      await query(`INSERT INTO audit_log (user_id, action, target, detail) VALUES ($1,$2,$3,$4)`,
        [req.ctx.perm.userId, action, 'crm_sync', JSON.stringify(detail || {})]);
    } catch (_) { /* ignore */ }
  }

  async function ready(reply) {
    if (await crmTableReady()) return true;
    reply.code(503).send({ error: 'migration_required', note: '0200_crm_customer_outbox 마이그레이션이 필요합니다.' });
    return false;
  }

  /**
   * 20260924 · **범위(scope)** — 누적이 아니라 「이번 전송」·「오늘」 단위로 본다.
   *   run_id : 제품 전송 1회(product_sync_runs.id) — 그 실행의 묶음/제품만
   *   from/to: 멕시코 날짜(YYYY-MM-DD) — 적재 시각 기준. 고객·오더 이력용
   *   아무것도 없으면 예전과 같다(전체 누적).
   */
  function scopeWhere(qs, params, where, hasEp) {
    const runId = Number(qs.run_id);
    if (qs.run_id != null && qs.run_id !== '' && Number.isFinite(runId) && hasEp) {
      params.push(runId);
      where.push(`o.entity='product' AND o.entity_id=$${params.length}`);
    }
    const ymd = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null);
    const from = ymd(qs.from), to = ymd(qs.to);
    if (from) { params.push(from); where.push(`(o.created_at AT TIME ZONE 'America/Mexico_City')::date >= $${params.length}::date`); }
    if (to)   { params.push(to);   where.push(`(o.created_at AT TIME ZONE 'America/Mexico_City')::date <= $${params.length}::date`); }
  }

  // 요약(전체 · 연동별 · 20260924 범위)
  app.get('/api/crm-sync/summary', guard, async (req) => {
    const engine = crmStatus();
    if (!(await crmTableReady())) return { engine, migrated: false, counts: {}, by_endpoint: {}, oldest_pending: null };
    const ep = await epCols();
    const keyExpr = ep ? `COALESCE(endpoint_key,'customer_commercial')` : `'customer_commercial'`;
    const rows = (await query(
      `SELECT ${keyExpr} AS k, status, count(*)::int AS n FROM crm_customer_outbox GROUP BY 1,2`)).rows;
    const counts = { pending: 0, sent: 0, failed: 0, skipped: 0 };
    const byEp = {};
    for (const r of rows) {
      counts[r.status] = (counts[r.status] || 0) + Number(r.n);
      byEp[r.k] = byEp[r.k] || { pending: 0, sent: 0, failed: 0, skipped: 0 };
      byEp[r.k][r.status] = Number(r.n);
    }
    const oldest = (await query(
      `SELECT min(created_at) AS t FROM crm_customer_outbox WHERE status='pending'`)).rows[0];
    // 20260924 · 범위 집계 — 창구 + (전송 1회 | 기간). 화면 상단 숫자가 누적이 아니라 이 범위를 보인다.
    let scope = null;
    const qs = req.query || {};
    if (qs.endpoint || qs.run_id || qs.from || qs.to) {
      const where = [], params = [];
      if (qs.endpoint && ep) { params.push(String(qs.endpoint)); where.push(`COALESCE(o.endpoint_key,'customer_commercial')=$${params.length}`); }
      scopeWhere(qs, params, where, ep);
      const sr = (await query(
        `SELECT o.status, count(*)::int AS n,
                min(o.created_at) AS first_at, max(o.sent_at) AS last_sent_at
           FROM crm_customer_outbox o
          ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
          GROUP BY 1`, params)).rows;
      scope = { pending: 0, sent: 0, failed: 0, skipped: 0, first_at: null, last_sent_at: null };
      for (const r of sr) {
        scope[r.status] = Number(r.n);
        if (r.first_at && (!scope.first_at || r.first_at < scope.first_at)) scope.first_at = r.first_at;
        if (r.last_sent_at && (!scope.last_sent_at || r.last_sent_at > scope.last_sent_at)) scope.last_sent_at = r.last_sent_at;
      }
    }
    return { engine, migrated: true, counts, by_endpoint: byEp, oldest_pending: oldest.t || null, scope };
  });

  // 목록 — status(open|pending|sent|failed|skipped|all) · endpoint · q 검색
  app.get('/api/crm-sync', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const ep = await epCols();
    const au = await authCols();
    const st = String(req.query.status || 'open');
    const key = String(req.query.endpoint || '').trim();
    const q = String(req.query.q || '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 300);
    // 09-24 · 페이지 넘기기. offset 이 없으면 예전 그대로(최신 limit 건).
    const offset = Math.max(Number(req.query.offset) || 0, 0);
    const where = [];
    const params = [];
    if (st === 'open') where.push(`o.status IN ('pending','failed')`);
    else if (['pending', 'sent', 'failed', 'skipped'].includes(st)) { params.push(st); where.push(`o.status=$${params.length}`); }
    if (key && ep) { params.push(key); where.push(`COALESCE(o.endpoint_key,'customer_commercial')=$${params.length}`); }
    scopeWhere(req.query || {}, params, where, ep);   // 20260924 · 전송 1회 / 기간
    if (q) {
      params.push(`%${q}%`);
      const i = params.length;
      where.push(`(c.code ILIKE $${i} OR c.name ILIKE $${i} OR o.rfc ILIKE $${i}${ep ? ` OR o.entity_label ILIKE $${i}` : ''})`);
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    // 전체 건수 — 같은 조건 그대로(검색이 고객 칼럼을 보므로 JOIN 도 같게).
    const total = Number((await query(
      `SELECT count(*)::int AS n
         FROM crm_customer_outbox o
         LEFT JOIN customers c ON c.id=o.customer_id
        ${whereSql}`, params)).rows[0].n);
    params.push(limit);
    const limIdx = params.length;
    params.push(offset);
    const offIdx = params.length;
    const authSel = au ? `o.auth_sent, o.auth_header,` : `NULL::boolean AS auth_sent, NULL::text AS auth_header,`;
    const extra = ep
      ? `COALESCE(o.endpoint_key,'customer_commercial') AS endpoint_key, o.entity, o.entity_id, o.entity_label, o.env, o.url, o.request_method,`
      : `'customer_commercial' AS endpoint_key, 'customer' AS entity, o.customer_id AS entity_id,
         NULL::text AS entity_label, NULL::text AS env, NULL::text AS url, NULL::text AS request_method,`;
    // 0213 · 폴백으로 이어진 건인지. 컬럼이 없을 수도 있다(마이그레이션 전).
    let fbSel = `NULL::bigint AS fallback_of,`;
    try {
      const f = (await query(
        `SELECT 1 FROM information_schema.columns
          WHERE table_name='crm_customer_outbox' AND column_name='fallback_of' LIMIT 1`)).rows[0];
      if (f) fbSel = `o.fallback_of,`;
    } catch (_) { /* 없으면 NULL */ }
    const rows = (await query(
      `SELECT o.id, o.customer_id, ${extra} ${authSel} ${fbSel}
              o.op, o.origin, o.rfc, o.payload, o.status, o.attempts,
              o.next_attempt_at, o.http_status, o.codigo_error, o.last_error, o.response,
              o.created_at, o.sent_at,
              c.code AS customer_code, c.name AS customer_name,
              u.name AS acted_by_name
         FROM crm_customer_outbox o
         LEFT JOIN customers c ON c.id=o.customer_id
         LEFT JOIN users u ON u.id=o.acted_by
        ${whereSql}
        ORDER BY o.id DESC LIMIT $${limIdx} OFFSET $${offIdx}`, params)).rows;
    return {
      max_attempts: MAX_ATTEMPTS,
      total, limit, offset,
      items: rows.map((r) => ({
        id: Number(r.id),
        endpoint_key: r.endpoint_key, entity: r.entity,
        entity_id: r.entity_id == null ? null : Number(r.entity_id),
        customer_id: r.customer_id == null ? null : Number(r.customer_id),
        customer_code: r.customer_code, customer_name: r.customer_name || r.entity_label,
        op: r.op, origin: r.origin, rfc: r.rfc, payload: r.payload,
        status: r.status, attempts: Number(r.attempts),
        next_attempt_at: r.next_attempt_at,
        http_status: r.http_status == null ? null : Number(r.http_status),
        codigo_error: r.codigo_error, last_error: r.last_error, response: r.response,
        env: r.env, url: r.url, request_method: r.request_method,
        auth_sent: r.auth_sent, auth_header: r.auth_header,
        fallback_of: r.fallback_of == null ? null : Number(r.fallback_of),
        created_at: r.created_at, sent_at: r.sent_at, acted_by_name: r.acted_by_name,
      })),
    };
  });

  /**
   * 2026-10-06 · 실패·대기 내역 내려받기 — CRM 개발자에게 그대로 넘길 용도.
   *   GET /api/crm-sync/export?endpoint=&status=open(기본: 대기+실패)&run_id=&from=&to=&q=
   *   목록과 같은 범위 조건 · 페이지 없이 최대 20,000건 · 보낸 본문·받은 응답 원문 포함.
   *   ⚠ 키는 들어가지 않는다 — 본문은 키를 싣기 전 상태로 저장되고, url 은 키를 *** 로 지운 형태다.
   */
  app.get('/api/crm-sync/export', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const ep = await epCols();
    const qs = req.query || {};
    const st = String(qs.status || 'open');
    const key = String(qs.endpoint || '').trim();
    const q = String(qs.q || '').trim();
    const where = [];
    const params = [];
    if (st === 'open') where.push(`o.status IN ('pending','failed')`);
    else if (['pending', 'sent', 'failed', 'skipped'].includes(st)) { params.push(st); where.push(`o.status=$${params.length}`); }
    if (key && ep) { params.push(key); where.push(`COALESCE(o.endpoint_key,'customer_commercial')=$${params.length}`); }
    scopeWhere(qs, params, where, ep);
    if (q) {
      params.push(`%${q}%`);
      const i = params.length;
      where.push(`(c.code ILIKE $${i} OR c.name ILIKE $${i} OR o.rfc ILIKE $${i}${ep ? ` OR o.entity_label ILIKE $${i}` : ''})`);
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const extra = ep
      ? `COALESCE(o.endpoint_key,'customer_commercial') AS endpoint_key, o.entity, o.entity_id, o.entity_label, o.env, o.url, o.request_method,`
      : `'customer_commercial' AS endpoint_key, 'customer' AS entity, o.customer_id AS entity_id,
         NULL::text AS entity_label, NULL::text AS env, NULL::text AS url, NULL::text AS request_method,`;
    const LIMIT = 20000;
    params.push(LIMIT + 1);
    const rows = (await query(
      `SELECT o.id, ${extra}
              o.op, o.origin, o.rfc, o.payload, o.status, o.attempts, o.next_attempt_at,
              o.http_status, o.codigo_error, o.last_error, o.response, o.created_at,
              c.code AS customer_code, c.name AS customer_name
         FROM crm_customer_outbox o
         LEFT JOIN customers c ON c.id=o.customer_id
        ${whereSql}
        ORDER BY o.id ASC LIMIT $${params.length}`, params)).rows;
    const truncated = rows.length > LIMIT;
    if (truncated) rows.length = LIMIT;
    // 사유별 묶음(개발자가 먼저 볼 표) — HTTP · codigoError · 사유 앞 160자
    const groups = new Map();
    for (const r of rows) {
      const reason = String(r.last_error || '').slice(0, 160);
      const g = `${r.status}|${r.http_status ?? ''}|${r.codigo_error ?? ''}|${reason}`;
      if (!groups.has(g)) groups.set(g, { status: r.status, http_status: r.http_status == null ? null : Number(r.http_status),
        codigo_error: r.codigo_error, reason, count: 0, example_id: Number(r.id),
        example: r.entity_label || [r.customer_code, r.customer_name].filter(Boolean).join(' ') || null });
      groups.get(g).count++;
    }
    await safeAudit(req, { action: 'update', detail: { op: 'crm_sync_export', endpoint: key || null, status: st, rows: rows.length } });
    return {
      ok: true, generated_at: new Date().toISOString(), endpoint: key || null, status: st,
      scope: { run_id: qs.run_id || null, from: qs.from || null, to: qs.to || null, q: q || null },
      total: rows.length, truncated, max_attempts: MAX_ATTEMPTS,
      counts: { pending: rows.filter((r) => r.status === 'pending').length, failed: rows.filter((r) => r.status === 'failed').length },
      groups: [...groups.values()].sort((a, b) => b.count - a.count),
      items: rows.map((r) => ({
        id: Number(r.id), endpoint_key: r.endpoint_key, entity: r.entity,
        reference: r.entity_label || [r.customer_code, r.customer_name].filter(Boolean).join(' ') || null,
        rfc: r.rfc, op: r.op, origin: r.origin, status: r.status, attempts: Number(r.attempts),
        created_at: r.created_at, next_attempt_at: r.next_attempt_at,
        env: r.env, request_method: r.request_method, url: r.url,
        http_status: r.http_status == null ? null : Number(r.http_status),
        codigo_error: r.codigo_error, last_error: r.last_error,
        payload: r.payload, response: r.response,
      })),
    };
  });

  // 고객별 최근 전송 이력(고객 상세에서 쓸 수 있게 열어 둔다)
  app.get('/api/crm-sync/customers/:id', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const rows = (await query(
      `SELECT id, op, origin, status, attempts, http_status, codigo_error, last_error, created_at, sent_at
         FROM crm_customer_outbox WHERE customer_id=$1 ORDER BY id DESC LIMIT 20`,
      [Number(req.params.id)])).rows;
    return { items: rows };
  });

  // 재전송 — failed/skipped 건을 다시 대기로 되돌린다(시도횟수 초기화).
  app.post('/api/crm-sync/:id/retry', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const id = Number(req.params.id);
    const row = (await query(`SELECT id, status FROM crm_customer_outbox WHERE id=$1`, [id])).rows[0];
    if (!row) return reply.code(404).send({ error: 'not_found' });
    if (row.status === 'sent') return reply.code(409).send({ error: 'already_sent' });
    await query(
      `UPDATE crm_customer_outbox
          SET status='pending', attempts=0, next_attempt_at=now(), last_error=NULL WHERE id=$1`, [id]);
    // 마침 워커가 돌고 있으면(busy) 잠깐 기다렸다 한 번 더 — 화면에 "안 나갔다"고 잘못 뜨는 것을 막는다.
    let out = await drainOutbox({ app, limit: 5 });
    if (out.busy) {
      await new Promise((r) => setTimeout(r, 400));
      out = await drainOutbox({ app, limit: 5 });
    }
    const after = (await query(`SELECT status, last_error, http_status FROM crm_customer_outbox WHERE id=$1`, [id])).rows[0];
    return { ok: true, id, result: after, drain: out };
  });

  // 특정 고객을 지금 상태 그대로 다시 보낸다(초기 이관·수동 대조용).
  app.post('/api/crm-sync/customers/:id/resend', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const id = Number(req.params.id);
    const c = (await query(`SELECT id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    const r = await enqueueCustomerSync(id, 'upsert', { origin: 'manual_resend', actorUserId: req.ctx.perm.userId, app });
    return { ok: !!r.ok, ...r };
  });

  /**
   * 전체 동기화(강제 일괄 전송) — 새 변경이 없어도 지금 ERP 값을 그대로 다시 보낸다.
   *   "CRM 이 최신인지 확신이 안 설 때" 사람이 눌러서 맞추는 장치다.
   *   body: { dry_run?: true, scope?: 'approved'|'all', team_id?, only_missing?: true, limit? }
   *     dry_run       — 몇 건이 대상인지만 세어 본다(적재하지 않는다)
   *     scope         — approved(기본): 승인된 고객만 · all: 승인 대기 포함
   *     only_missing  — 아직 한 번도 CRM 에 성공 전송된 적 없는 고객만
   *   RFC 없는 고객은 애초에 대상이 아니다(CRM 조회 키가 없다).
   */
  app.post('/api/crm-sync/bulk-push', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const b = req.body || {};
    const scope = b.scope === 'all' ? 'all' : 'approved';
    const limit = Math.min(Math.max(Number(b.limit || 1000), 1), 5000);
    const params = [];
    const conds = [
      `c.deleted_at IS NULL`,
      `c.rfc IS NOT NULL AND btrim(c.rfc) <> ''`,
    ];
    if (scope === 'approved') conds.push(`COALESCE(c.approval_status,'approved')='approved'`);
    if (b.team_id) { params.push(Number(b.team_id)); conds.push(`c.team_id=$${params.length}`); }
    if (b.only_missing) {
      conds.push(`NOT EXISTS (SELECT 1 FROM crm_customer_outbox o
                               WHERE o.customer_id=c.id AND o.op='upsert' AND o.status='sent')`);
    }
    // 이미 대기 중인 건이 있는 고객은 건너뛴다 — 같은 값을 두 번 줄 세울 이유가 없다.
    conds.push(`NOT EXISTS (SELECT 1 FROM crm_customer_outbox o
                             WHERE o.customer_id=c.id AND o.op='upsert' AND o.status='pending')`);
    params.push(limit);
    const rows = (await query(
      `SELECT c.id, c.code, c.name FROM customers c
        WHERE ${conds.join(' AND ')}
        ORDER BY c.id LIMIT $${params.length}`, params)).rows;

    if (b.dry_run) {
      return { ok: true, dry_run: true, count: rows.length,
               sample: rows.slice(0, 5).map((r) => `${r.code} ${r.name}`) };
    }

    let queued = 0, skipped = 0;
    for (const r of rows) {
      const out = await enqueueCustomerSync(Number(r.id), 'upsert',
        { origin: 'bulk_push', actorUserId: req.ctx.perm.userId });
      if (out.ok && out.status === 'pending') queued++; else skipped++;
    }
    // ⚠ audit_log.action 은 체크 제약이 있는 고정 목록이다 — 'crm_bulk_push' 를 그대로 넣으면
    //   제약 위반으로 조용히 버려진다(safeAudit 이 삼킨다). 목록에 있는 'update' 로 남기고
    //   무슨 작업이었는지는 detail 에 적는다.
    await safeAudit(req, { action: 'update', detail: { op: 'crm_bulk_push', scope, queued, skipped } });
    // 첫 묶음은 바로 밀어 준다. 적재 직후 예약된 드레인과 겹치면(busy) 잠깐 기다렸다 다시 —
    // 그렇지 않으면 "적재는 됐는데 아무것도 안 나간" 것처럼 보인다. 나머지는 워커가 순서대로 처리한다.
    const drain = { drained: 0, sent: 0, failed: 0, held: 0 };
    for (let i = 0; i < 5; i++) {
      const d = await drainOutbox({ app, limit: 50 });
      if (d.busy) { await new Promise((r) => setTimeout(r, 300)); continue; }
      drain.drained += d.drained || 0; drain.sent += d.sent || 0;
      drain.failed += d.failed || 0; drain.held += d.held || 0;
      if (!d.drained) break;
    }
    if (queued > (drain.drained || 0)) scheduleDrain(app);   // 20260924 · 나머지는 연속 전송으로 이어서
    return { ok: true, queued, skipped, drain,
             note: queued > 50 ? '나머지는 이어서 연속 전송됩니다.' : null };
  });

  /**
   * 2026-09-29 · 실패 건 일괄 재전송 — 전송 이력 화면에서 「지금 보고 있는 범위」의 실패(failed)만.
   *   body: { endpoint, run_id?, from?, to?, q?, dry_run? }  (목록 조회와 같은 조건 · 상태만 failed 고정)
   *   ⚠ 본문은 적재 시점의 스냅샷이다. 그래서 **뒤에 더 새 값이 나간 건은 다시 보내지 않는다**(옛 값으로 덮어쓰기 방지):
   *     · 고객·오더: 같은 대상에 더 나중 건이 전송 완료 또는 대기 중이면 제외
   *     · 제품: 가장 최근 전송 회차가 아닌 묶음은 제외(다음 전체 전송이 최신 값을 싣는다)
   *   건너뜀(skipped)은 대상이 아니다 — 상대가 거절한 영구 오류라 설정을 고친 뒤 건별 재전송으로 처리한다.
   */
  app.post('/api/crm-sync/retry-failed', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const ep = await epCols();
    const b = req.body || {};
    const key = String(b.endpoint || '').trim();
    const q = String(b.q || '').trim();
    const params = [];
    const where = [`o.status='failed'`];
    if (key && ep) { params.push(key); where.push(`COALESCE(o.endpoint_key,'customer_commercial')=$${params.length}`); }
    scopeWhere(b, params, where, ep);
    if (q) {
      params.push(`%${q}%`);
      const i = params.length;
      where.push(`(c.code ILIKE $${i} OR c.name ILIKE $${i} OR o.rfc ILIKE $${i}${ep ? ` OR o.entity_label ILIKE $${i}` : ''})`);
    }
    const superSql = ep
      ? `CASE WHEN o.entity='product' THEN
              o.entity_id < (SELECT max(p.entity_id) FROM crm_customer_outbox p
                              WHERE p.entity='product'
                                AND COALESCE(p.endpoint_key,'customer_commercial')=COALESCE(o.endpoint_key,'customer_commercial'))
            ELSE EXISTS (SELECT 1 FROM crm_customer_outbox n
                          WHERE n.id > o.id AND n.status IN ('sent','pending')
                            AND COALESCE(n.endpoint_key,'customer_commercial')=COALESCE(o.endpoint_key,'customer_commercial')
                            AND COALESCE(n.entity,'customer')=COALESCE(o.entity,'customer')
                            AND COALESCE(n.entity_id, n.customer_id)=COALESCE(o.entity_id, o.customer_id)
                            AND n.op=o.op)
          END`
      : `EXISTS (SELECT 1 FROM crm_customer_outbox n
                  WHERE n.id > o.id AND n.status IN ('sent','pending')
                    AND n.customer_id=o.customer_id AND n.op=o.op)`;
    const label = ep ? `COALESCE(o.entity_label, c.code || ' ' || c.name, '#' || o.id)` : `COALESCE(c.code || ' ' || c.name, '#' || o.id)`;
    const rows = (await query(
      `SELECT o.id, ${label} AS label, (${superSql}) AS superseded
         FROM crm_customer_outbox o
         LEFT JOIN customers c ON c.id=o.customer_id
        WHERE ${where.join(' AND ')}
        ORDER BY o.id
        LIMIT 5000`, params)).rows;
    const go = rows.filter((r) => !r.superseded);
    const superseded = rows.length - go.length;
    if (b.dry_run) {
      return { ok: true, dry_run: true, count: go.length, superseded,
               sample: go.slice(0, 5).map((r) => r.label) };
    }
    if (!go.length) return { ok: true, queued: 0, superseded, drain: { drained: 0, sent: 0, failed: 0, held: 0 } };
    const ids = go.map((r) => Number(r.id));
    // 되돌리는 순간에도 여전히 failed 인 것만(동시에 다른 사람이 건별 재전송한 건은 건드리지 않는다).
    const upd = await query(
      `UPDATE crm_customer_outbox
          SET status='pending', attempts=0, next_attempt_at=now(), last_error=NULL
        WHERE id = ANY($1) AND status='failed'`, [ids]);
    const queued = upd.rowCount || 0;
    await safeAudit(req, { action: 'update', detail: { op: 'crm_retry_failed', endpoint: key || null, queued, superseded } });
    const drain = { drained: 0, sent: 0, failed: 0, held: 0 };
    for (let i = 0; i < 5; i++) {
      const d = await drainOutbox({ app, limit: 50 });
      if (d.busy) { await new Promise((r) => setTimeout(r, 300)); continue; }
      drain.drained += d.drained || 0; drain.sent += d.sent || 0;
      drain.failed += d.failed || 0; drain.held += d.held || 0;
      if (!d.drained) break;
    }
    if (queued > (drain.drained || 0)) scheduleDrain(app);
    return { ok: true, queued, superseded, drain,
             note: queued > 50 ? '나머지는 이어서 연속 전송됩니다.' : null };
  });

  // 대기분 즉시 밀기
  app.post('/api/crm-sync/drain', guard, async (_req, reply) => {
    if (!(await ready(reply))) return;
    const out = await drainOutbox({ app, limit: 50 });
    scheduleDrain(app);   // 20260924 · 50건 뒤의 나머지도 이어서 끝까지
    return { ok: true, ...out };
  });
}
