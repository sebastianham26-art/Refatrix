// 연동 관리(디렉터 전용) — URL·계약서·인증을 화면에서 고치고, 연결을 시험한다.
//   전송 이력 조회·재전송은 crmSyncRoutes.js.
import { query } from '../db.js';
import { authGuard, requireDirector } from '../middleware/authGuard.js';
import {
  endpointsReady, listEndpoints, getEndpoint, publicEndpoint,
  saveEndpoint, createEndpoint, activeUrl, invalidateEndpointCache,
  activeToken, maskSecret, cleanSecret,
} from '../integrations.js';
import { sendPayload, isSuccess, crmStatus, buildPayload } from '../crmSync.js';
import { fetchProducts, buildProduct, buildLote, mxNowParts } from '../productSync.js';
import { testPayload as orderTestPayload, sweepOrderStatus, orderStatusReady, CRM_ORDER_STEPS, CRM_FINAL_STEPS,
  previewOrderStatus, endpointState as orderEndpointState } from '../orderStatusSync.js';   // 0227
import { inboundCounts } from '../crmInboundLog.js';
import { promoReady, buildPromoPayload, PROMO_COLS, PROMO_CATEGORY, promoCode } from '../promoSync.js';   // 0237

const ERR_NOTE = {
  env_invalid: '환경은 test 또는 prod 만 됩니다.',
  method_invalid: '메서드는 POST · PUT · PATCH · DELETE · GET 중 하나여야 합니다.',
  user_field_invalid: 'transactionUser 필드는 login_id · name · role 중 하나여야 합니다.',
  timeout_invalid: '타임아웃은 1000~60000ms 범위여야 합니다.',
  url_invalid: 'URL 은 http:// 또는 https:// 로 시작해야 합니다.',
  url_prod_required: '운영으로 전환하려면 운영 URL 을 먼저 입력하세요.',
  url_space: '주소에 공백이 섞여 있습니다 — 붙여넣을 때 뒷줄(예: Content-Type: …)이 같이 딸려온 것 같습니다. 주소만 남기세요.',
  key_invalid: '연동 키는 영문 소문자·숫자·밑줄 3~40자입니다.',
  key_taken: '이미 같은 키의 연동이 있습니다.',
  fallback_self: '자기 자신을 대체 창구로 지정할 수 없습니다 — 같은 실패가 끝없이 반복됩니다.',
  auth_from_self: '자기 자신에게서 키를 물려받을 수는 없습니다.',
  batch_size_invalid: '묶음 크기는 10~2000 사이여야 합니다.',
  send_hour_invalid: '자동 전송 시각은 0~23 사이여야 합니다.',
  delta_every_invalid: '변경분 확인 주기는 5~1440분 사이여야 합니다.',
  full_weekday_invalid: '전체 전송 요일이 올바르지 않습니다.',
  img_base_invalid: '사진 기본주소는 http:// 또는 https:// 로 시작해야 합니다.',
  img_base_space: '사진 기본주소에 공백이 섞여 있습니다 — 주소만 남기세요.',
  no_products: '보낼 제품이 없습니다 — 제품 마스터를 먼저 확인하세요.',
  body_shape_invalid: '본문 형식은 묶음 · 제품 배열 · 1건씩 중 하나여야 합니다.',
  field_map_invalid: '필드 이름 매핑이 올바른 형태가 아닙니다.',
  banner_size_invalid: '배너 규격은 10~5000 px 정수입니다(비우면 검사하지 않음).',
  field_map_name_invalid: '보낼 필드 이름에 쓸 수 없는 문자가 있습니다(영문·숫자·_ . - 만).',
};

export default async function integrationRoutes(app) {
  const guard = { preHandler: [authGuard, requireDirector] };

  async function ready(reply) {
    if (await endpointsReady()) return true;
    reply.code(503).send({ error: 'migration_required', note: '0201_integration_endpoints 마이그레이션이 필요합니다.' });
    return false;
  }

  // 목록 — 카테고리별 정리 + 연동별 전송 집계
  app.get('/api/integrations', guard, async () => {
    const eps = (await listEndpoints()).map(publicEndpoint);
    let counts = {};
    try {
      const rows = (await query(
        `SELECT COALESCE(endpoint_key,'customer_commercial') AS k, status, count(*)::int AS n
           FROM crm_customer_outbox GROUP BY 1,2`)).rows;
      for (const r of rows) {
        counts[r.k] = counts[r.k] || { pending: 0, sent: 0, failed: 0, skipped: 0 };
        counts[r.k][r.status] = Number(r.n);
      }
    } catch (_) { counts = {}; }
    // 수신 연동은 아웃박스가 아니라 수신 이력으로 센다(created·updated=성공, rejected=거절).
    //   ⚠ **창구별로** 센다. 예전에는 전체를 세어 모든 수신 연동에 같은 숫자를 붙였다.
    const inb = await inboundCounts();
    const inboundFor = (key) => {
      const c = inb[key] || { created: 0, updated: 0, rejected: 0 };
      return { pending: 0, sent: Number(c.created) + Number(c.updated), failed: Number(c.rejected), skipped: 0 };
    };
    return {
      migrated: await endpointsReady(),
      engine: crmStatus(),
      items: eps.map((e) => ({ ...e,
        counts: e.direction === 'in' ? inboundFor(e.key)
          : (counts[e.key] || { pending: 0, sent: 0, failed: 0, skipped: 0 }) })),
    };
  });

  // 단건(계약서 포함) + 설정 변경 이력
  app.get('/api/integrations/:key', guard, async (req, reply) => {
    const ep = await getEndpoint(req.params.key);
    if (!ep) return reply.code(404).send({ error: 'not_found' });
    let changes = [];
    try {
      changes = (await query(
        `SELECT c.changes, c.changed_at, u.name AS changed_by_name
           FROM integration_endpoint_changes c
           LEFT JOIN integration_endpoints e ON e.id=c.endpoint_id
           LEFT JOIN users u ON u.id=c.changed_by
          WHERE e.key=$1 ORDER BY c.changed_at DESC LIMIT 30`, [req.params.key])).rows;
    } catch (_) { changes = []; }
    return { endpoint: publicEndpoint(ep), changes };
  });

  // 설정·계약서 저장
  app.put('/api/integrations/:key', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const r = await saveEndpoint(req.params.key, req.body || {}, req.ctx.perm.userId);
    if (r.error) return reply.code(r.error === 'not_found' ? 404 : 400).send({ error: r.error, note: ERR_NOTE[r.error] || null });
    const ep = await getEndpoint(req.params.key);
    return { ok: true, unchanged: !!r.unchanged, changes: r.changes || {}, endpoint: publicEndpoint(ep) };
  });

  // 새 연동 등록(예: 제품 외 추가 계약)
  app.post('/api/integrations', guard, async (req, reply) => {
    if (!(await ready(reply))) return;
    const r = await createEndpoint(req.body || {}, req.ctx.perm.userId);
    if (r.error) return reply.code(400).send({ error: r.error, note: r.note || ERR_NOTE[r.error] || null });
    return { ok: true, endpoint: publicEndpoint({ ...r.endpoint, source: 'db' }) };
  });

  /**
   * 연결 테스트 — 지금 저장된 설정 그대로 1건 쏘고 요청·응답 원문을 돌려준다.
   *   아웃박스에 남기지 않는다(이력을 시험 건으로 더럽히지 않기 위해).
   *   body: { op?: 'upsert'|'delete', customer_id?, payload? }
   *     customer_id 를 주면 그 고객의 실제 값으로, 없으면 계약서의 요청 예시로 보낸다.
   */
  app.post('/api/integrations/:key/test', guard, async (req, reply) => {
    const ep = await getEndpoint(req.params.key);
    if (!ep) return reply.code(404).send({ error: 'not_found' });
    // 0208 · 수신 연동은 우리가 쏘는 게 아니라 **상대가 우리에게 쏜다**. 시험 전송할 대상이 없다.
    if (ep.direction === 'in') {
      return reply.code(400).send({ error: 'inbound_endpoint',
        note: '이 연동은 수신용입니다 — 상대(CRM)가 우리 주소로 보냅니다. '
            + '키를 발급해 상대에게 주고, 결과는 「수신 이력」에서 확인하세요.' });
    }
    if (!activeUrl(ep)) {
      return reply.code(400).send({ error: 'url_missing', note: (ep.env === 'prod' ? '운영' : '테스트') + ' URL 이 비어 있습니다.' });
    }
    const b = req.body || {};
    const op = b.op === 'delete' ? 'delete' : 'upsert';
    let payload = b.payload;
    let usedCustomer = null;
    let usedProduct = null;
    let usedQuote = null;

    // 0227 · 오더상태 창구는 **가장 최근 웹(COT) 견적의 지금 단계**로 시험한다.
    //   고객 본문을 오더 주소로 보내면 상대는 무엇을 받았는지 알 수 없다(제품 창구와 같은 이유).
    //   실제 전송과 **같은 함수**로 만든다. 웹 견적이 하나도 없으면 계약서의 요청 예시로 보낸다.
    if (!payload && ep.category === 'order') {
      const u = (await query(`SELECT login_id, name, role FROM users WHERE id=$1`, [req.ctx.perm.userId])).rows[0] || {};
      const f = ['login_id', 'name', 'role'].includes(ep.user_field) ? ep.user_field : 'login_id';
      const t = await orderTestPayload(String(u[f] || 'erp'));
      if (t) { payload = t.payload; usedQuote = t.quote; }
    }

    // 0237 · 프로모션 창구는 **가장 최근 프로모션**(전송된 것 우선)으로 시험한다 — 실제 전송과 같은 함수.
    //   ⚠ CRM 에 실제로 등록된다(시험이라고 표시할 칸이 계약에 없다). 그래서 버전은 올리지 않고
    //     지금 버전 그대로 보낸다 — CRM 이 version 으로 거르면 정식 전송이 이 시험을 덮어쓴다.
    if (!payload && ep.category === PROMO_CATEGORY && await promoReady()) {
      const p = (await query(
        `SELECT ${PROMO_COLS} FROM crm_promotions p
          WHERE p.deleted_at IS NULL AND p.image_sha IS NOT NULL
          ORDER BY (p.status='published') DESC, p.id DESC LIMIT 1`)).rows[0];
      if (p) {
        const u = (await query(`SELECT login_id, name, role FROM users WHERE id=$1`, [req.ctx.perm.userId])).rows[0] || {};
        const f = ['login_id', 'name', 'role'].includes(ep.user_field) ? ep.user_field : 'login_id';
        payload = buildPromoPayload(p, { op, user: String(u[f] || 'erp'), map: ep.field_map || null });
        usedProduct = { codigo: promoCode(p.id), descripcion: p.title };
      }
    }

    // 0218 · 제품 창구는 **고객 본문을 절대 보내지 않는다.**
    //   예전에는 화면에 「시험 전송할 고객」 칸이 그대로 보였고, 거기에 값이 있으면
    //   고객 본문(rfc·discountPercent…)이 제품 주소로 나갔다 — 상대는 우리가 무엇을
    //   보내는지 알 수 없게 된다. 제품 창구는 **진짜 제품 1건**으로 시험한다.
    //   ⚠ 시험 전송에는 마감 신호를 싣지 않는다(esUltimoLote=false) —
    //     한 건 보낸 뒤 마감하면 CRM 이 나머지 전 제품을 감춘다.
    if (!payload && ep.category === 'product') {
      const code = String(b.code || '').trim();
      const rows = code ? await fetchProducts({ code }) : await fetchProducts({ limit: 1 });
      if (!rows.length) {
        return reply.code(400).send({ error: 'no_products',
          note: code ? `제품 ${code} 을(를) 찾지 못했습니다.` : '보낼 제품이 없습니다.' });
      }
      const u = (await query(`SELECT login_id, name, role FROM users WHERE id=$1`, [req.ctx.perm.userId])).rows[0] || {};
      const f = ['login_id', 'name', 'role'].includes(ep.user_field) ? ep.user_field : 'login_id';
      const productos = rows.map((r) => buildProduct(r, ep.img_base_url || ''));
      const { ymd, stamp } = mxNowParts();
      // ⚠ 실제 전송과 **같은 함수·같은 설정**으로 만든다(매핑·본문 형식 포함) —
      //   시험만 다른 모양이면 "테스트는 되는데 실전은 안 되는" 상황이 생긴다.
      payload = buildLote({
        envioId: `TEST-${stamp}`, fechaCorte: ymd, lote: 1, totalLotes: 1,
        totalProductos: productos.length, transactionUser: String(u[f] || 'erp'), mode: 'test',
      }, productos, { map: ep.field_map || {}, shape: ep.body_shape || 'lote' });
      usedProduct = { codigo: productos[0].codigo, descripcion: productos[0].descripcion };
    }

    // 테스트에 쓸 고객: id 로 지정하거나, 코드·상호·RFC 로 찾는다.
    //   아무것도 안 주면 고객 연동에 한해 **가장 최근 승인된 RFC 보유 고객**을 자동으로 고른다.
    //   (매번 예시 JSON 을 손으로 채우게 하지 않기 위해서다. 실제 값으로 시험하는 편이 계약 검증에도 낫다)
    if (!payload && ep.category !== 'order' && ep.category !== PROMO_CATEGORY
        && (ep.category === 'customer' || b.customer_id || b.customer_query)) {
      let c = null;
      if (b.customer_id) {
        c = (await query(
          `SELECT id, code, name, rfc, discount, credit_days,
                  COALESCE(approval_status,'approved') AS approval_status
             FROM customers WHERE id=$1`, [Number(b.customer_id)])).rows[0];
        if (!c) return reply.code(404).send({ error: 'customer_not_found' });
      } else if (String(b.customer_query || '').trim()) {
        const q = `%${String(b.customer_query).trim()}%`;
        c = (await query(
          `SELECT id, code, name, rfc, discount, credit_days,
                  COALESCE(approval_status,'approved') AS approval_status
             FROM customers
            WHERE deleted_at IS NULL AND (code ILIKE $1 OR name ILIKE $1 OR rfc ILIKE $1)
            ORDER BY (rfc IS NULL), id DESC LIMIT 1`, [q])).rows[0];
        if (!c) return reply.code(404).send({ error: 'customer_not_found', note: '그 조건으로 고객을 찾지 못했습니다.' });
      } else {
        c = (await query(
          `SELECT id, code, name, rfc, discount, credit_days,
                  COALESCE(approval_status,'approved') AS approval_status
             FROM customers
            WHERE deleted_at IS NULL AND rfc IS NOT NULL AND btrim(rfc) <> ''
              AND COALESCE(approval_status,'approved')='approved'
            ORDER BY id DESC LIMIT 1`)).rows[0];
      }
      if (c) {
        if (!String(c.rfc || '').trim()) {
          return reply.code(400).send({ error: 'rfc_missing', note: `${c.code || ''} ${c.name || ''} 은(는) RFC 가 없어 시험 전송할 수 없습니다.` });
        }
        const u = (await query(`SELECT login_id, name, role FROM users WHERE id=$1`, [req.ctx.perm.userId])).rows[0] || {};
        const f = ['login_id', 'name', 'role'].includes(ep.user_field) ? ep.user_field : 'login_id';
        // ⚠ 본문은 **실제 전송과 같은 함수**로 만든다. 예전에는 여기서 따로 조립했는데,
        //   그러면 계약이 바뀔 때(예: estatus 추가) 시험 전송만 옛 본문을 보내
        //   "테스트는 되는데 실전은 안 되는" 상황이 생긴다.
        payload = buildPayload(op, c, String(u[f] || 'erp'));
        usedCustomer = { id: Number(c.id), code: c.code, name: c.name };
      }
    }

    // 고객 연동이 아니거나(제품 등) 고객을 못 고른 경우 → 계약서의 요청 예시로 보낸다.
    if (!payload) {
      const sample = (ep.contract && ep.contract.sample_request) || '';
      try { payload = sample ? JSON.parse(sample) : null; } catch (_) {
        return reply.code(400).send({ error: 'sample_invalid', note: '계약서의 「요청 예시」가 올바른 JSON 이 아닙니다.' });
      }
      if (!payload) {
        return reply.code(400).send({ error: 'payload_required',
          note: '보낼 본문이 없습니다. 테스트할 고객을 입력하거나, 계약서 탭의 「요청 예시」를 채우세요(필드표가 있으면 「필드표로 예시 만들기」로 자동 생성됩니다).' });
      }
    }

    const r = await sendPayload(ep, op, payload);
    const ok = !r.error && isSuccess(r.httpStatus, r.body, ep.ok_code);
    // ⚠ 「인증 헤더 포함」 이라고만 하면 401 이 났을 때 **아무것도 알 수 없다.**
    //   상대가 「API key es requerida」 라고 답하는데 화면은 「키 있음」 이면
    //   어디가 틀렸는지 볼 방법이 없다. 그래서 **실제로 실어 보낸 것**을 그대로 보여 준다:
    //   어디에(헤더/쿼리/본문) · 무슨 이름으로 · 어떤 값인지(앞뒤 4글자만).
    const tok = activeToken(ep);
    const where = ['header', 'query', 'body'].includes(ep.auth_in) ? ep.auth_in : 'header';
    const auth = {
      sent: !!tok,
      where,
      name: where === 'header' ? (ep.auth_header || 'Authorization') : (ep.auth_param || 'apiKey'),
      hint: maskSecret(tok),
      borrowed_from: ep.token_borrowed_label || ep.token_borrowed_from || null,
      suspect: tok ? cleanSecret(tok, [ep.auth_header, ep.auth_param]).notes : [],
    };
    return {
      ok,
      request: { method: r.method, url: r.url, env: ep.env, payload, auth, customer: usedCustomer, product: usedProduct, quote: usedQuote },
      response: r.error ? { error: r.error } : { http_status: r.httpStatus, body: r.body, ms: r.ms },
      verdict: ok ? 'CRM 이 성공(codigoError=' + (ep.ok_code) + ')으로 응답했습니다.'
        : (r.error ? '연결하지 못했습니다: ' + r.error
          : 'CRM 이 성공코드를 주지 않았습니다 — 계약서의 오류코드 표와 대조하세요.'),
    };
  });

  // ===== 0227 · 오더상태 (전송) — 현황 · 지금 따라잡기 · 견적 1건 확인 =====
  //   현황: 웹(COT) 견적이 CRM 에 **어느 단계까지 알려졌는지** 단계별로 센다.
  app.get('/api/order-status/overview', guard, async (req, reply) => {
    if (!(await orderStatusReady())) {
      return reply.code(503).send({ error: 'migration_required', note: 'npm run migrate (0227) 를 먼저 실행하세요.' });
    }
    const st = await orderEndpointState();
    const byTop = (await query(
      `SELECT COALESCE(e.top,0) AS top, COUNT(*)::int AS n
         FROM quotes q
         LEFT JOIN (SELECT quote_id, MAX(seq) AS top FROM crm_order_status_events GROUP BY quote_id) e
                ON e.quote_id = q.id
        WHERE q.external_quote_no IS NOT NULL
          AND q.created_at >= now() - INTERVAL '120 days'
          AND (q.deleted_at IS NULL OR COALESCE(e.top,0) = 9)   -- 0296 · 삭제된 견적은 eliminado 를 보낸 것만 센다
        GROUP BY COALESCE(e.top,0)`)).rows;
    const recent = (await query(
      `SELECT e.quote_id, e.seq, e.status, e.event_at, e.origin, e.created_at, e.outbox_id,
              q.quote_no, q.external_quote_no, c.name AS customer_name,
              o.status AS send_status, o.http_status, o.last_error
         FROM crm_order_status_events e
         JOIN quotes q ON q.id = e.quote_id
         LEFT JOIN customers c ON c.id = q.customer_id
         LEFT JOIN crm_customer_outbox o ON o.id = e.outbox_id
        ORDER BY e.created_at DESC, e.seq DESC
        LIMIT 30`)).rows;
    const counts = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 8: 0, 9: 0 };
    for (const r of byTop) counts[Number(r.top)] = Number(r.n);
    return {
      ready: st.ok, reason: st.ok ? null : st.reason,
      steps: [...CRM_ORDER_STEPS, ...CRM_FINAL_STEPS],   // 0296 · 8 expirado · 9 eliminado(끝 상태)
      counts,
      recent: recent.map((r) => ({
        quote_id: Number(r.quote_id), seq: Number(r.seq), status: r.status,
        event_at: r.event_at, origin: r.origin, created_at: r.created_at,
        outbox_id: r.outbox_id == null ? null : Number(r.outbox_id),
        quote_no: r.quote_no, external_quote_no: r.external_quote_no, customer_name: r.customer_name,
        send_status: r.send_status || null, http_status: r.http_status == null ? null : Number(r.http_status),
        last_error: r.last_error || null,
      })),
    };
  });

  //   지금 따라잡기: 90초 감시를 기다리지 않고 바로 한 번 돌린다(연동을 막 켰을 때).
  app.post('/api/order-status/sweep', guard, async (req, reply) => {
    const st = await orderEndpointState();
    if (!st.ok) {
      return reply.code(409).send({ error: st.reason,
        note: st.reason === 'endpoint_disabled' ? '오더상태 (전송)이 꺼져 있습니다 — 사용 여부를 켜고 저장한 뒤 누르세요.'
          : (st.reason === 'url_missing' ? '지금 환경의 URL 이 비어 있습니다.' : '오더상태 창구를 찾을 수 없습니다(0227 미적용).') });
    }
    const r = await sweepOrderStatus({ app });
    return { ok: true, ...r };
  });

  //   견적 1건 확인: 이 견적이 지금 CRM 에 무엇으로 보여야 하는지 + 이미 보낸 단계(보내지 않는다).
  app.get('/api/order-status/quote', guard, async (req, reply) => {
    const qno = String(req.query.q || '').trim();
    if (!qno) return reply.code(400).send({ error: 'q_required' });
    const row = (await query(
      `SELECT id FROM quotes WHERE (quote_no=$1 OR external_quote_no=$1)
        ORDER BY (deleted_at IS NULL) DESC, id DESC LIMIT 1`, [qno])).rows[0];   // 0296 · 삭제 승인된 견적도 확인(eliminado)
    if (!row) return reply.code(404).send({ error: 'not_found', note: `견적 ${qno} 을(를) 찾지 못했습니다.` });
    return { ok: true, ...(await previewOrderStatus(row.id)) };
  });

  // 캐시 즉시 반영(설정을 바꾸고 바로 시험할 때)
  app.post('/api/integrations/:key/refresh', guard, async (req) => {
    invalidateEndpointCache(req.params.key);
    const ep = await getEndpoint(req.params.key);
    return { ok: true, endpoint: publicEndpoint(ep) };
  });
}
