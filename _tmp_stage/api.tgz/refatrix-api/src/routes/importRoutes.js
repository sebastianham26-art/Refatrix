import { query, withTx } from '../db.js';
import { authGuard, requirePage, requireDirector } from '../middleware/authGuard.js';
import { computeImportCosting } from '../cost.js';
import { logEvent } from '../audit.js';
import { fieldVisible, flatAvgCostEnabled } from '../permissions.js';
import { flatAvgCost } from '../flatAvgCost.js';
import { consumeBackorder } from '../poBackorder.js';
import { resolveBatchReceipt } from '../shortageReceipt.js';   // 0277 · 입고 시 부족분 해소
import { generateOfferSheets } from '../offerSheets.js';

export default async function importRoutes(app) {
  // 수입 입고 작성(영업지원). 라인(SKU별) + 부대비용(명목·인보이스별).
  // 작성 시점에는 재고/평균원가에 영향 없음(status=pending).
  app.post('/api/imports', { preHandler: [authGuard, requirePage('inventory')] }, async (req, reply) => {
    const { batch_no, import_date, currency = 'USD', fx_rate, lines = [], overheads = [], note, inbound_shipment_id } = req.body || {};
    if (!import_date || !fx_rate || !lines.length) {
      return reply.code(400).send({ error: 'import_date_fx_lines_required' });
    }
    const userId = req.ctx.perm.userId;
    const shipId = inbound_shipment_id ? Number(inbound_shipment_id) : null;
    // 선적 연결(0178) — 같은 선적으로 배치를 이중 등록하지 않게 막는다(반려된 배치는 제외)
    if (shipId) {
      const dup = (await query(
        `SELECT id FROM import_batches
          WHERE inbound_shipment_id=$1 AND deleted_at IS NULL AND status <> 'rejected'`, [shipId])).rows[0];
      if (dup) return reply.code(409).send({ error: 'shipment_already_costed', batch_id: Number(dup.id) });
    }
    const result = await withTx(async (c) => {
      const b = (await c.query(
        `INSERT INTO import_batches (batch_no, import_date, currency, fx_rate, status, created_by, note, inbound_shipment_id)
         VALUES ($1,$2,$3,$4,'pending',$5,$6,$7) RETURNING id`,
        [batch_no, import_date, currency, fx_rate, userId, note, shipId])).rows[0];
      for (const l of lines) {
        await c.query(
          `INSERT INTO import_lines (batch_id, product_id, qty, import_price, currency, invoice_no, po_ref)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [b.id, l.product_id, l.qty, l.import_price, l.currency || currency, l.invoice_no || null,
           l.po_ref ? String(l.po_ref).trim() : null]);   // 구매 참조번호(오더번호, 0179)
      }
      for (const o of overheads) {
        await c.query(
          `INSERT INTO import_overheads (batch_id, label, amount, currency, invoice_no)
           VALUES ($1,$2,$3,$4,$5)`, [b.id, o.label, o.amount, o.currency || currency, o.invoice_no || null]);
      }
      return b.id;
    });
    await logEvent({ userId, deviceId: req.ctx.deviceId, action: 'create', target: `import_batch:${result}` });
    const skuCount = new Set(lines.map((l) => l.product_id)).size;
    const totalQty = lines.reduce((s, l) => s + (Number(l.qty) || 0), 0);
    const fx = Number(fx_rate) || 1;
    const baseCur = lines.reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.import_price) || 0), 0);
    const ohMxn = (overheads || []).reduce((s, o) => s + ((o.currency === 'USD' ? Number(o.amount || 0) * fx : Number(o.amount || 0))), 0);
    const stockValueMxn = Math.round((baseCur * (currency === 'USD' ? fx : 1) + ohMxn) * 100) / 100;
    const seeCost = fieldVisible(req.ctx.perm, 'unit_cost');
    return { id: result, status: 'pending', sku_count: skuCount, total_qty: totalQty, stock_value_mxn: seeCost ? stockValueMxn : null };
  });

  // ===== 입고 선적에서 불러오기(0178, 2026-08-18) =====
  // "수입원가 등록 때 분배 대상(입고한 인보이스)을 보여주고 선택" — 디렉터 요구 절차.
  // ① 목록: 마감(입고 반영)된 선적 + 배치 등록 여부
  app.get('/api/imports/from-inbound', { preHandler: [authGuard, requirePage('inventory')] }, async () => {
    // 진행 중(마감 전) 선적도 함께 내려준다(ready=false) — "지금 입고하는 선적이 목록에 안 보인다"
    // 는 혼선 방지: 화면에 보이되 선택은 마감 후에만 가능하게(2026-08-18 저녁).
    const rows = (await query(
      `SELECT s.id, s.invoice_no, s.eta, s.closed_at, s.status,
              COUNT(DISTINCT pl.id) FILTER (WHERE pl.received_at IS NOT NULL)::int AS received_pallets,
              COUNT(DISTINCT pl.id)::int AS pallet_count,
              COUNT(DISTINCT pi.product_id) FILTER (WHERE pi.product_id IS NOT NULL AND pl.received_at IS NOT NULL)::int AS sku_count,
              COALESCE(SUM(CASE WHEN pl.received_at IS NOT NULL AND pi.product_id IS NOT NULL THEN
                (CASE WHEN pi.cartons > 0 THEN ROUND(pi.qty / pi.cartons) * pi.scanned_cartons ELSE pi.qty END)
                ELSE 0 END),0) AS measured_qty,
              COALESCE(SUM(CASE WHEN pi.product_id IS NOT NULL THEN pi.qty ELSE 0 END),0) AS expected_qty,
              (SELECT b.id FROM import_batches b
                WHERE b.inbound_shipment_id = s.id AND b.deleted_at IS NULL AND b.status <> 'rejected'
                ORDER BY b.id DESC LIMIT 1) AS batch_id,
              (SELECT b.status FROM import_batches b
                WHERE b.inbound_shipment_id = s.id AND b.deleted_at IS NULL AND b.status <> 'rejected'
                ORDER BY b.id DESC LIMIT 1) AS batch_status
         FROM inbound_shipments s
         LEFT JOIN inbound_pallets pl ON pl.shipment_id = s.id
         LEFT JOIN inbound_pallet_items pi ON pi.pallet_id = pl.id
        WHERE s.deleted_at IS NULL AND s.status <> 'cancelled'
        GROUP BY s.id
        HAVING COUNT(pl.id) > 0
        ORDER BY (CASE WHEN COUNT(DISTINCT pl.id) FILTER (WHERE pl.received_at IS NOT NULL) > 0 THEN 0 ELSE 1 END),
                 s.closed_at DESC NULLS LAST, s.id DESC
        LIMIT 30`)).rows;
    return {
      items: rows.map((r) => ({
        id: Number(r.id), invoice_no: r.invoice_no, eta: r.eta, closed_at: r.closed_at, status: r.status,
        ready: Number(r.received_pallets) > 0,                 // 마감(입고 반영)된 팔렛이 있어야 배치 생성 가능
        sku_count: r.sku_count, measured_qty: Number(r.measured_qty),
        expected_qty: Number(r.expected_qty),
        batch_id: r.batch_id ? Number(r.batch_id) : null, batch_status: r.batch_status || null,
      })),
    };
  });
  // ② 라인 프리필: 선적의 실측 수량(SKU별) + 구매 단가 제안(그 제품의 최근 발주가)
  app.get('/api/imports/from-inbound/:sid', { preHandler: [authGuard, requirePage('inventory')] }, async (req, reply) => {
    const sid = Number(req.params.sid);
    const s = (await query(`SELECT id, invoice_no FROM inbound_shipments WHERE id=$1 AND deleted_at IS NULL`, [sid])).rows[0];
    if (!s) return reply.code(404).send({ error: 'not_found' });
    // (오더번호 × SKU) 단위 라인(0179, 2026-08-19):
    //   같은 SKU가 여러 발주(참조번호)에 걸쳐 있으면 합치지 않고 오더별로 분리한다.
    //   단가 제안도 "그 오더(ref_no = 팔렛 order_no)의 발주 라인" 우선 → 없으면 다른 발주 폴백.
    //   (기존: SKU만 맞으면 최근 발주 아무거나 → CE0536L 사례처럼 엉뚱한 단가가 붙던 문제)
    const rows = (await query(
      `SELECT pi.product_id, pr.code, pr.name, pl.order_no,
              SUM(CASE WHEN pi.cartons > 0 THEN ROUND(pi.qty / pi.cartons) * pi.scanned_cartons ELSE pi.qty END) AS qty,
              po.unit_cost_usd AS po_price, po.ref_no AS po_ref, po.ref_match
         FROM inbound_pallets pl
         JOIN inbound_pallet_items pi ON pi.pallet_id = pl.id
         JOIN products pr ON pr.id = pi.product_id
         LEFT JOIN LATERAL (
           -- 단가 제안 우선순위: ① 참조번호(ref_no)=이 팔렛의 order_no 인 발주의 라인
           --                    ② 제품 연결된 발주 라인 ③ 미매칭 라인(product_id NULL)은 제품코드로
           SELECT l.unit_cost_usd, p.ref_no,
                  (UPPER(REGEXP_REPLACE(p.ref_no,'[^A-Za-z0-9]','','g'))
                     = UPPER(REGEXP_REPLACE(pl.order_no,'[^A-Za-z0-9]','','g'))) AS ref_match
             FROM purchase_order_lines l JOIN purchase_orders p ON p.id = l.po_id
            WHERE (l.product_id = pi.product_id
                   OR (l.product_id IS NULL
                       AND UPPER(REGEXP_REPLACE(l.input_code,'[^A-Za-z0-9]','','g'))
                         = UPPER(REGEXP_REPLACE(pr.code,'[^A-Za-z0-9]','','g'))))
              AND p.deleted_at IS NULL AND p.status <> 'cancelled'
            ORDER BY (UPPER(REGEXP_REPLACE(p.ref_no,'[^A-Za-z0-9]','','g'))
                        = UPPER(REGEXP_REPLACE(pl.order_no,'[^A-Za-z0-9]','','g'))) DESC,
                     (l.product_id IS NOT NULL) DESC, p.order_date DESC, l.id DESC LIMIT 1
         ) po ON true
        WHERE pl.shipment_id=$1 AND pl.received_at IS NOT NULL AND pi.product_id IS NOT NULL
        GROUP BY pi.product_id, pr.code, pr.name, pl.order_no, po.unit_cost_usd, po.ref_no, po.ref_match
        ORDER BY pr.code, pl.order_no`, [sid])).rows;
    const seeCost = fieldVisible(req.ctx.perm, 'unit_cost');
    return {
      shipment: { id: Number(s.id), invoice_no: s.invoice_no },
      lines: rows.filter((r) => Number(r.qty) > 0).map((r) => ({
        product_id: Number(r.product_id), code: r.code, name: r.name,
        qty: Number(r.qty),
        order_no: r.order_no || null,                                          // 이 라인의 참조번호(오더번호)
        po_price: seeCost && r.po_price != null ? Number(r.po_price) : null,   // 제안가(수정 가능)
        po_ref: r.po_ref || null,
        po_ref_match: r.ref_match === true,                                    // 제안가가 같은 참조번호 발주에서 왔는지
      })),
    };
  });

  // 미리보기: 승인 시 적용될 단위원가·평균원가를 계산해서 보여줌(반영 없음)
  app.get('/api/imports/:id/preview', { preHandler: [authGuard, requirePage('inventory')] }, async (req) => {
    const r = await computeBatch(Number(req.params.id));
    // 원가 권한 없는 직원에겐 단위원가/부대비용/평균원가 필드를 제거(데이터 자체를 안 보냄)
    if (r && Array.isArray(r.preview) && !fieldVisible(req.ctx.perm, 'unit_cost')) {
      r.preview = r.preview.map((cl) => ({ product_id: cl.product_id, qty: cl.qty, po_ref: cl.po_ref || null }));
    }
    return r;
  });

  // 디렉터 승인 → 이동평균 갱신, 재고 증가, 원장 기록 (트랜잭션)
  app.post('/api/imports/:id/approve', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const userId = req.ctx.perm.userId;

    const out = await withTx(async (c) => {
      const batch = (await c.query(`SELECT * FROM import_batches WHERE id=$1`, [id])).rows[0];
      if (!batch || batch.status !== 'pending') return { error: 'not_pending' };

      const lines = (await c.query(`SELECT * FROM import_lines WHERE batch_id=$1`, [id])).rows;
      const overheads = (await c.query(`SELECT * FROM import_overheads WHERE batch_id=$1`, [id])).rows;

      // 관련 제품 현재 상태 잠금(FOR UPDATE)
      const pids = [...new Set(lines.map((l) => l.product_id))];
      const ps = (await c.query(
        `SELECT id, stock_qty, avg_cost FROM products WHERE id = ANY($1) FOR UPDATE`, [pids])).rows;
      const productState = {};
      for (const p of ps) productState[p.id] = { stock_qty: p.stock_qty, avg_cost: p.avg_cost };

      const { computedLines, newState } = computeImportCosting({
        lines, overheads, fxRate: batch.fx_rate, productState, batchCurrency: batch.currency,
      });

      // 라인 원가 스냅샷 기록
      const evNo = Number((await c.query(`SELECT nextval('stock_event_seq') AS n`)).rows[0].n);
      // 참조(referencia): 라인별 매입 인보이스 번호 → 없으면 batch_no → 없으면 batch:#
      const invByProduct = {};
      for (const l of lines) { if (l.invoice_no && String(l.invoice_no).trim()) invByProduct[l.product_id] = String(l.invoice_no).trim(); }
      const refFallback = (batch.batch_no && String(batch.batch_no).trim()) ? String(batch.batch_no).trim() : `batch:${id}`;
      for (const cl of computedLines) {
        // 같은 제품이 여러 라인(오더번호별, 0179)일 수 있으므로 라인 id 로 정확히 갱신
        if (cl.line_id != null) {
          await c.query(
            `UPDATE import_lines SET alloc_overhead=$1, unit_cost_mxn=$2, avg_cost_after=$3 WHERE id=$4`,
            [cl.alloc_overhead, cl.unit_cost_mxn, cl.avg_cost_after, cl.line_id]);
        } else {
          await c.query(
            `UPDATE import_lines SET alloc_overhead=$1, unit_cost_mxn=$2, avg_cost_after=$3
               WHERE batch_id=$4 AND product_id=$5`,
            [cl.alloc_overhead, cl.unit_cost_mxn, cl.avg_cost_after, id, cl.product_id]);
        }
        // 입출고 원장(입고) — 배치 전체가 하나의 이벤트. 날짜는 지정한 import_date(재고 등재일), 참조는 인보이스 번호.
        await c.query(
          `INSERT INTO stock_movements (product_id, move_type, qty, unit_cost_mxn, ref, batch_id, event_no, moved_at, created_by)
           VALUES ($1,'in',$2,$3,$4,$5,$6,$7,$8)`,
          [cl.product_id, cl.qty, cl.unit_cost_mxn, invByProduct[cl.product_id] || refFallback, id, evNo, batch.import_date, userId]);
      }
      // 창고 마감 선반영분 차감(0176, 2026-08-18) — 창고 마감이 이미 stock_qty 에 올린 수량은
      //   여기서 다시 더하지 않는다(재고 이중 증가 방지). 원가/평균원가/원장은 그대로 기록.
      const preOff = {};
      for (const cl of computedLines) {
        const pre = (await c.query(`SELECT qty FROM inbound_prestock WHERE product_id=$1 FOR UPDATE`, [cl.product_id])).rows[0];
        const avail = pre ? Number(pre.qty) : 0;
        const off = Math.min(avail, Math.abs(Number(cl.qty) || 0));
        if (off > 0) {
          preOff[Number(cl.product_id)] = (preOff[Number(cl.product_id)] || 0) + off;
          await c.query(`UPDATE inbound_prestock SET qty = qty - $1, updated_at = now() WHERE product_id=$2`, [off, cl.product_id]);
        }
      }
      // 승인 확정을 평균원가 계산보다 먼저 기록(2026-08-19):
      //   flatAvgCost 가 이제 status='approved' 배치만 집계하므로, 이 배치를 포함시키려면
      //   같은 트랜잭션 안에서 먼저 approved 로 바꿔야 한다.
      await c.query(
        `UPDATE import_batches SET status='approved', approved_by=$1, approved_at=now() WHERE id=$2`,
        [userId, id]);
      // 제품 재고·평균원가 갱신
      //   기본(단순가중평균 모드): 평균원가 = 승인 반영된 배치들의 Σ(수량×입고단가)÷Σ수량.
      //   이동평균 모드(MOVING_AVG_COST=1): 기존 newState.avg_cost(이동평균) 사용.
      let flatAvg = {};
      if (flatAvgCostEnabled()) {
        flatAvg = await flatAvgCost(c, pids);  // 방금 승인한 배치의 라인이 포함됨(위에서 approved 처리)
      }
      for (const [pid, st] of Object.entries(newState)) {
        const avg = (flatAvg[Number(pid)] != null) ? flatAvg[Number(pid)] : st.avg_cost;
        const stockFinal = Number(st.stock_qty) - (preOff[Number(pid)] || 0);   // 선반영분 제외
        await c.query(
          `UPDATE products SET stock_qty=$1, avg_cost=$2, updated_by=$3 WHERE id=$4`,
          [stockFinal, avg, userId, pid]);
      }
      // 발주(backorder) 소진 — 입고(재고 등재)된 수량만큼 해당 SKU의 열린 구매라인
      //   received_qty 를 선입선출로 채움 → v_backorder 잔량이 실입고와 연동돼 줄어듦.
      //   구매기록이 없는 SKU 는 그대로 통과(재고·원가 영향 없음).
      const cqb = c.query.bind(c);
      let boConsumed = 0;
      for (const cl of computedLines) {
        // 선반영분(창고 마감)은 이미 그 발주의 received_qty 를 채웠으므로 그만큼 빼고 소진(0176)
        const boQty = Math.max(0, Math.abs(Number(cl.qty) || 0) - (preOff[Number(cl.product_id)] || 0));
        if (!boQty) continue;
        const bo = await consumeBackorder(cqb, Number(cl.product_id), boQty);
        boConsumed += bo.consumed;
      }
      // 0277 · 입고(재고 등재)된 수량으로 그 SKU 의 미해소 부족분을 오래된 것부터 해소(원장 source='receipt').
      //   SAVEPOINT 격리 — 해소 기록이 실패해도 입고 승인은 그대로 간다.
      let shRes = { resolved: 0, entries: 0 };
      try {
        await c.query('SAVEPOINT sh_receipt');
        shRes = await resolveBatchReceipt(cqb, id, userId);
        await c.query('RELEASE SAVEPOINT sh_receipt');
      } catch (_) { await c.query('ROLLBACK TO SAVEPOINT sh_receipt').catch(() => {}); }
      return { ok: true, lines: computedLines, backorder_consumed: Math.round(boConsumed * 1000) / 1000,
        shortage_resolved: shRes.resolved };
    });

    if (out.error) return reply.code(409).send({ error: out.error });
    await logEvent({ userId, deviceId: req.ctx.deviceId, action: 'update', target: `import_batch:${id}`, detail: { approved: true } });
    // ── Offer Sheet 자동 생성 ──────────────────────────────────────
    //   재고 등재가 확정된 직후, 이번 배치로 입고된 SKU의 미해소 부족분
    //   (stock_shortages open, 고객 있음)을 고객별 오퍼 시트로 생성.
    //   승인 트랜잭션과 분리(승인은 이미 확정) + 실패해도 승인에는 영향 없음(best-effort).
    try {
      const pidsIn = [...new Set((out.lines || []).map((l) => Number(l.product_id)))];
      if (pidsIn.length) {
        const gen = await withTx(async (c) => generateOfferSheets(c.query.bind(c), {
          productIds: pidsIn, importBatchId: id, origin: 'auto', userId,
        }));
        out.offer_sheets = { sheets: gen.sheets, items: gen.items };
        if (gen.sheets > 0) {
          await logEvent({ userId, action: 'create', target: 'offer_sheets', detail: { import_batch: id, sheets: gen.sheets, items: gen.items } });
        }
      }
    } catch (e) {
      app.log?.error?.({ err: e }, 'offer sheet auto-generate failed');
      out.offer_sheets = { error: 'generate_failed' };
    }
    return out;
  });

  // 반려(승인거절) — 재고 변동 없음, 거절 기록만
  app.post('/api/imports/:id/reject', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const userId = req.ctx.perm.userId;
    const reason = (req.body && req.body.reason) ? String(req.body.reason).slice(0, 500) : null;
    const batch = (await query(`SELECT id, status FROM import_batches WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!batch) return reply.code(404).send({ error: 'not_found' });
    if (batch.status !== 'pending') return reply.code(409).send({ error: 'not_pending' });
    await query(
      `UPDATE import_batches SET status='rejected', rejected_by=$1, rejected_at=now(), reject_reason=$2 WHERE id=$3`,
      [userId, reason, id]);
    await logEvent({ userId, deviceId: req.ctx.deviceId, action: 'update', target: `import_batch:${id}`, detail: { rejected: true, reason } });
    return { ok: true, status: 'rejected' };
  });
}

// 미리보기 계산(읽기 전용)
async function computeBatch(id) {
  const batch = (await query(`SELECT * FROM import_batches WHERE id=$1`, [id])).rows[0];
  if (!batch) return { error: 'not_found' };
  const lines = (await query(`SELECT * FROM import_lines WHERE batch_id=$1`, [id])).rows;
  const overheads = (await query(`SELECT * FROM import_overheads WHERE batch_id=$1`, [id])).rows;
  const pids = [...new Set(lines.map((l) => l.product_id))];
  const ps = pids.length
    ? (await query(`SELECT id, stock_qty, avg_cost FROM products WHERE id = ANY($1)`, [pids])).rows
    : [];
  const productState = {};
  for (const p of ps) productState[p.id] = { stock_qty: p.stock_qty, avg_cost: p.avg_cost };
  const { computedLines } = computeImportCosting({ lines, overheads, fxRate: batch.fx_rate, productState, batchCurrency: batch.currency });
  return { batch_id: id, status: batch.status, preview: computedLines };
}
