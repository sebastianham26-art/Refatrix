// build 20260918tier — 고객 등록 디렉터 승인 + **RFC 선점**(0188) + 기준품목 할인율 제안 (0185)
//   20260918tier: CRM 이 새 RFC 에 요구하는 4종(razonSocial·contactEmail·contactPhone·businessTypeId)을
//         ERP 등록 입구에서 필수로 만든다. 이메일은 **수정에서도** 필수. 엑셀 일괄등록은 대상이 아니다.
//   0188: 선점 조건이 CONSTANCIA → RFC 로 바뀌었다. CONSTANCIA 번호·PDF 는 선택 증빙.
//   0193: **RFC 도 선택 입력**이 되었다. 대신 RFC 가 채워지는 순간 선점이 성립하고,
//         남의 RFC-없는 고객에 내 RFC 를 넣어 가져오는 「선점 이관」은 디렉터 승인을 탄다.
//         등록은 디렉터 본인이 해도 승인 대기(pending)로 간다 — 예외 없는 단일 경로.
import { query, withTx } from '../db.js';
import { CROSS_TEAM_PAGE_KEY } from '../permLoader.js';
import { authGuard, requirePage, requirePageEdit, requireDirector } from '../middleware/authGuard.js';
import { logEvent } from '../audit.js';
// ERP → CRM(웹 카달록) 고객 동기화. 승인·수정·삭제가 확정된 직후에만 적재한다.
//   ⚠ 절대 await 실패로 승인을 되돌리지 않는다 — enqueueCustomerSync 는 스스로 throw 하지 않는다.
import { enqueueCustomerSync } from '../crmSync.js';
import { visibleTeamIds, canViewTeam, canEditTeam, canRequestCrossTeam } from '../teams.js';
import { fieldVisible } from '../permissions.js';
import { AR_PAID_EPS, AR_SETTLED_SQL } from '../ar.js';
import { buildHeaderIndex, parseCustRow, buildCustPreview, CUST_TEMPLATE_HEADERS } from '../customerImport.js';
import { mxTodayStr } from '../workingHours.js';
import { reorderMetrics, medianWorkingGap } from '../salesCycle.js';
import { assembleVisitHistory } from '../customerVisits.js';
import { stageLabel, stripStageLabel } from '../stageLabel.js';
import { normalizeClaimKey, computeBaselineDiscount, validateChosenDiscount,
         discountGap, MAX_DISCOUNT_PCT, validateRfc, validateRfcOptional, RFC_ERROR_NOTE,
         nameSimilarity, NAME_SIMILAR_THRESHOLD } from '../customerClaim.js';
import { MERGE_MOVES, MOVED_TABLES, safeIdent, residualLabel,
         checkMerge, moveTotal, mergeNote } from '../customerMerge.js';
// 코드 채번은 CRM 수신부(0208)와 **같은 규칙**을 써야 한다 → 공용 모듈로 뺐다.
import { computeNextCode } from '../customerCode.js';
import { planOwnerChange, applyOwnerTransfer } from '../exclusivity.js';   // 0280 · 담당자 변경 ↔ 독점 이전
import { verifyPin } from '../auth.js';   // 20261019dpin · 할인율 수정 PIN

const VISIT_TZ = 'America/Mexico_City';   // 방문 시각 표시 기준(현지)
const VISIT_HIST_LIMIT = 300;             // 상담·방문 이력 1회 조회 상한(방문·미팅 각각)

// 0185 · 기준품목 — 고객이 경쟁사(SYD)에서 사는 단가를 물어보는 대표 SKU.
//   Railway 환경변수 SYD_BASE_CODE 로 바꿀 수 있다(코드 배포 없이 기준 교체).
const SYD_BASE_CODE = String(process.env.SYD_BASE_CODE || '1516049').trim();

function r2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }
async function safeLog(args) { try { await logEvent(args); } catch (_) { /* ignore */ } }

// 0185 · 등록 승인 상태. 컬럼 추가 전(마이그레이션 미적용) DB 에서도 죽지 않도록
//   읽기는 전부 COALESCE 로 감싸고, 쓰기는 아래 regColumnsReady() 가 true 일 때만 한다.
let _regReady = null, _regCheckedAt = 0;
async function regColumnsReady() {
  const now = Date.now();
  if (_regReady !== null && now - _regCheckedAt < 60000) return _regReady;
  try {
    const r = (await query(
      `SELECT count(*)::int AS n FROM information_schema.columns
        WHERE table_name='customers' AND column_name IN ('approval_status','constancia_no','suggested_discount')`)).rows[0];
    _regReady = Number(r.n) >= 3;
  } catch (_) { _regReady = false; }
  _regCheckedAt = now;
  return _regReady;
}

// 0267 · 사후승인 축(ratified_at) 적용 여부.
//   ⚠ 긍정만 캐싱한다(이 저장소의 관례). false 는 30초 뒤 다시 본다 —
//     배포 직후 마이그레이션이 늦게 적용되는 창에서 「없다」가 굳으면,
//     컬럼이 생긴 뒤에도 화면이 계속 옛 길로 가고 아무도 이유를 모른다.
let _ratifyReady = false, _ratifyCheckedAt = 0;
async function ratifyColsReady() {
  if (_ratifyReady) return true;
  const now = Date.now();
  if (now - _ratifyCheckedAt < 30000) return false;
  _ratifyCheckedAt = now;
  try {
    const r = (await query(
      `SELECT count(*)::int AS n FROM information_schema.columns
        WHERE table_name='customers' AND column_name IN ('ratified_at','ratified_by')`)).rows[0];
    _ratifyReady = Number(r.n) >= 2;
  } catch (_) { _ratifyReady = false; }
  return _ratifyReady;
}

// 0188 · RFC 선점 예외 컬럼(rfc_claim_exempt) + 유니크 인덱스 적용 여부.
//   미적용이어도 등록은 막지 않는다 — 애플리케이션 사전조회로 선점을 판정하고,
//   DB 유니크(동시성 최종 방어선)만 없는 상태로 동작한다.
let _rfcReady = null, _rfcCheckedAt = 0;
async function rfcClaimReady() {
  const now = Date.now();
  if (_rfcReady !== null && now - _rfcCheckedAt < 60000) return _rfcReady;
  try {
    const r = (await query(
      `SELECT count(*)::int AS n FROM information_schema.columns
        WHERE table_name='customers' AND column_name='rfc_claim_exempt'`)).rows[0];
    _rfcReady = Number(r.n) >= 1;
  } catch (_) { _rfcReady = false; }
  _rfcCheckedAt = now;
  return _rfcReady;
}

// 0193 · RFC 선택 입력 + 선점 이관(customer_rfc_claims) 적용 여부.
//   미적용이어도 서비스는 죽지 않는다 — 이관 요청 경로만 503 으로 막고
//   등록은 「RFC 선택」 규칙 그대로 동작한다(선점 시각 기록만 생략).
let _claimReady = null, _claimCheckedAt = 0;
async function claimTableReady() {
  const now = Date.now();
  if (_claimReady !== null && now - _claimCheckedAt < 60000) return _claimReady;
  try {
    const r = (await query(
      `SELECT (SELECT count(*)::int FROM information_schema.tables
                WHERE table_name='customer_rfc_claims') AS t,
              (SELECT count(*)::int FROM information_schema.columns
                WHERE table_name='customers' AND column_name='rfc_claimed_at') AS c`)).rows[0];
    _claimReady = Number(r.t) >= 1 && Number(r.c) >= 1;
  } catch (_) { _claimReady = false; }
  _claimCheckedAt = now;
  return _claimReady;
}

// 0193 · 이 RFC 를 지금 잡을 수 있는가 — 확정 선점(customers) + 대기 선점(claims) 둘 다 본다.
//   returns null(비어 있음) | { kind:'customer'|'claim', ... }
//   ⚠ rfc_claim_exempt(레거시 중복) 행도 여기서는 선점자로 본다(0188 결정 ④ 유지).
// 20261028 · 'null'·'undefined' 등은 RFC 가 아니라 **값이 없다는 표시**가 문자열로 굳은 것이다.
//   이 값끼리 「같은 RFC」 로 묶이면 RFC 없는 고객들이 서로 선점 충돌을 일으킨다.
const PLACEHOLDER_RFC_KEYS = new Set(['NULL', 'UNDEFINED', 'NONE', 'NA']);
function isPlaceholderRfc(v) {
  const k = normalizeClaimKey(v);
  return !!k && PLACEHOLDER_RFC_KEYS.has(k);
}

async function findRfcHolder(rfcNorm, { excludeCustomerId = null, claimsOn = true } = {}) {
  if (!rfcNorm || PLACEHOLDER_RFC_KEYS.has(String(rfcNorm).toUpperCase())) return null;
  const cur = (await query(
    `SELECT c.id, c.name, u.name AS owner_name, c.owner_id,
            to_char(COALESCE(c.rfc_claimed_at, c.created_at),'YYYY-MM-DD') AS claimed_at
       FROM customers c LEFT JOIN users u ON u.id=c.owner_id
      WHERE c.deleted_at IS NULL AND COALESCE(c.approval_status,'approved') <> 'rejected'
        AND c.rfc_norm = $1 AND ($2::bigint IS NULL OR c.id <> $2)
      ORDER BY c.created_at LIMIT 1`, [rfcNorm, excludeCustomerId])).rows[0];
  if (cur) {
    return { kind: 'customer', customer_id: Number(cur.id), name: cur.name,
      owner_name: cur.owner_name || null, owner_id: cur.owner_id == null ? null : Number(cur.owner_id),
      claimed_at: cur.claimed_at };
  }
  if (!claimsOn || !(await claimTableReady())) return null;
  const pend = (await query(
    `SELECT k.id, k.customer_id, c.name, u.name AS requested_by_name, k.requested_by,
            to_char(k.requested_at,'YYYY-MM-DD HH24:MI') AS requested_at
       FROM customer_rfc_claims k
       LEFT JOIN customers c ON c.id=k.customer_id
       LEFT JOIN users u ON u.id=k.requested_by
      WHERE k.status='pending' AND k.rfc_norm=$1
      ORDER BY k.requested_at LIMIT 1`, [rfcNorm])).rows[0];
  if (!pend) return null;
  return { kind: 'claim', claim_id: Number(pend.id), customer_id: Number(pend.customer_id),
    name: pend.name, owner_name: pend.requested_by_name || null,
    owner_id: pend.requested_by == null ? null : Number(pend.requested_by),
    claimed_at: pend.requested_at };
}

// 0193 · 상호명이 비슷한 기존 고객 (경고 전용 — 등록·저장을 막지 않는다).
//   1차로 「의미 단어 하나라도 겹치는 후보」를 DB 에서 넓게 긁고,
//   2차로 nameSimilarity 로 점수를 매겨 임계값 이상만 남긴다.
//   ⚠ 반환 필드는 claim-check 과 같은 최소 신원정보뿐이다(매출·연락처 절대 금지).
async function findSimilarCustomers(name, { excludeId = null, limit = 5 } = {}) {
  const raw = String(name || '').trim();
  if (raw.length < 2) return [];
  // 후보 긁기: 상호에서 가장 긴 두 단어로 ILIKE (인덱스는 못 타지만 고객 테이블 규모가 작다)
  const words = raw.replace(/[^\p{L}\p{N}]+/gu, ' ').split(' ')
    .filter((w) => w.length >= 3).sort((a, b) => b.length - a.length).slice(0, 2);
  if (!words.length) return [];
  const params = [excludeId];
  const likes = words.map((w) => { params.push(`%${w.replace(/([%_\\])/g, '\\$1')}%`); return `c.name ILIKE $${params.length}`; });
  const rows = (await query(
    `SELECT c.id, c.name, c.rfc, c.rfc_norm, u.name AS owner_name,
            to_char(c.created_at,'YYYY-MM-DD') AS registered_at,
            COALESCE(c.approval_status,'approved') AS approval_status
       FROM customers c LEFT JOIN users u ON u.id=c.owner_id
      WHERE c.deleted_at IS NULL AND COALESCE(c.approval_status,'approved') <> 'rejected'
        AND ($1::bigint IS NULL OR c.id <> $1)
        AND (${likes.join(' OR ')})
      ORDER BY c.created_at LIMIT 40`, params)).rows;
  return rows
    .map((r) => ({ ...r, score: nameSimilarity(raw, r.name) }))
    .filter((r) => r.score >= NAME_SIMILAR_THRESHOLD)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((r) => ({
      customer_id: Number(r.id), name: r.name, rfc: r.rfc || null,
      has_rfc: !!r.rfc_norm,                  // false = 선점 미성립 → 내 RFC 로 가져올 수 있는 대상
      owner_name: r.owner_name || '(담당자 미지정)',
      registered_at: r.registered_at, approval_status: r.approval_status, score: r.score,
    }));
}

function rfcHolderNote(h) {
  if (!h) return null;
  return h.kind === 'claim'
    ? `이 RFC 는 ${h.owner_name || '(미지정)'} 님이 ${h.claimed_at} 에 먼저 선점 요청했습니다(디렉터 승인 대기)`
      + ' — 먼저 입력한 사람에게 우선권이 있습니다.'
    : `이미 등록된 고객입니다 — ${h.name} · 담당 ${h.owner_name || '(미지정)'} · 선점일 ${h.claimed_at}. `
      + '같은 고객이 맞다면 디렉터에게 문의하세요.';
}

// ── 20260918tier · 신규 고객 필수값 ───────────────────────────────────
//   CRM(웹 카달록)은 새 RFC 를 받을 때 razonSocial · contactEmail · contactPhone ·
//   businessTypeId 를 요구한다. ERP 에서 비워 둔 채 등록하면 승인 직후 전송이 상대 쪽에서
//   거절되고, 그 사실은 연동 아웃박스를 들여다봐야만 알게 된다. 그래서 입구에서 막는다.
//   프런트(custform)에서도 막지만 **서버가 최종 관문**이다 — 캐시된 구버전 화면으로도 못 뚫는다.
export const BUSINESS_TIERS = {
  A: 'Distribuidor mayorista / cliente estratégico',
  B: 'Distribuidor medio / refaccionaria grande',
  C: 'Refaccionaria / taller establecido',
  D: 'Cliente nuevo / pequeño volumen',
};
export function isEmailAddr(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v == null ? '' : v).trim());
}
export const CONTACT_REQUIRED_NOTE =
  '이메일 주소를 입력해야 저장됩니다 — 청구서(팩투라)와 오퍼시트가 이 주소로 나갑니다.';
export const CONTACT_INVALID_NOTE =
  '이메일 주소 형식이 올바르지 않습니다. (예: ejemplo@correo.com)';

export default async function customerRoutes(app) {
  try { app.log?.info?.('[customerRoutes] loaded rev 20260918tier'); } catch (_) { /* 로깅 실패는 무시 */ }
  // 팀 목록(고객 배정·필터용 = 영업팀만)
  app.get('/api/teams', { preHandler: [authGuard, requirePage('customers')] }, async () => {
    const rows = (await query(`SELECT id, name, sort_order FROM sales_teams WHERE deleted_at IS NULL AND is_sales=true ORDER BY sort_order, id`)).rows;
    return { items: rows.map((t) => ({ id: t.id, name: t.name })) };
  });

  // 소속 배정용 전체 팀(director 포함) — 팀 권한 관리 화면
  app.get('/api/team-admin/teams', { preHandler: [authGuard, requireDirector] }, async () => {
    const rows = (await query(
      `SELECT t.id, t.name, t.sort_order, t.is_sales,
              (SELECT COUNT(*) FROM users u WHERE u.team_id = t.id AND u.deleted_at IS NULL)     AS member_count,
              (SELECT COUNT(*) FROM customers c WHERE c.team_id = t.id AND c.deleted_at IS NULL) AS customer_count
         FROM sales_teams t
        WHERE t.deleted_at IS NULL
        ORDER BY t.sort_order, t.id`)).rows;
    return {
      items: rows.map((t) => ({
        id: Number(t.id),
        name: t.name,
        is_sales: t.is_sales,
        sort_order: Number(t.sort_order),
        member_count: Number(t.member_count),
        customer_count: Number(t.customer_count),
      })),
    };
  });

  // 팀 생성(디렉터) — 자동 추가. name UNIQUE 이므로 동명 소프트삭제 팀은 되살림.
  app.post('/api/team-admin/teams', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const name = String(req.body?.name || '').trim();
    const isSales = req.body?.is_sales === false ? false : true;
    const sortOrder = Number.isFinite(Number(req.body?.sort_order)) ? Number(req.body.sort_order) : 0;
    if (!name) return reply.code(400).send({ error: 'name_required' });
    const dup = (await query(`SELECT id, deleted_at FROM sales_teams WHERE name = $1`, [name])).rows[0];
    if (dup && dup.deleted_at == null) return reply.code(409).send({ error: 'name_taken' });
    let row;
    if (dup && dup.deleted_at != null) {
      // 과거 소프트삭제된 동명 팀 재활성화(이름 UNIQUE 충돌 회피)
      row = (await query(
        `UPDATE sales_teams SET deleted_at = NULL, is_sales = $2, sort_order = $3 WHERE id = $1
         RETURNING id, name, is_sales, sort_order`, [dup.id, isSales, sortOrder])).rows[0];
    } else {
      row = (await query(
        `INSERT INTO sales_teams (name, sort_order, is_sales) VALUES ($1, $2, $3)
         RETURNING id, name, is_sales, sort_order`, [name, sortOrder, isSales])).rows[0];
    }
    await safeLog({ userId: req.ctx.perm.userId, action: 'create', target: `team:${row.id}`, detail: { name, is_sales: isSales } });
    return { ok: true, team: { id: Number(row.id), name: row.name, is_sales: row.is_sales, sort_order: Number(row.sort_order) } };
  });

  // 팀 개명·유형·정렬 변경(디렉터). id 불변이라 기존 연결 유지.
  app.patch('/api/team-admin/teams/:id', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const cur = (await query(`SELECT id, name, is_sales, sort_order FROM sales_teams WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!cur) return reply.code(404).send({ error: 'not_found' });
    const b = req.body || {};
    const name = b.name != null ? String(b.name).trim() : cur.name;
    if (!name) return reply.code(400).send({ error: 'name_required' });
    const isSales = b.is_sales != null ? (b.is_sales === false ? false : true) : cur.is_sales;
    const sortOrder = (b.sort_order != null && Number.isFinite(Number(b.sort_order))) ? Number(b.sort_order) : Number(cur.sort_order);
    if (name !== cur.name) {
      const dup = (await query(`SELECT id FROM sales_teams WHERE name = $1 AND id <> $2`, [name, id])).rows[0];
      if (dup) return reply.code(409).send({ error: 'name_taken' });
    }
    const row = (await query(
      `UPDATE sales_teams SET name = $1, is_sales = $2, sort_order = $3 WHERE id = $4
       RETURNING id, name, is_sales, sort_order`, [name, isSales, sortOrder, id])).rows[0];
    await safeLog({ userId: req.ctx.perm.userId, action: 'update', target: `team:${id}`, detail: { name, is_sales: isSales, sort_order: sortOrder } });
    return { ok: true, team: { id: Number(row.id), name: row.name, is_sales: row.is_sales, sort_order: Number(row.sort_order) } };
  });

  // 팀 삭제(소프트, 디렉터) — 소속 유저·고객 있으면 차단(고아 방지).
  app.delete('/api/team-admin/teams/:id', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const cur = (await query(`SELECT id FROM sales_teams WHERE id = $1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!cur) return reply.code(404).send({ error: 'not_found' });
    const mem = Number((await query(`SELECT COUNT(*) AS n FROM users WHERE team_id = $1 AND deleted_at IS NULL`, [id])).rows[0].n);
    const cus = Number((await query(`SELECT COUNT(*) AS n FROM customers WHERE team_id = $1 AND deleted_at IS NULL`, [id])).rows[0].n);
    if (mem > 0 || cus > 0) return reply.code(409).send({ error: 'team_in_use', member_count: mem, customer_count: cus });
    await query(`UPDATE sales_teams SET deleted_at = now() WHERE id = $1`, [id]);
    // 이 팀을 가리키던 상대팀 열람권도 정리(팀이 비었을 때만 이 지점 도달).
    await query(`DELETE FROM user_team_access WHERE team_id = $1`, [id]);
    await safeLog({ userId: req.ctx.perm.userId, action: 'delete', target: `team:${id}`, detail: {} });
    return { ok: true };
  });

  // 0206 · CRM 유입 표시 컬럼 준비 여부(반쪽 배포 안전). 긍정만 영구 캐시.
  let crmColsReady = false; let crmColsProbe = 0;
  async function crmOriginColsReady() {
    if (crmColsReady) return true;
    if (Date.now() - crmColsProbe < 30000) return false;
    crmColsProbe = Date.now();
    try {
      const r = await query(
        `SELECT 1 FROM information_schema.columns
          WHERE table_name='customers' AND column_name='crm_customer_code' LIMIT 1`);
      crmColsReady = r.rows.length > 0;
    } catch (_) { crmColsReady = false; }
    return crmColsReady;
  }

  //   (채번 규칙은 ../customerCode.js — CRM 수신 등록(P-####)과 한 곳에서 관리한다)

  // 다음 고객코드 자동생성(미리보기). 대소문자 무관, 빈 번호 충돌 회피.
  //   ⚠ 미리보기와 실제 채번이 **같은 계열**이어야 한다. 화면엔 C-0123 이 떠 있는데
  //     저장하면 P-0007 이 나오면, 코드를 받아 적어 둔 사람이 엉뚱한 번호를 들고 있게 된다.
  //     그래서 웹 가입 신청에서 넘어온 등록이면 여기서도 P 로 미리 보여 준다.
  app.get('/api/customers/next-code', { preHandler: [authGuard, requirePage('customers')] }, async (req) => {
    let prefix = 'C';
    const leadId = Number(req.query?.lead_id || 0);
    if (leadId > 0) {
      try {
        const l = (await query(
          `SELECT 1 FROM crm_web_leads WHERE id=$1 AND status IN ('new','assigned')`, [leadId])).rows[0];
        if (l) prefix = 'P';
      } catch (_) { /* 0210 미적용 — C 그대로 */ }
    }
    return { code: await computeNextCode(prefix), prefix };
  });

  // Constancia(세무등록) 미입력 고객 알림 — 이름이 Maria인 사용자에게만 nag.
  app.get('/api/customers/missing-constancia', { preHandler: [authGuard] }, async (req) => {
    const isMaria = String(req.ctx.perm.name || '').trim().toLowerCase().startsWith('maria');
    const rows = (await query(
      `SELECT id, code, name FROM customers
        WHERE deleted_at IS NULL AND (constancia_fiscal IS NULL OR btrim(constancia_fiscal) = '')
        ORDER BY created_at DESC, id DESC`)).rows;
    const items = rows.map((r) => ({ id: Number(r.id), code: r.code, name: r.name }));
    return { is_target: isMaria, nag: isMaria && items.length > 0, count: items.length, items: isMaria ? items : [] };
  });

  // 업로드 양식 헤더(프런트가 빈 xlsx 양식 생성에 사용)
  app.get('/api/customers/template', { preHandler: [authGuard, requirePage('customers')] }, async () => {
    return { headers: CUST_TEMPLATE_HEADERS };
  });

  async function resolveRefs() {
    const teams = (await query(`SELECT id, name FROM sales_teams WHERE deleted_at IS NULL AND is_sales=true`)).rows;
    const owners = (await query(`SELECT id, name FROM users WHERE deleted_at IS NULL AND role IN ('sales','director')`)).rows;
    const stages = (await query(`SELECT id, name FROM stages WHERE deleted_at IS NULL`)).rows;
    const existing = (await query(
      `SELECT c.code, c.name, c.rfc, c.customer_type, c.contact, c.phone, COALESCE((to_jsonb(c)->>'discount_agreed')::numeric, c.discount) AS discount, COALESCE((to_jsonb(c)->>'credit_days_agreed')::int, c.credit_days) AS credit_days, c.memo, c.team_id, t.name AS team_name
         FROM customers c LEFT JOIN sales_teams t ON t.id=c.team_id WHERE c.deleted_at IS NULL`)).rows;
    const teamByName = {}; for (const t of teams) teamByName[t.name.toLowerCase()] = t.id;
    const ownerByName = {}; for (const o of owners) ownerByName[o.name.toLowerCase()] = o.id;
    const stageByName = {}; for (const s of stages) stageByName[stripStageLabel(s.name).toLowerCase()] = s.id;
    const existingByCode = new Set(existing.map((r) => String(r.code).toLowerCase()));
    const existingByCodeData = {}; for (const r of existing) existingByCodeData[String(r.code).toLowerCase()] = r;
    return { teamByName, ownerByName, stageByName, existingByCode, existingByCodeData };
  }

  // 엑셀 업로드 미리보기 — body: { rows: [[...]] } (첫 행 헤더)
  app.post('/api/customers/import/preview', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const all = Array.isArray(req.body?.rows) ? req.body.rows : [];
    if (!all.length) return reply.code(400).send({ error: 'no_rows' });
    const idx = buildHeaderIndex(all[0]);
    if (idx.name == null) return reply.code(400).send({ error: 'missing_name_column' });
    const parsed = all.slice(1).map((r) => parseCustRow(r, idx)).filter(Boolean);
    const resolve = await resolveRefs();
    const preview = buildCustPreview(parsed, resolve);
    return { ...preview, total: parsed.length };
  });

  // 커밋 — 신규는 코드 자동생성, 기존(코드 일치)은 갱신. 팀 편집권한 확인.
  app.post('/api/customers/import/commit', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const all = Array.isArray(req.body?.rows) ? req.body.rows : [];
    if (!all.length) return reply.code(400).send({ error: 'no_rows' });
    const idx = buildHeaderIndex(all[0]);
    const parsed = all.slice(1).map((r) => parseCustRow(r, idx)).filter(Boolean);
    const resolve = await resolveRefs();
    const userId = req.ctx.perm.userId;
    // 0185 · 엑셀 일괄 등록은 RFC 선점·승인 흐름을 우회하는 경로다.
    //   신규 고객 생성은 디렉터만 허용하고, 그 외 사용자는 기존 고객 갱신만 가능하다.
    const isDir = req.ctx.perm.role === 'director';
    let created = 0, updated = 0, skipped = 0, blockedNew = 0;
    for (const p of parsed) {
      if (!p.name || !p.team) { skipped++; continue; }
      const teamId = resolve.teamByName[p.team.toLowerCase()];
      if (!teamId || !canEditTeam(req.ctx.perm, teamId)) { skipped++; continue; }
      const ownerId = p.owner ? (resolve.ownerByName[p.owner.toLowerCase()] || null) : null;
      const stageId = p.stage ? (resolve.stageByName[stripStageLabel(p.stage).toLowerCase()] || null) : null;
      const isUpdate = p.code && resolve.existingByCode.has(p.code.toLowerCase());
      if (isUpdate) {
        // 기본할인·외상일은 엑셀 일괄수정에서 제외 — 반드시 고객 폼(수정이유·제공조건 + 디렉터 승인)으로만 변경
        await query(
          `UPDATE customers SET name=$1, rfc=$2, contact=$3, phone=$4,
             team_id=$5, stage_id=COALESCE($6,stage_id), owner_id=COALESCE($7,owner_id),
             customer_type=COALESCE($8,customer_type), memo=COALESCE($9,memo), updated_by=$10
           WHERE lower(code)=lower($11) AND deleted_at IS NULL`,
          [p.name, p.rfc, p.contact, p.phone, teamId, stageId, ownerId, p.customer_type, p.memo, userId, p.code]);
        updated++;
      } else if (!isDir) {
        blockedNew++;                       // 신규 고객 생성은 디렉터 전용(승인·RFC 선점 우회 방지)
      } else {
        let code = p.code, ok = false;
        for (let attempt = 0; attempt < 5 && !ok; attempt++) {
          if (!code || attempt > 0) code = await computeNextCode();
          try {
            const ins = (await query(
              `INSERT INTO customers (code, name, rfc, contact, phone, discount, credit_days, team_id, stage_id, owner_id, customer_type, memo, stage_since, created_by)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12, CASE WHEN $9::bigint IS NOT NULL THEN CURRENT_DATE END, $13) RETURNING id`,
              [code, p.name, p.rfc, p.contact, p.phone, p.discount, p.credit_days, teamId, stageId, ownerId, p.customer_type, p.memo, userId])).rows[0];
            ok = true; resolve.existingByCode.add(String(code).toLowerCase());
            // 신규 고객 초기 할인/외상일 이력(0이 아니면)
            const initT = [];
            if ((Number(p.discount) || 0) !== 0) initT.push({ field: 'discount', old: null, nv: Number(p.discount) || 0 });
            if ((Number(p.credit_days) || 0) !== 0) initT.push({ field: 'credit_days', old: null, nv: Number(p.credit_days) || 0 });
            if (initT.length) { try { await logTermsHistory(ins.id, initT, { reason: '엑셀 일괄 등록 초기값', conditions: null, changedBy: userId, approvedBy: null }); } catch (_) {} }
          } catch (e) { if (!String(e.message || '').match(/unique|duplicate/)) throw e; }
        }
        if (ok) created++; else skipped++;
      }
    }
    await safeLog({ userId, action: 'create', target: 'customer_import', detail: { created, updated, skipped, blockedNew } });
    return { ok: true, created, updated, skipped, blocked_new: blockedNew,
      blocked_note: blockedNew ? '신규 고객 생성은 디렉터만 가능합니다(RFC 선점·승인 흐름). 고객 등록 화면에서 등록하세요.' : null };
  });

  // 고객 단계 목록
  app.get('/api/stages', { preHandler: [authGuard, requirePage('customers')] }, async () => {
    const rows = (await query(`SELECT id, name, sort_order FROM stages WHERE deleted_at IS NULL ORDER BY sort_order, id`)).rows;
    return { items: rows.map((s) => ({ id: s.id, name: stageLabel(s.name) })) };
  });

  // 영업 담당(사용자) 목록 — 고객 배정용
  app.get('/api/sales-users', { preHandler: [authGuard, requirePage('customers')] }, async (req) => {
    const vis = visibleTeamIds(req.ctx.perm);
    let where = `deleted_at IS NULL AND role IN ('sales','director')`;
    const params = [];
    if (vis !== null) {
      if (!vis.length) return { items: [] };
      params.push(vis); where += ` AND (team_id = ANY($1) OR team_id IS NULL)`;
    }
    const rows = (await query(`SELECT id, name, team_id FROM users WHERE ${where} ORDER BY name`, params)).rows;
    return { items: rows.map((u) => ({ id: u.id, name: u.name, team_id: u.team_id })) };
  });

  // 고객 목록: 팀 가시성 적용 + 검색 + 미수/연체 요약
  app.get('/api/customers', { preHandler: [authGuard, requirePage('customers')] }, async (req) => {
    const { perm } = req.ctx;
    const vis = visibleTeamIds(perm);
    const q = String(req.query.q || '').trim();
    const teamFilter = req.query.team_id ? Number(req.query.team_id) : null;
    const conds = ['c.deleted_at IS NULL']; const params = [];
    if (vis !== null) {
      if (!vis.length) return { items: [] };
      params.push(vis); conds.push(`c.team_id = ANY($${params.length})`);
    }
    if (teamFilter) {
      if (vis !== null && !vis.includes(teamFilter)) return { items: [] };
      params.push(teamFilter); conds.push(`c.team_id = $${params.length}`);
    }
    if (q) { params.push(`%${q}%`); conds.push(`(c.name ILIKE $${params.length} OR c.code ILIKE $${params.length} OR c.rfc ILIKE $${params.length})`); }
    // 0185 · 승인 대기 고객도 목록에는 보인다(등록자가 자기 건 상태를 봐야 하므로).
    //   실제 사용 차단은 견적·매출 생성 시점에서 한다.
    const regOn = await regColumnsReady();
    const crmOn = await crmOriginColsReady();
    const apprExpr = regOn ? `COALESCE(c.approval_status,'approved')` : `'approved'`;
    const rows = (await query(
      `SELECT c.id, c.code, c.name, c.rfc, c.contact, c.phone, c.buyer_name, c.buyer_phone, c.discount, c.credit_days, c.customer_type, c.branch_count,
              c.ship_address, ${apprExpr} AS approval_status,
              ${crmOn ? 'c.crm_customer_code' : 'NULL::text'} AS crm_customer_code,
              ${regOn ? 'c.constancia_no' : 'NULL::text'} AS constancia_no,
              c.team_id, t.name AS team_name, c.stage_id, s.name AS stage_name,
              c.owner_id, u.name AS owner_name,
              COALESCE(ar.outstanding,0) AS outstanding,
              COALESCE(ar.overdue,0) AS overdue,
              COALESCE(ar.sales_total,0) AS sales_total,
              COALESCE(dc.doc_count,0) AS doc_count,
              COALESCE(lq.live_quote_mxn,0) AS live_quote_mxn,
              COALESCE(iq.total_qty,0) AS total_qty,
              iq.order_dates AS order_dates,
              iq.first_deal_date AS first_deal_date,
              iq.last_deal_date AS last_deal_date,
              iq.first_qty AS first_qty,
              (CURRENT_DATE - COALESCE(ar.last_sale_date, c.created_at::date)) AS days_no_sales,
              (CURRENT_DATE - COALESCE(ar.last_sale_date, c.created_at::date)) AS no_sale_days,
              (EXISTS (SELECT 1 FROM customer_change_requests rr WHERE rr.customer_id=c.id AND rr.status='pending')) AS has_pending
         FROM customers c
         LEFT JOIN sales_teams t ON t.id=c.team_id
         LEFT JOIN stages s ON s.id=c.stage_id
         LEFT JOIN users u ON u.id=c.owner_id
         LEFT JOIN (
           SELECT i.customer_id,
                  SUM(i.total_mxn - COALESCE(p.paid,0)) AS outstanding,
                  SUM(CASE WHEN i.due_date < CURRENT_DATE THEN (i.total_mxn - COALESCE(p.paid,0)) ELSE 0 END) AS overdue,
                  SUM(i.total_mxn) AS sales_total,
                  MAX(i.inv_date) AS last_sale_date
             FROM sales_invoices i
             LEFT JOIN (SELECT invoice_id, SUM(amount) AS paid FROM sales_payment_allocations GROUP BY invoice_id) p
                    ON p.invoice_id=i.id
            WHERE i.status='posted'
            GROUP BY i.customer_id
         ) ar ON ar.customer_id=c.id
         LEFT JOIN (
           SELECT customer_id, COUNT(*) AS doc_count
             FROM customer_documents
            WHERE deleted_at IS NULL
            GROUP BY customer_id
         ) dc ON dc.customer_id=c.id
         LEFT JOIN (
           SELECT customer_id, SUM(total_mxn) AS live_quote_mxn
             FROM quotes
            WHERE status IN ('draft','confirmed','expired')   -- 저장된 미전환 견적(주문) = 견적/수주 단계 금액 (전환·취소·삭제·가격표 제외, 24h 만료도 포함)
              AND deleted_at IS NULL
            GROUP BY customer_id
         ) lq ON lq.customer_id=c.id
         LEFT JOIN (
           SELECT customer_id,
                  SUM(day_qty) AS total_qty,
                  COUNT(*) AS order_dates,
                  to_char(MIN(inv_date),'YYYY-MM-DD') AS first_deal_date,
                  to_char(MAX(inv_date),'YYYY-MM-DD') AS last_deal_date,
                  (ARRAY_AGG(day_qty ORDER BY inv_date))[1] AS first_qty
             FROM (SELECT si.customer_id, si.inv_date, SUM(sil.qty) AS day_qty
                     FROM sales_invoices si JOIN sales_invoice_lines sil ON sil.invoice_id=si.id
                    WHERE si.status='posted' GROUP BY si.customer_id, si.inv_date) pd
            GROUP BY customer_id
         ) iq ON iq.customer_id=c.id
        WHERE ${conds.join(' AND ')}
        ORDER BY c.name LIMIT 300`, params)).rows;
    // 재주문(구매주기) 지표 — 첫 주문 제외, 영업일 기준(파이프라인/그래프/상세 공통 계산)
    const mxToday = mxTodayStr(new Date());
    for (const c of rows) {
      c._rc = reorderMetrics({ total_qty: c.total_qty, order_dates: c.order_dates, first_qty: c.first_qty,
        first_date: c.first_deal_date, last_date: c.last_deal_date }, mxToday);
    }
    return { items: rows.map((c) => ({
      id: c.id, code: c.code, name: c.name, rfc: c.rfc, contact: c.contact, phone: c.phone,
      buyer_name: c.buyer_name || null, buyer_phone: c.buyer_phone || null,
      discount: Number(c.discount), credit_days: c.credit_days, customer_type: c.customer_type,
      branch_count: c.branch_count == null ? null : Number(c.branch_count),
      ship_address: c.ship_address || null,
      approval_status: c.approval_status, constancia_no: c.constancia_no || null,
      team_id: c.team_id, team_name: c.team_name, stage_id: c.stage_id, stage_name: stageLabel(c.stage_name),
      owner_id: c.owner_id, owner_name: c.owner_name,
      outstanding: r2(c.outstanding), overdue: r2(c.overdue),
      sales_total: r2(c.sales_total), doc_count: Number(c.doc_count),
      // 카탈로그(CRM)에서 들어온 고객인지 — 목록·상세에 배지로 표시한다
      crm_customer_code: c.crm_customer_code || null,
      from_crm: !!(c.crm_customer_code || /^p-/i.test(String(c.code || ''))),
      live_quote_mxn: r2(c.live_quote_mxn),
      total_qty: Number(c.total_qty) || 0,
      orders: c._rc.orders,
      first_deal_date: c.first_deal_date || null,
      last_deal_date: c.last_deal_date || null,
      reorder_velocity: c._rc.reorder_velocity,  // ② 그래프 우측축
      reorder_cycle: c._rc.reorder_cycle,        // ③ (참고)
      reorder_qty: c._rc.reorder_qty,            // ③ (참고)
      days_no_sales: c.days_no_sales == null ? null : Number(c.days_no_sales),
      no_sale_days: c.no_sale_days == null ? null : Number(c.no_sale_days),
      pending_change: !!c.has_pending,
    })) };
  });

  // 고객 상세 + 미수/연체 인보이스
  app.get('/api/customers/:id', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const c = (await query(
      `SELECT c.*, t.name AS team_name, s.name AS stage_name, u.name AS owner_name,
              to_char(c.stage_since,'YYYY-MM-DD') AS stage_since_str
         FROM customers c
         LEFT JOIN sales_teams t ON t.id=c.team_id
         LEFT JOIN stages s ON s.id=c.stage_id
         LEFT JOIN users u ON u.id=c.owner_id
        WHERE c.id=$1 AND c.deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(req.ctx.perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    agreedTerms(c);
    // 연초~현재 누적 매출실적(올해, posted 인보이스 합계)
    const ytd = (await query(
      `SELECT COALESCE(SUM(total_mxn),0) AS actual
         FROM sales_invoices
        WHERE customer_id=$1 AND status='posted'
          AND inv_date >= date_trunc('year', CURRENT_DATE)`, [id])).rows[0];
    // 올해 매출목표(고객 월 목표 합) — 매출 목표 메뉴에서 설정되면 채워짐
    const tgt = (await query(
      `SELECT COALESCE(SUM(amount),0) AS yt FROM target_customer_months
        WHERE customer_id=$1 AND ym LIKE to_char(CURRENT_DATE,'YYYY') || '-%'`, [id])).rows[0];
    const yearTarget = Number(tgt.yt) > 0 ? r2(tgt.yt) : null;
    const invs = (await query(
      `SELECT i.id, to_char(i.inv_date,'YYYY-MM-DD') AS inv_date, to_char(i.due_date,'YYYY-MM-DD') AS due_date,
              i.total_mxn, COALESCE(p.paid,0) AS paid, (i.total_mxn - COALESCE(p.paid,0)) AS outstanding,
              (i.due_date < CURRENT_DATE AND (i.total_mxn - COALESCE(p.paid,0)) > 0) AS overdue
         FROM sales_invoices i
         LEFT JOIN (SELECT invoice_id, SUM(amount) AS paid FROM sales_payment_allocations GROUP BY invoice_id) p ON p.invoice_id=i.id
        WHERE i.customer_id=$1 AND i.status='posted'
        ORDER BY i.inv_date DESC LIMIT 100`, [id])).rows;
    // 재주문(구매주기) 지표 — 주문일(중복 제거)별 수량 목록에서 ②재주문속도/③주기·수량/④중앙값 산출
    const orderDays = (await query(
      `SELECT to_char(si.inv_date,'YYYY-MM-DD') AS d, SUM(sil.qty) AS day_qty
         FROM sales_invoices si JOIN sales_invoice_lines sil ON sil.invoice_id=si.id
        WHERE si.customer_id=$1 AND si.status='posted'
        GROUP BY si.inv_date ORDER BY si.inv_date`, [id])).rows;
    const rcToday = mxTodayStr(new Date());
    const rcTotal = orderDays.reduce((s, r) => s + (Number(r.day_qty) || 0), 0);
    const rcFirst = orderDays.length ? orderDays[0].d : null;
    const rcLast = orderDays.length ? orderDays[orderDays.length - 1].d : null;
    const rcFirstQty = orderDays.length ? (Number(orderDays[0].day_qty) || 0) : 0;
    const rc = reorderMetrics({ total_qty: rcTotal, order_dates: orderDays.length, first_qty: rcFirstQty,
      first_date: rcFirst, last_date: rcLast }, rcToday);
    const reorderSummary = {
      orders: orderDays.length, total_qty: rcTotal, first_qty: rcFirstQty,
      first_date: rcFirst, last_date: rcLast,
      reorder_velocity: rc.reorder_velocity,      // ② 개/영업일
      reorder_cycle: rc.reorder_cycle,            // ③ 영업일/회
      reorder_qty: rc.reorder_qty,                // ③ 개/회
      median_cycle: medianWorkingGap(orderDays.map((r) => r.d)),  // ④ 영업일
    };
    // 중요 아이템 — 누적 구매 SKU 중 파레토(누적 80%) ∪ 반복주문(2회 이상) + 적용차량정보
    const skuRows = (await query(
      `SELECT p.id AS product_id, p.code, p.name,
              SUM(sil.qty) AS total_qty,
              COUNT(DISTINCT sil.invoice_id) AS order_count,
              to_char(MAX(si.inv_date),'YYYY-MM-DD') AS last_date
         FROM sales_invoice_lines sil
         JOIN sales_invoices si ON si.id=sil.invoice_id
         JOIN products p ON p.id=sil.product_id
        WHERE si.customer_id=$1 AND si.status='posted'
        GROUP BY p.id, p.code, p.name
        ORDER BY SUM(sil.qty) DESC, p.code`, [id])).rows;
    const grandQty = skuRows.reduce((s, r) => s + (Number(r.total_qty) || 0), 0);
    let cum = 0;
    const skuMarked = skuRows.map((r) => {
      const qty = Number(r.total_qty) || 0;
      const before = cum; cum += qty;
      // 파레토: 내림차순 누적이 80%에 도달하기 전(경계를 넘기는 항목 포함) = 핵심 소수
      const isPareto = grandQty > 0 ? (before < 0.8 * grandQty) : false;
      const isRepeat = (Number(r.order_count) || 0) >= 2; // 서로 다른 인보이스 2건 이상 = 반복주문
      return { product_id: r.product_id, code: r.code, name: r.name, total_qty: qty,
        order_count: Number(r.order_count) || 0, last_date: r.last_date || null,
        is_pareto: isPareto, is_repeat: isRepeat };
    });
    const importantRaw = skuMarked.filter((r) => r.is_pareto || r.is_repeat);
    const appMap = {};
    if (importantRaw.length) {
      const ids = importantRaw.map((r) => r.product_id);
      const apps = (await query(
        `SELECT product_id, app_text FROM product_applications WHERE product_id = ANY($1) ORDER BY product_id, id`, [ids])).rows;
      for (const a of apps) { (appMap[a.product_id] ||= []).push(a.app_text); }
    }
    const importantSkus = importantRaw.map((r) => ({
      code: r.code, name: r.name, total_qty: r.total_qty, order_count: r.order_count,
      last_date: r.last_date, is_pareto: r.is_pareto, is_repeat: r.is_repeat,
      applications: appMap[r.product_id] || [],
    }));

    // 0194 · rfc_claim_exempt 는 **0188 이 돌던 시점의 스냅샷**이라 철이 지날 수 있다.
    //   상대 고객이 그 뒤 삭제·반려·RFC 정정되면 중복은 사라졌는데 플래그만 남는다.
    //   → 화면이 "진짜 중복" 과 "철 지난 표시" 를 구분해 말할 수 있도록 지금 상태를 같이 센다.
    //   ⚠ 팀 스코프를 넘는 정보라 **건수와 담당자 이름만** 내보낸다(금액·연락처 금지).
    let rfcDup = null;
    if (c.rfc_claim_exempt === true && normalizeClaimKey(c.rfc)) {
      const others = (await query(
        `SELECT o.name, u.name AS owner_name, to_char(o.created_at,'YYYY-MM-DD') AS registered_at
           FROM customers o LEFT JOIN users u ON u.id=o.owner_id
          WHERE o.id <> $1 AND o.rfc_norm = $2 AND o.deleted_at IS NULL
            AND COALESCE(o.approval_status,'approved') <> 'rejected'
          ORDER BY o.created_at LIMIT 5`, [id, normalizeClaimKey(c.rfc)])).rows;
      rfcDup = {
        count: others.length,           // 0 = 중복이 이미 해소됨(플래그만 철 지난 상태)
        others: others.map((o) => ({ name: o.name, owner_name: o.owner_name || '(담당자 미지정)',
          registered_at: o.registered_at })),
      };
    }
    return {
      customer: {
        id: c.id, code: c.code, name: c.name, rfc: c.rfc, contact: c.contact, phone: c.phone,
        buyer_name: c.buyer_name || null, buyer_phone: c.buyer_phone || null,
        discount: Number(c.discount), credit_days: c.credit_days, memo: c.memo, customer_type: c.customer_type,
        // 0235 · 서류 관문이 적용된 실효 조건(신규 고객) + 독점 대상 여부
        discount_effective: c.discount_effective == null ? Number(c.discount) : Number(c.discount_effective),
        credit_days_effective: c.credit_days_effective == null ? c.credit_days : Number(c.credit_days_effective),
        doc_gate: c.doc_gate === true, excl_policy: c.excl_policy === true,
        constancia_fiscal: c.constancia_fiscal || null,
        // 0185 · 등록 승인 + 선점 + 기준품목 근거 (마이그레이션 전 DB 에서는 undefined → 화면이 알아서 숨김)
        approval_status: c.approval_status || 'approved',
        constancia_no: c.constancia_no || null,
        // 0188 · RFC 가 선점 키. exempt = 마이그레이션 시점에 이미 RFC 가 중복이던 레거시 행.
        rfc_claim_exempt: c.rfc_claim_exempt === true,
        // 0194 · 그 예외가 **지금도 유효한지**. dup_count=0 이면 중복은 이미 사라졌고
        //   플래그만 남은 것이라 디렉터가 「선점 보호 복구」 한 번으로 정리할 수 있다.
        rfc_dup_count: rfcDup ? rfcDup.count : null,
        rfc_dup_others: rfcDup ? rfcDup.others : null,
        // 0193 · RFC 가 비어 있으면 **선점이 없는 고객**이다 — 화면에 빨간 안내 + 매출 차단.
        rfc_claimed: !!normalizeClaimKey(c.rfc),
        rfc_claimed_at: c.rfc_claimed_at || null,
        rejected_reason: c.rejected_reason || null,
        syd_ref_code: c.syd_ref_code || null,
        syd_ref_buy_price: c.syd_ref_buy_price == null ? null : Number(c.syd_ref_buy_price),
        syd_ref_list_price: c.syd_ref_list_price == null ? null : Number(c.syd_ref_list_price),
        syd_ref_discount: c.syd_ref_discount == null ? null : Number(c.syd_ref_discount),
        ctr_ref_code: c.ctr_ref_code || null,
        ctr_ref_list_price: c.ctr_ref_list_price == null ? null : Number(c.ctr_ref_list_price),
        suggested_discount: c.suggested_discount == null ? null : Number(c.suggested_discount),
        ship_address: c.ship_address || null,
        branch_count: c.branch_count == null ? null : Number(c.branch_count),
        team_id: c.team_id, team_name: c.team_name, stage_id: c.stage_id, stage_name: stageLabel(c.stage_name),
        owner_id: c.owner_id, owner_name: c.owner_name, stage_since: c.stage_since_str,
      },
      invoices: invs.map((i) => ({ ...i, total_mxn: r2(i.total_mxn), paid: r2(i.paid), outstanding: r2(i.outstanding) })),
      important_skus: importantSkus,
      reorder_summary: reorderSummary,
      sku_stats: { distinct: skuRows.length, total_qty: grandQty, important: importantSkus.length },
      summary: {
        ytd_actual: r2(ytd.actual),     // 연초~현재 누적 매출실적
        year_target: yearTarget,        // 올해 고객 월 목표 합(매출 목표 메뉴에서 설정)
        year: new Date().getUTCFullYear(),
      },
    };
  });

  // ===== 기본할인(%)·외상일 변경 통제 헬퍼 =====
  // 숫자 정규화: 빈값/무효 → 현재값 유지(applyCustomerUpdate 의 keepNum 과 동일 의미)
  // 0235 · 화면·수정·승인은 **약정** 할인/외상일로 본다. customers.discount/credit_days 는
  //   서류 관문(신규 고객)이 적용된 실효값이라, 그대로 비교하면 서류 없는 고객 수정이 매번
  //   「할인 변경」으로 잡힌다. 실효값은 *_effective 로 따로 싣는다.
  function agreedTerms(c) {
    if (!c) return c;
    if (c.discount_agreed !== undefined && c.discount_agreed !== null) { c.discount_effective = c.discount; c.discount = c.discount_agreed; }
    if (c.credit_days_agreed !== undefined && c.credit_days_agreed !== null) { c.credit_days_effective = c.credit_days; c.credit_days = c.credit_days_agreed; }
    return c;
  }
  function termsNum(v, cur) {
    if (v === undefined || v === '' || v === null) return Number(cur) || 0;
    const n = Number(v); return Number.isFinite(n) ? n : (Number(cur) || 0);
  }
  // 요청 본문 b 를 현재값 c 와 비교해 할인/외상일 실변경 목록 반환
  function detectTermsChanges(c, b) {
    const out = [];
    const nd = termsNum(b.discount, c.discount);
    const nc = termsNum(b.credit_days, c.credit_days);
    if (nd !== (Number(c.discount) || 0)) out.push({ field: 'discount', old: Number(c.discount) || 0, nv: nd });
    if (nc !== (Number(c.credit_days) || 0)) out.push({ field: 'credit_days', old: Number(c.credit_days) || 0, nv: nc });
    return out;
  }
  // 20261019dpin · 디렉터 지시: 「최초 등록은 PIN 없이, **할인율을 수정할 때만** PIN」.
  //   기본할인(%) 값이 실제로 바뀌는 디렉터 경로(고객 수정 즉시반영 · 수정요청 승인)만 PIN 을 받는다.
  //   신규 등록 · 사후승인 · 서류 관문 승인(약정값을 켜는 것)은 PIN 없이 간다.
  //   외상일만 바뀌면 PIN 없음(지시가 할인율에 한정).
  //   반환: null = 통과, 아니면 { code, body } 로 그대로 응답.
  async function discountPinError(changes, userId, pin) {
    if (!(changes || []).some((ch) => ch.field === 'discount')) return null;
    const p = String(pin == null ? '' : pin).trim();
    if (!p) return { code: 403, body: { error: 'pin_required', note: '기본할인(%)을 수정하려면 디렉터 PIN 이 필요합니다.' } };
    const me = (await query(`SELECT pin_hash FROM users WHERE id=$1 AND deleted_at IS NULL`, [userId])).rows[0];
    if (!me || !verifyPin(p, me.pin_hash)) return { code: 403, body: { error: 'bad_pin', note: 'PIN 이 올바르지 않습니다.' } };
    return null;
  }
  // 변경이력 기록(변경 필드당 1행, 같은 이유·조건 공유)
  async function logTermsHistory(customerId, changes, { reason, conditions, changedBy, approvedBy }) {
    for (const ch of changes) {
      await query(
        `INSERT INTO customer_terms_history (customer_id, field, old_value, new_value, reason, conditions, changed_by, approved_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [customerId, ch.field, ch.old, ch.nv, reason || null, conditions || null, changedBy || null, approvedBy || null]);
    }
  }

  // 기본할인·외상일 변경이력 — 고객을 볼 수 있으면 열람 가능
  app.get('/api/customers/:id/terms-history', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const c = (await query(`SELECT team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(req.ctx.perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const rows = (await query(
      `SELECT h.id, h.field, h.old_value, h.new_value, h.reason, h.conditions,
              to_char(h.changed_at,'YYYY-MM-DD HH24:MI') AS changed_at,
              cb.name AS changed_by_name, ab.name AS approved_by_name
         FROM customer_terms_history h
         LEFT JOIN users cb ON cb.id=h.changed_by
         LEFT JOIN users ab ON ab.id=h.approved_by
        WHERE h.customer_id=$1
        ORDER BY h.changed_at DESC, h.id DESC LIMIT 200`, [id])).rows;
    return { items: rows.map((r) => ({
      id: Number(r.id), field: r.field,
      old_value: r.old_value == null ? null : Number(r.old_value),
      new_value: r.new_value == null ? null : Number(r.new_value),
      reason: r.reason, conditions: r.conditions, changed_at: r.changed_at,
      changed_by_name: r.changed_by_name, approved_by_name: r.approved_by_name,
    })) };
  });

  // 상담·방문 이력 — 현장방문 + 수기 미팅 통합, 최신순.
  //   열람 범위(디렉터 확정 2026-08-19): **디렉터는 전체 · 그 외는 본인이 기록한 것만**.
  //   영업활동(pipeline) 화면의 ownerCond 와 동일한 규칙 — 고객 화면을 통해 남의 상담
  //   내용이 새어나가지 않게 한다. 팀 가시성(canViewTeam)은 그 위에 추가로 건다.
  //   방문 목적 컬럼이 없으므로 카테고리는 visitTags 가 텍스트에서 자동 추출한다.
  app.get('/api/customers/:id/visits', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const perm = req.ctx.perm;
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return reply.code(400).send({ error: 'bad_id' });
    const c = (await query(`SELECT team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });

    const isDir = perm.role === 'director';
    const ownerId = isDir ? null : Number(perm.userId);

    const vParams = [id, VISIT_TZ, VISIT_HIST_LIMIT];
    let vOwner = '';
    if (!isDir) { vParams.push(ownerId); vOwner = ` AND v.created_by = $${vParams.length}`; }
    const visits = (await query(
      `SELECT v.id,
              to_char(v.visit_date,'YYYY-MM-DD') AS visit_date,
              to_char(v.visited_at AT TIME ZONE $2,'HH24:MI') AS visit_time,
              v.met_person, v.talk_note, v.insight_note, u.name AS by_name
         FROM sales_visits v
         LEFT JOIN users u ON u.id = v.created_by
        WHERE v.customer_id = $1 AND v.deleted_at IS NULL${vOwner}
        ORDER BY v.visit_date DESC, v.visited_at DESC, v.id DESC
        LIMIT $3`, vParams)).rows;

    const vids = visits.map((v) => Number(v.id));
    let pendings = []; let recordings = [];
    if (vids.length) {
      pendings = (await query(
        `SELECT id, visit_id, content, due_date, done FROM sales_visit_pendings
          WHERE visit_id = ANY($1) ORDER BY done ASC, (due_date IS NULL) ASC, due_date ASC, id ASC`,
        [vids])).rows;
      try {
        recordings = (await query(
          `SELECT id, visit_id, status, summary_json FROM sales_visit_recordings
            WHERE visit_id = ANY($1) ORDER BY id ASC`, [vids])).rows;
      } catch (_) { recordings = []; }   // 0165 이전 DB 호환
    }

    // 수기 미팅(자동 생성된 '[현장방문]' 미팅은 방문 줄과 중복되므로 제외)
    const mParams = [id, VISIT_HIST_LIMIT];
    let mOwner = '';
    if (!isDir) { mParams.push(ownerId); mOwner = ` AND m.created_by = $${mParams.length}`; }
    const meetings = (await query(
      `SELECT m.id, to_char(m.meeting_date,'YYYY-MM-DD') AS meeting_date, m.note,
              u.name AS by_name, sb.name AS stage_before_name, sa.name AS stage_after_name
         FROM customer_meetings m
         LEFT JOIN users  u  ON u.id  = m.created_by
         LEFT JOIN stages sb ON sb.id = m.stage_before
         LEFT JOIN stages sa ON sa.id = m.stage_after
        WHERE m.customer_id = $1 AND COALESCE(m.note,'') NOT LIKE '[현장방문]%'${mOwner}
        ORDER BY m.meeting_date DESC, m.id DESC
        LIMIT $2`, mParams)).rows;

    // 상한에 걸렸으면 총계·최초방문일이 '담긴 범위' 기준임을 화면에 알린다.
    const truncated = visits.length >= VISIT_HIST_LIMIT || meetings.length >= VISIT_HIST_LIMIT;
    const mxToday = mxTodayStr(new Date());
    return { mx_today: mxToday, limit: VISIT_HIST_LIMIT, scope: isDir ? 'all' : 'own',
      ...assembleVisitHistory({ visits, meetings, pendings, recordings, mxToday, truncated }) };
  });

  // =====================================================================
  // 📈 월별 거래 요약 — 견적 · 매출 · 수금 (2026-09-04)
  //
  //   고객 하나를 놓고 "이 고객에게 얼마를 견적했고, 얼마가 매출이 됐고, 얼마가 들어왔나"
  //   를 월 단위 한 표로 본다. 금액 기준은 다른 화면(영업 대시보드·커미션)과 맞춘다:
  //     · 견적 = quotes.subtotal_mxn (ex-IVA 스냅샷) · quote_date 월
  //         취소(cancelled)·삭제 제외. **가격표(pricelist)는 견적이 아니므로 제외**
  //         (금액 0 으로 기록되지만 건수를 부풀린다).
  //     · 매출 = sales_invoices.subtotal_mxn (ex-IVA) · inv_date 월 · status='posted'
  //     · 수금 = sales_payment_allocations 중 **현금 배분(kind='cash')** · 입금일(pay_date) 월
  //         실입금액은 IVA 포함이므로 ex-IVA 환산액(배분액 ÷ (1+그 인보이스 IVA율))을 함께 준다.
  //         nota de crédito 비현금 반제(kind='nota_credito')는 수금이 아니므로 따로 뺀다.
  //     · 선수금(advance) 은 인보이스에 배분되기 전이라 수금 칸에 안 들어간다 — 따로 준다.
  //   금액 가시성은 영업 대시보드와 동일한 sales_amount 필드 권한을 탄다(없으면 locked).
  // =====================================================================
  app.get('/api/customers/:id/monthly-summary', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const perm = req.ctx.perm;
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return reply.code(400).send({ error: 'bad_id' });
    const c = (await query(
      `SELECT id, code, name, team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });

    // 거래가 있는 연도(연도 ◀▶ 이동 범위). 셋 중 하나라도 있으면 그 해를 넣는다.
    const yearRows = (await query(
      `SELECT DISTINCT y FROM (
          SELECT to_char(quote_date,'YYYY') AS y FROM quotes
           WHERE customer_id=$1 AND deleted_at IS NULL AND status NOT IN ('cancelled','pricelist')
          UNION ALL
          SELECT to_char(inv_date,'YYYY') FROM sales_invoices
           WHERE customer_id=$1 AND status='posted'
          UNION ALL
          SELECT to_char(sp.pay_date,'YYYY') FROM sales_payments sp
           WHERE sp.customer_id=$1
        ) t WHERE y IS NOT NULL ORDER BY y DESC`, [id])).rows;
    const years = yearRows.map((r) => Number(r.y));
    const thisYear = Number(mxTodayStr(new Date()).slice(0, 4));
    if (!years.includes(thisYear)) years.unshift(thisYear);
    years.sort((a, b) => b - a);

    const year = req.query.year === undefined || req.query.year === '' ? thisYear : Number(req.query.year);
    if (!Number.isInteger(year) || year < 2000 || year > 2100) return reply.code(400).send({ error: 'bad_year' });
    const ys = String(year);

    const customer = { id: Number(c.id), code: c.code, name: c.name };
    const seeSales = fieldVisible(perm, 'sales_amount');
    if (!seeSales) return { customer, year, years, locked: true, months: [], totals: null };

    const qRows = (await query(
      `SELECT to_char(quote_date,'MM') AS m,
              COUNT(*)::int AS cnt,
              COALESCE(SUM(subtotal_mxn),0) AS amt,
              COUNT(*) FILTER (WHERE status='converted')::int AS conv_cnt,
              COALESCE(SUM(subtotal_mxn) FILTER (WHERE status='converted'),0) AS conv_amt
         FROM quotes
        WHERE customer_id=$1 AND deleted_at IS NULL
          AND status NOT IN ('cancelled','pricelist')
          AND to_char(quote_date,'YYYY')=$2
        GROUP BY 1`, [id, ys])).rows;

    const sRows = (await query(
      `SELECT to_char(inv_date,'MM') AS m,
              COUNT(*)::int AS cnt,
              COALESCE(SUM(subtotal_mxn),0) AS amt,
              COALESCE(SUM(total_mxn),0)    AS amt_incl
         FROM sales_invoices
        WHERE customer_id=$1 AND status='posted' AND to_char(inv_date,'YYYY')=$2
        GROUP BY 1`, [id, ys])).rows;

    // 수금 — 현금 배분만. kind 컬럼(0085) 이전 DB 호환: COALESCE(kind,'cash')
    const pRows = (await query(
      `SELECT to_char(sp.pay_date,'MM') AS m,
              COUNT(DISTINCT sp.id)::int AS cnt,
              COALESCE(SUM(a.amount),0) AS amt_incl,
              COALESCE(SUM(a.amount / (1 + COALESCE(i.iva_rate,16)/100.0)),0) AS amt_ex
         FROM sales_payment_allocations a
         JOIN sales_payments sp ON sp.id = a.payment_id
         JOIN sales_invoices  i  ON i.id = a.invoice_id
        WHERE sp.customer_id=$1 AND COALESCE(a.kind,'cash')='cash'
          AND i.status <> 'deleted'
          AND to_char(sp.pay_date,'YYYY')=$2
        GROUP BY 1`, [id, ys])).rows;

    // 비현금 반제(nota de crédito) — 수금은 아니지만 인보이스 잔액을 줄이므로 따로 보여준다.
    let ncRows = [];
    try {
      ncRows = (await query(
        `SELECT to_char(nc.applied_at AT TIME ZONE $3,'MM') AS m,
                COALESCE(SUM(nc.base_mxn),0)  AS amt_ex,
                COALESCE(SUM(nc.total_mxn),0) AS amt_incl
           FROM notas_credito nc
          WHERE nc.customer_id=$1 AND nc.status='applied' AND nc.applied_at IS NOT NULL
            AND to_char(nc.applied_at AT TIME ZONE $3,'YYYY')=$2
          GROUP BY 1`, [id, ys, VISIT_TZ])).rows;
    } catch (_) { ncRows = []; }   // 0085 이전 DB 호환

    // 선수금(미배분 입금) — 그 달 입금 총액 − 그 달 배분액. 음수는 0으로 절사.
    let advRows = [];
    try {
      advRows = (await query(
        `SELECT to_char(pay_date,'MM') AS m, COALESCE(SUM(advance_amount),0) AS amt_incl
           FROM sales_payments
          WHERE customer_id=$1 AND to_char(pay_date,'YYYY')=$2
          GROUP BY 1`, [id, ys])).rows;
    } catch (_) { advRows = []; }

    // ── 결제 지연 (2026-09-04) ────────────────────────────────────────────
    //   완납일·지연 정의는 수금/정산 화면과 **같은 것**(ar.js AR_SETTLED_SQL + AR_PAID_EPS).
    //     지연 = 완납일 − 만기일   (양수 지연 · 0 정시 · 음수 조기)
    //     실제 결제일수 = 완납일 − 인보이스일 (약정 외상일 credit_days 와 비교용)
    //   디렉터 확정 2026-09-04: **수금월(완납된 달) 기준**으로 그 달 행에 붙이고,
    //     평균은 **건수 단순평균**, **미완납 건은 평균에서 제외**하고 따로 경고로 보여준다.
    const invRows = (await query(
      `SELECT i.id, i.sat_no, i.credit_days,
              to_char(i.inv_date,'YYYY-MM-DD') AS inv_date,
              to_char(i.due_date,'YYYY-MM-DD') AS due_date,
              i.total_mxn, i.subtotal_mxn,
              COALESCE(pa.paid,0) AS paid,
              to_char(sd.settled_dt,'YYYY-MM-DD') AS settled_date,
              (sd.settled_dt - i.due_date) AS delay_days,
              (sd.settled_dt - i.inv_date) AS actual_days,
              COALESCE(sd.has_nc,false) AS has_nc
         FROM sales_invoices i
         LEFT JOIN (SELECT invoice_id, SUM(amount) AS paid
                      FROM sales_payment_allocations GROUP BY invoice_id) pa ON pa.invoice_id=i.id
         ${AR_SETTLED_SQL} sd ON sd.invoice_id=i.id
        WHERE i.customer_id=$1 AND i.status='posted'`, [id])).rows;

    const today = mxTodayStr(new Date());
    const dayDiff = (a, b) => Math.round((Date.parse(a + 'T00:00:00Z') - Date.parse(b + 'T00:00:00Z')) / 86400000);
    const settled = [], openInv = [];
    for (const r of invRows) {
      const outstanding = r2(Number(r.total_mxn) - Number(r.paid));
      const paidFull = outstanding < AR_PAID_EPS;
      if (paidFull && r.settled_date && r.due_date) {
        settled.push({
          sat_no: r.sat_no, inv_date: r.inv_date, due_date: r.due_date, settled_date: r.settled_date,
          amount: r2(r.total_mxn), credit_days: r.credit_days == null ? null : Number(r.credit_days),
          delay: Number(r.delay_days), actual_days: r.actual_days == null ? null : Number(r.actual_days),
          has_nc: r.has_nc === true,
          ym: String(r.settled_date).slice(0, 7),
        });
      } else if (!paidFull) {
        const od = r.due_date ? dayDiff(today, r.due_date) : null;
        openInv.push({ sat_no: r.sat_no, due_date: r.due_date, outstanding, overdue_days: od != null && od > 0 ? od : 0 });
      }
    }
    const avg = (arr) => (arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length * 10) / 10 : null);
    const median = (arr) => {
      if (!arr.length) return null;
      const s = [...arr].sort((a, b) => a - b); const h = Math.floor(s.length / 2);
      return s.length % 2 ? s[h] : Math.round((s[h - 1] + s[h]) / 2 * 10) / 10;
    };
    const yearSettled = settled.filter((s) => s.ym.startsWith(ys));
    const dly = yearSettled.map((s) => s.delay);
    const onTime = yearSettled.filter((s) => s.delay <= 0).length;
    const worst = yearSettled.reduce((w, s) => (w == null || s.delay > w.delay ? s : w), null);
    const actualDays = yearSettled.filter((s) => s.actual_days != null).map((s) => s.actual_days);
    const creditDays = yearSettled.filter((s) => s.credit_days != null).map((s) => s.credit_days);
    const overdueOpen = openInv.filter((o) => o.overdue_days > 0);
    const delay = {
      settled_count: yearSettled.length,
      avg_delay: avg(dly),
      median_delay: median(dly),
      on_time_count: onTime,
      on_time_pct: yearSettled.length ? Math.round(onTime / yearSettled.length * 1000) / 10 : null,
      worst: worst ? { delay: worst.delay, sat_no: worst.sat_no, due_date: worst.due_date,
        settled_date: worst.settled_date, amount: worst.amount } : null,
      buckets: {
        early_ontime: yearSettled.filter((s) => s.delay <= 0).length,
        d1_7: yearSettled.filter((s) => s.delay >= 1 && s.delay <= 7).length,
        d8_30: yearSettled.filter((s) => s.delay >= 8 && s.delay <= 30).length,
        d30plus: yearSettled.filter((s) => s.delay > 30).length,
      },
      avg_actual_days: avg(actualDays),        // 인보이스일 → 완납일 실제 소요
      avg_credit_days: avg(creditDays),        // 그 건들의 약정 외상일 평균
      open_overdue: {                          // 아직 안 낸 연체 건(평균에서 제외 · 연도 무관)
        count: overdueOpen.length,
        amount: r2(overdueOpen.reduce((a, o) => a + o.outstanding, 0)),
        max_days: overdueOpen.reduce((m, o) => Math.max(m, o.overdue_days), 0) || null,
      },
      open_not_due: openInv.length - overdueOpen.length,   // 만기 전 미수 건
    };
    // 월(완납월)별 지연 — 단순평균
    const delayByMonth = {};
    for (const s of yearSettled) {
      const m = s.ym.slice(5, 7);
      (delayByMonth[m] = delayByMonth[m] || []).push(s.delay);
    }

    const pick = (rows, m) => rows.find((r) => r.m === m) || {};
    const months = [];
    for (let i = 1; i <= 12; i++) {
      const m = String(i).padStart(2, '0');
      const q = pick(qRows, m), s = pick(sRows, m), p = pick(pRows, m);
      const nc = pick(ncRows, m), ad = pick(advRows, m);
      months.push({
        month: i,
        ym: `${ys}-${m}`,
        quote_count: Number(q.cnt || 0),
        quote_amount: r2(q.amt || 0),                 // ex-IVA
        quote_converted_count: Number(q.conv_cnt || 0),
        quote_converted_amount: r2(q.conv_amt || 0),  // ex-IVA
        sales_count: Number(s.cnt || 0),
        sales_amount: r2(s.amt || 0),                 // ex-IVA
        sales_amount_incl: r2(s.amt_incl || 0),       // IVA 포함(참고)
        collect_count: Number(p.cnt || 0),
        collect_amount: r2(p.amt_ex || 0),            // ex-IVA 환산
        collect_amount_incl: r2(p.amt_incl || 0),     // 실입금액(IVA 포함)
        nc_amount: r2(nc.amt_ex || 0),                // 비현금 반제 ex-IVA
        nc_amount_incl: r2(nc.amt_incl || 0),
        advance_amount_incl: r2(ad.amt_incl || 0),    // 선수금(미배분)
        settled_count: (delayByMonth[m] || []).length,          // 그 달에 완납된 인보이스 건수
        delay_avg: avg(delayByMonth[m] || []),                  // 그 건들의 지연 단순평균(일)
      });
    }
    const sum = (k) => r2(months.reduce((a, x) => a + Number(x[k] || 0), 0));
    const totals = {
      quote_count: months.reduce((a, x) => a + x.quote_count, 0),
      quote_amount: sum('quote_amount'),
      quote_converted_count: months.reduce((a, x) => a + x.quote_converted_count, 0),
      quote_converted_amount: sum('quote_converted_amount'),
      sales_count: months.reduce((a, x) => a + x.sales_count, 0),
      sales_amount: sum('sales_amount'),
      sales_amount_incl: sum('sales_amount_incl'),
      collect_count: months.reduce((a, x) => a + x.collect_count, 0),
      collect_amount: sum('collect_amount'),
      collect_amount_incl: sum('collect_amount_incl'),
      nc_amount: sum('nc_amount'),
      nc_amount_incl: sum('nc_amount_incl'),
      advance_amount_incl: sum('advance_amount_incl'),
    };
    totals.conversion_pct = totals.quote_amount > 0
      ? Math.round(totals.quote_converted_amount / totals.quote_amount * 1000) / 10 : null;

    // 미수 잔액(연도 무관 — 현재 시점 기준) · 표 아래 한 줄로 보여준다.
    const ar = (await query(
      `SELECT COALESCE(SUM(i.total_mxn - COALESCE(p.paid,0)),0) AS outstanding,
              COALESCE(SUM(CASE WHEN i.due_date < CURRENT_DATE
                                THEN (i.total_mxn - COALESCE(p.paid,0)) ELSE 0 END),0) AS overdue
         FROM sales_invoices i
         LEFT JOIN (SELECT invoice_id, SUM(amount) AS paid
                      FROM sales_payment_allocations GROUP BY invoice_id) p ON p.invoice_id=i.id
        WHERE i.customer_id=$1 AND i.status='posted'`, [id])).rows[0];

    return {
      customer, year, years, locked: false, months, totals, delay,
      ar: { outstanding: r2(ar.outstanding), overdue: r2(ar.overdue) },
      note: '금액은 IVA 제외(ex-IVA) 기준 · 수금은 실입금액을 그 인보이스 IVA율로 환산 · '
          + '지연 = 완납일 − 만기일(완납 건만, 건수 단순평균)',
    };
  });

  // =====================================================================
  // 0185 · 고객 선점(claim) 조회  (0188 — 선점 키는 RFC)
  //
  //   100% 커미션 영업사원은 서로의 존재를 모른다. 그래서 "이미 남이 잡은 고객인가"
  //   만 확인할 수 있어야 하고, 그 이상(매출·상담·연락처·팀·금액)은 절대 보이면 안 된다.
  //   → 반환 필드는 **상호 · RFC · 담당 영업사원 이름 · 등록일 · 승인상태** 뿐이다.
  //   팀 스코프를 타지 않는 유일한 고객 조회 경로이므로 SELECT 목록을 함부로 늘리지 말 것.
  // =====================================================================
  app.get('/api/customers/claim-check', { preHandler: [authGuard, requirePage('customers')] }, async (req) => {
    const regOn = await regColumnsReady();
    const name = String(req.query.name || req.query.q || '').trim();
    const rfcN = normalizeClaimKey(req.query.rfc);
    const conN = normalizeClaimKey(req.query.constancia);
    if (!name && !rfcN && !conN) return { items: [], note: 'empty_query' };
    if (name && name.length < 2 && !rfcN && !conN) return { items: [], note: 'min_2_chars' };

    const where = [], params = [];
    if (name && name.length >= 2) { params.push(`%${name}%`); where.push(`c.name ILIKE $${params.length}`); }
    if (rfcN) {
      params.push(rfcN);
      where.push(regOn ? `c.rfc_norm = $${params.length}`
                       : `upper(regexp_replace(coalesce(c.rfc,''),'[^A-Za-z0-9]','','g')) = $${params.length}`);
    }
    if (conN && regOn) { params.push(conN); where.push(`c.constancia_no_norm = $${params.length}`); }

    const statusExpr = regOn ? `COALESCE(c.approval_status,'approved')` : `'approved'`;
    const rows = (await query(
      `SELECT c.id, c.name, c.rfc, u.name AS owner_name,
              to_char(c.created_at,'YYYY-MM-DD') AS registered_at,
              ${statusExpr} AS approval_status,
              ${regOn ? 'c.constancia_no_norm' : 'NULL::text'} AS con_norm,
              ${regOn ? 'c.rfc_norm' : `upper(regexp_replace(coalesce(c.rfc,''),'[^A-Za-z0-9]','','g'))`} AS rfc_n
         FROM customers c
         LEFT JOIN users u ON u.id=c.owner_id
        WHERE c.deleted_at IS NULL AND ${statusExpr} <> 'rejected' AND (${where.join(' OR ')})
        ORDER BY c.created_at LIMIT 30`, params)).rows;

    // 0193 · 내가 넣으려는 RFC 로 대기 중인 선점 요청이 있으면 그것도 「선점됨」이다.
    const pendingClaim = rfcN ? await findRfcHolder(rfcN, { excludeCustomerId: null }) : null;
    const claimPending = !!(pendingClaim && pendingClaim.kind === 'claim');

    return {
      items: rows.map((r) => ({
        // 0193 · id 는 「RFC 없는 고객에 선점 요청」을 걸기 위해 필요하다.
        //   RFC 가 이미 있는(=선점된) 고객은 요청 대상이 아니므로 id 를 내보내지 않는다.
        customer_id: r.rfc_n ? null : Number(r.id),
        name: r.name, rfc: r.rfc || null,
        has_rfc: !!r.rfc_n,                    // false = 선점 미성립 → 내가 RFC 를 넣어 가져올 수 있다
        owner_name: r.owner_name || '(담당자 미지정)',
        registered_at: r.registered_at,
        approval_status: r.approval_status,
        // 어떤 키로 걸렸는지 — 화면에서 "이 RFC 는 이미 선점됨" 을 정확히 안내하기 위함
        matched_constancia: !!(conN && r.con_norm && r.con_norm === conN),
        matched_rfc: !!(rfcN && r.rfc_n && r.rfc_n === rfcN),
        // 상호만으로 걸린 후보의 유사도(경고 강약 표시용)
        name_score: name && name.length >= 2 ? nameSimilarity(name, r.name) : null,
      })),
      // 이 둘 중 하나라도 true 면 등록이 차단된다 (0188 · 주 판정은 RFC)
      blocked_constancia: rows.some((r) => conN && r.con_norm && r.con_norm === conN),
      blocked_rfc: rows.some((r) => rfcN && r.rfc_n && r.rfc_n === rfcN) || claimPending,
      // 0193 · 「남이 먼저 요청했지만 아직 승인 안 됨」 은 별도로 알려 준다(문구가 달라야 한다).
      claim_pending: claimPending,
      claim_pending_note: claimPending ? rfcHolderNote(pendingClaim) : null,
      migration_required: !regOn,
      // 0188 마이그레이션 전이면 DB 유니크가 없어 동시 등록 극단 케이스가 뚫릴 수 있다.
      rfc_db_lock: await rfcClaimReady(),
      claim_transfer_on: await claimTableReady(),
    };
  });

  // =====================================================================
  // 0185 · 기준품목(SYD) 구매단가 → 할인율 산출 + 제안
  //
  //   ① 고객이 SYD 1516049 를 얼마에 사는지 입력  → SYD List Price 대비 할인율
  //   ② 그 구매가보다 5% 싸게 주는 목표가         → 구매단가 × 0.95
  //   ③ 목표가를 만드는 CTR 정가 대비 할인율      → **제안 할인율**
  //   CTR 정가는 1516049 에 매칭된 실제 CTR 제품의 List Price 를 쓴다(상수 마크업 아님).
  //
  //   권한: 고객을 등록할 수 있는 사람(requirePageEdit('customers')).
  //         할인율을 정하려면 정가를 봐야 하므로 sale_price 필드권한과 별도로 연다.
  // =====================================================================
  app.get('/api/customers/price-baseline', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req) => {
    const code = String(req.query.code || SYD_BASE_CODE).trim();
    const buy = req.query.buy;
    const out = { base_code: code, found: false, ctr_code: null, product_name: null,
      syd_list_price: null, ctr_list_price: null, calc: null };
    if (!code) return out;
    const esc = code.replace(/([%_\\])/g, '\\$1');
    // 매칭: product_syd_codes 정확일치 우선 → products.scode 부분일치 폴백 (syd-baseline 과 동일 규칙)
    let row = (await query(
      `SELECT p.code, p.name, p.list_price_syd, p.list_price
         FROM product_syd_codes sc
         JOIN products p ON p.id = sc.product_id AND p.deleted_at IS NULL
        WHERE sc.syd_code = $1
        ORDER BY p.code LIMIT 1`, [code])).rows[0];
    if (!row) {
      row = (await query(
        `SELECT code, name, list_price_syd, list_price
           FROM products
          WHERE deleted_at IS NULL AND scode ILIKE $1
          ORDER BY code LIMIT 1`, ['%' + esc + '%'])).rows[0];
    }
    if (!row) return out;
    out.found = true;
    out.ctr_code = row.code;
    out.product_name = row.name;
    out.syd_list_price = row.list_price_syd != null ? Number(row.list_price_syd) : null;
    out.ctr_list_price = row.list_price != null ? Number(row.list_price) : null;
    if (buy != null && buy !== '') {
      out.calc = computeBaselineDiscount({
        buy_price: buy, syd_list_price: out.syd_list_price, ctr_list_price: out.ctr_list_price });
    }
    return out;
  });

  // =====================================================================
  // 고객 등록 (0185 → 0188 → **0193** 개정)
  //   · **RFC 는 선택 입력**이다(0193). 없어도 등록된다 — 상담·방문 이력을 먼저 쌓기 위함.
  //     넣으면 0188 과 똑같이 엄격하게 검증하고, 그 시점에 선점이 성립한다(rfc_claimed_at).
  //   · RFC 를 비운 등록은 **선점이 없다.** 나중에 다른 영업사원이 같은 고객에 RFC 를 먼저
  //     넣으면 그 사람에게 우선권이 간다(→ POST /api/customers/:id/rfc-claim).
  //   · 상호명이 비슷한 기존 고객이 있으면 **경고만** 한다(차단하지 않음) — RFC 없이는
  //     법적 동일성을 판단할 수 없고, 지점·법인 분리가 흔해 차단은 오탐이 더 비싸다.
  //   · CONSTANCIA 번호·PDF 는 선택 — 넣으면 그 번호도 함께 잠긴다(0185 유니크 유지).
  //   · 기준품목(SYD) 구매단가는 **여전히 필수** — 할인율 산출의 유일한 근거다.
  //   · 0193: **디렉터가 등록해도 approval_status='pending'.** 모든 신규 고객이 예외 없이
  //     승인 대기 탭을 한 번 거친다(승인 경로가 하나여야 이력·커미션 귀속이 흔들리지 않는다).
  // =====================================================================
  app.post('/api/customers', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const b = req.body || {};
    const perm = req.ctx.perm;
    if (!(await regColumnsReady())) {
      return reply.code(503).send({ error: 'migration_required',
        note: '고객 등록 고도화(0185) 마이그레이션이 아직 적용되지 않았습니다. 디렉터에게 문의하세요.' });
    }
    if (!b.name) return reply.code(400).send({ error: 'missing_fields' });

    // ── 20260918tier → **0267 개정** · 이메일·전화만 필수로 남긴다 ────
    //   razonSocial = name(위에서 검사) · contactEmail · contactPhone · businessTypeId = customer_type.
    //   이메일·전화를 계속 막는 이유: **상대(CRM)가 새 RFC 에 요구하는 값**이고, 우리가 없는 값을
    //   지어내 보낼 수는 없다. 비우고 등록하면 그 고객은 CRM 등록이 거절되어 카달록에서
    //   가격도 재고도 못 본다 — 입력 한 칸을 아끼고 고객을 잃는 거래다.
    //   회사 종류(TIER)는 **풀었다**(디렉터 지시 2026-10-09). 비어 있으면 CRM 전송 때
    //   `businessTypeId` 를 D 로 메운다(crmSync.businessTypeFallback — 2026-09-23).
    const contactIn = String(b.contact == null ? '' : b.contact).trim();
    const phoneIn = String(b.phone == null ? '' : b.phone).trim();
    const tierIn = String(b.customer_type == null ? '' : b.customer_type).trim();
    if (!contactIn) return reply.code(400).send({ error: 'contact_required', note: CONTACT_REQUIRED_NOTE });
    if (!isEmailAddr(contactIn)) return reply.code(400).send({ error: 'contact_invalid', note: CONTACT_INVALID_NOTE });
    if (!phoneIn) return reply.code(400).send({ error: 'phone_required',
      note: '전화번호를 입력해야 고객을 등록할 수 있습니다 — CRM 이 새 RFC 에 요구하는 항목입니다.' });
    b.contact = contactIn; b.phone = phoneIn; b.customer_type = tierIn || null;

    const teamId = b.team_id ? Number(b.team_id) : (perm.teamId || null);
    if (!teamId) return reply.code(400).send({ error: 'team_required' });
    if (!canEditTeam(perm, teamId)) return reply.code(403).send({ error: 'forbidden_team' });

    // ── ① RFC 선택 입력 (0193) ────────────────────────────────────────
    //   비우면 통과한다 — 다만 **선점은 성립하지 않는다**.
    //   넣으면 0188 과 동일하게 엄격히 본다(느슨하게 봐 주면 「아무 문자열로 선점」 우회가 살아난다).
    const rfcChk = validateRfcOptional(b.rfc);
    if (!rfcChk.ok) {
      return reply.code(400).send({ error: rfcChk.error, note: RFC_ERROR_NOTE[rfcChk.error] });
    }
    const rfcClean = rfcChk.value;                 // null 가능. 대문자·구분자 제거본을 저장한다
    const rfcNorm = normalizeClaimKey(rfcClean);   // null 가능

    // ── ② CONSTANCIA 번호 + 스캔본 (선택) ─────────────────────────────
    //   넣으면 그 번호도 0185 유니크로 함께 잠긴다. 안 넣어도 등록·선점은 된다.
    const conNo = String(b.constancia_no || '').trim();
    const conNorm = normalizeClaimKey(conNo);
    const doc = b.constancia_file || null;
    const docName = String(doc?.file_name || '').trim();
    const docMime = String(doc?.mime_type || '').trim();
    const docB64 = String(doc?.data_base64 || '');
    const hasDoc = !!(docName || docMime || docB64);
    let docBuf = null;
    if (hasDoc) {
      if (!docName || !docMime || !docB64) {
        return reply.code(400).send({ error: 'constancia_file_incomplete',
          note: 'CONSTANCIA 첨부가 불완전합니다. 파일을 다시 선택하세요.' });
      }
      if (!ALLOWED_DOC_MIME.includes(docMime)) {
        return reply.code(400).send({ error: 'unsupported_type', note: 'PDF·JPEG·PNG·WEBP만 첨부할 수 있습니다.' });
      }
      try { docBuf = Buffer.from(docB64, 'base64'); } catch (_) { return reply.code(400).send({ error: 'bad_base64' }); }
      if (!docBuf.length) return reply.code(400).send({ error: 'empty_file' });
      if (docBuf.length > MAX_DOC_BYTES) {
        return reply.code(400).send({ error: 'too_large', note: '파일은 5MB 이하만 가능합니다.' });
      }
    }

    // ── ②-b 서류 3종 (등록 화면에서 바로 첨부) ────────────────────────
    //   커미셔너 정책: constancia · 주소증명 · 서스펜션 구매 팩투라 3종이 모두 붙으면
    //   그 고객은 독점 대상이고 외상 30일 조건이 적용된다(디렉터 승인 시 확정).
    //   여기서는 **파일을 받아 보관**만 한다 — 조건 적용 여부는 승인 화면의 판단이다.
    //   `constancia_file`(단건 · 기존 경로)은 그대로 살려 두고, 추가분만 docs[] 로 받는다.
    const EXTRA_DOC_TYPES = ['constancia', 'domicilio', 'factura_compra', 'other'];
    const rawDocs = Array.isArray(b.docs) ? b.docs.slice(0, 6) : [];
    const extraDocs = [];
    for (const d of rawDocs) {
      const nm = String(d?.file_name || '').trim();
      const mm = String(d?.mime_type || '').trim();
      const bb = String(d?.data_base64 || '');
      if (!nm && !mm && !bb) continue;                     // 빈 슬롯은 건너뛴다
      if (!nm || !mm || !bb) {
        return reply.code(400).send({ error: 'doc_file_incomplete',
          note: '첨부가 불완전한 서류가 있습니다. 파일을 다시 선택하거나 비워 두세요.' });
      }
      if (!ALLOWED_DOC_MIME.includes(mm)) {
        return reply.code(400).send({ error: 'unsupported_type', note: 'PDF·JPEG·PNG·WEBP만 첨부할 수 있습니다.' });
      }
      let buf;
      try { buf = Buffer.from(bb, 'base64'); } catch (_) { return reply.code(400).send({ error: 'bad_base64' }); }
      if (!buf.length) return reply.code(400).send({ error: 'empty_file' });
      if (buf.length > MAX_DOC_BYTES) {
        return reply.code(400).send({ error: 'too_large', note: '파일은 5MB 이하만 가능합니다.' });
      }
      const dt = EXTRA_DOC_TYPES.includes(String(d?.doc_type || '')) ? String(d.doc_type) : 'other';
      extraDocs.push({ doc_type: dt, file_name: nm, mime_type: mm, buf });
    }

    // ── ③ 선점 검사 (RFC · CONSTANCIA) ────────────────────────────────
    //   유니크 인덱스가 최종 방어선이지만, 사용자에게는 "누가 선점했는지" 를 알려줘야 하므로
    //   저장 전에 먼저 조회한다. 동시성 충돌은 아래 INSERT 의 unique 에러로 다시 잡힌다.
    //   ⚠ rfc_claim_exempt(레거시 중복) 행도 여기서는 그대로 걸린다 —
    //     인덱스에서만 빠질 뿐, 남의 고객을 새로 등록해 가져가는 건 막아야 하기 때문.
    //   0193: RFC 를 넣었을 때만 선점 충돌을 본다. **대기 중인 선점 요청도 선점자로 본다**
    //     — 먼저 RFC 를 입력한 사람의 우선권이 승인 대기 중에 새 등록으로 뚫리면 안 된다.
    if (rfcNorm) {
      const holder = await findRfcHolder(rfcNorm);
      if (holder) {
        return reply.code(409).send({
          error: holder.kind === 'claim' ? 'rfc_claim_pending' : 'rfc_taken',
          note: rfcHolderNote(holder),
          claimed_by: holder.owner_name, claimed_at: holder.claimed_at, claimed_name: holder.name,
        });
      }
    }
    if (conNorm) {
      const dupCon = (await query(
        `SELECT c.name, u.name AS owner_name, to_char(c.created_at,'YYYY-MM-DD') AS registered_at
           FROM customers c LEFT JOIN users u ON u.id=c.owner_id
          WHERE c.deleted_at IS NULL AND COALESCE(c.approval_status,'approved') <> 'rejected'
            AND c.constancia_no_norm = $1
          ORDER BY c.created_at LIMIT 1`, [conNorm])).rows[0];
      if (dupCon) {
        return reply.code(409).send({ error: 'constancia_taken',
          note: `이미 등록된 고객입니다 — ${dupCon.name} · 담당 ${dupCon.owner_name || '(미지정)'} · 등록일 ${dupCon.registered_at}. `
              + '같은 고객이 맞다면 디렉터에게 문의하세요.',
          claimed_by: dupCon.owner_name || null, claimed_at: dupCon.registered_at, claimed_name: dupCon.name });
      }
    }

    // ── ③-b 상호명 유사 (0193 · 경고 전용, 차단하지 않음) ─────────────
    //   RFC 없이 등록하는 경우가 중복 등록의 주 경로다. 막지는 않되, 등록 응답과
    //   디렉터 승인 카드에 「유사 고객」 을 실어 보내 사람이 판단할 재료를 남긴다.
    const similar = await findSimilarCustomers(b.name, { excludeId: null });

    // ── ④ 기준품목 단가 → 할인율 근거 스냅샷 (**0267: 선택 입력**) ────
    //   디렉터 지시(2026-10-09)로 필수를 풀었다. 넣으면 종전대로 제안 할인율을 계산해
    //   `suggested_discount` 로 남기고, 비우면 **근거 없이** 등록자가 정한 할인율만 남는다.
    //   ⚠ 대체 산출 경로를 만들지 않았다 — TIER 별 기본 할인율 같은 표는 이 시스템에 없고,
    //     없는 표를 지어내면 「근거처럼 보이는 숫자」가 생겨 사후승인이 그걸 믿게 된다.
    //     근거가 없으면 **없다고 보여 주는 쪽**이 맞다(사후승인 화면이 그렇게 표시한다).
    const baseCode = String(b.syd_ref_code || SYD_BASE_CODE).trim();
    const buyRaw = (b.syd_ref_buy_price == null || b.syd_ref_buy_price === '') ? null : Number(b.syd_ref_buy_price);
    const buyPrice = (buyRaw != null && Number.isFinite(buyRaw) && buyRaw > 0) ? buyRaw : null;
    const base = buyPrice == null ? null : (await query(
      `SELECT p.code, p.list_price_syd, p.list_price
         FROM product_syd_codes sc JOIN products p ON p.id=sc.product_id AND p.deleted_at IS NULL
        WHERE sc.syd_code=$1 ORDER BY p.code LIMIT 1`, [baseCode])).rows[0]
      || (await query(
      `SELECT code, list_price_syd, list_price FROM products
        WHERE deleted_at IS NULL AND scode ILIKE $1 ORDER BY code LIMIT 1`,
        ['%' + baseCode.replace(/([%_\\])/g, '\\$1') + '%'])).rows[0] || null;
    const sydLP = base?.list_price_syd != null ? Number(base.list_price_syd) : null;
    const ctrLP = base?.list_price != null ? Number(base.list_price) : null;
    //   구매단가가 없으면 계산을 **시도하지 않는다** — 빈 근거를 들고 제안값을 만들지 않는다.
    const calc = buyPrice == null
      ? { suggested_discount: null, syd_discount: null, target_price: null, error: null }
      : computeBaselineDiscount({ buy_price: buyPrice, syd_list_price: sydLP, ctr_list_price: ctrLP });

    // ── ⑤ 등록자가 정한 할인율 ────────────────────────────────────────
    const chosen = validateChosenDiscount(b.discount);
    if (!chosen.ok) {
      return reply.code(400).send({ error: chosen.error,
        note: `기본 할인율을 0~${MAX_DISCOUNT_PCT}% 범위로 입력하세요(제안값: ${calc.suggested_discount ?? '—'}%).` });
    }

    // 0193 → **0267 개정 · 사후승인.** 등록이 승인을 기다리지 않는다.
    //   디렉터 지시(2026-10-09): "디렉터 사후승인으로 하자. 디렉터가 승인안한걸 모아서
    //   나중에 승인하는 걸로 해줘"
    //
    //   그래서 신규 고객은 등록되는 즉시 `approved` 다 — 견적도 되고 CRM 으로도 바로 나간다.
    //   디렉터의 승인은 **게이트가 아니라 사후 확인**이고, 그 축은 `ratified_at` 이다(0267).
    //
    //   ★ `approval_status` 에 새 뜻을 끼워 넣지 않은 이유: 이 값은 견적 차단 4곳,
    //     CRM 수신 견적 차단, CRM 상태값 변환(pendiente), 독점·조건 트리거(0235·0247),
    //     리드 팝업, 목록 배지 등 20여 곳에서 읽힌다. 「pending 인데 쓸 수 있는 고객」을
    //     만들면 그 전부를 고쳐야 하고, 한 곳만 놓치면 고객이 조용히 막힌다.
    //     승인 여부를 별도 축으로 뺐으므로 **그 20여 곳은 한 줄도 고치지 않았다.**
    const isDir = perm.role === 'director';
    const status = 'approved';
    const claimOn = await claimTableReady();

    // ── 0212 · 웹에서 들어온 고객은 **P-####** 다 ──────────────────────
    //   원칙: 유입 경로가 코드 계열로 한눈에 보여야 한다.
    //     C-#### = ERP 에서 영업사원·디렉터가 등록한 고객
    //     P-#### = 웹카달록에서 들어온 고객(CRM 직접 등록 · 웹 가입 신청 모두)
    //   ⚠ 예전에는 가입 신청에서 넘어온 등록도 기본값 C 로 채번했다. CRM 이 직접 보낸
    //     신규고객만 P 를 받고, 웹 가입 신청 → 고객 등록 경로는 C 를 받아 원칙이 반쪽이었다.
    //   리드를 여기서 미리 읽는다(채번 전에 알아야 하므로). 아래 ⑦-b 의 연결도 이 값을 쓴다.
    const leadIdIn = Number(b.lead_id || 0);
    let leadSrc = null;
    if (leadIdIn > 0) {
      try {
        leadSrc = (await query(
          `SELECT id, crm_lead_code, received_at FROM crm_web_leads
            WHERE id=$1 AND status IN ('new','assigned')`, [leadIdIn])).rows[0] || null;
      } catch (_) { leadSrc = null; }   // 0210 미적용 — 등록은 그대로 진행(코드는 C)
    }
    const codePrefix = leadSrc ? 'P' : 'C';
    const crmColsOn = leadSrc ? await crmOriginColsReady() : false;

    // 코드 충돌 시 재시도(동시 생성 대비)
    let row, dupKey = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      const code = await computeNextCode(codePrefix);
      try {
        row = (await query(
          `INSERT INTO customers (code, name, rfc, contact, phone, discount, credit_days, team_id, stage_id, owner_id,
                                  customer_type, memo, branch_count, ship_address, buyer_name, buyer_phone,
                                  constancia_fiscal, constancia_no,
                                  syd_ref_code, syd_ref_buy_price, syd_ref_list_price, syd_ref_discount,
                                  ctr_ref_code, ctr_ref_list_price, suggested_discount,
                                  approval_status, submitted_at, approved_by, approved_at,
                                  stage_since, created_by${claimOn ? ', rfc_claimed_at, rfc_claimed_by' : ''}
                                  ${crmColsOn ? ', crm_customer_code, crm_registered_at' : ''})
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
                   $11,$12,$13,$14,$15,$16,
                   $17,$18,
                   $19,$20,$21,$22,
                   $23,$24,$25,
                   $26, now(), $27, $28,
                   CASE WHEN $9::bigint IS NOT NULL THEN CURRENT_DATE END, $29
                   ${claimOn ? ', CASE WHEN $3::text IS NOT NULL THEN now() END, CASE WHEN $3::text IS NOT NULL THEN $10::bigint END' : ''}
                   ${crmColsOn ? ', $30, $31' : ''})
           RETURNING id, code`,
          [code, b.name, rfcClean, b.contact || null, b.phone || null, chosen.value,
           Number(b.credit_days) || 0, teamId, b.stage_id || null,
           // 담당자 미지정이면 등록한 본인이 담당 = 선점자. 커미션 귀속의 근거가 된다.
           b.owner_id || perm.userId || null,
           b.customer_type || null, b.memo || null,
           (b.branch_count === '' || b.branch_count == null) ? null : Number(b.branch_count),
           (b.ship_address == null || String(b.ship_address).trim() === '') ? null : String(b.ship_address).trim(),
           (b.buyer_name == null || String(b.buyer_name).trim() === '') ? null : String(b.buyer_name).trim(),
           (b.buyer_phone == null || String(b.buyer_phone).trim() === '') ? null : String(b.buyer_phone).trim(),
           b.constancia_fiscal || null, conNo || null,
           baseCode, buyPrice, sydLP, calc.syd_discount,
           base?.code || null, ctrLP, calc.suggested_discount,
           // 0267 · 상태는 approved 로 들어가지만 **승인자·승인시각은 비운다** —
           //   아직 아무도 승인하지 않았다. 사후승인은 ratified_at 축이 들고 있고,
           //   그 컬럼은 기본값 NULL 이라 여기서 쓸 것이 없다(= 사후승인 대기).
           status, null, null,
           perm.userId,
           ...(crmColsOn ? [leadSrc.crm_lead_code || null, leadSrc.received_at] : [])])).rows[0];
        break;
      } catch (e) {
        const msg = String(e.message || '');
        if (msg.includes('uq_customers_rfc_claim')) { dupKey = 'rfc_taken'; break; }
        if (msg.includes('uq_customers_constancia_no')) { dupKey = 'constancia_taken'; break; }
        if (!msg.includes('unique') && !msg.includes('duplicate')) throw e;
      }
    }
    if (dupKey) {
      return reply.code(409).send({ error: dupKey,
        note: dupKey === 'rfc_taken'
          ? '방금 다른 영업사원이 같은 RFC 로 먼저 등록했습니다.'
          : '방금 다른 영업사원이 같은 CONSTANCIA 로 먼저 등록했습니다.' });
    }
    if (!row) return reply.code(409).send({ error: 'code_generation_failed' });

    // ── ⑥ CONSTANCIA 스캔본 저장 (첨부된 경우에만) ────────────────────
    //   0188 이후 증빙은 선택이다. 저장에 실패해도 **선점(RFC)은 이미 유효**하므로
    //   등록을 되돌리지 않는다 — 되돌리면 그 사이 남이 같은 RFC 를 가져갈 수 있다.
    //   대신 경고를 실어 보내 "증빙만 다시 올리세요" 로 유도한다.
    let docWarning = null;
    if (docBuf) {
      try {
        await query(
          `INSERT INTO customer_documents (customer_id, doc_type, file_name, mime_type, byte_size, content, uploaded_by)
           VALUES ($1,'constancia',$2,$3,$4,$5,$6)`,
          [row.id, docName, docMime, docBuf.length, docBuf, perm.userId]);
      } catch (e) {
        docWarning = 'constancia_save_failed';
      }
    }

    // 등록 화면에서 함께 올라온 나머지 서류 — 하나가 실패해도 등록을 되돌리지 않는다(위와 같은 이유).
    let docsSaved = docBuf && !docWarning ? 1 : 0;
    const docTypesSaved = docBuf && !docWarning ? ['constancia'] : [];
    for (const ed of extraDocs) {
      try {
        await query(
          `INSERT INTO customer_documents (customer_id, doc_type, file_name, mime_type, byte_size, content, uploaded_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [row.id, ed.doc_type, ed.file_name, ed.mime_type, ed.buf.length, ed.buf, perm.userId]);
        docsSaved += 1;
        if (!docTypesSaved.includes(ed.doc_type)) docTypesSaved.push(ed.doc_type);
      } catch (e) {
        docWarning = docWarning || 'doc_save_failed';
      }
    }
    // 3종(constancia · 주소증명 · 구매 팩투라)이 모두 붙었는지 — 승인 화면·안내 문구용 신호.
    const docsComplete = ['constancia', 'domicilio', 'factura_compra'].every((t) => docTypesSaved.includes(t));

    // ── ⑦ 이력 ───────────────────────────────────────────────────────
    const snapshot = {
      syd_ref_code: baseCode, syd_ref_buy_price: buyPrice, syd_ref_list_price: sydLP,
      syd_ref_discount: calc.syd_discount, ctr_ref_code: base?.code || null, ctr_ref_list_price: ctrLP,
      suggested_discount: calc.suggested_discount, chosen_discount: chosen.value,
      gap: discountGap(chosen.value, calc.suggested_discount), calc_note: calc.note || null,
      // 0193 — 승인 화면이 「RFC 없이 들어온 건」·「유사 고객」 을 바로 볼 수 있게 박제한다.
      rfc: rfcClean, rfc_claimed: !!rfcClean, registered_by_director: isDir,
      similar: similar.map((s) => ({ name: s.name, rfc: s.rfc, owner_name: s.owner_name, score: s.score })),
    };
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'submit',$2,$3,$4)`,
        [row.id, b.memo || null, JSON.stringify(snapshot), perm.userId]);
    } catch (_) { /* 이력 실패가 등록을 막지 않음 */ }

    // 초기 할인/외상일이 0이 아니면 기존 변경이력에도 남김(승인자는 디렉터 등록일 때만)
    const initTerms = [];
    if (chosen.value !== 0) initTerms.push({ field: 'discount', old: null, nv: chosen.value });
    if ((Number(b.credit_days) || 0) !== 0) initTerms.push({ field: 'credit_days', old: null, nv: Number(b.credit_days) || 0 });
    if (initTerms.length) {
      try {
        await logTermsHistory(row.id, initTerms, {
          // 0267 · 구매단가가 선택이 되었으니 「근거 없음」도 사실대로 적는다.
          reason: buyPrice == null
            ? '신규 등록 초기값 (기준품목 구매단가 미입력 — 제안 할인율 근거 없음)'
            : '신규 등록 초기값 (기준품목 ' + baseCode + ' 구매단가 ' + buyPrice
              + ' → 제안 ' + (calc.suggested_discount ?? '—') + '%)',
          // 0267 · 사후승인이므로 이 시점의 승인자는 없다(사후승인 시 이력이 따로 남는다).
          conditions: null, changedBy: perm.userId, approvedBy: null });
      } catch (_) { /* 이력 실패가 등록을 막지 않음 */ }
    }
    // ── ⑦-b 0210 · 웹 가입 신청(리드)에서 넘어온 등록이면 그 리드를 닫아 준다 ──
    //   사람이 「고객 등록 완료로 표시」를 따로 눌러야 했는데, 그 한 번을 빠뜨리면
    //   같은 신청이 팝업에 계속 남아 다른 사람이 또 전화한다. 등록이 곧 처리 완료다.
    //   ⚠ 리드 연결 실패가 고객 등록을 되돌리지는 않는다(등록이 본질, 연결은 정리).
    let leadLinked = null;
    const leadId = leadSrc ? Number(leadSrc.id) : 0;
    if (leadId > 0) {
      try {
        // 0211 → **0267 개정 · 등록이 곧 완결이다.** 예전에는 디렉터 승인까지 팝업이
        //   계속 떠 있었다(승인 전에는 고객이 카달록에서 가격을 못 봤으니 맞는 설계였다).
        //   이제 등록 즉시 활성이고 CRM 으로도 나가므로, 담당자가 더 할 일이 없다 —
        //   여기서 닫는다. 사후승인은 디렉터의 일이고 담당자 팝업과는 무관하다.
        //   (리드 팝업의 OPEN_WHERE 는 approved 고객을 이미 제외하므로 두 길이 같은 답을 낸다.)
        const lk = (await query(
          `UPDATE crm_web_leads
              SET status='done', customer_id=$1, registered_at=now(),
                  closed_by=$3, closed_at=now()
            WHERE id=$2 AND status IN ('new','assigned')
            RETURNING id, crm_lead_code`, [row.id, leadId, perm.userId])).rows[0];
        if (lk) leadLinked = { id: Number(lk.id), crm_lead_code: lk.crm_lead_code || null };
      } catch (_) { /* 0210 미적용이거나 이미 닫힌 건 — 등록은 그대로 진행 */ }
    }

    // ── ⑦-c 0267 · **CRM 전송은 이제 등록 시점이다.** ──────────────────
    //   예전에는 승인 라우트(origin='registration_approve')만 전송했다. 사후승인으로
    //   바뀌었으니 전송을 승인에 매어 두면 디렉터가 늦게 보는 동안 고객이 카달록에서
    //   가격을 못 본다 — 단순화의 목적이 그것이었다.
    //   ⚠ enqueueCustomerSync 는 절대 throw 하지 않는다(crmSync.js). 전송 실패가
    //     등록을 되돌리지 않는 것이 이 아웃박스 설계의 요점이다.
    //   RFC 가 없으면 CRM 조회 키가 없으므로 skipped 로 남는다(종전과 동일).
    await enqueueCustomerSync(row.id, 'upsert',
      { origin: 'registration_create', actorUserId: perm.userId, app });

    await safeLog({ userId: perm.userId, action: 'create', target: `customer:${row.id}`,
      detail: { approval_status: status, ratified: false,
        rfc_claimed: !!rfcClean, lead_id: leadLinked ? leadId : null } });
    return { ok: true, id: row.id, code: row.code, approval_status: status, lead_linked: leadLinked,
      // 0267 · 고객은 **이미 쓸 수 있다.** 기다리는 것은 디렉터의 사후 확인뿐이다.
      //   예전 키(pending_approval)는 「아직 못 쓴다」는 뜻으로 화면들이 읽고 있었으므로
      //   false 로 고정하고, 사후승인 대기는 새 키로 알린다(뜻이 다른 두 사실을 한 키에
      //   담으면 다음 사람이 반드시 틀린 쪽으로 읽는다).
      pending_approval: false, awaiting_ratify: true,
      calc, suggested_discount: calc.suggested_discount,
      // 0193 · RFC 를 넣었으면 그 순간 선점됐고, 안 넣었으면 선점이 없다(나중에 남이 가져갈 수 있다).
      claimed_by: rfcClean ? 'rfc' : null, rfc_claimed: !!rfcClean,
      rfc: rfcClean, constancia_no: conNo || null, constancia_doc: !!docBuf && !docWarning,
      docs_saved: docsSaved, docs_types: docTypesSaved, docs_complete: docsComplete,
      // 0235 · 서류는 독점과 무관하다(독점은 RFC 등록·판매로 생긴다). 할인·외상 관문만 알린다.
      gate: {
        discount_ok: docTypesSaved.includes('constancia') && docTypesSaved.includes('domicilio'),
        credit_ok: docTypesSaved.includes('factura_compra'),
        missing: ['constancia', 'domicilio', 'factura_compra'].filter((t) => !docTypesSaved.includes(t)),
      },
      docs_note: [
        (docTypesSaved.includes('constancia') && docTypesSaved.includes('domicilio'))
          ? '할인 적용 ✔' : '할인 미적용 — Constancia + 주소 증빙을 올려야 할인이 적용됩니다',
        docTypesSaved.includes('factura_compra')
          ? '외상 30일 ✔' : '외상 불가(선입금) — 경쟁사 서스펜션 구매 인보이스를 올려야 외상이 적용됩니다',
      ].join(' · '),
      similar,
      // 0267 · 「요청을 보냈습니다」가 아니다. 등록이 끝났고 바로 쓸 수 있다.
      note: rfcClean
        ? `등록을 완료했습니다 — RFC ${rfcClean} 로 선점되었고, 지금 바로 견적에 쓸 수 있습니다. `
          + 'CRM(웹카달록) 으로도 전송했습니다. 디렉터 사후승인은 따로 진행됩니다.'
        : '등록을 완료했습니다 — 지금 바로 견적에 쓸 수 있습니다. '
          + '⚠ RFC 가 비어 있어 **아직 선점되지 않았고**, CRM 전송도 RFC 가 있어야 됩니다. '
          + '다른 영업사원이 이 고객에 RFC 를 먼저 입력하면 그 사람에게 우선권이 갑니다. RFC 를 받는 대로 입력하세요.',
      warning: docWarning,
      warning_note: docWarning
        ? '등록은 완료됐지만 CONSTANCIA 스캔본 저장에 실패했습니다. 고객 상세의 증빙서류에서 다시 올려 주세요.'
        : null };
  });

  // =====================================================================
  // 0193 · RFC 선점 이관
  //
  //   RFC 없이 등록된 고객은 **선점이 없다.** 그 고객에 RFC 를 먼저 입력한 사람이
  //   우선권을 갖는다 — 요청 시각(requested_at)이 그 근거이고, 확정은 디렉터 승인이다.
  //
  //   두 갈래:
  //     ① 내가 이미 담당인 고객에 RFC 를 채우는 경우 → **즉시 적용**(뺏을 게 없다).
  //     ② 남이 담당인 고객에 내 RFC 를 넣는 경우     → 대기 요청 + 디렉터 승인 시 담당 이관.
  //   같은 RFC 로는 대기 요청이 하나만 존재할 수 있다(uq_rfc_claims_pending_rfc).
  //
  //   ⚠ 이 경로는 팀 스코프를 타지 않는다(claim-check 과 같은 이유). 그래서
  //     응답에 상호·담당자·시각 외의 정보는 절대 싣지 않는다.
  // =====================================================================
  app.post('/api/customers/:id/rfc-claim', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    if (!(await claimTableReady())) {
      return reply.code(503).send({ error: 'migration_required',
        note: 'RFC 선점 이관(0193) 마이그레이션이 아직 적용되지 않았습니다. 디렉터에게 문의하세요.' });
    }
    const chk = validateRfc(req.body?.rfc);        // 이관은 RFC 가 본질이므로 여기서는 필수 + 엄격
    if (!chk.ok) return reply.code(400).send({ error: chk.error, note: RFC_ERROR_NOTE[chk.error] });
    const rfcClean = chk.value;
    const rfcNorm = normalizeClaimKey(rfcClean);

    const c = (await query(
      `SELECT c.id, c.name, c.rfc, c.rfc_norm, c.owner_id, c.team_id, u.name AS owner_name
         FROM customers c LEFT JOIN users u ON u.id=c.owner_id
        WHERE c.id=$1 AND c.deleted_at IS NULL
          AND COALESCE(c.approval_status,'approved') <> 'rejected'`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    // 이미 RFC 가 있으면 선점이 끝난 고객이다 — 이 경로로는 못 바꾼다(수정 화면으로 보낸다).
    if (c.rfc_norm) {
      return reply.code(409).send({ error: 'rfc_already_set', note: RFC_ERROR_NOTE.rfc_already_set,
        claimed_by: c.owner_name || null });
    }
    // 그 RFC 를 이미 누가 갖고 있으면(확정이든 대기든) 여기서 멈춘다.
    const holder = await findRfcHolder(rfcNorm, { excludeCustomerId: id });
    if (holder) {
      return reply.code(409).send({
        error: holder.kind === 'claim' ? 'rfc_claim_pending' : 'rfc_taken',
        note: rfcHolderNote(holder),
        claimed_by: holder.owner_name, claimed_at: holder.claimed_at, claimed_name: holder.name });
    }

    // ① 내 고객이면 즉시 적용 — 남에게서 뺏는 게 아니므로 승인을 기다릴 이유가 없고,
    //    기다리는 사이 다른 영업사원이 같은 RFC 를 채가는 게 더 큰 손해다.
    const mine = c.owner_id != null && Number(c.owner_id) === Number(perm.userId);
    if (mine) {
      try {
        await query(
          `UPDATE customers SET rfc=$1, rfc_claimed_at=now(), rfc_claimed_by=$2, updated_by=$2 WHERE id=$3`,
          [rfcClean, perm.userId, id]);
      } catch (e) {
        if (String(e.message || '').includes('uq_customers_rfc_claim')) {
          return reply.code(409).send({ error: 'rfc_taken', note: '방금 다른 영업사원이 같은 RFC 를 먼저 선점했습니다.' });
        }
        throw e;
      }
      try {
        await query(
          `INSERT INTO customer_rfc_claims (customer_id, rfc, requested_by, status, transfer_owner, note, decided_by, decided_at)
           VALUES ($1,$2,$3,'approved',false,$4,$3,now())`,
          [id, rfcClean, perm.userId, req.body?.note ? String(req.body.note) : null]);
        await query(
          `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
           VALUES ($1,'rfc_claim_self',$2,$3,$4)`,
          [id, req.body?.note ? String(req.body.note) : null,
           JSON.stringify({ rfc: rfcClean, transfer_owner: false }), perm.userId]);
      } catch (_) { /* 이력 실패가 선점을 막지 않음 */ }
      await safeLog({ userId: perm.userId, action: 'rfc_claim_self', target: `customer:${id}` });
      return { ok: true, applied: true, customer_id: id, rfc: rfcClean,
        note: `RFC ${rfcClean} 로 선점이 확정되었습니다 — 이 시점부터 다른 영업사원은 이 고객을 가져갈 수 없습니다.` };
    }

    // ② 남의 고객 → 대기 요청. 확정은 디렉터 승인.
    let claim;
    try {
      claim = (await query(
        `INSERT INTO customer_rfc_claims (customer_id, rfc, requested_by, note)
         VALUES ($1,$2,$3,$4) RETURNING id, to_char(requested_at,'YYYY-MM-DD HH24:MI') AS requested_at`,
        [id, rfcClean, perm.userId, req.body?.note ? String(req.body.note) : null])).rows[0];
    } catch (e) {
      if (String(e.message || '').includes('uq_rfc_claims_pending_rfc')) {
        const h = await findRfcHolder(rfcNorm, { excludeCustomerId: id });
        return reply.code(409).send({ error: 'rfc_claim_pending',
          note: rfcHolderNote(h) || RFC_ERROR_NOTE.rfc_claim_pending });
      }
      throw e;
    }
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'rfc_claim_request',$2,$3,$4)`,
        [id, req.body?.note ? String(req.body.note) : null,
         JSON.stringify({ rfc: rfcClean, claim_id: Number(claim.id),
           previous_owner: c.owner_name || null }), perm.userId]);
    } catch (_) { /* ignore */ }
    await safeLog({ userId: perm.userId, action: 'rfc_claim_request', target: `customer:${id}` });
    return { ok: true, applied: false, pending_approval: true,
      claim_id: Number(claim.id), customer_id: id, rfc: rfcClean, requested_at: claim.requested_at,
      note: `RFC ${rfcClean} 로 선점을 요청했습니다(${claim.requested_at}). `
          + '이 시각이 우선권의 근거이고, 디렉터가 승인하면 담당이 본인으로 이관됩니다.' };
  });

  // =====================================================================
  // 0194 · RFC 선점 예외(rfc_claim_exempt) 정리 — 디렉터
  //
  //   0188 은 유니크를 걸기 위해, 그때 중복이던 그룹의 2번째 이후 행에 예외를 찍었다.
  //   그 플래그는 **스냅샷**이라 상대 고객이 삭제·반려·RFC 정정되면 철이 지난다.
  //   철 지난 예외는 표시만 이상한 게 아니라, 그 고객이 **실제로 DB 유니크 보호를 못 받는** 상태다.
  //   → 여기서 지금 상태를 다시 세고, 중복이 사라진 건은 예외를 해제해 보호를 되찾아 준다.
  //
  //   해제 규칙은 마이그레이션 0194 와 동일하다: **그 RFC 를 쓰는 살아있는 고객이 자기 하나뿐일 때만.**
  //   진짜 중복 그룹은 손대지 않는다 — 어느 쪽이 진짜인지는 사람이 판단할 일이고,
  //   둘 다 해제하면 유니크 인덱스가 깨진다.
  // =====================================================================

  // 예외 목록 + 지금 기준 중복 건수(= 해제 가능 여부)
  app.get('/api/customers/rfc-exempt', { preHandler: [authGuard, requireDirector] }, async () => {
    if (!(await rfcClaimReady())) return { items: [], migration_required: true };
    const rows = (await query(
      `SELECT c.id, c.code, c.name, c.rfc, c.rfc_norm,
              u.name AS owner_name, t.name AS team_name,
              to_char(c.created_at,'YYYY-MM-DD') AS registered_at,
              COALESCE(c.approval_status,'approved') AS approval_status,
              (SELECT count(*)::int FROM customers o
                WHERE o.id <> c.id AND o.rfc_norm = c.rfc_norm AND o.deleted_at IS NULL
                  AND COALESCE(o.approval_status,'approved') <> 'rejected') AS dup_count,
              (SELECT string_agg(x.name, ' · ' ORDER BY x.created_at)
                 FROM (SELECT o.name, o.created_at FROM customers o
                        WHERE o.id <> c.id AND o.rfc_norm = c.rfc_norm AND o.deleted_at IS NULL
                          AND COALESCE(o.approval_status,'approved') <> 'rejected'
                        ORDER BY o.created_at LIMIT 5) x) AS dup_names
         FROM customers c
         LEFT JOIN users u ON u.id=c.owner_id
         LEFT JOIN sales_teams t ON t.id=c.team_id
        WHERE c.rfc_claim_exempt = true AND c.deleted_at IS NULL
          AND COALESCE(c.approval_status,'approved') <> 'rejected'
        ORDER BY c.rfc_norm, c.created_at
        LIMIT 300`)).rows;
    return {
      items: rows.map((r) => ({
        id: Number(r.id), code: r.code, name: r.name, rfc: r.rfc || null,
        owner_name: r.owner_name || '(담당자 미지정)', team_name: r.team_name || null,
        registered_at: r.registered_at, approval_status: r.approval_status,
        dup_count: Number(r.dup_count), dup_names: r.dup_names || null,
        // dup_count 0 = 중복이 이미 해소된 「철 지난 예외」 → 버튼 한 번으로 해제 가능
        releasable: Number(r.dup_count) === 0,
      })),
      // 화면 상단 요약 — "몇 건이 그냥 정리되는지" 를 먼저 보여 준다
      stale: rows.filter((r) => Number(r.dup_count) === 0).length,
      real: rows.filter((r) => Number(r.dup_count) > 0).length,
    };
  });

  // 철 지난 예외 일괄 해제(재검사) — 마이그레이션 0194 와 같은 규칙을 운영 중에 다시 돌린다.
  app.post('/api/customers/rfc-exempt-rescan', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const perm = req.ctx.perm;
    if (!(await rfcClaimReady())) return reply.code(503).send({ error: 'migration_required' });
    const rows = (await query(
      `UPDATE customers c SET rfc_claim_exempt = false
        WHERE c.rfc_claim_exempt = true AND c.rfc_norm IS NOT NULL AND c.deleted_at IS NULL
          AND COALESCE(c.approval_status,'approved') <> 'rejected'
          AND NOT EXISTS (
            SELECT 1 FROM customers o
             WHERE o.id <> c.id AND o.rfc_norm = c.rfc_norm AND o.deleted_at IS NULL
               AND COALESCE(o.approval_status,'approved') <> 'rejected')
        RETURNING c.id, c.code, c.name`)).rows;
    for (const r of rows) {
      try {
        await query(
          `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
           VALUES ($1,'rfc_exempt_release','재검사 — 중복이 해소되어 선점 보호 복구',$2,$3)`,
          [r.id, JSON.stringify({ via: 'rescan' }), perm.userId]);
      } catch (_) { /* 이력 실패가 정리를 막지 않음 */ }
    }
    await safeLog({ userId: perm.userId, action: 'rfc_exempt_rescan', target: 'customers',
      detail: { released: rows.length } });
    return { ok: true, released: rows.length,
      items: rows.map((r) => ({ id: Number(r.id), code: r.code, name: r.name })),
      note: rows.length
        ? `${rows.length}건의 선점 보호를 복구했습니다 — 중복이 이미 해소된 고객들입니다.`
        : '해제할 수 있는 건이 없습니다. 남아 있는 예외는 실제로 RFC 가 중복인 그룹입니다.' };
  });

  // 개별 해제 — 같은 규칙을 한 건에만 적용한다(유니크 위반은 여기서 잡아 안내로 바꾼다).
  app.post('/api/customers/:id/rfc-exempt-release', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    if (!(await rfcClaimReady())) return reply.code(503).send({ error: 'migration_required' });
    const c = (await query(
      `SELECT id, name, rfc, rfc_norm, rfc_claim_exempt FROM customers
        WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (c.rfc_claim_exempt !== true) return { ok: true, already: true, note: '이미 선점 보호를 받고 있는 고객입니다.' };
    if (!c.rfc_norm) {
      return reply.code(400).send({ error: 'rfc_required',
        note: 'RFC 가 비어 있어 해제할 수 없습니다. RFC 를 먼저 입력하세요.' });
    }
    const others = (await query(
      `SELECT o.name, u.name AS owner_name FROM customers o LEFT JOIN users u ON u.id=o.owner_id
        WHERE o.id <> $1 AND o.rfc_norm = $2 AND o.deleted_at IS NULL
          AND COALESCE(o.approval_status,'approved') <> 'rejected'
        ORDER BY o.created_at LIMIT 3`, [id, c.rfc_norm])).rows;
    if (others.length) {
      // 아직 진짜 중복이다 — 해제하면 유니크가 깨진다. 어느 쪽이 진짜인지는 사람이 정해야 한다.
      return reply.code(409).send({ error: 'rfc_still_duplicated',
        note: `같은 RFC 를 쓰는 고객이 아직 ${others.length}건 있습니다 — `
            + others.map((o) => `${o.name}(담당 ${o.owner_name || '미지정'})`).join(' · ')
            + '. 한쪽의 RFC 를 정정하거나 고객을 통합한 뒤 다시 시도하세요.',
        others: others.map((o) => ({ name: o.name, owner_name: o.owner_name || null })) });
    }
    try {
      await query(`UPDATE customers SET rfc_claim_exempt=false, updated_by=$1 WHERE id=$2`, [perm.userId, id]);
    } catch (e) {
      if (String(e.message || '').includes('uq_customers_rfc_claim')) {
        return reply.code(409).send({ error: 'rfc_still_duplicated',
          note: '방금 다른 고객이 같은 RFC 로 선점을 가져갔습니다. 목록을 새로고침해 확인하세요.' });
      }
      throw e;
    }
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'rfc_exempt_release','디렉터 개별 해제 — 선점 보호 복구',$2,$3)`,
        [id, JSON.stringify({ rfc: c.rfc, via: 'manual' }), perm.userId]);
    } catch (_) { /* ignore */ }
    await safeLog({ userId: perm.userId, action: 'rfc_exempt_release', target: `customer:${id}` });
    return { ok: true, id, rfc: c.rfc,
      note: `${c.name} 의 선점 보호를 복구했습니다 — 이제 RFC ${c.rfc} 는 DB 유니크로 잠깁니다.` };
  });

  // ===================================================================
  // 🔗 고객 병합 (디렉터) — 0188 인수인계 ⑨ 「RFC 중복 정리 — 병합」 구현
  //   같은 RFC 인데 고객번호가 나뉜 건을 하나로 모은다.
  //   **복사가 아니라 이관**이다 — customer_id 만 바꾼다(사본을 만들면 후속조치가 두 번 뜬다).
  //   옮기는 것은 상담·방문 3종뿐이고, 견적·매출 등은 「남는 것」으로 세어 보여만 준다.
  // ===================================================================

  // 병합 판정에 필요한 최소 필드만 — 미리보기·실행 양쪽이 같은 것을 본다.
  async function mergeCustBrief(id, client = null) {
    const q = client ? ((sql, p) => client.query(sql, p)) : query;
    const regOn = await regColumnsReady();
    const rfcOn = await rfcClaimReady();
    const rows = (await q(
      `SELECT c.id, c.code, c.name, c.rfc, c.rfc_norm, c.deleted_at, c.team_id, c.owner_id,
              ${regOn ? `COALESCE(c.approval_status,'approved')` : `'approved'`} AS approval_status,
              ${rfcOn ? 'c.rfc_claim_exempt' : 'false'} AS rfc_claim_exempt,
              u.name AS owner_name, t.name AS team_name
         FROM customers c
         LEFT JOIN users u ON u.id = c.owner_id
         LEFT JOIN sales_teams t ON t.id = c.team_id
        WHERE c.id = $1`, [Number(id)])).rows;
    return rows[0] || null;
  }

  // 이관 대상 건수(부모 + 따라오는 자식). 미리보기 전용 — 실행은 UPDATE 의 rowCount 를 쓴다.
  async function mergeMoveCounts(customerId) {
    const out = [];
    for (const m of MERGE_MOVES) {
      const soft = m.table === 'sales_visits' || m.table === 'sales_consults' || m.table === 'customer_notes';
      const row = (await query(
        `SELECT count(*) FILTER (WHERE ${soft ? 'deleted_at IS NULL' : 'true'})::int AS live,
                count(*) FILTER (WHERE ${soft ? 'deleted_at IS NOT NULL' : 'false'})::int AS gone
           FROM ${m.table} WHERE ${m.col} = $1`, [customerId])).rows[0];
      const cnt = Number(row.live); const gone = Number(row.gone);
      const kids = [];
      for (const c of m.children) {
        const n = Number((await query(
          `SELECT count(*)::int AS n FROM ${c.table} ch
            WHERE ch.${c.fk} IN (SELECT id FROM ${m.table} WHERE ${m.col} = $1${soft ? ' AND deleted_at IS NULL' : ''})`,
          [customerId])).rows[0].n);
        if (n > 0) kids.push({ label: c.label, cnt: n });
      }
      // gone = 소프트삭제된 기록. 화면에는 안 보이지만 옮겨는 간다(원본에 매달아 두면 미아가 된다).
      out.push({ key: m.key, label: m.label, cnt, deleted: gone, children: kids });
    }
    return out;
  }

  // 남는 것 — customers 를 참조하는 모든 단일컬럼 FK 를 카탈로그에서 읽어 센다.
  //   테이블 목록을 코드에 박아 두면 새 모듈이 생길 때마다 조용히 빠뜨린다.
  //   501 에서 끊고 「500+」로 표시 — 큰 테이블에서 count(*) 로 끌지 않기 위해서.
  async function mergeResidual(customerId) {
    let refs = [];
    try {
      refs = (await query(
        `SELECT cl.relname AS tbl, a.attname AS col
           FROM pg_constraint c
           JOIN pg_class cl ON cl.oid = c.conrelid
           JOIN pg_namespace ns ON ns.oid = cl.relnamespace
           JOIN unnest(c.conkey) WITH ORDINALITY k(attnum, ord) ON true
           JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = k.attnum
          WHERE c.contype = 'f'
            AND c.confrelid = 'customers'::regclass
            AND array_length(c.conkey, 1) = 1
            AND ns.nspname = 'public'
            AND cl.relname <> 'customers'
          ORDER BY cl.relname`)).rows;
    } catch (_) { return { items: [], total: 0, unavailable: true }; }
    const items = [];
    for (const r of refs) {
      if (MOVED_TABLES.has(r.tbl)) continue;                 // 이번에 옮기는 것
      if (!safeIdent(r.tbl) || !safeIdent(r.col)) continue;   // 동적 식별자 방어
      let n = 0;
      try {
        n = Number((await query(
          `SELECT count(*)::int AS n FROM (SELECT 1 FROM ${r.tbl} WHERE ${r.col} = $1 LIMIT 501) x`,
          [customerId])).rows[0].n);
      } catch (_) { continue; }
      if (n > 0) items.push({ table: r.tbl, column: r.col, label: residualLabel(r.tbl), cnt: n, capped: n > 500 });
    }
    items.sort((a, b) => b.cnt - a.cnt || a.table.localeCompare(b.table));
    return { items, total: items.reduce((s, x) => s + x.cnt, 0), unavailable: false };
  }

  // 미리보기 — 실행 전에 「무엇이 옮겨지고 무엇이 남는가」를 전부 보여 준다.
  app.get('/api/customers/:id/merge-preview', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const fromId = Number(req.params.id);
    const intoId = Number(req.query.into || 0);
    if (!Number.isFinite(intoId) || intoId <= 0) {
      return reply.code(400).send({ error: 'into_required', note: '합칠 대상(남길 고객)을 지정하세요.' });
    }
    const from = await mergeCustBrief(fromId);
    const into = await mergeCustBrief(intoId);
    const { blockers, warnings } = checkMerge(from, into);
    if (blockers.some((b) => b.code === 'from_not_found' || b.code === 'into_not_found')) {
      return reply.code(404).send({ error: 'not_found', blockers });
    }
    const moves = await mergeMoveCounts(fromId);
    const residual = await mergeResidual(fromId);
    const brief = (c) => ({
      id: Number(c.id), code: c.code, name: c.name, rfc: c.rfc || null,
      owner_name: c.owner_name || null, team_name: c.team_name || null,
      approval_status: c.approval_status, rfc_claim_exempt: c.rfc_claim_exempt === true,
    });
    return {
      from: brief(from), into: brief(into),
      same_rfc: !!(from.rfc_norm && into.rfc_norm && from.rfc_norm === into.rfc_norm),
      moves, move_total: moveTotal(moves),
      residual: residual.items, residual_total: residual.total, residual_unavailable: residual.unavailable,
      warnings, blockers,
      can_merge: blockers.length === 0,
    };
  });

  // 실행 — 단일 트랜잭션. 옮기고, (선택) 원본을 종료하고, 풀린 RFC 선점을 복구한다.
  app.post('/api/customers/merge', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const perm = req.ctx.perm;
    const fromId = Number(req.body?.from_id);
    const intoId = Number(req.body?.into_id);
    const closeSource = req.body?.close_source !== false;      // 기본 = 원본 종료(합치는 게 목적이므로)
    const ackResidual = req.body?.ack_residual === true;
    const reason = String(req.body?.reason || '').trim();
    if (!Number.isFinite(fromId) || !Number.isFinite(intoId)) {
      return reply.code(400).send({ error: 'bad_request', note: '고객을 지정하세요.' });
    }
    if (!reason) {
      return reply.code(400).send({ error: 'reason_required',
        note: '병합 사유를 적어야 합니다 — 나중에 왜 합쳤는지 추적할 수 있어야 합니다.' });
    }

    // 남는 거래 데이터가 있는데 원본을 닫으려 하면, 디렉터가 그것을 보고 확인해야 통과한다.
    const residual = await mergeResidual(fromId);
    if (closeSource && residual.total > 0 && !ackResidual) {
      const fc = await mergeCustBrief(fromId);
      const who = fc ? `${fc.name}(${fc.code})` : `${fromId} 번 고객`;
      return reply.code(409).send({ error: 'residual_not_acknowledged',
        residual: residual.items, residual_total: residual.total,
        note: `${who} 에는 견적·매출 등 ${residual.total}건이 남아 있습니다. `
            + '이 화면은 상담·방문만 옮깁니다 — 그래도 원본을 종료할지 확인해 주세요.' });
    }

    const result = await withTx(async (client) => {
      // 교착 방지: 항상 작은 id 부터 잠근다.
      const ids = [fromId, intoId].sort((a, b) => a - b);
      await client.query(`SELECT id FROM customers WHERE id = ANY($1) ORDER BY id FOR UPDATE`, [ids]);
      const from = await mergeCustBrief(fromId, client);
      const into = await mergeCustBrief(intoId, client);
      const { blockers, warnings } = checkMerge(from, into);
      if (blockers.length) return { blocked: blockers };

      // 소프트삭제된 기록도 함께 옮긴다(원본에 남기면 종료된 고객에 매달린 미아가 된다).
      // 다만 안내 문구의 건수는 **화면에 보이는 살아있는 기록** 기준이어야 한다 — 둘을 따로 센다.
      const counts = {}; const countsAll = {};
      for (const m of MERGE_MOVES) {
        const soft = m.table === 'sales_visits' || m.table === 'sales_consults' || m.table === 'customer_notes';
        const r = await client.query(
          `UPDATE ${m.table} SET ${m.col} = $2 WHERE ${m.col} = $1
           RETURNING ${soft ? 'deleted_at' : 'NULL::timestamptz AS deleted_at'}`, [fromId, intoId]);
        countsAll[m.key] = r.rowCount || 0;
        counts[m.key] = r.rows.filter((x) => x.deleted_at == null).length;
      }

      let closed = false;
      if (closeSource) {
        await client.query(`UPDATE customers SET deleted_at = now(), updated_by = $1 WHERE id = $2`,
          [perm.userId, fromId]);
        closed = true;
      }

      // 원본이 빠지면서 남길 고객의 RFC 중복이 해소될 수 있다 →
      // 0194 재검사와 **같은 규칙**으로 그 자리에서 선점 보호를 복구한다.
      let exemptReleased = false;
      if (closed && (await rfcClaimReady())) {
        const rel = await client.query(
          `UPDATE customers c SET rfc_claim_exempt = false
            WHERE c.id = $1 AND c.rfc_claim_exempt = true AND c.rfc_norm IS NOT NULL
              AND c.deleted_at IS NULL
              AND COALESCE(c.approval_status,'approved') <> 'rejected'
              AND NOT EXISTS (
                SELECT 1 FROM customers o
                 WHERE o.id <> c.id AND o.rfc_norm = c.rfc_norm AND o.deleted_at IS NULL
                   AND COALESCE(o.approval_status,'approved') <> 'rejected')`, [intoId]);
        exemptReleased = (rel.rowCount || 0) > 0;
      }

      // 이력 — 양쪽 고객 상세에서 각각 읽히도록 두 줄로 남긴다.
      const snap = JSON.stringify({ from_id: fromId, from_code: from.code, from_name: from.name,
        into_id: intoId, into_code: into.code, into_name: into.name,
        counts, counts_all: countsAll, closed, exempt_released: exemptReleased,
        residual_total: residual.total, warnings: warnings.map((w) => w.code) });
      for (const [cid, action] of [[fromId, 'merge_out'], [intoId, 'merge_in']]) {
        try {
          await client.query(
            `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
             VALUES ($1,$2,$3,$4,$5)`, [cid, action, reason, snap, perm.userId]);
        } catch (_) { /* 이력 실패가 병합을 되돌리지는 않는다 */ }
      }
      return { counts, countsAll, closed, exemptReleased, from, into, warnings };
    });

    if (result.blocked) {
      return reply.code(409).send({ error: 'merge_blocked', blockers: result.blocked,
        note: result.blocked.map((b) => b.note).join(' ') });
    }
    await safeLog({ userId: perm.userId, action: 'customer_merge', target: `customer:${intoId}`,
      detail: { from: fromId, into: intoId, counts: result.counts, closed: result.closed, reason } });
    return {
      ok: true, from_id: fromId, into_id: intoId,
      counts: result.counts, counts_all: result.countsAll,
      moved_total: moveTotal(MERGE_MOVES.map((m) => ({ cnt: result.counts[m.key] }))),
      closed: result.closed, exempt_released: result.exemptReleased,
      residual_total: residual.total,
      note: mergeNote(result.counts, {
        fromName: `${result.from.name}(${result.from.code})`,
        intoName: `${result.into.name}(${result.into.code})`,
        closed: result.closed, residualTotal: residual.total,
      }) + (result.exemptReleased ? ' 중복이 해소되어 남길 고객의 RFC 선점 보호도 복구했습니다.' : ''),
    };
  });

  // 선점 이관 대기 목록 (디렉터) — requested_at 오름차순 = 우선순위 순
  app.get('/api/customer-rfc-claims', { preHandler: [authGuard, requireDirector] }, async (req) => {
    if (!(await claimTableReady())) return { items: [], migration_required: true };
    const status = ['pending', 'approved', 'rejected', 'superseded'].includes(req.query.status)
      ? req.query.status : 'pending';
    const rows = (await query(
      `SELECT k.id, k.customer_id, k.rfc, k.status, k.note,
              to_char(k.requested_at,'YYYY-MM-DD HH24:MI') AS requested_at,
              to_char(k.decided_at,'YYYY-MM-DD HH24:MI')   AS decided_at,
              k.decided_reason,
              ru.name AS requested_by_name, du.name AS decided_by_name,
              c.name AS customer_name, c.code AS customer_code, c.rfc AS customer_rfc,
              COALESCE(c.approval_status,'approved') AS approval_status,
              ou.name AS owner_name, t.name AS team_name,
              to_char(c.created_at,'YYYY-MM-DD') AS registered_at
         FROM customer_rfc_claims k
         JOIN customers c ON c.id=k.customer_id
         LEFT JOIN users ru ON ru.id=k.requested_by
         LEFT JOIN users du ON du.id=k.decided_by
         LEFT JOIN users ou ON ou.id=c.owner_id
         LEFT JOIN sales_teams t ON t.id=c.team_id
        WHERE k.status=$1 AND c.deleted_at IS NULL
        ORDER BY k.requested_at, k.id
        LIMIT 200`, [status])).rows;
    return {
      items: rows.map((r, i) => ({
        id: Number(r.id), customer_id: Number(r.customer_id),
        customer_name: r.customer_name, customer_code: r.customer_code,
        customer_rfc: r.customer_rfc || null, approval_status: r.approval_status,
        current_owner: r.owner_name || '(담당자 미지정)', team_name: r.team_name || null,
        registered_at: r.registered_at,
        rfc: r.rfc, requested_by: r.requested_by_name || '(알 수 없음)', requested_at: r.requested_at,
        note: r.note || null, status: r.status,
        decided_by: r.decided_by_name || null, decided_at: r.decided_at, decided_reason: r.decided_reason || null,
        // 같은 고객에 요청이 여러 건이면 시각이 빠른 쪽이 우선 — 목록이 이미 그 순서다.
        priority: i + 1,
      })),
    };
  });

  // 선점 이관 승인 — RFC 확정 + 담당 이관.
  //   ★ rfc_claimed_at 은 **승인 시각이 아니라 요청 시각**을 박는다.
  //     우선권의 근거는 "RFC 를 언제 입력했는가" 이지 "디렉터가 언제 눌렀는가" 가 아니다.
  app.post('/api/customer-rfc-claims/:id/approve', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const cid = Number(req.params.id);
    const perm = req.ctx.perm;
    if (!(await claimTableReady())) return reply.code(503).send({ error: 'migration_required' });
    const k = (await query(
      `SELECT k.*, to_char(k.requested_at,'YYYY-MM-DD HH24:MI') AS requested_at_txt,
              c.owner_id, c.team_id, c.rfc_norm AS cur_rfc_norm, c.name AS customer_name
         FROM customer_rfc_claims k JOIN customers c ON c.id=k.customer_id
        WHERE k.id=$1 AND k.status='pending' AND c.deleted_at IS NULL`, [cid])).rows[0];
    if (!k) return reply.code(404).send({ error: 'not_found' });
    if (k.cur_rfc_norm) {
      return reply.code(409).send({ error: 'rfc_already_set', note: RFC_ERROR_NOTE.rfc_already_set });
    }
    const holder = await findRfcHolder(k.rfc_norm, { excludeCustomerId: Number(k.customer_id), claimsOn: false });
    if (holder) {
      return reply.code(409).send({ error: 'rfc_taken', note: rfcHolderNote(holder) });
    }
    // 이관 대상 영업사원의 팀으로 고객을 옮긴다(커미션·매출 집계가 팀 기준이라 같이 가야 한다).
    const reqUser = (await query(`SELECT id, team_id, name FROM users WHERE id=$1`, [k.requested_by])).rows[0];
    const newTeam = reqUser?.team_id || k.team_id;
    const prevOwner = k.owner_id;
    await withTx(async (c) => {
      await c.query(
        `UPDATE customers
            SET rfc=$1, rfc_claimed_at=$2, rfc_claimed_by=$3, owner_id=$3, team_id=$4, updated_by=$5
          WHERE id=$6`,
        [k.rfc, k.requested_at, k.requested_by, newTeam, perm.userId, k.customer_id]);
      await c.query(
        `UPDATE customer_rfc_claims SET status='approved', decided_by=$1, decided_at=now(), decided_reason=$2
          WHERE id=$3`, [perm.userId, req.body?.reason ? String(req.body.reason) : null, cid]);
      // 같은 고객에 걸린 나머지 대기 요청은 무효가 된다(우선권이 이미 결정됐다).
      await c.query(
        `UPDATE customer_rfc_claims SET status='superseded', decided_by=$1, decided_at=now()
          WHERE customer_id=$2 AND status='pending' AND id<>$3`, [perm.userId, k.customer_id, cid]);
    });
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'rfc_claim_approve',$2,$3,$4)`,
        [k.customer_id, req.body?.reason ? String(req.body.reason) : null,
         JSON.stringify({ claim_id: cid, rfc: k.rfc, requested_at: k.requested_at_txt,
           previous_owner_id: prevOwner == null ? null : Number(prevOwner),
           new_owner_id: Number(k.requested_by), new_team_id: newTeam == null ? null : Number(newTeam) }),
         perm.userId]);
    } catch (_) { /* ignore */ }
    await safeLog({ userId: perm.userId, action: 'approve_rfc_claim', target: `customer:${k.customer_id}`,
      detail: { claim_id: cid, new_owner_id: Number(k.requested_by) } });
    return { ok: true, id: cid, customer_id: Number(k.customer_id), rfc: k.rfc,
      new_owner: reqUser?.name || null,
      // ★ 화면에 보여 주는 선점 시점도 요청 시각이다(승인 시각이 아니다).
      note: `${k.customer_name} 의 선점이 ${reqUser?.name || '요청자'} 님에게 이관되었습니다(선점 시점 ${k.requested_at_txt}).` };
  });

  // 선점 이관 반려 — 사유 필수. RFC 는 다시 비어 있는 상태로 남고, 다음 요청이 들어올 수 있다.
  app.post('/api/customer-rfc-claims/:id/reject', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const cid = Number(req.params.id);
    const perm = req.ctx.perm;
    if (!(await claimTableReady())) return reply.code(503).send({ error: 'migration_required' });
    const reason = String(req.body?.reason || '').trim();
    if (!reason) return reply.code(400).send({ error: 'reason_required', note: '반려 사유를 입력하세요.' });
    const k = (await query(
      `SELECT * FROM customer_rfc_claims WHERE id=$1 AND status='pending'`, [cid])).rows[0];
    if (!k) return reply.code(404).send({ error: 'not_found' });
    await query(
      `UPDATE customer_rfc_claims SET status='rejected', decided_by=$1, decided_at=now(), decided_reason=$2
        WHERE id=$3`, [perm.userId, reason, cid]);
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'rfc_claim_reject',$2,$3,$4)`,
        [k.customer_id, reason, JSON.stringify({ claim_id: cid, rfc: k.rfc }), perm.userId]);
    } catch (_) { /* ignore */ }
    await safeLog({ userId: perm.userId, action: 'reject_rfc_claim', target: `customer:${k.customer_id}` });
    return { ok: true, id: cid };
  });

  // =====================================================================
  // 0185 → **0267 · 고객 등록 사후승인 (디렉터)**
  //
  //   바뀐 것: 이 목록은 「쓸 수 없는 고객」이 아니라 「**이미 쓰고 있는데 아직 확인
  //   안 한 고객**」이다. 그래서 필터가 `approval_status='pending'` 에서
  //   `ratified_at IS NULL` 로 옮겨 갔다 — 사후승인 여부를 묻는 조건이 **한 곳**이다.
  //
  //   `?status=` 는 하위호환으로 남긴다(옛 화면이 보내도 깨지지 않게):
  //     status 없음 | 'pending'  → 사후승인 대기 (ratified_at IS NULL, 반려 제외)
  //     'approved'              → 사후승인 완료
  //     'rejected'              → 반려된 고객
  // =====================================================================
  app.get('/api/customer-registrations', { preHandler: [authGuard, requireDirector] }, async (req) => {
    if (!(await regColumnsReady())) return { items: [], migration_required: true };
    const ratifyOn = await ratifyColsReady();
    if (!ratifyOn) return { items: [], migration_required: true, need: '0267' };
    const status = ['pending', 'approved', 'rejected'].includes(req.query.status) ? req.query.status : 'pending';
    //   반려 건은 대기 목록에 섞이지 않는다 — 0267 마이그레이션이 ratified_at 을 채워 닫지만,
    //   그 뒤 사후 반려된 건도 있으므로 조건으로 한 번 더 못 박는다.
    const WHERE_BY_STATUS = {
      pending: `c.ratified_at IS NULL AND COALESCE(c.approval_status,'approved') <> 'rejected'`,
      approved: `c.ratified_at IS NOT NULL AND COALESCE(c.approval_status,'approved') = 'approved'`,
      rejected: `COALESCE(c.approval_status,'approved') = 'rejected'`,
    };
    const claimsOn = await claimTableReady();
    const rows = (await query(
      `SELECT c.id, c.code, c.name, c.rfc, c.constancia_no, COALESCE((to_jsonb(c)->>'discount_agreed')::numeric, c.discount) AS discount, COALESCE((to_jsonb(c)->>'credit_days_agreed')::int, c.credit_days) AS credit_days,
              ${await crmOriginColsReady() ? 'c.crm_customer_code' : 'NULL::text'} AS crm_customer_code,
              c.suggested_discount, c.syd_ref_code, c.syd_ref_buy_price, c.syd_ref_list_price,
              c.syd_ref_discount, c.ctr_ref_code, c.ctr_ref_list_price, c.customer_type, c.memo,
              to_char(c.created_at,'YYYY-MM-DD') AS registered_at,
              t.name AS team_name, u.name AS owner_name, cu.name AS created_by_name,
              COALESCE(c.approval_status,'approved') AS approval_status,
              ${claimsOn ? `to_char(c.rfc_claimed_at,'YYYY-MM-DD HH24:MI') AS rfc_claimed_at,` : `NULL::text AS rfc_claimed_at,`}
              (SELECT e.snapshot FROM customer_registration_events e
                WHERE e.customer_id=c.id AND e.action='submit'
                ORDER BY e.acted_at LIMIT 1) AS submit_snapshot,
              (SELECT count(*) FROM customer_documents d
                WHERE d.customer_id=c.id AND d.deleted_at IS NULL AND d.doc_type='constancia') AS constancia_docs,
              -- 0267 · **사후 반려는 되돌리는 일이다.** 이 고객에 이미 견적·매출이 붙어
              --   있으면 반려는 그 일까지 건드린다. 디렉터가 누르기 전에 보여 줘야 한다.
              (SELECT count(*) FROM quotes q
                WHERE q.customer_id=c.id AND q.deleted_at IS NULL) AS quote_cnt,
              (SELECT count(*) FROM invoices i
                WHERE i.customer_id=c.id AND i.deleted_at IS NULL) AS sale_cnt,
              to_char(c.ratified_at,'YYYY-MM-DD HH24:MI') AS ratified_at,
              ru.name AS ratified_by_name
         FROM customers c
         LEFT JOIN sales_teams t ON t.id=c.team_id
         LEFT JOIN users u ON u.id=c.owner_id
         LEFT JOIN users cu ON cu.id=c.created_by
         LEFT JOIN users ru ON ru.id=c.ratified_by
        WHERE c.deleted_at IS NULL AND ${WHERE_BY_STATUS[status]}
        ORDER BY c.created_at DESC LIMIT 200`)).rows;
    return {
      items: rows.map((r) => ({
        id: Number(r.id), code: r.code, name: r.name, rfc: r.rfc || null,
        constancia_no: r.constancia_no || null, constancia_docs: Number(r.constancia_docs),
        discount: r.discount == null ? null : Number(r.discount),
        credit_days: r.credit_days == null ? null : Number(r.credit_days),
        suggested_discount: r.suggested_discount == null ? null : Number(r.suggested_discount),
        discount_gap: discountGap(r.discount, r.suggested_discount),
        syd_ref_code: r.syd_ref_code, ctr_ref_code: r.ctr_ref_code,
        syd_ref_buy_price: r.syd_ref_buy_price == null ? null : Number(r.syd_ref_buy_price),
        syd_ref_list_price: r.syd_ref_list_price == null ? null : Number(r.syd_ref_list_price),
        syd_ref_discount: r.syd_ref_discount == null ? null : Number(r.syd_ref_discount),
        ctr_ref_list_price: r.ctr_ref_list_price == null ? null : Number(r.ctr_ref_list_price),
        customer_type: r.customer_type, memo: r.memo,
        team_name: r.team_name, owner_name: r.owner_name, created_by_name: r.created_by_name,
        registered_at: r.registered_at, approval_status: r.approval_status,
        // 0267 · 사후승인 축. ratified_at 이 null 이면 「아직 확인 안 함」 — 쓸 수 없다는 뜻이 아니다.
        ratified_at: r.ratified_at || null, ratified_by_name: r.ratified_by_name || null,
        // 사후 반려가 무엇을 건드리는지 — 디렉터가 누르기 전에 알아야 하는 숫자.
        quote_cnt: Number(r.quote_cnt || 0), sale_cnt: Number(r.sale_cnt || 0),
        crm_customer_code: r.crm_customer_code || null,
        from_crm: !!(r.crm_customer_code || /^p-/i.test(String(r.code || ''))),
        // 0193 · RFC 없이 올라온 건은 **선점이 없는 상태**다. 승인 화면에서 눈에 띄어야 한다.
        rfc_claimed: !!r.rfc, rfc_claimed_at: r.rfc_claimed_at || null,
        // 등록 시점에 박제한 유사 고객(경고). 디렉터가 중복인지 판단할 재료.
        similar: (r.submit_snapshot && Array.isArray(r.submit_snapshot.similar)) ? r.submit_snapshot.similar : [],
      })),
      claim_transfer_on: claimsOn,
    };
  });

  // 승인: 할인율을 디렉터가 조정해서 승인할 수도 있다(body.discount).
  app.post('/api/customer-registrations/:id/approve', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    if (!(await ratifyColsReady())) {
      return reply.code(503).send({ error: 'migration_required',
        note: '사후승인(0267) 마이그레이션이 아직 적용되지 않았습니다. Railway 콘솔에서 npm run migrate 를 먼저 실행하세요.' });
    }
    // 0267 · 대상 조건이 `pending` 에서 **`ratified_at IS NULL`** 로 옮겨 갔다.
    //   반려된 고객은 사후승인 대상이 아니다(반려를 되돌리려면 고객 수정 경로를 쓴다).
    const c = (await query(
      `SELECT * FROM customers
        WHERE id=$1 AND deleted_at IS NULL AND ratified_at IS NULL
          AND COALESCE(approval_status,'approved') <> 'rejected'`,
      [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    agreedTerms(c);
    // 0188 · CONSTANCIA 는 선택 증빙이 되었으므로 **승인을 막지 않는다**.
    //   대신 증빙 유무를 응답에 실어 승인 화면이 "증빙 없이 승인함" 을 남길 수 있게 한다.
    const docs = (await query(
      `SELECT count(*)::int AS n FROM customer_documents
        WHERE customer_id=$1 AND deleted_at IS NULL AND doc_type='constancia'`, [id])).rows[0];
    const hadDoc = Number(docs.n) > 0;
    let discount = c.discount == null ? 0 : Number(c.discount);
    if (req.body && req.body.discount != null && req.body.discount !== '') {
      const v = validateChosenDiscount(req.body.discount);
      if (!v.ok) return reply.code(400).send({ error: v.error });
      discount = v.value;
    }
    // 0267 · 사후승인은 **ratified_* 를 채우는 일**이다. approval_status 는 등록 때 이미
    //   approved 이지만, 0267 전환으로 넘어온 고객(예전 pending)과 혹시 모를 수동 변경을
    //   생각해 여기서도 approved 로 못 박는다 — 멱등하고, 상태가 갈라지지 않는다.
    await query(
      `UPDATE customers SET approval_status='approved', approved_by=$1, approved_at=now(),
              ratified_at=now(), ratified_by=$1, ratified_note=$4,
              rejected_reason=NULL, discount=$2, updated_by=$1 WHERE id=$3`,
      [perm.userId, discount, id,
       (req.body && req.body.reason) ? String(req.body.reason).slice(0, 500) : null]);
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'ratify',$2,$3,$4)`,
        [id, (req.body && req.body.reason) ? String(req.body.reason) : null,
         JSON.stringify({ approved_discount: discount, requested_discount: c.discount == null ? null : Number(c.discount),
           suggested_discount: c.suggested_discount == null ? null : Number(c.suggested_discount),
           constancia_doc: hadDoc }), perm.userId]);
    } catch (_) { /* ignore */ }
    // 디렉터가 할인율을 바꿔 승인했으면 변경이력에 남긴다
    if (Number(c.discount || 0) !== discount) {
      try {
        await logTermsHistory(id, [{ field: 'discount', old: Number(c.discount || 0), nv: discount }], {
          reason: '등록 승인 시 디렉터 조정', conditions: null, changedBy: c.created_by, approvedBy: perm.userId });
      } catch (_) { /* ignore */ }
    }
    // 0193 · RFC 가 없어도 승인은 된다(견적까지는 쓸 수 있어야 한다). 다만 **선점이 없는 고객**이므로
    //   경고를 실어 보낸다 — 매출 확정은 salesRoutes 에서 RFC 를 요구해 따로 막는다.
    const hasRfc = !!normalizeClaimKey(c.rfc);
    const warns = [];
    if (!hadDoc) warns.push('constancia_missing');
    if (!hasRfc) warns.push('rfc_missing');
    await safeLog({ userId: perm.userId, action: 'ratify_registration', target: `customer:${id}`,
      detail: { constancia_doc: hadDoc, rfc_claimed: hasRfc, discount } });
    // 0211 → 0267 · 리드는 이제 **등록 시점에** 닫힌다. 여기 남겨 둔 것은 전환(0267)으로
    //   넘어온 고객과, 등록 때 리드 정리가 실패했던 건을 위한 안전망이다 — 멱등하다.
    try {
      await query(
        `UPDATE crm_web_leads SET status='done', closed_by=$1, closed_at=now()
          WHERE customer_id=$2 AND status IN ('new','assigned','registered')`, [perm.userId, id]);
    } catch (_) { /* 0210/0211 미적용 — 승인은 그대로 진행 */ }

    // → CRM 전송. 등록 시점에 이미 한 번 나갔지만(origin=registration_create) 여기서
    //   **다시** 보낸다: 디렉터가 할인율을 조정했을 수 있고, 0267 전환으로 넘어온 고객은
    //   아직 한 번도 나가지 않았다. upsert 라 중복 전송이 해롭지 않다.
    await enqueueCustomerSync(id, 'upsert', { origin: 'registration_ratify', actorUserId: perm.userId, app });
    return { ok: true, id, discount, ratified: true, constancia_doc: hadDoc, rfc_claimed: hasRfc,
      warning: warns[0] || null, warnings: warns,
      warning_note: warns.length
        ? [
            hadDoc ? null : 'CONSTANCIA 스캔본 없이 승인했습니다(0188 이후 선택 항목).',
            hasRfc ? null : 'RFC 없이 승인했습니다 — 이 고객은 아직 선점되지 않았고, 다른 영업사원이 RFC 를 먼저 입력하면 우선권이 넘어갑니다. 매출 확정도 RFC 입력 전에는 막힙니다.',
          ].filter(Boolean).join(' ')
        : null };
  });

  // 반려: 선점을 풀어준다 — rejected 는 RFC·CONSTANCIA 두 유니크 인덱스 모두에서 빠진다 + 소프트 삭제.
  //
  // ★ 0267 · **반려의 성격이 바뀌었다.** 예전에는 아직 아무것도 못 한 고객을 걸러내는 일이었다.
  //   이제 이 고객은 등록된 순간부터 활성이었으므로, 그 사이 견적이 나갔거나 팩투라가
  //   발행됐을 수 있다. 그런 고객을 소프트 삭제하면 **이미 일어난 거래의 상대가 사라진다.**
  //   그래서 붙어 있는 일을 먼저 보고 판단한다:
  //     · 매출(팩투라)이 있으면 → **반려하지 않는다.** 되돌릴 수 없는 일이 이미 끝났다.
  //     · 견적만 있으면       → 디렉터가 confirm 을 보내야 진행한다(화면이 숫자를 보여 주고 묻는다).
  app.post('/api/customer-registrations/:id/reject', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    const reason = (req.body && req.body.reason) ? String(req.body.reason).trim() : '';
    if (!reason) return reply.code(400).send({ error: 'reason_required', note: '반려 사유를 입력하세요.' });
    if (!(await ratifyColsReady())) {
      return reply.code(503).send({ error: 'migration_required',
        note: '사후승인(0267) 마이그레이션이 아직 적용되지 않았습니다. Railway 콘솔에서 npm run migrate 를 먼저 실행하세요.' });
    }
    const c = (await query(
      `SELECT id, name, code FROM customers
        WHERE id=$1 AND deleted_at IS NULL AND ratified_at IS NULL
          AND COALESCE(approval_status,'approved') <> 'rejected'`,
      [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    const att = (await query(
      `SELECT (SELECT count(*)::int FROM quotes   q WHERE q.customer_id=$1 AND q.deleted_at IS NULL) AS quote_cnt,
              (SELECT count(*)::int FROM invoices i WHERE i.customer_id=$1 AND i.deleted_at IS NULL) AS sale_cnt`,
      [id])).rows[0];
    const quoteCnt = Number(att.quote_cnt || 0), saleCnt = Number(att.sale_cnt || 0);
    if (saleCnt > 0) {
      return reply.code(409).send({ error: 'has_sales', quote_cnt: quoteCnt, sale_cnt: saleCnt,
        note: `이 고객에게 이미 매출 ${saleCnt}건이 있습니다 — 반려로 지울 수 없습니다. `
          + '조건이 문제라면 고객 상세에서 할인율·외상일을 고치고, 거래를 끊어야 한다면 고객 삭제 경로를 쓰세요.' });
    }
    if (quoteCnt > 0 && !(req.body && req.body.confirm === true)) {
      return reply.code(409).send({ error: 'has_quotes', quote_cnt: quoteCnt, sale_cnt: 0,
        note: `이 고객으로 작성된 견적이 ${quoteCnt}건 있습니다. 반려하면 고객이 삭제되어 그 견적들의 고객이 사라집니다. `
          + '계속하려면 다시 확인해 주세요.' });
    }
    await query(
      `UPDATE customers SET approval_status='rejected', rejected_reason=$1, approved_by=$2, approved_at=now(),
              ratified_at=now(), ratified_by=$2, deleted_at=now(), updated_by=$2 WHERE id=$3`,
      [reason, perm.userId, id]);
    try {
      await query(
        `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
         VALUES ($1,'reject',$2,$3,$4)`,
        [id, reason, JSON.stringify({ quote_cnt: quoteCnt, sale_cnt: saleCnt, post_approval: true }), perm.userId]);
    } catch (_) { /* ignore */ }
    await safeLog({ userId: perm.userId, action: 'reject_registration', target: `customer:${id}`,
      detail: { quote_cnt: quoteCnt } });
    // → CRM 전송(반려). 이 고객은 등록 시점에 이미 CRM 으로 나갔으므로, 상태를 되돌리는
    //   전송이 **반드시** 필요하다(안 보내면 CRM 에만 살아 있는 고객이 된다).
    await enqueueCustomerSync(id, 'reject', { origin: 'registration_reject', actorUserId: perm.userId, reason, app });
    return { ok: true, id, quote_cnt: quoteCnt };
  });

  // =====================================================================
  // 0267 · **모아서 한 번에 사후승인** (디렉터 지시: "승인안한걸 모아서 나중에 승인")
  //
  //   한 건씩 누르는 화면으로는 「모아서」가 안 된다. 다만 **일괄에 할인율 조정은 없다** —
  //   여러 고객에게 같은 할인율을 한 번에 박는 버튼은 사고가 나는 종류의 편의다.
  //   할인율을 손볼 건은 단건 승인으로 가야 한다(화면이 그렇게 안내한다).
  //
  //   한 건이 실패해도 나머지는 승인한다 — 전부 되돌리면 디렉터가 원인 하나를 찾아
  //   고칠 때까지 아무것도 못 끝낸다. 대신 **실패한 건과 이유를 돌려준다.**
  // =====================================================================
  app.post('/api/customer-registrations/ratify-bulk', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const perm = req.ctx.perm;
    if (!(await ratifyColsReady())) {
      return reply.code(503).send({ error: 'migration_required',
        note: '사후승인(0267) 마이그레이션이 아직 적용되지 않았습니다. Railway 콘솔에서 npm run migrate 를 먼저 실행하세요.' });
    }
    const raw = Array.isArray(req.body?.ids) ? req.body.ids : [];
    const ids = [...new Set(raw.map((v) => Number(v)).filter((n) => Number.isInteger(n) && n > 0))];
    if (!ids.length) return reply.code(400).send({ error: 'ids_required', note: '승인할 고객을 선택하세요.' });
    if (ids.length > 200) {
      return reply.code(400).send({ error: 'too_many',
        note: '한 번에 200건까지 승인할 수 있습니다. 나눠서 눌러 주세요.' });
    }
    const note = (req.body && req.body.reason) ? String(req.body.reason).slice(0, 500) : null;
    //   대상만 골라 한 문장으로 갱신한다 — 건당 왕복을 돌면 200건에서 화면이 멈춘다.
    const done = (await query(
      `UPDATE customers
          SET approval_status='approved', approved_by=$1, approved_at=now(),
              ratified_at=now(), ratified_by=$1, ratified_note=$3,
              rejected_reason=NULL, updated_by=$1
        WHERE id = ANY($2::bigint[]) AND deleted_at IS NULL AND ratified_at IS NULL
          AND COALESCE(approval_status,'approved') <> 'rejected'
        RETURNING id, code, name`, [perm.userId, ids, note])).rows;
    const okIds = done.map((r) => Number(r.id));
    const skipped = ids.filter((n) => !okIds.includes(n));
    for (const r of done) {
      try {
        await query(
          `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
           VALUES ($1,'ratify',$2,$3,$4)`,
          [Number(r.id), note, JSON.stringify({ bulk: true, count: done.length }), perm.userId]);
      } catch (_) { /* 이력 실패가 승인을 되돌리지 않는다 */ }
      // 리드 안전망(등록 시점에 이미 닫혔을 수 있다 — 멱등).
      try {
        await query(
          `UPDATE crm_web_leads SET status='done', closed_by=$1, closed_at=now()
            WHERE customer_id=$2 AND status IN ('new','assigned','registered')`, [perm.userId, Number(r.id)]);
      } catch (_) { /* 0210/0211 미적용 */ }
      // 0267 전환으로 넘어온 고객은 아직 CRM 에 안 나갔다 — 여기서 보낸다(upsert, 멱등).
      await enqueueCustomerSync(Number(r.id), 'upsert',
        { origin: 'registration_ratify_bulk', actorUserId: perm.userId, app });
    }
    await safeLog({ userId: perm.userId, action: 'ratify_registration_bulk',
      target: `customer:${okIds.join(',')}`, detail: { ok: okIds.length, skipped: skipped.length } });
    return { ok: true, ratified: done.map((r) => ({ id: Number(r.id), code: r.code, name: r.name })),
      ratified_count: done.length, skipped,
      note: skipped.length
        ? `${done.length}건 승인했습니다. ${skipped.length}건은 이미 승인됐거나 반려·삭제된 고객이라 건너뛰었습니다.`
        : `${done.length}건 승인했습니다.` };
  });

  // 고객 수정
  // ===== 타팀 고객 수정요청(디렉터 승인 전제) =====
  //  배경: 영업이 다른 팀 고객을 "본인 담당으로 이관" 하려면 그 고객을 수정해야 하는데,
  //        고객 목록·상세는 팀 스코프라 아예 접근이 막혀 있었다(403 forbidden_team).
  //  방침: 열람 범위는 넓히지 않는다. 대신 디렉터가 켜 준 「타팀 수정요청」 권한이 있는 사용자에게만
  //        ① 상호/코드/RFC 로 고객을 "찾고"(최소 신원정보만),
  //        ② 그 고객의 "수정 요청 폼에 필요한 기본 항목"만 읽고,
  //        ③ PATCH 로 수정 요청을 넣는 경로를 연다. 실제 반영은 디렉터 승인 시에만.
  //  ⚠ 매출·미수·인보이스·증빙서류·방문이력 등 민감 데이터는 이 경로로 절대 나가지 않는다.

  // 고객 찾기(타팀 포함) — 수정요청용 최소 신원정보만 반환
  app.get('/api/customers/lookup', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const perm = req.ctx.perm;
    if (perm.role !== 'director' && !canRequestCrossTeam(perm)) {
      return reply.code(403).send({ error: 'cross_team_request_denied' });
    }
    const q = String(req.query.q || '').trim();
    if (q.length < 2) return { items: [], note: 'min_2_chars' };
    const vis = visibleTeamIds(perm);
    const rows = (await query(
      `SELECT c.id, c.code, c.name, c.rfc, c.team_id, t.name AS team_name, c.owner_id, u.name AS owner_name,
              (EXISTS (SELECT 1 FROM customer_change_requests r WHERE r.customer_id=c.id AND r.status='pending')) AS has_pending
         FROM customers c
         LEFT JOIN sales_teams t ON t.id=c.team_id
         LEFT JOIN users u ON u.id=c.owner_id
        WHERE c.deleted_at IS NULL
          AND (c.name ILIKE $1 OR c.code ILIKE $1 OR c.rfc ILIKE $1)
        ORDER BY c.name LIMIT 30`, [`%${q}%`])).rows;
    return {
      items: rows.map((c) => ({
        id: Number(c.id), code: c.code, name: c.name, rfc: c.rfc,
        team_id: c.team_id == null ? null : Number(c.team_id), team_name: c.team_name,
        owner_id: c.owner_id == null ? null : Number(c.owner_id), owner_name: c.owner_name,
        // in_scope=true 면 원래 내 팀 고객(목록에서 그냥 열면 됨), false 면 타팀 → 수정요청 대상
        in_scope: vis === null ? true : (c.team_id != null && vis.includes(Number(c.team_id))),
        pending_change: !!c.has_pending,
      })),
    };
  });

  // 수정요청 폼용 기본 항목만 조회(타팀 고객 허용) — 금액·이력·서류는 포함하지 않는다
  app.get('/api/customers/:id/edit-basic', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    const c = (await query(
      `SELECT c.id, c.code, c.name, c.rfc, c.contact, c.phone, c.buyer_name, c.buyer_phone,
              COALESCE((to_jsonb(c)->>'discount_agreed')::numeric, c.discount) AS discount, COALESCE((to_jsonb(c)->>'credit_days_agreed')::int, c.credit_days) AS credit_days, c.branch_count, c.customer_type, c.memo, c.constancia_fiscal,
              c.ship_address, c.team_id, c.stage_id, c.owner_id,
              t.name AS team_name, s.name AS stage_name, u.name AS owner_name
         FROM customers c
         LEFT JOIN sales_teams t ON t.id=c.team_id
         LEFT JOIN stages s ON s.id=c.stage_id
         LEFT JOIN users u ON u.id=c.owner_id
        WHERE c.id=$1 AND c.deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    const inScope = canViewTeam(perm, c.team_id);        // 볼 수 있나 (금액 등 노출 판단)
    const canEdit = canEditTeam(perm, c.team_id);        // 바로 고칠 수 있나 (승인 없이)
    if (!inScope && !canRequestCrossTeam(perm)) return reply.code(403).send({ error: 'forbidden_team' });
    const pend = (await query(
      `SELECT r.id, r.requested_by, u.name AS requested_by_name, r.created_at
         FROM customer_change_requests r LEFT JOIN users u ON u.id=r.requested_by
        WHERE r.customer_id=$1 AND r.status='pending' LIMIT 1`, [id])).rows[0] || null;
    return {
      item: {
        id: Number(c.id), code: c.code, name: c.name, rfc: c.rfc, contact: c.contact, phone: c.phone,
        buyer_name: c.buyer_name, buyer_phone: c.buyer_phone,
        discount: c.discount == null ? 0 : Number(c.discount),
        credit_days: c.credit_days == null ? 0 : Number(c.credit_days),
        branch_count: c.branch_count == null ? null : Number(c.branch_count),
        customer_type: c.customer_type, memo: c.memo, constancia_fiscal: c.constancia_fiscal,
        // 배송지는 타팀 요청 화면에서 수정 대상이 아니다(즉시 저장 경로라 승인 우회가 되므로).
        ship_address: inScope ? (c.ship_address || null) : null,
        team_id: c.team_id == null ? null : Number(c.team_id), team_name: c.team_name,
        stage_id: c.stage_id == null ? null : Number(c.stage_id), stage_name: stageLabel(c.stage_name),
        owner_id: c.owner_id == null ? null : Number(c.owner_id), owner_name: c.owner_name,
      },
      in_scope: inScope,
      // ⚠ cross_team 은 "볼 수 있나"가 아니라 "바로 고칠 수 있나" 기준이다.
      //   상대팀 열람만 부여받은 사용자는 고객이 목록에 보여서 일반 수정 화면으로 들어오는데,
      //   그때도 배송지 즉시저장은 막히고 저장은 승인 대기로 가야 하므로 PATCH 와 같은 기준을 쓴다.
      cross_team: !canEdit,
      pending: pend ? { id: Number(pend.id), requested_by_name: pend.requested_by_name, created_at: pend.created_at } : null,
    };
  });

  // 고객 수정에 적용할 필드를 customers에 반영(헬퍼) — 승인 시 재사용
  async function applyCustomerUpdate(id, c, b, userId) {
    // 빈문자열/무효값이 숫자·FK 컬럼(owner_id, stage_id, team_id, credit_days 등)에 들어가
    // "invalid input syntax for type bigint" 류 오류로 승인이 실패하던 문제 방지.
    // (요청 생성 시엔 proposed JSON 저장만 하므로 통과, 실제 검증은 승인 UPDATE 시점에 발생)
    // 필수/NOT NULL 숫자(team_id·stage_id·discount·credit_days): 빈값·무효 → 현재값 유지.
    const keepNum = (v, cur) => {
      if (v === undefined || v === '' || v === null) return cur;
      const n = Number(v); return Number.isFinite(n) ? n : cur;
    };
    // nullable FK/숫자(owner_id·branch_count): 빈값 → null(명시적 비움 허용), 무효 → 현재값.
    const nullNum = (v, cur) => {
      if (v === undefined) return cur;
      if (v === '' || v === null) return null;
      const n = Number(v); return Number.isFinite(n) ? n : cur;
    };
    const teamId = keepNum(b.team_id, c.team_id);
    const stageId = keepNum(b.stage_id, c.stage_id);
    const stageChanged = Number(stageId) !== Number(c.stage_id);
    // 0188 · RFC 가 선점 키이지만, **수정 화면에서는 RFC 를 강요하지 않는다.**
    //   전화·배송지·구매결정권자만 고치려는 사람에게 RFC 형식까지 요구하면 일상 업무가 막힌다.
    //   RFC 가 없거나 형식이 지저분한 레거시 고객이 실제로 많다.
    //   ① 빈값이면 **그냥 현재값을 유지**한다(오류 아님). 지워서 선점이 풀리는 일만 막으면 된다.
    //   ② 형식 검증은 **하지 않는다** — 신규 등록(=선점이 생기는 순간)에서만 본다.
    //   ③ 남의 선점을 뺏는 것만 막는다. 이건 어차피 DB 유니크가 던지므로,
    //      500 대신 "누가 갖고 있는지" 를 알려 주려고 미리 조회한다.
    //   20261028 · ⚠ `b.rfc` 가 **null** 이면 String(null) = 'null' 이 되어 「null」 이라는 RFC 가
    //     새로 입력된 것으로 취급됐다. 수정 요청의 proposed JSON 은 RFC 없는 고객이면 rfc:null 을
    //     싣고 오므로, 승인할 때마다 'NULL' 선점키로 충돌 검사가 돌아 같은 'null' 이 저장된
    //     엉뚱한 고객(예: JOEL FUANTOS LUNA · 담당 dante)이 「이미 등록된 고객」 으로 잡혔다.
    //     충돌이 없던 때에는 'null' 문자열이 그대로 RFC 로 저장됐다(그렇게 생긴 행이 그 고객).
    //   → null·'null'·'undefined' 같은 자리표시 값은 **입력이 없는 것**으로 본다(현재값 유지).
    const rfcIn = (b.rfc === undefined || b.rfc === null) ? '' : String(b.rfc).trim();
    const rfcGiven = rfcIn !== '' && !/^(null|undefined|none|n\/?a)$/i.test(rfcIn);
    const rfcVal = rfcGiven ? rfcIn : (isPlaceholderRfc(c.rfc) ? null : (c.rfc || null));
    const rfcChanged = !!rfcVal && normalizeClaimKey(rfcVal) !== normalizeClaimKey(c.rfc);
    if (rfcChanged) {
      // 0193 · 확정 선점뿐 아니라 **대기 중인 선점 요청**도 막는다.
      //   먼저 RFC 를 넣은 사람의 우선권이 남의 수정으로 뚫리면 선점 장치가 무의미해진다.
      const clash = await findRfcHolder(normalizeClaimKey(rfcVal), { excludeCustomerId: id });
      if (clash) {
        const err = clash.kind === 'claim' ? 'rfc_claim_pending' : 'rfc_taken';
        const e = new Error(err); e.claimError = err;
        e.claimNote = rfcHolderNote(clash);
        throw e;
      }
    }
    // 0193 · 비어 있던 RFC 가 채워지는 순간이 곧 선점 시점이다(이 값이 커미션 귀속의 근거).
    //   이미 RFC 가 있던 고객의 표기 정정은 선점 시점을 다시 찍지 않는다 — 새로 잡은 게 아니다.
    const claimsOn = await claimTableReady();
    const newlyClaimed = claimsOn && rfcChanged && !normalizeClaimKey(c.rfc);
    // 0280 · 담당자 변경이 독점과 부딪히는지 UPDATE 전에 판정한다(막히면 아무것도 저장하지 않음).
    const newOwner = nullNum(b.owner_id, c.owner_id);
    const ownerChanged = newOwner != null && Number(newOwner) !== Number(c.owner_id);
    const ownerPlan = ownerChanged ? await planOwnerChange(query, id, Number(newOwner)) : { action: 'none' };
    if (ownerPlan.action === 'block') {
      const e = new Error(ownerPlan.error); e.claimError = ownerPlan.error; e.claimNote = ownerPlan.note;
      throw e;
    }
    // 0185 · CONSTANCIA 번호는 마이그레이션이 적용된 DB 에서만 건드린다
    //   (컬럼이 없는 반쪽 배포 상태에서도 기존 고객 수정이 죽지 않게).
    //   0188 이후 선점 키가 아니므로 **빈값으로 지우는 것도 허용**한다.
    const conOn = await regColumnsReady();
    const params = [b.name || c.name, rfcVal, b.contact !== undefined ? b.contact : c.contact,
      b.phone !== undefined ? b.phone : c.phone, keepNum(b.discount, c.discount),
      keepNum(b.credit_days, c.credit_days), teamId,
      stageId, nullNum(b.owner_id, c.owner_id),
      b.customer_type !== undefined ? b.customer_type : c.customer_type,
      b.memo !== undefined ? b.memo : c.memo, stageChanged, userId, id,
      b.constancia_fiscal !== undefined ? b.constancia_fiscal : c.constancia_fiscal,
      nullNum(b.branch_count, c.branch_count),
      b.buyer_name !== undefined ? b.buyer_name : c.buyer_name,
      b.buyer_phone !== undefined ? b.buyer_phone : c.buyer_phone];
    if (conOn) {
      params.push(b.constancia_no === undefined
        ? (c.constancia_no || null)
        : (String(b.constancia_no).trim() || null));
    }
    await query(
      `UPDATE customers SET name=$1, rfc=$2, contact=$3, phone=$4, discount=$5, credit_days=$6,
         team_id=$7, stage_id=$8, owner_id=$9, customer_type=$10, memo=$11, constancia_fiscal=$15, branch_count=$16,
         buyer_name=$17, buyer_phone=$18${conOn ? ', constancia_no=$19' : ''}
         ${newlyClaimed ? ', rfc_claimed_at=now(), rfc_claimed_by=COALESCE($9::bigint,$13::bigint)' : ''},
         stage_since=CASE WHEN $12 THEN CURRENT_DATE ELSE stage_since END, updated_by=$13 WHERE id=$14`,
      params);
    // 선점이 방금 성립했다면 이력에 남긴다 — 나중에 "언제부터 이 사람 고객인가" 를 여기서 읽는다.
    if (newlyClaimed) {
      try {
        await query(
          `INSERT INTO customer_registration_events (customer_id, action, reason, snapshot, acted_by)
           VALUES ($1,'rfc_claim_self','고객 수정에서 RFC 입력',$2,$3)`,
          [id, JSON.stringify({ rfc: rfcVal, via: 'customer_edit' }), userId]);
      } catch (_) { /* 이력 실패가 저장을 막지 않음 */ }
    }
    if (ownerPlan.action === 'transfer') await applyOwnerTransfer(id, Number(newOwner), userId, ownerPlan);
  }

  app.patch('/api/customers/:id', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    const c = agreedTerms((await query(`SELECT * FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0]);
    if (!c) return reply.code(404).send({ error: 'not_found' });
    // 타팀 고객: cross_team_request 권한이 있으면 "수정 요청"만 허용(즉시 반영 경로로는 절대 못 감).
    const crossTeam = !canEditTeam(perm, c.team_id);
    if (crossTeam && !canRequestCrossTeam(perm)) return reply.code(403).send({ error: 'forbidden_team' });
    const b = req.body || {};
    // ── 20260918tier · 이메일은 **수정에서도** 필수다 ──────────────────
    //   다만 «본문에 contact 가 실려 온 경우»에만 본다. 배송지 즉시저장처럼 일부 항목만
    //   보내는 경로까지 이메일을 요구하면 일상 업무가 멈춘다.
    //   전화·TIER 는 여기서 막지 않는다 — 기존 고객 정리는 목록의 ⚠ 배지로 유도한다.
    if (b.contact !== undefined) {
      const v = String(b.contact == null ? '' : b.contact).trim();
      if (!v) return reply.code(400).send({ error: 'contact_required', note: CONTACT_REQUIRED_NOTE });
      if (!isEmailAddr(v)) return reply.code(400).send({ error: 'contact_invalid', note: CONTACT_INVALID_NOTE });
      b.contact = v;
    }
    // 팀 이동 권한 체크(디렉터/양팀 편집권).
    //   타팀 수정요청은 "이관 요청" 그 자체이므로 목적지 팀 편집권을 요구하지 않는다
    //   — 어차피 제안일 뿐이고 디렉터 승인에서 최종 판단한다.
    if (!crossTeam && b.team_id != null && Number(b.team_id) !== c.team_id) {
      if (!canEditTeam(perm, Number(b.team_id))) return reply.code(403).send({ error: 'forbidden_team_move' });
    }
    // 기본할인(%)·외상일 변경은 수정이유 + 제공 조건 작성이 필수(디렉터 포함)
    const termsChanges = detectTermsChanges(c, b);
    const termsReason = String(b.terms_reason || b.reason || '').trim();
    const termsConditions = String(b.terms_conditions || '').trim();
    if (termsChanges.length && (!termsReason || !termsConditions)) {
      return reply.code(400).send({ error: 'terms_reason_required',
        note: '기본할인(%)·외상일을 변경할 때는 수정이유와 제공 조건을 반드시 입력해야 합니다.' });
    }
    // 디렉터: 즉시 반영(+이력 기록) / 그 외: 디렉터 승인 대기로 보관
    // (crossTeam 은 디렉터에게 항상 false — 방어적으로 한 번 더 명시)
    if (perm.role === 'director' && !crossTeam) {
      const pinErr = await discountPinError(termsChanges, perm.userId, b.discount_pin);
      if (pinErr) return reply.code(pinErr.code).send(pinErr.body);
      try {
        await applyCustomerUpdate(id, c, b, perm.userId);
      } catch (e) {
        if (e.claimError) {
          return reply.code((e.claimError === 'rfc_taken' || e.claimError === 'rfc_claim_pending') ? 409 : 400)
            .send({ error: e.claimError, note: e.claimNote || RFC_ERROR_NOTE[e.claimError] || null });
        }
        throw e;
      }
      if (termsChanges.length) {
        await logTermsHistory(id, termsChanges, { reason: termsReason, conditions: termsConditions, changedBy: perm.userId, approvedBy: perm.userId });
      }
      await safeLog({ userId: perm.userId, action: 'update', target: `customer:${id}` });
      // → CRM 전송(디렉터 즉시 수정). 승인 단계가 없는 경로라 여기가 곧 확정 시점이다.
      //   승인 대기 고객(pending)은 아직 확정 전이므로 보내지 않는다.
      if (String(c.approval_status || 'approved') !== 'pending') {
        await enqueueCustomerSync(id, 'upsert', { origin: 'director_edit', actorUserId: perm.userId, app });
      }
      return { ok: true };
    }
    // 같은 고객에 이미 대기중인 요청이 있으면 갱신(최신으로 덮어씀)
    // ⚠ 여기에 빠진 필드는 승인해도 절대 반영되지 않는다(diff에도 안 뜸).
    //    승인 화면 LABELS / applyCustomerUpdate 와 항상 같은 집합을 유지할 것.
    //    2026-08-18: buyer_name·buyer_phone(구매결정권자 WhatsApp)·branch_count 누락 수정.
    const proposed = {
      name: b.name, rfc: b.rfc, contact: b.contact, phone: b.phone,
      buyer_name: b.buyer_name, buyer_phone: b.buyer_phone,
      discount: b.discount, credit_days: b.credit_days, branch_count: b.branch_count,
      team_id: b.team_id, stage_id: b.stage_id, owner_id: b.owner_id,
      customer_type: b.customer_type, memo: b.memo, constancia_fiscal: b.constancia_fiscal,
      constancia_no: b.constancia_no,
    };
    const existing = (await query(`SELECT id FROM customer_change_requests WHERE customer_id=$1 AND status='pending'`, [id])).rows[0];
    if (existing) {
      await query(`UPDATE customer_change_requests SET proposed=$1, requested_by=$2, reason=$3, conditions=$4, created_at=now() WHERE id=$5`,
        [JSON.stringify(proposed), perm.userId, termsReason || null, termsConditions || null, existing.id]);
    } else {
      await query(`INSERT INTO customer_change_requests (customer_id, proposed, requested_by, reason, conditions) VALUES ($1,$2,$3,$4,$5)`,
        [id, JSON.stringify(proposed), perm.userId, termsReason || null, termsConditions || null]);
    }
    await safeLog({ userId: perm.userId, action: 'change_request', target: `customer:${id}`, detail: { cross_team: crossTeam } });
    return { ok: true, pending: true, cross_team: crossTeam };
  });

  // 배송지(ship_address) 즉시 저장 — 승인 플로우 없이 언제든 입력/수정 가능.
  //   포장 라벨(etiqueta)·패킹리스트 출력에 쓰이는 운영 정보라 지연 없이 반영한다.
  //   편집 권한(requirePageEdit) + 팀 편집권만 확인. 빈값 저장 = 배송지 비우기.
  app.patch('/api/customers/:id/ship-address', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    const c = (await query(`SELECT id, team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canEditTeam(perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const raw = (req.body || {}).ship_address;
    const val = (raw == null || String(raw).trim() === '') ? null : String(raw).trim();
    await query(`UPDATE customers SET ship_address=$1, updated_by=$2 WHERE id=$3`, [val, perm.userId, id]);
    await safeLog({ userId: perm.userId, action: 'update', target: `customer:${id}`, detail: { field: 'ship_address' } });
    return { ok: true, ship_address: val };
  });

  // ── 0304 · 고객 메모 기록(고객 상세 「고객정보」 아래) ─────────────────
  //   보기 = 고객을 볼 수 있는 사람(canViewTeam) · 쓰기 = 편집권 + 팀 편집권 · 승인 없음(즉시).
  //   삭제 = 작성자 본인 또는 디렉터, deleted_at 만 찍는다.
  const NOTE_MAX = 2000;
  const noteRow = (r, perm) => ({
    id: Number(r.id), body: r.body, created_at: r.created_at_str,
    created_by: r.created_by == null ? null : Number(r.created_by), author: r.author || null,
    can_delete: perm.role === 'director' || (r.created_by != null && Number(r.created_by) === Number(perm.userId)),
  });
  const NOTE_SELECT = `SELECT n.id, n.body, n.created_by, u.name AS author,
            to_char(n.created_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS created_at_str
       FROM customer_notes n LEFT JOIN users u ON u.id = n.created_by`;

  app.get('/api/customers/:id/notes', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    const c = (await query(`SELECT id, team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const rows = (await query(`${NOTE_SELECT} WHERE n.customer_id=$1 AND n.deleted_at IS NULL ORDER BY n.created_at DESC, n.id DESC LIMIT 200`, [id])).rows;
    const pageEdit = perm.role === 'director' || ((perm.pageAccess && perm.pageAccess.customers) || 'edit') === 'edit';
    return { items: rows.map((r) => { const x = noteRow(r, perm); x.can_delete = x.can_delete && pageEdit; return x; }), can_write: pageEdit && canEditTeam(perm, c.team_id) };
  });

  app.post('/api/customers/:id/notes', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const perm = req.ctx.perm;
    const c = (await query(`SELECT id, team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canEditTeam(perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team', note: '다른 팀 고객에는 메모를 쓸 수 없습니다.' });
    const raw = (req.body || {}).body;
    const body = String(raw == null ? '' : raw).replace(/\r\n/g, '\n').trim();
    if (!body) return reply.code(400).send({ error: 'note_empty', note: '메모 내용을 입력하세요.' });
    if (body.length > NOTE_MAX) return reply.code(400).send({ error: 'note_too_long', note: `메모는 ${NOTE_MAX}자까지입니다.` });
    const ins = (await query(`INSERT INTO customer_notes (customer_id, body, created_by) VALUES ($1,$2,$3) RETURNING id`,
      [id, body, perm.userId])).rows[0];
    const row = (await query(`${NOTE_SELECT} WHERE n.id=$1`, [ins.id])).rows[0];
    await safeLog({ userId: perm.userId, action: 'create', target: `customer:${id}`, detail: { field: 'note', note_id: Number(ins.id) } });
    return { ok: true, item: noteRow(row, perm) };
  });

  app.delete('/api/customers/:id/notes/:noteId', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const noteId = Number(req.params.noteId);
    const perm = req.ctx.perm;
    const n = (await query(
      `SELECT n.id, n.created_by, c.team_id FROM customer_notes n JOIN customers c ON c.id=n.customer_id
        WHERE n.id=$1 AND n.customer_id=$2 AND n.deleted_at IS NULL`, [noteId, id])).rows[0];
    if (!n) return reply.code(404).send({ error: 'not_found' });
    const mine = n.created_by != null && Number(n.created_by) === Number(perm.userId);
    if (perm.role !== 'director' && !mine) return reply.code(403).send({ error: 'forbidden', note: '본인이 쓴 메모만 지울 수 있습니다(디렉터는 전부).' });
    if (perm.role !== 'director' && !canEditTeam(perm, n.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    await query(`UPDATE customer_notes SET deleted_at=now(), deleted_by=$1 WHERE id=$2`, [perm.userId, noteId]);
    await safeLog({ userId: perm.userId, action: 'delete', target: `customer:${id}`, detail: { field: 'note', note_id: noteId } });
    return { ok: true };
  });

  // 단계별 고객수 요약(팀별 + 합계) — 견적30/협상40/수주50/거래중60
  app.get('/api/customers/stage-summary', { preHandler: [authGuard, requirePage('customers')] }, async (req) => {
    const { perm } = req.ctx;
    const vis = visibleTeamIds(perm);
    const conds = ['c.deleted_at IS NULL']; const params = [];
    if (vis !== null) {
      if (!vis.length) return { teams: [], total: { total: 0, unset: 0, latent: 0, contact: 0, quote: 0, nego: 0, won: 0, active: 0 } };
      params.push(vis); conds.push(`c.team_id = ANY($${params.length})`);
    }
    const rows = (await query(
      `SELECT c.team_id, t.name AS team_name, t.sort_order AS team_sort,
              COUNT(*)::int AS total,
              COUNT(*) FILTER (WHERE s.sort_order IS NULL OR s.sort_order=0)::int AS unset,
              COUNT(*) FILTER (WHERE s.sort_order=10)::int AS latent,
              COUNT(*) FILTER (WHERE s.sort_order=20)::int AS contact,
              COUNT(*) FILTER (WHERE s.sort_order=30)::int AS quote,
              COUNT(*) FILTER (WHERE s.sort_order=40)::int AS nego,
              COUNT(*) FILTER (WHERE s.sort_order=50)::int AS won,
              COUNT(*) FILTER (WHERE s.sort_order=60)::int AS active
         FROM customers c
         LEFT JOIN sales_teams t ON t.id=c.team_id
         LEFT JOIN stages s ON s.id=c.stage_id
        WHERE ${conds.join(' AND ')}
        GROUP BY c.team_id, t.name, t.sort_order
        ORDER BY t.sort_order NULLS LAST, t.name`, params)).rows;
    const teams = rows.map((r) => ({
      team_id: r.team_id, team_name: r.team_name || '(미지정)',
      total: Number(r.total), unset: Number(r.unset), latent: Number(r.latent), contact: Number(r.contact),
      quote: Number(r.quote), nego: Number(r.nego), won: Number(r.won), active: Number(r.active),
    }));
    const total = teams.reduce((a, t) => ({
      total: a.total + t.total, unset: a.unset + t.unset, latent: a.latent + t.latent, contact: a.contact + t.contact,
      quote: a.quote + t.quote, nego: a.nego + t.nego, won: a.won + t.won, active: a.active + t.active,
    }), { total: 0, unset: 0, latent: 0, contact: 0, quote: 0, nego: 0, won: 0, active: 0 });
    return { teams, total };
  });

  // 고객 수정 승인 대기 목록(디렉터)
  app.get('/api/customer-change-requests', { preHandler: [authGuard, requireDirector] }, async (req) => {
    const status = ['pending', 'approved', 'rejected'].includes(req.query.status) ? req.query.status : 'pending';
    const cid = req.query.customer_id ? Number(req.query.customer_id) : null;
    const rows = (await query(
      `SELECT r.id, r.customer_id, r.proposed, r.status, r.reason, r.conditions, r.created_at,
              c.code AS customer_code, c.name AS customer_name,
              c.name AS cur_name, c.rfc AS cur_rfc, c.contact AS cur_contact, c.phone AS cur_phone,
              c.buyer_name AS cur_buyer_name, c.buyer_phone AS cur_buyer_phone,
              COALESCE((to_jsonb(c)->>'discount_agreed')::numeric, c.discount) AS cur_discount, COALESCE((to_jsonb(c)->>'credit_days_agreed')::int, c.credit_days) AS cur_credit_days, c.branch_count AS cur_branch_count,
              c.team_id AS cur_team_id, c.stage_id AS cur_stage_id, c.owner_id AS cur_owner_id,
              c.customer_type AS cur_customer_type, c.memo AS cur_memo, c.constancia_fiscal AS cur_constancia_fiscal,
              c.constancia_no AS cur_constancia_no,
              u.name AS requested_by_name, u.team_id AS requester_team_id, rt.name AS requester_team_name,
              ct.name AS cur_team_name
         FROM customer_change_requests r
         JOIN customers c ON c.id=r.customer_id
         LEFT JOIN users u ON u.id=r.requested_by
         LEFT JOIN sales_teams rt ON rt.id=u.team_id
         LEFT JOIN sales_teams ct ON ct.id=c.team_id
        WHERE r.status=$1 AND ($2::bigint IS NULL OR r.customer_id=$2) ORDER BY r.created_at DESC`, [status, cid])).rows;

    // 팀/단계/담당자 id → 이름 매핑(현재값·제안값 모두 모아서 한 번에 조회)
    const teamIds = new Set(), stageIds = new Set(), ownerIds = new Set();
    for (const r of rows) {
      const p = r.proposed || {};
      [r.cur_team_id, p.team_id].forEach((v) => { if (v != null && v !== '') teamIds.add(Number(v)); });
      [r.cur_stage_id, p.stage_id].forEach((v) => { if (v != null && v !== '') stageIds.add(Number(v)); });
      [r.cur_owner_id, p.owner_id].forEach((v) => { if (v != null && v !== '') ownerIds.add(Number(v)); });
    }
    const nameMap = async (table, ids) => {
      if (!ids.size) return {};
      const rs = (await query(`SELECT id, name FROM ${table} WHERE id = ANY($1)`, [[...ids]])).rows;
      const m = {}; rs.forEach((x) => { m[Number(x.id)] = x.name; }); return m;
    };
    const teamNames = await nameMap('sales_teams', teamIds);
    const stageNames = await nameMap('stages', stageIds);
    const ownerNames = await nameMap('users', ownerIds);

    const LABELS = { name: '고객명', rfc: 'RFC(선점 키)', contact: '이메일 주소', phone: '전화', buyer_name: '구매결정권자', buyer_phone: '구매결정권자 전화(WhatsApp)', discount: '기본할인', credit_days: '외상일', branch_count: '지점 수', team_id: '영업팀', stage_id: '영업단계', owner_id: '담당자', customer_type: '고객유형', memo: '메모', constancia_fiscal: '세무등록(Constancia)', constancia_no: 'CONSTANCIA 번호' };
    const NUMERIC = new Set(['discount', 'credit_days', 'branch_count', 'team_id', 'stage_id', 'owner_id']);
    const isEmpty = (v) => v == null || v === '';
    const disp = (field, val) => {
      if (isEmpty(val)) return '(미지정)';
      if (field === 'team_id') return teamNames[Number(val)] || `팀 #${val}`;
      if (field === 'stage_id') return stageLabel(stageNames[Number(val)]) || `단계 #${val}`;
      if (field === 'owner_id') return ownerNames[Number(val)] || `사용자 #${val}`;
      if (field === 'discount') return `${val}%`;
      if (field === 'credit_days') return `${val}일`;
      return String(val);
    };

    const items = rows.map((r) => {
      const p = r.proposed || {};
      const cur = {
        name: r.cur_name, rfc: r.cur_rfc, contact: r.cur_contact, phone: r.cur_phone,
        buyer_name: r.cur_buyer_name, buyer_phone: r.cur_buyer_phone,
        discount: r.cur_discount, credit_days: r.cur_credit_days, branch_count: r.cur_branch_count,
        team_id: r.cur_team_id, stage_id: r.cur_stage_id, owner_id: r.cur_owner_id,
        customer_type: r.cur_customer_type, memo: r.cur_memo, constancia_fiscal: r.cur_constancia_fiscal,
        constancia_no: r.cur_constancia_no,
      };
      const changes = [];
      for (const f of Object.keys(LABELS)) {
        if (!(f in p)) continue;                       // 요청에 포함된 필드만
        const pv = p[f]; const cv = cur[f];
        let same;
        if (NUMERIC.has(f)) {
          if (isEmpty(cv) && isEmpty(pv)) same = true;
          else if (isEmpty(cv) || isEmpty(pv)) same = false;
          else same = Number(cv) === Number(pv);
        } else { same = String(cv == null ? '' : cv) === String(pv == null ? '' : pv); }
        if (same) continue;                            // 실제로 바뀐 것만
        changes.push({ field: f, label: LABELS[f], from: disp(f, cv), to: disp(f, pv) });
      }
      return {
        id: r.id, customer_id: r.customer_id, customer_code: r.customer_code, customer_name: r.customer_name,
        proposed: r.proposed, status: r.status, reason: r.reason, conditions: r.conditions,
        requested_by_name: r.requested_by_name, created_at: r.created_at, changes,
        // 요청자 소속팀 ≠ 고객 소속팀 → 「타팀 요청」. 디렉터가 승인 화면에서 바로 알아볼 수 있게 표시.
        requester_team_name: r.requester_team_name || null,
        customer_team_name: r.cur_team_name || null,
        cross_team: r.requester_team_id != null && r.cur_team_id != null
          && Number(r.requester_team_id) !== Number(r.cur_team_id),
      };
    });
    return { items };
  });

  // 승인 → customers에 반영(디렉터)
  app.post('/api/customer-change-requests/:id/approve', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const r = (await query(`SELECT * FROM customer_change_requests WHERE id=$1 AND status='pending'`, [id])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    const c = agreedTerms((await query(`SELECT * FROM customers WHERE id=$1 AND deleted_at IS NULL`, [r.customer_id])).rows[0]);
    if (!c) return reply.code(404).send({ error: 'customer_gone' });
    // 승인 전 현재값 기준으로 할인/외상일 실변경 산출 → 반영 후 이력 기록
    const approvedTerms = detectTermsChanges(c, r.proposed || {});
    // 20261019dpin · 할인율이 바뀌는 수정요청은 승인할 때 디렉터 PIN
    const pinErr = await discountPinError(approvedTerms, req.ctx.perm.userId, (req.body || {}).pin);
    if (pinErr) return reply.code(pinErr.code).send(pinErr.body);
    try {
      await applyCustomerUpdate(r.customer_id, c, r.proposed, req.ctx.perm.userId);
    } catch (e) {
      // 0188 · 요청이 올라온 뒤 그 RFC 를 다른 고객이 선점했거나 형식이 잘못된 경우.
      //   요청은 pending 그대로 두고 디렉터에게 이유를 알린다(반려/수정 판단은 사람이).
      if (e.claimError) {
        return reply.code((e.claimError === 'rfc_taken' || e.claimError === 'rfc_claim_pending') ? 409 : 400)
          .send({ error: e.claimError, note: e.claimNote || RFC_ERROR_NOTE[e.claimError] || null });
      }
      throw e;
    }
    if (approvedTerms.length) {
      await logTermsHistory(r.customer_id, approvedTerms, {
        reason: r.reason, conditions: r.conditions,
        changedBy: r.requested_by, approvedBy: req.ctx.perm.userId,
      });
    }
    await query(`UPDATE customer_change_requests SET status='approved', decided_by=$1, decided_at=now() WHERE id=$2`, [req.ctx.perm.userId, id]);
    await safeLog({ userId: req.ctx.perm.userId, action: 'approve_change', target: `customer:${r.customer_id}` });
    // → CRM 전송(수정 승인). 할인·외상일이 실제로 바뀌지 않았어도 현재값 전체를 보낸다(상태 동기화).
    await enqueueCustomerSync(r.customer_id, 'upsert', { origin: 'change_approve', actorUserId: req.ctx.perm.userId, app });
    return { ok: true };
  });

  // 반려(디렉터)
  app.post('/api/customer-change-requests/:id/reject', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const r = (await query(`SELECT id FROM customer_change_requests WHERE id=$1 AND status='pending'`, [id])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await query(`UPDATE customer_change_requests SET status='rejected', decided_by=$1, decided_at=now(), reject_reason=$2 WHERE id=$3`,
      [req.ctx.perm.userId, (req.body && req.body.reason) ? String(req.body.reason) : null, id]);
    return { ok: true };
  });

  // 고객 삭제(디렉터)
  app.delete('/api/customers/:id', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const c = (await query(`SELECT id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    await query(`UPDATE customers SET deleted_at=now(), updated_by=$1 WHERE id=$2`, [req.ctx.perm.userId, id]);
    await safeLog({ userId: req.ctx.perm.userId, action: 'delete', target: `customer:${id}` });
    // → CRM 전송(baja). 한 번도 보낸 적 없는 고객이면 enqueue 쪽에서 skipped 로 남는다.
    await enqueueCustomerSync(id, 'delete', { origin: 'customer_delete', actorUserId: req.ctx.perm.userId, app });
    return { ok: true };
  });

  // ===== 디렉터: 팀 배정 · 상대팀 열람 권한 =====
  // 사용자 목록(팀·권한 보기용)
  app.get('/api/team-admin/users', { preHandler: [authGuard, requireDirector] }, async () => {
    const users = (await query(
      `SELECT u.id, u.name, u.role, u.team_id, t.name AS team_name
         FROM users u LEFT JOIN sales_teams t ON t.id=u.team_id
        WHERE u.deleted_at IS NULL ORDER BY u.name`)).rows;
    // 타팀 수정요청 권한 — 스키마 변경 없이 user_page_access 의 행 유무로 판단
    const crossOn = new Set((await query(
      `SELECT user_id FROM user_page_access WHERE page_key=$1`, [CROSS_TEAM_PAGE_KEY]
    )).rows.map((r) => String(r.user_id)));
    const grants = (await query(
      `SELECT a.user_id, a.team_id, a.can_edit, t.name AS team_name
         FROM user_team_access a JOIN sales_teams t ON t.id=a.team_id`)).rows;
    const grantsByUser = {};
    // ★ BIGINT는 pg가 문자열로 반환 → Number로 정규화(프런트 === 비교가 어긋나 저장값이 '미지정'으로 보이던 원인)
    for (const g of grants) (grantsByUser[String(g.user_id)] ||= []).push({ team_id: Number(g.team_id), team_name: g.team_name, can_edit: g.can_edit });
    return {
      items: users.map((u) => ({
        id: Number(u.id), name: u.name, role: u.role,
        team_id: u.team_id == null ? null : Number(u.team_id),
        team_name: u.team_name,
        cross_team_request: crossOn.has(String(u.id)),
        grants: grantsByUser[String(u.id)] || [],
      })),
    };
  });

  // 타팀 고객 수정요청 허용/차단(디렉터)
  //   ⚠ 이 스위치는 "열람 권한"이 아니다. 켜도 고객 목록·매출·미수는 종전대로 자기 팀만 보인다.
  //      켜진 사용자는 타팀 고객을 상호/코드로 찾아 「수정 요청」만 넣을 수 있고, 반영은 디렉터 승인 시.
  app.patch('/api/team-admin/users/:id/cross-team-request', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const on = req.body?.enabled === true;
    // 스키마 변경 없이 기존 권한 테이블에 행을 넣고/빼는 것으로 끝낸다(마이그레이션 불필요).
    const usr = (await query(`SELECT id FROM users WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!usr) return reply.code(404).send({ error: 'user_not_found' });
    if (on) {
      await query(
        `INSERT INTO user_page_access (user_id, page_key, device_req, access)
         VALUES ($1,$2,'anywhere','edit')
         ON CONFLICT (user_id, page_key) DO UPDATE SET access='edit'`, [id, CROSS_TEAM_PAGE_KEY]);
    } else {
      await query(`DELETE FROM user_page_access WHERE user_id=$1 AND page_key=$2`, [id, CROSS_TEAM_PAGE_KEY]);
    }
    await safeLog({ userId: req.ctx.perm.userId, action: 'permission_change',
      target: `user_cross_team_request:${id}`, detail: { enabled: on } });
    return { ok: true, enabled: on };
  });

  // 사용자 소속팀 지정(디렉터)
  app.patch('/api/team-admin/users/:id/team', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const teamId = req.body?.team_id != null ? Number(req.body.team_id) : null;
    // 존재하지 않는 팀/사용자면 FK 500 대신 명확한 오류 반환(프런트가 사유를 표시하고 원복)
    let teamName = null;
    if (teamId != null) {
      const t = (await query(`SELECT id, name FROM sales_teams WHERE id=$1 AND deleted_at IS NULL`, [teamId])).rows[0];
      if (!t) return reply.code(400).send({ error: 'team_not_found' });
      teamName = t.name;
    }
    const up = await query(`UPDATE users SET team_id=$1, updated_by=$2 WHERE id=$3 AND deleted_at IS NULL`, [teamId, req.ctx.perm.userId, id]);
    if (up.rowCount === 0) return reply.code(404).send({ error: 'user_not_found' });
    await safeLog({ userId: req.ctx.perm.userId, action: 'permission_change', target: `user_team:${id}`, detail: { team_id: teamId } });
    return { ok: true, team_id: teamId, team_name: teamName };
  });

  // 상대팀 열람 권한 부여/회수(디렉터)
  app.post('/api/team-admin/users/:id/grant', { preHandler: [authGuard, requireDirector] }, async (req, reply) => {
    const id = Number(req.params.id);
    const teamId = Number(req.body?.team_id);
    const canEdit = !!req.body?.can_edit;
    if (!teamId) return reply.code(400).send({ error: 'team_required' });
    const t = (await query(`SELECT id FROM sales_teams WHERE id=$1 AND deleted_at IS NULL`, [teamId])).rows[0];
    if (!t) return reply.code(400).send({ error: 'team_not_found' });
    const usr = (await query(`SELECT id FROM users WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!usr) return reply.code(404).send({ error: 'user_not_found' });
    await query(
      `INSERT INTO user_team_access (user_id, team_id, can_edit, created_by) VALUES ($1,$2,$3,$4)
       ON CONFLICT (user_id, team_id) DO UPDATE SET can_edit=$3`, [id, teamId, canEdit, req.ctx.perm.userId]);
    await safeLog({ userId: req.ctx.perm.userId, action: 'permission_change', target: `user_team_grant:${id}`, detail: { team_id: teamId, can_edit: canEdit } });
    return { ok: true };
  });

  app.delete('/api/team-admin/users/:id/grant/:teamId', { preHandler: [authGuard, requireDirector] }, async (req) => {
    const id = Number(req.params.id), teamId = Number(req.params.teamId);
    await query(`DELETE FROM user_team_access WHERE user_id=$1 AND team_id=$2`, [id, teamId]);
    await safeLog({ userId: req.ctx.perm.userId, action: 'permission_change', target: `user_team_revoke:${id}`, detail: { team_id: teamId } });
    return { ok: true };
  });

  // ===== 고객 증빙서류 (PDF·JPEG 등) — DB 저장 =====
  const ALLOWED_DOC_MIME = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
  const MAX_DOC_BYTES = 5 * 1024 * 1024; // 5MB

  // 목록 (본문 제외)
  app.get('/api/customers/:id/documents', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const c = (await query(`SELECT team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(req.ctx.perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const rows = (await query(
      `SELECT d.id, d.doc_type, d.file_name, d.mime_type, d.byte_size, to_char(d.uploaded_at,'YYYY-MM-DD') AS uploaded_at, u.name AS uploaded_by_name
         FROM customer_documents d LEFT JOIN users u ON u.id=d.uploaded_by
        WHERE d.customer_id=$1 AND d.deleted_at IS NULL ORDER BY d.uploaded_at DESC, d.id DESC`, [id])).rows;
    return { items: rows.map((r) => ({ ...r, byte_size: Number(r.byte_size) })) };
  });

  // 업로드: { doc_type?, file_name, mime_type, data_base64 }
  // 0247 · 서류가 바뀌어 실효 할인·외상일(0235 관문)이 달라지면 CRM 에 다시 보낸다.
  //   전에는 서류를 나중에 올려도 CRM 에는 등록 당시의 0 이 그대로 남았다.
  async function resyncIfTermsChanged(id, before, actorUserId) {
    try {
      if (!before) return;
      const now = (await query(`SELECT discount, credit_days, approval_status FROM customers WHERE id=$1`, [id])).rows[0];
      if (!now || String(now.approval_status || 'approved') === 'pending') return;
      if (Number(now.discount) === Number(before.discount) && Number(now.credit_days) === Number(before.credit_days)) return;
      await enqueueCustomerSync(id, 'upsert', { origin: 'docs_terms_change', actorUserId, app });
    } catch (_) { /* 전송 실패가 업로드를 막지 않음 */ }
  }

  app.post('/api/customers/:id/documents', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id);
    const c = (await query(`SELECT team_id, discount, credit_days FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canEditTeam(req.ctx.perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const b = req.body || {};
    const fileName = String(b.file_name || '').trim();
    const mime = String(b.mime_type || '').trim();
    const b64 = String(b.data_base64 || '');
    if (!fileName || !mime || !b64) return reply.code(400).send({ error: 'missing_fields' });
    if (!ALLOWED_DOC_MIME.includes(mime)) return reply.code(400).send({ error: 'unsupported_type', note: 'PDF·JPEG·PNG·WEBP만 업로드할 수 있습니다.' });
    let buf;
    try { buf = Buffer.from(b64, 'base64'); } catch (e) { return reply.code(400).send({ error: 'bad_base64' }); }
    if (!buf.length) return reply.code(400).send({ error: 'empty_file' });
    if (buf.length > MAX_DOC_BYTES) return reply.code(400).send({ error: 'too_large', note: '파일은 5MB 이하만 가능합니다.' });
    const row = (await query(
      `INSERT INTO customer_documents (customer_id, doc_type, file_name, mime_type, byte_size, content, uploaded_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [id, b.doc_type || null, fileName, mime, buf.length, buf, req.ctx.perm.userId])).rows[0];
    await safeLog({ userId: req.ctx.perm.userId, action: 'create', target: `customer_doc:${row.id}`, detail: { customer_id: id, file_name: fileName } });
    await resyncIfTermsChanged(id, c, req.ctx.perm.userId);
    return { ok: true, id: row.id };
  });

  // 다운로드(본문) — 바이너리 반환
  app.get('/api/customers/:id/documents/:docId', { preHandler: [authGuard, requirePage('customers')] }, async (req, reply) => {
    const id = Number(req.params.id), docId = Number(req.params.docId);
    const c = (await query(`SELECT team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canViewTeam(req.ctx.perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const d = (await query(`SELECT file_name, mime_type, content FROM customer_documents WHERE id=$1 AND customer_id=$2 AND deleted_at IS NULL`, [docId, id])).rows[0];
    if (!d) return reply.code(404).send({ error: 'not_found' });
    reply.header('Content-Type', d.mime_type);
    reply.header('Content-Disposition', `inline; filename="${encodeURIComponent(d.file_name)}"`);
    return reply.send(d.content);
  });

  // 삭제(soft)
  app.delete('/api/customers/:id/documents/:docId', { preHandler: [authGuard, requirePageEdit('customers')] }, async (req, reply) => {
    const id = Number(req.params.id), docId = Number(req.params.docId);
    const c = (await query(`SELECT team_id, discount, credit_days FROM customers WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (!canEditTeam(req.ctx.perm, c.team_id)) return reply.code(403).send({ error: 'forbidden_team' });
    const r = (await query(`UPDATE customer_documents SET deleted_at=now() WHERE id=$1 AND customer_id=$2 AND deleted_at IS NULL RETURNING id`, [docId, id])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await safeLog({ userId: req.ctx.perm.userId, action: 'delete', target: `customer_doc:${docId}` });
    await resyncIfTermsChanged(id, c, req.ctx.perm.userId);
    return { ok: true };
  });
}
