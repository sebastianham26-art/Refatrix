// =====================================================================
// Refatrix ERP · treasuryDaily.js — 일일 자금(AP/AR) 스냅샷 · 월간실적 · WhatsApp 문구
//   디렉터 요청(2026-09-30): 재무의 「일일 AP/AR 요약」(은행잔고 → AR → 환율 → AP → 마감잔고
//   → MXN 환산) 양식을 ERP 가 매일 자동으로 만들어 누적하고, 월간실적(실제 입출금 누계 +
//   일별 잔고 추이)을 만들어 지정된 사람에게만 WhatsApp 으로 보낸다.
//
//   ── 숫자의 정의(= 재무/계좌 화면 잔액과 100% 같은 공식) ──
//   · 은행잔고(통화별, 계좌 통화 기준 원화폐): Σ open_balance + Σ 실적(status='actual' AND approved)
//       in:+amount / out:-amount — /api/accounts 의 balance 와 동일. 삭제 계좌·삭제 거래 제외.
//       open_date 가 있는 계좌는 그날부터 잔고에 들어간다(그 전 날짜의 기초엔 없음 → 개설일 「계좌 개설」 조정).
//   · AR(수금) = 그날 실제 입금 거래 / AP(지급) = 그날 실제 출금 거래. 승인 대기 실적은 잔고 제외, 건수만 표시.
//   · 집계 대상 계좌(0241): 불공제(non_deductible) 계좌와 금고(이름·유형에 금고/caja/efectivo/현금/cash)는
//       자동 제외. 계좌별 강제 포함/제외는 accounts.treasury_exclude(화면 📲 탭 「집계 대상 계좌」).
//       제외 계좌의 기초잔액·실적·예정·승인대기는 전부 빠진다. 계좌 미지정 예정지출·미수 인보이스는 포함.
//   · MXN 환산 = MXN + USD × 그날 환율(환율 탭, 없으면 직전 값) — 유첨 엑셀 맨 아래 줄과 같은 계산.
//   · 예정(오늘 이후) = **거래목록의 「예정」 거래 그대로**(2026-10-01 디렉터 지시: 거래목록 예정과 일치해야 함).
//       status='plan' · 삭제 안 됨 · 기록된 날짜(예정일)에만 표시. 수금예정(AR)도 인보이스가 아니라
//       인보이스 발행 시 생긴 예정 거래(반제 때마다 잔액으로 맞춰지고 완납이면 지워짐)를 그대로 쓴다.
//       제외는 두 가지뿐이며 화면에 건수로 보인다: 비활성 고정비 회차(현금흐름과 동일) · 집계 제외 계좌.
//     오늘 이전 날짜의 미처리 예정은 **다른 날로 옮기지 않는다**(예전 「오늘 칸으로 이월」 규칙 폐지 — 거래목록에서
//       그 날짜로 조회하면 없는 항목이 오늘 칸에 보이던 문제, 10/1 Nom.Palomino 2건 보고). 대신 「지난 예정 미처리」로 건수·금액만 따로 알리고 잔고 예측에는 넣지 않는다.
//
//   ── 스케줄 (멕시코 시간, UTC-6 고정) ──
//   · 발송 시각·대상일은 관리 › WhatsApp 발송 시각(wa_schedules, 0262). 기본(2026-10-08 디렉터 지시):
//       일일 = 매일 18:00 그날 마감분 · 월간 = 말일 18:00 그달(놓치면 다음 달 1~3일 따라잡기)
//   · 스냅샷 누적은 시각과 무관하게 매 실행
//   · 실패는 5분 간격 최대 5회 재시도. WhatsApp 미설정이어도 스냅샷 누적은 계속된다.
//   · 발송 형식(15:13 지시): 표 이미지(PNG) + 한 줄 캡션. 실패 시 이미지 헤더 템플릿(TREASURY_WA_IMAGE_TEMPLATE) → 텍스트 순으로 대체.
//     TREASURY_WA_FORMAT=text 면 예전 텍스트 방식.
//   · TREASURY_DAILY_ENABLED=0 → 전체 끄기 · TREASURY_WA_TEMPLATE → 24h 창 밖 폴백 템플릿(없으면 WHATSAPP_TEMPLATE)
// =====================================================================
import { accAmtSql, signedAccAmtSql } from './accAmount.js';
import { query } from './db.js';
import { runningRuleIds, isSupersededRecurringPlan } from './recurring.js';
import { getFxRange, getRateForDate } from './fx.js';
import { AR_PAID_EPS } from './ar.js';
import { MX_OFFSET_MIN } from './workingHours.js';
import { waApiReady, sendWaTo, uploadWaMedia, sendWaImage, sendWaImageTemplate } from './waSend.js';
import { dailyImageSvg, monthlyImageSvg, svgToWaPng } from './treasuryImage.js';
import { loadSchedules, isDue, targetDate, toMinutes, mxParts } from './waSchedule.js';
import { windowState } from './waWebhook.js';   // 0253 · 24시간 창(웹훅이 아는 경우)

export const CURS = ['MXN', 'USD'];
export const SEND_HOUR_MX = 18;         // (표시용 기본값) 실제 시각은 wa_schedules — 관리 › WhatsApp 발송 시각
export const DAILY_SEND_UNTIL_MX = 24;  // (폐지 — waSchedule.WINDOW_MIN 6시간 창으로 대체) 하위호환용
export const MONTHLY_CATCHUP_DAYS = 3;  // 1~3일 사이 월간 발송(서버 중단 대비)
export const MAX_ATTEMPTS = 5;
export const ITEM_LINES = 8;            // WA 본문에 항목 최대 줄 수(통화·방향별)
export const DEFAULT_REPORT_URL = 'https://sebastianham26-art.github.io/Refatrix/refatrix-cashdaily.html';

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;
export const isYmd = (s) => DATE_RE.test(String(s || '')) && !isNaN(Date.parse(s + 'T00:00:00Z'));
export const isMonth = (s) => MONTH_RE.test(String(s || ''));

// ───────────────────────── 순수 도우미 ─────────────────────────
export function r2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }
const zero = () => ({ MXN: 0, USD: 0 });
const cur = (c) => (String(c || '').toUpperCase() === 'USD' ? 'USD' : 'MXN');

export function addDays(ymd, n) {
  const [y, m, d] = String(ymd).split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d));
  t.setUTCDate(t.getUTCDate() + n);
  return t.toISOString().slice(0, 10);
}
export function dowOf(ymd) { const [y, m, d] = String(ymd).split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)).getUTCDay(); } // 0=일
export function monthBounds(month) {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${String(last).padStart(2, '0')}` };
}
export function prevMonth(month) { const { from } = monthBounds(month); return addDays(from, -1).slice(0, 7); }
export function weekStart(ymd) { const w = dowOf(ymd); return addDays(ymd, -((w + 6) % 7)); } // 월요일
export function dateList(from, to) { const out = []; for (let d = from; d <= to; d = addDays(d, 1)) out.push(d); return out; }

// 멕시코 현재(UTC-6 고정 — workingHours 와 동일 규칙)
//   TREASURY_FAKE_NOW(ISO 시각)는 테스트 전용 — 운영에선 설정하지 않는다.
export function mxNow(nowMs = (process.env.TREASURY_FAKE_NOW ? Date.parse(process.env.TREASURY_FAKE_NOW) : Date.now())) {
  const m = new Date(nowMs + MX_OFFSET_MIN * 60000);
  return { ymd: m.toISOString().slice(0, 10), hour: m.getUTCHours(), day: m.getUTCDate() };
}

// 환율: 기간 내 일자별 값(없는 날은 직전 값, 첫날 이전 값은 seed)
export function fxFill(rows, from, to, seed) {
  const by = new Map((rows || []).map((r) => [String(r.rate_date).slice(0, 10), Number(r.rate)]));
  const out = new Map();
  let last = Number(seed) || null;
  for (const d of dateList(from, to)) {
    if (by.has(d) && by.get(d) > 0) last = by.get(d);
    out.set(d, last);
  }
  return out;
}

// 거래 → 표시 이름. 입금: 고객(인보이스·선수금·통장입금·태그) › 송금인 메모 › 메모 › 계정과목
//                  출금: 고정비 이름(Nomina Maria 등) › 메모 › 계정과목
// 전자결재 연결 거래(2026-10-07 디렉터 요청): 「EXP-2026-」은 반복이라 빼고 번호만 + 제목(간략) + 받는 사람(지급처).
//   원천 = 거래에 연결된 결재 문서(approval_payments.txn_id) — 없으면 메모 「[전자결재] EXP-YYYY-NNNN 제목 (n/m) · 지급처」 해석.
//   반환 { no:'0012', title, vendor, seq:'1/3'|null } 또는 null
const APPR_MEMO_RE = /^\[전자결재\]\s*(?:[A-Z]+-\d{4}-)?(\S+)\s*(.*?)(?:\s*\((\d+\/\d+)\))?(?:\s*·\s*(.+))?$/;
export function shortDocNo(docNo) { return String(docNo || '').replace(/^[A-Z]+-\d{4}-/, ''); }
export function approvalLabel(t) {
  const memo = String(t.memo || '').trim();
  const m = APPR_MEMO_RE.exec(memo);
  if (t.ap_doc_no) {
    return { no: shortDocNo(t.ap_doc_no), title: String(t.ap_title || '').trim(), vendor: String(t.ap_vendor || '').trim() || null,
      seq: (m && m[3]) || null };
  }
  if (!m) return null;
  return { no: m[1], title: (m[2] || '').trim(), vendor: (m[4] || '').trim() || null, seq: m[3] || null };
}
export function approvalName(a) {
  return `${a.no} ${a.title}${a.seq ? ` (${a.seq})` : ''}${a.vendor ? ` · ${a.vendor}` : ''}`.replace(/\s+/g, ' ').trim();
}

export function itemName(t) {
  const ap = approvalLabel(t);
  if (ap) return approvalName(ap);
  const clean = (s) => String(s || '').replace(/^\[고정비\]\s*/, '').trim();
  if (t.direction === 'in') {
    return clean(t.customer_name) || clean(t.payer_memo) || clean(t.memo) || clean(t.category_name) || '입금';
  }
  return clean(t.rule_name) || clean(t.memo) || clean(t.category_name) || '지출';
}

function toItem(t, extra = {}) {
  return {
    id: t.id != null ? Number(t.id) : null,
    dir: t.direction === 'in' ? 'in' : 'out',
    cur: cur(t.currency),
    amount: r2(t.amount),
    amount_mxn: r2(t.amount_mxn != null ? t.amount_mxn : t.amount),
    name: itemName(t),
    category: t.category_name || null,
    account: t.account_name || null,
    sat_no: t.sat_no || null,
    private: t.is_private === true,
    appr: approvalLabel(t),
    ...extra,
  };
}

// ── 실적 일자별 구성 ──
//   base   : from 전날 마감 잔고(통화별)
//   opens  : 기간 안에 개설된 계좌 [{d, currency, amount}] → 그날 「계좌 개설」 조정
//   txns   : 기간 안 승인 실적 [{id, d, direction, currency, amount, amount_mxn, …이름필드}]
//   pending: 승인 대기 실적 [{d, n, amount_mxn}]
//   fx     : Map(date → rate)
export function buildDays({ from, to, base, opens = [], txns = [], pending = [], fx = new Map() }) {
  const days = [];
  let run = { MXN: r2((base && base.MXN) || 0), USD: r2((base && base.USD) || 0) };
  const cum = { in: zero(), out: zero(), in_eq: 0, out_eq: 0 };
  const byDate = new Map();
  for (const t of txns) { const d = String(t.d).slice(0, 10); if (!byDate.has(d)) byDate.set(d, []); byDate.get(d).push(t); }
  const openBy = new Map(); for (const o of opens) { const k = String(o.d).slice(0, 10); if (!openBy.has(k)) openBy.set(k, zero()); openBy.get(k)[cur(o.currency)] += Number(o.amount) || 0; }
  const pendBy = new Map(); for (const p of pending) { const k = String(p.d).slice(0, 10); const x = pendBy.get(k) || { n: 0, amount_mxn: 0 }; x.n += Number(p.n) || 0; x.amount_mxn = r2(x.amount_mxn + (Number(p.amount_mxn) || 0)); pendBy.set(k, x); }
  for (const d of dateList(from, to)) {
    const fxr = fx.get(d) || null;
    const open = { ...run };
    const adj = openBy.get(d) || zero();
    const inn = zero(), out = zero();
    let in_eq = 0, out_eq = 0;
    const items = (byDate.get(d) || []).map((t) => toItem(t));
    for (const it of items) {
      if (it.dir === 'in') { inn[it.cur] = r2(inn[it.cur] + it.amount); in_eq = r2(in_eq + it.amount_mxn); }
      else { out[it.cur] = r2(out[it.cur] + it.amount); out_eq = r2(out_eq + it.amount_mxn); }
    }
    const close = {};
    for (const c of CURS) close[c] = r2(open[c] + adj[c] + inn[c] - out[c]);
    for (const c of CURS) { cum.in[c] = r2(cum.in[c] + inn[c]); cum.out[c] = r2(cum.out[c] + out[c]); }
    cum.in_eq = r2(cum.in_eq + in_eq); cum.out_eq = r2(cum.out_eq + out_eq);
    days.push({
      date: d, dow: dowOf(d), kind: 'actual', fx: fxr,
      open, adj: { MXN: r2(adj.MXN), USD: r2(adj.USD) }, in: inn, out, close,
      in_eq, out_eq,
      open_eq: fxr ? r2(open.MXN + open.USD * fxr) : null,
      close_eq: fxr ? r2(close.MXN + close.USD * fxr) : null,
      items: items.sort((a, b) => (a.dir === b.dir ? b.amount_mxn - a.amount_mxn : (a.dir === 'in' ? -1 : 1))),
      pending: pendBy.get(d) || { n: 0, amount_mxn: 0 },
      moved: items.length > 0 || adj.MXN !== 0 || adj.USD !== 0,
      cum: { in: { ...cum.in }, out: { ...cum.out }, in_eq: cum.in_eq, out_eq: cum.out_eq },
    });
    run = close;
  }
  return days;
}

// ── 예정(오늘 이후) 일자별 구성 ──
//   startOpen: 오늘 기초(= 어제 실적 마감) · todayActual: 오늘 이미 들어온 실적 거래(목록)
//   invoices : 미수 인보이스 [{id, due, outstanding, customer_name, sat_no}] (MXN)
//   planIn/planOut: 예정 거래 [{id, d, direction, currency, amount, amount_mxn, …}]
//   planIn/planOut: 거래목록 예정 거래(각자 기록된 날짜). 오늘 이전 날짜: AR(수금)은 첫 예정일(today) 칸으로 이월(rolled), AP 는 overdue 경고로 모은다.
export function planSrc(t) { return t.sales_invoice_id ? 'inv' : (t.recurring_rule_id ? 'fix' : (t.direction === 'in' ? 'man' : 'plan')); }
export function projectDays({ today, to, startOpen, todayActual = [], planIn = [], planOut = [], fx = new Map(), rollAr = true }) {
  const days = [];
  let run = { MXN: r2(startOpen.MXN || 0), USD: r2(startOpen.USD || 0) };
  const bucket = new Map();
  const overdue = [];
  const rolled = [];
  const push = (d, it) => { if (d > to) return; if (!bucket.has(d)) bucket.set(d, []); bucket.get(d).push(it); };
  for (const t of todayActual) push(today, toItem(t, { state: 'actual' }));
  for (const t of [...planIn, ...planOut]) {
    const d0 = String(t.d).slice(0, 10);
    const it = toItem(t, { state: 'plan', src: planSrc(t), due: d0 });
    const late = Math.round((Date.parse(today) - Date.parse(d0)) / 86400000);
    // 1019 · AR(수금) 예정이 날짜가 지나도 안 들어왔으면 「오늘」(첫 예정일)로 하루씩 밀어 표시 — 오늘 안 들어오면 내일 들어올 것으로 본다.
    //        AP(지급)는 그대로 경고만(잔고 예측 제외).
    if (d0 < today && it.dir === 'in' && rollAr) { const r = { ...it, rolled: true, late_days: late }; rolled.push(r); push(today, r); }
    else if (d0 < today) overdue.push({ ...it, late_days: late });
    else push(d0, it);
  }
  for (const d of dateList(today, to)) {
    const fxr = fx.get(d) || null;
    const open = { ...run };
    const items = (bucket.get(d) || []).sort((a, b) => (a.dir === b.dir ? b.amount_mxn - a.amount_mxn : (a.dir === 'in' ? -1 : 1)));
    const inn = zero(), out = zero(); let in_eq = 0, out_eq = 0;
    for (const it of items) {
      if (it.dir === 'in') { inn[it.cur] = r2(inn[it.cur] + it.amount); in_eq = r2(in_eq + it.amount_mxn); }
      else { out[it.cur] = r2(out[it.cur] + it.amount); out_eq = r2(out_eq + it.amount_mxn); }
    }
    const close = {}; for (const c of CURS) close[c] = r2(open[c] + inn[c] - out[c]);
    days.push({ date: d, dow: dowOf(d), kind: d === today ? 'today' : 'plan', fx: fxr, open, adj: zero(), in: inn, out, close,
      in_eq, out_eq, open_eq: fxr ? r2(open.MXN + open.USD * fxr) : null, close_eq: fxr ? r2(close.MXN + close.USD * fxr) : null,
      items, pending: { n: 0, amount_mxn: 0 }, moved: items.length > 0 });
    run = close;
  }
  if (days.length) { days[0].overdue = summarizeOverdue(overdue); days[0].rolled = summarizeOverdue(rolled); }
  return days;
}
export function summarizeOverdue(list) {
  const xs = [...list].sort((a, b) => (a.due < b.due ? -1 : a.due > b.due ? 1 : b.amount_mxn - a.amount_mxn));
  const sum = (dir) => r2(xs.filter((x) => x.dir === dir).reduce((s, x) => s + x.amount_mxn, 0));
  return { n: xs.length, in_mxn: sum('in'), out_mxn: sum('out'), items: xs };
}

// ── 월간실적 요약 ──
//   mask=true 면 비공개(is_private) 항목을 하나(「비공개」)로 묶는다(WhatsApp 용).
export function summarizeMonth(days, { mask = false } = {}) {
  if (!days.length) return null;
  const first = days[0], last = days[days.length - 1];
  const inn = zero(), out = zero(), adj = zero();
  let in_eq = 0, out_eq = 0, pn = 0, pa = 0;
  const gIn = new Map(), gOut = new Map(), gCat = new Map();
  const add = (mp, key, name, it) => { const x = mp.get(key) || { name, amount_mxn: 0, n: 0, private: false }; x.amount_mxn = r2(x.amount_mxn + it.amount_mxn); x.n += 1; if (it.private) x.private = true; mp.set(key, x); };
  let min = null, max = null, moved = 0;
  for (const d of days) {
    for (const c of CURS) { inn[c] = r2(inn[c] + d.in[c]); out[c] = r2(out[c] + d.out[c]); adj[c] = r2(adj[c] + d.adj[c]); }
    in_eq = r2(in_eq + d.in_eq); out_eq = r2(out_eq + d.out_eq);
    pn += d.pending.n; pa = r2(pa + d.pending.amount_mxn);
    if (d.moved) moved += 1;
    if (d.close_eq != null) {
      if (!min || d.close_eq < min.close_eq) min = { date: d.date, close_eq: d.close_eq };
      if (!max || d.close_eq > max.close_eq) max = { date: d.date, close_eq: d.close_eq };
    }
    for (const it of d.items) {
      const hide = mask && it.private;
      const key = hide ? '__private' : it.name;
      if (it.dir === 'in') add(gIn, key, hide ? '__private' : it.name, it);
      else {
        add(gOut, key, hide ? '__private' : it.name, it);
        const ck = hide ? '__private' : (it.category || '기타');
        add(gCat, ck, ck, it);
      }
    }
  }
  const top = (mp, n = 10) => [...mp.values()].sort((a, b) => b.amount_mxn - a.amount_mxn).slice(0, n);
  return {
    month: first.date.slice(0, 7), from: first.date, to: last.date, days_n: days.length, moved_days: moved,
    open: { ...first.open }, open_eq: first.open_eq, close: { ...last.close }, close_eq: last.close_eq,
    fx_first: first.fx, fx_last: last.fx,
    in: inn, out, adj, in_eq, out_eq, net_eq: r2(in_eq - out_eq),
    in_n: days.reduce((s, d) => s + d.items.filter((i) => i.dir === 'in').length, 0),
    out_n: days.reduce((s, d) => s + d.items.filter((i) => i.dir === 'out').length, 0),
    top_in: top(gIn), top_out: top(gOut), by_category_out: top(gCat, 12),
    min, max, pending: { n: pn, amount_mxn: pa },
  };
}

// 스냅샷(저장본) vs 지금 원장 재계산 비교 — 사후 수정(소급 등록·삭제) 감지
export function driftOf(stored, live) {
  if (!stored || !live) return null;
  const f = (o, k) => r2((o && o[k]) || 0);
  const diff = {};
  let any = false;
  for (const k of ['close_mxn', 'close_usd', 'in_mxn', 'in_usd', 'out_mxn', 'out_usd']) {
    const dv = r2(f(live, k) - f(stored, k));
    if (Math.abs(dv) >= 0.5) { diff[k] = dv; any = true; }
  }
  return any ? diff : null;
}
export const flatOf = (d) => ({
  close_mxn: d.close.MXN, close_usd: d.close.USD, in_mxn: d.in.MXN, in_usd: d.in.USD, out_mxn: d.out.MXN, out_usd: d.out.USD,
});

// ───────────────────────── WhatsApp 문구 ─────────────────────────
const L = {
  es: {
    dow: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
    months: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
    dailyTitle: '💰 Refatrix · Resumen diario de caja', monthlyTitle: '📊 Refatrix · Resultado mensual de caja',
    open: 'Saldo inicial', close: 'Saldo final', ar: 'Cobros (AR)', ap: 'Pagos (AP)', eq: 'Equiv. MXN', fx: 'TC',
    none: 'sin movimientos', more: (n) => `…y ${n} más`, adj: 'Alta de cuenta',
    mtd: (m) => `Acumulado del mes (${m})`, inL: 'Cobros', outL: 'Pagos', net: 'Neto',
    plan: (d) => `Programado hoy (${d})`, planTomorrow: (d) => `Programado mañana (${d})`, overdue: (n, a) => `⚠ ${n} programado(s) de fechas pasadas sin procesar · MXN ${a} (revisar en lista de movimientos; no incluido)`,
    pend: (n, a) => `⚠ ${n} movimiento(s) pendiente(s) de aprobación · MXN ${a} (no incluido en saldo)`,
    priv: 'Privado', topIn: 'Principales cobros', topOut: 'Principales pagos', cat: 'Por concepto',
    change: 'Variación', minBal: 'Saldo mínimo', maxBal: 'Saldo máximo', moves: (n) => `${n} mov.`, days: (n) => `${n} días con movimiento`,
    link: 'Detalle en ERP', asOf: (d) => `Saldo al ${d}`,
  },
  ko: {
    dow: ['일', '월', '화', '수', '목', '금', '토'],
    months: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    dailyTitle: '💰 Refatrix · 일일 자금 요약', monthlyTitle: '📊 Refatrix · 월간 자금실적',
    open: '기초잔고', close: '마감잔고', ar: '수금(AR)', ap: '지급(AP)', eq: 'MXN 환산', fx: '환율',
    none: '거래 없음', more: (n) => `…외 ${n}건`, adj: '계좌 개설',
    mtd: (m) => `이번 달 누계 (${m})`, inL: '수금', outL: '지급', net: '순액',
    plan: (d) => `오늘 예정 (${d})`, planTomorrow: (d) => `내일 예정 (${d})`, overdue: (n, a) => `⚠ 지난 날짜 예정 미처리 ${n}건 · MXN ${a} (거래목록에서 처리/삭제 필요 · 잔고 예측 미포함)`,
    pend: (n, a) => `⚠ 승인 대기 ${n}건 · MXN ${a} (잔고 미반영)`,
    priv: '비공개', topIn: '주요 수금처', topOut: '주요 지급', cat: '계정과목별',
    change: '증감', minBal: '최저 잔고', maxBal: '최고 잔고', moves: (n) => `${n}건`, days: (n) => `거래일 ${n}일`,
    link: 'ERP 상세', asOf: (d) => `${d} 잔고`,
  },
};
const lg = (lang) => (lang === 'ko' ? L.ko : L.es);
export const fmt0 = (n) => (n == null ? '—' : Math.round(Number(n)).toLocaleString('en-US'));
const sgn = (n) => (Number(n) >= 0 ? '+' : '−') + fmt0(Math.abs(Number(n)));
function dayLabel(ymd, lang) {
  const t = lg(lang); const [, m, d] = ymd.split('-').map(Number);
  return lang === 'ko' ? `${m}/${d}(${t.dow[dowOf(ymd)]})` : `${t.dow[dowOf(ymd)]} ${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`;
}
// 1009 · 승인 템플릿 resumen_diario_fondos 본문 「… con corte al {{1}}.」 — {{1}} = 「mar, 06/10」 형식(템플릿이 스페인어라 언어 무관)
export function templateDate(ymd) {
  const [, m, d] = ymd.split('-').map(Number);
  return `${lg('es').dow[dowOf(ymd)]}, ${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`;
}
function monthLabel(month, lang) { const [y, m] = month.split('-').map(Number); return lang === 'ko' ? `${y}년 ${m}월` : `${lg(lang).months[m - 1]} ${y}`; }
const pair = (o) => `MXN ${fmt0(o.MXN)}` + (Math.abs(o.USD) >= 0.5 ? ` · USD ${fmt0(o.USD)}` : '');
const dispName = (it, lang, mask = true) => ((mask && it.private) || it.name === '__private' ? lg(lang).priv : it.name);

function itemLines(items, lang, n = ITEM_LINES) {
  const out = items.slice(0, n).map((it) => `• ${dispName(it, lang)}${it.sat_no && !it.private ? ` (${it.sat_no})` : ''} ${it.cur === 'USD' ? 'USD ' : ''}${fmt0(it.amount)}${it.late_days ? ` ⏰${it.late_days}d` : ''}`);
  if (items.length > n) out.push(lg(lang).more(items.length - n));
  return out;
}

// 일일 요약 — day: buildDays 의 한 날 · mtd: summarizeMonth(월초~그날) · plan: projectDays 의 발송일(오늘) 1칸(선택)
export function buildDailyText(day, { mtd = null, plan = null, lang = 'es', planTomorrow = false } = {}) {
  const t = lg(lang);
  const ins = day.items.filter((i) => i.dir === 'in'), outs = day.items.filter((i) => i.dir === 'out');
  const L1 = [`*${t.dailyTitle}*`, `*${dayLabel(day.date, lang)} ${day.date.slice(0, 4)}*`, ''];
  L1.push(`*${t.open}*  ${pair(day.open)}`);
  if (day.adj.MXN || day.adj.USD) L1.push(`${t.adj}  ${pair(day.adj)}`);
  L1.push(`*${t.ar}*  ${ins.length ? pair(day.in) : t.none}`);
  L1.push(...itemLines(ins, lang));
  L1.push(`*${t.ap}*  ${outs.length ? pair(day.out) : t.none}`);
  L1.push(...itemLines(outs, lang));
  L1.push(`*${t.close}*  ${pair(day.close)}`);
  if (day.close_eq != null) L1.push(`${t.eq} *${fmt0(day.close_eq)}* (${t.fx} ${Number(day.fx).toFixed(2)} · ${sgn(r2(day.close_eq - day.open_eq))})`);
  if (day.pending && day.pending.n) L1.push(t.pend(day.pending.n, fmt0(day.pending.amount_mxn)));
  if (mtd) {
    L1.push('', `*${t.mtd(monthLabel(mtd.month, lang))}*`);
    L1.push(`${t.inL} MXN ${fmt0(mtd.in_eq)} · ${t.outL} MXN ${fmt0(mtd.out_eq)} · ${t.net} ${sgn(mtd.net_eq)}`);
  }
  if (plan && plan.items && plan.items.some((i) => i.state === 'plan')) {
    const pi = plan.items.filter((i) => i.state === 'plan' && i.dir === 'in');
    const po = plan.items.filter((i) => i.state === 'plan' && i.dir === 'out');
    const s = (xs) => r2(xs.reduce((a, b) => a + b.amount_mxn, 0));
    L1.push('', `*${(planTomorrow ? t.planTomorrow : t.plan)(dayLabel(plan.date, lang))}*`);
    L1.push(`${t.inL} ${pi.length} · MXN ${fmt0(s(pi))}  |  ${t.outL} ${po.length} · MXN ${fmt0(s(po))}`);
    L1.push(...itemLines([...pi, ...po].sort((a, b) => b.amount_mxn - a.amount_mxn), lang, 5).map((x) => x));
  }
  if (plan && plan.overdue && plan.overdue.n) L1.push('', t.overdue(plan.overdue.n, fmt0(plan.overdue.in_mxn + plan.overdue.out_mxn)));
  return clip(L1.join('\n'));
}

export function buildDailyHeadline(day, lang = 'es') {
  const t = lg(lang);
  return `[${t.dailyTitle.replace(/^\S+\s/, '')}] ${dayLabel(day.date, lang)} — ${t.ar} ${fmt0(day.in_eq)} · ${t.ap} ${fmt0(day.out_eq)} · ${t.close} ${pair(day.close)}`
    + (day.close_eq != null ? ` · ${t.eq} ${fmt0(day.close_eq)}` : '');
}

export function buildMonthlyText(sum, { lang = 'es', link = null } = {}) {
  const t = lg(lang);
  const ml = monthLabel(sum.month, lang);
  const dl = (d) => dayLabel(d, lang);
  const L1 = [`*${t.monthlyTitle}*`, `*${ml}*`, ''];
  L1.push(`*${t.asOf(dl(sum.from))}* (${t.open})  ${pair(sum.open)}${sum.open_eq != null ? `  ≈ ${fmt0(sum.open_eq)}` : ''}`);
  L1.push(`*${t.asOf(dl(sum.to))}* (${t.close})  ${pair(sum.close)}${sum.close_eq != null ? `  ≈ ${fmt0(sum.close_eq)}` : ''}`);
  if (sum.open_eq != null && sum.close_eq != null) L1.push(`${t.change} ${t.eq} *${sgn(r2(sum.close_eq - sum.open_eq))}*`);
  if (sum.adj.MXN || sum.adj.USD) L1.push(`${t.adj}  ${pair(sum.adj)}`);
  L1.push('');
  L1.push(`*${t.inL}*  ${pair(sum.in)}  (${t.eq} ${fmt0(sum.in_eq)} · ${t.moves(sum.in_n)})`);
  L1.push(`*${t.outL}*  ${pair(sum.out)}  (${t.eq} ${fmt0(sum.out_eq)} · ${t.moves(sum.out_n)})`);
  L1.push(`*${t.net}*  ${sgn(sum.net_eq)} · ${t.days(sum.moved_days)}`);
  const tops = (arr, n) => arr.slice(0, n).map((x) => `• ${x.name === '__private' ? t.priv : x.name} ${fmt0(x.amount_mxn)}${x.n > 1 ? ` (${t.moves(x.n)})` : ''}`);
  if (sum.top_in.length) L1.push('', `*${t.topIn}*`, ...tops(sum.top_in, 5));
  if (sum.by_category_out.length) L1.push('', `*${t.cat} (${t.outL})*`, ...tops(sum.by_category_out, 6));
  if (sum.min) L1.push('', `${t.minBal}: ${dl(sum.min.date)} ${t.eq} ${fmt0(sum.min.close_eq)}` + (sum.max ? ` · ${t.maxBal}: ${dl(sum.max.date)} ${fmt0(sum.max.close_eq)}` : ''));
  if (sum.pending && sum.pending.n) L1.push(t.pend(sum.pending.n, fmt0(sum.pending.amount_mxn)));
  if (link) L1.push('', `${t.link}: ${link}`);
  return clip(L1.join('\n'));
}
export function buildMonthlyHeadline(sum, lang = 'es') {
  const t = lg(lang);
  return `[${t.monthlyTitle.replace(/^\S+\s/, '')}] ${monthLabel(sum.month, lang)} — ${t.inL} ${fmt0(sum.in_eq)} · ${t.outL} ${fmt0(sum.out_eq)} · ${t.net} ${sgn(sum.net_eq)} · ${t.close} ${pair(sum.close)}`;
}
function clip(s, max = 3800) { return s.length > max ? s.slice(0, max) + '\n…' : s; }

// ───────────────────────── 집계 대상 계좌 ─────────────────────────
export const CASH_BOX_RE = /금고|caja|efectivo|현금|cash/i;
// a: { non_deductible, name, type, treasury_exclude } → { included, reason: manual_in|manual_out|non_deductible|cash_box|auto }
export function accountScopeOf(a) {
  if (a.treasury_exclude === true) return { included: false, reason: 'manual_out' };
  if (a.treasury_exclude === false) return { included: true, reason: 'manual_in' };
  if (a.non_deductible === true) return { included: false, reason: 'non_deductible' };
  if (CASH_BOX_RE.test(`${a.name || ''} ${a.type || ''}`)) return { included: false, reason: 'cash_box' };
  return { included: true, reason: 'auto' };
}
export async function loadAccountScope(q = query) {
  const rows = (await q(`SELECT id, name, type, currency, non_deductible, disabled, treasury_exclude
                           FROM accounts WHERE deleted_at IS NULL ORDER BY id`)).rows;
  const accounts = rows.map((a) => ({ id: Number(a.id), name: a.name, type: a.type || null, currency: a.currency,
    non_deductible: a.non_deductible === true, disabled: a.disabled === true,
    treasury_exclude: a.treasury_exclude === true ? true : a.treasury_exclude === false ? false : null,
    ...accountScopeOf(a) }));
  return { accounts, ids: accounts.filter((a) => a.included).map((a) => a.id) };
}

// ───────────────────────── DB 적재 ─────────────────────────
const TXN_NAME_JOINS = `
  LEFT JOIN categories cat ON cat.code=t.category_code
  LEFT JOIN recurring_rules rr ON rr.id=t.recurring_rule_id
  LEFT JOIN sales_invoices si ON si.id=t.sales_invoice_id
  LEFT JOIN customers c ON c.id=si.customer_id
  LEFT JOIN sales_payments sp ON sp.advance_txn_id=t.id
  LEFT JOIN customers cadv ON cadv.id=sp.customer_id
  LEFT JOIN bank_deposits_pending bd ON bd.txn_id=t.id
  LEFT JOIN customers cbd ON cbd.id=bd.customer_id
  LEFT JOIN customers ctag ON ctag.id=t.customer_id
  LEFT JOIN LATERAL (SELECT ad.doc_no, ad.title, ad.vendor FROM approval_payments ap
                       JOIN approval_documents ad ON ad.id=ap.document_id
                      WHERE ap.txn_id=t.id ORDER BY ap.id LIMIT 1) apd ON true`;
// t.amount = 계좌 통화 기준 금액(거래 통화가 다르면 환산 — accAmount.js, 2026-11-23). 계좌 미지정은 원금액.
const TXN_NAME_COLS = `t.id, t.direction, ${accAmtSql('t', 'a')} AS amount, t.amount_mxn, t.is_private, t.memo, t.recurring_rule_id,
  a.name AS account_name, cat.name AS category_name, rr.name AS rule_name, si.sat_no,
  COALESCE(c.name, cadv.name, cbd.name, ctag.name) AS customer_name, bd.payer_memo,
  apd.doc_no AS ap_doc_no, apd.title AS ap_title, apd.vendor AS ap_vendor`;

// 기간 실적 입력 적재(한 번의 조회 묶음)
export async function loadActualInputs(from, to, q = query, scopeIds = null) {
  const ids = scopeIds || (await loadAccountScope(q)).ids;
  const [openRows, preRows, opens, txns, pend] = await Promise.all([
    q(`SELECT a.currency, COALESCE(SUM(a.open_balance),0) AS s FROM accounts a
        WHERE a.deleted_at IS NULL AND a.id = ANY($2) AND (a.open_date IS NULL OR a.open_date < $1) GROUP BY a.currency`, [from, ids]),
    q(`SELECT a.currency, COALESCE(SUM(${signedAccAmtSql('t', 'a')}),0) AS s
         FROM transactions t JOIN accounts a ON a.id=t.account_id
        WHERE t.status='actual' AND t.approved=true AND t.deleted_at IS NULL AND a.deleted_at IS NULL AND a.id = ANY($2) AND t.txn_date < $1
        GROUP BY a.currency`, [from, ids]),
    q(`SELECT a.currency, to_char(a.open_date,'YYYY-MM-DD') AS d, a.open_balance AS amount FROM accounts a
        WHERE a.deleted_at IS NULL AND a.id = ANY($3) AND a.open_date >= $1 AND a.open_date <= $2`, [from, to, ids]),
    q(`SELECT ${TXN_NAME_COLS}, a.currency, to_char(t.txn_date,'YYYY-MM-DD') AS d
         FROM transactions t JOIN accounts a ON a.id=t.account_id ${TXN_NAME_JOINS}
        WHERE t.status='actual' AND t.approved=true AND t.deleted_at IS NULL AND a.deleted_at IS NULL AND a.id = ANY($3)
          AND t.txn_date >= $1 AND t.txn_date <= $2
        ORDER BY t.txn_date, t.id`, [from, to, ids]),
    q(`SELECT to_char(t.txn_date,'YYYY-MM-DD') AS d, COUNT(*) AS n, COALESCE(SUM(t.amount_mxn),0) AS amount_mxn
         FROM transactions t
        WHERE t.status='actual' AND t.approved=false AND t.deleted_at IS NULL AND t.txn_date >= $1 AND t.txn_date <= $2
          AND (t.account_id IS NULL OR t.account_id = ANY($3))
        GROUP BY t.txn_date`, [from, to, ids]),
  ]);
  const base = zero();
  for (const r of openRows.rows) base[cur(r.currency)] += Number(r.s) || 0;
  for (const r of preRows.rows) base[cur(r.currency)] += Number(r.s) || 0;
  base.MXN = r2(base.MXN); base.USD = r2(base.USD);
  // 사후 동일 이름 거래가 여러 조인에 걸려 중복될 수 있어 id 기준 1건만
  const seen = new Set();
  const tx = [];
  for (const r of txns.rows) { const id = Number(r.id); if (seen.has(id)) continue; seen.add(id); tx.push({ ...r, amount: Number(r.amount), amount_mxn: Number(r.amount_mxn) }); }
  return { base, opens: opens.rows.map((o) => ({ ...o, amount: Number(o.amount) })), txns: tx,
    pending: pend.rows.map((p) => ({ d: p.d, n: Number(p.n), amount_mxn: Number(p.amount_mxn) })) };
}

export async function loadFx(from, to) {
  const seed = await getRateForDate(from);
  const rows = await getFxRange(from, to, 'MXN');
  return fxFill(rows, from, to, seed);
}

export async function computeActualDays(from, to, q = query) {
  const [inp, fx] = await Promise.all([loadActualInputs(from, to, q), loadFx(from, to)]);
  return buildDays({ from, to, ...inp, fx });
}

// 예정 입력: ~to 의 예정 전부(오늘 이전 날짜분은 projectDays 가 overdue 로 분리)
// 예정 = 거래목록 예정(status='plan', 미삭제) 그대로. 제외 사유별 건수(excluded)도 함께 돌려준다.
export const PLAN_FILTER_SQL = `t.status='plan' AND t.deleted_at IS NULL`;
export async function loadPlanInputs(today, to, q = query, scopeIds = null) {
  const ids = scopeIds || (await loadAccountScope(q)).ids;
  const [plan, act] = await Promise.all([
    q(`SELECT ${TXN_NAME_COLS}, COALESCE(a.currency, t.currency) AS currency,
              to_char(COALESCE(t.plan_date, t.txn_date),'YYYY-MM-DD') AS d, t.sales_invoice_id,
              CASE WHEN t.account_id IS NOT NULL AND NOT (t.account_id = ANY($2)) THEN 'account'
                   WHEN t.recurring_rule_id IS NOT NULL AND t.recurring_rule_id NOT IN
                        (SELECT r.id FROM recurring_rules r WHERE r.active=true AND r.deleted_at IS NULL) THEN 'inactive_rule'
                   ELSE NULL END AS excluded_by
         FROM transactions t LEFT JOIN accounts a ON a.id=t.account_id ${TXN_NAME_JOINS}
        WHERE ${PLAN_FILTER_SQL} AND COALESCE(t.plan_date, t.txn_date) <= $1`, [to, ids]),
    q(`SELECT ${TXN_NAME_COLS}, a.currency, to_char(t.txn_date,'YYYY-MM-DD') AS d
         FROM transactions t JOIN accounts a ON a.id=t.account_id ${TXN_NAME_JOINS}
        WHERE t.status='actual' AND t.approved=true AND t.deleted_at IS NULL AND a.deleted_at IS NULL AND a.id = ANY($2) AND t.txn_date=$1`, [today, ids]),
  ]);
  const num = (r) => ({ ...r, amount: Number(r.amount), amount_mxn: Number(r.amount_mxn) });
  const uniq = (rows) => { const s = new Set(); return rows.filter((r) => { const k = Number(r.id); if (s.has(k)) return false; s.add(k); return true; }); };
  const all = uniq(plan.rows).map(num);
  // 2026-11-03 지난달 미처리 고정비 예정 — 같은 고정비가 이번 달에도 돌고 있으면 이번 달 회차로 대체된 것으로 보고 제외
  //   (현금흐름·필요자금과 같은 규칙 · recurring.js isSupersededRecurringPlan). 거래목록 데이터는 그대로.
  if (all.some((r) => r.recurring_rule_id != null && !r.excluded_by)) {
    const rules = (await q(`SELECT id, active, deleted_at, to_char(start_date,'YYYY-MM-DD') AS start_date, end_month FROM recurring_rules`)).rows;
    const ym = String(today).slice(0, 7);
    const running = runningRuleIds(rules, ym);
    for (const r of all) {
      if (!r.excluded_by && isSupersededRecurringPlan({ status: 'plan', recurring_rule_id: r.recurring_rule_id, plan_date: r.d }, running, ym)) r.excluded_by = 'superseded';
    }
  }
  const planRows = all.filter((r) => !r.excluded_by);
  const ex = (why) => all.filter((r) => r.excluded_by === why);
  const brief = (xs) => ({ n: xs.length, amount_mxn: r2(xs.reduce((s, x) => s + x.amount_mxn, 0)) });
  return {
    planIn: planRows.filter((r) => r.direction === 'in'),
    planOut: planRows.filter((r) => r.direction === 'out'),
    todayActual: uniq(act.rows).map(num),
    // 대사(거래목록 예정과의 일치 확인): 오늘~to 예정 중 표시/제외 건수
    reconcile: (() => {
      const inWin = (r) => r.d >= today;
      return { list_n: all.filter(inWin).length, shown_n: planRows.filter(inWin).length,
        excluded: { account: brief(ex('account').filter(inWin)), inactive_rule: brief(ex('inactive_rule').filter(inWin)),
          superseded: brief(ex('superseded')) } };
    })(),
  };
}

// 오늘~to 예정 일자 (기초 = 어제 실적 마감)
// 0290 · 일일 자금 설정(디렉터) — 마이그레이션 전이면 기본값
export const TREASURY_SETTINGS_DEFAULT = { ar_roll: true };
export async function loadTreasurySettings(q = query) {
  try {
    const r = (await q(`SELECT ar_roll, updated_at FROM treasury_settings WHERE id = 1`)).rows[0];
    return r ? { ar_roll: r.ar_roll !== false, updated_at: r.updated_at } : { ...TREASURY_SETTINGS_DEFAULT };
  } catch (_) { return { ...TREASURY_SETTINGS_DEFAULT, missing: true }; }
}
export async function computePlanDays(today, to, q = query) {
  const yday = addDays(today, -1);
  const [prev, plan, fx, set] = await Promise.all([
    computeActualDays(yday, yday, q), loadPlanInputs(today, to, q), loadFx(today, to), loadTreasurySettings(q),
  ]);
  const days = projectDays({ today, to, startOpen: prev[0].close, ...plan, fx, rollAr: set.ar_roll });
  if (days.length) { days[0].reconcile = plan.reconcile; days[0].ar_roll = set.ar_roll; }
  return days;
}

// 1019 · 사후 반영(늦게 들어온 실적): 실적일 마감 시각(일일 발송 시각, 기본 18:00 MX) 이후에 등록·수정·승인·삭제된 승인 실적.
//   예) 금요일 업무 종료 후·주말·월요일에 금요일 날짜로 기록 → 금요일 칸이 그날 보고 뒤에 바뀐 것.
export async function loadLateEntries(from, to, cutoffHm = '18:00', q = query, scopeIds = null) {
  if (to < from) return [];
  const ids = scopeIds || (await loadAccountScope(q)).ids;
  const rows = (await q(
    `SELECT ${TXN_NAME_COLS}, a.currency, to_char(t.txn_date,'YYYY-MM-DD') AS d,
            GREATEST(t.updated_at, COALESCE(t.deleted_at, t.updated_at)) AS changed_at, (t.deleted_at IS NOT NULL) AS deleted
       FROM transactions t JOIN accounts a ON a.id=t.account_id ${TXN_NAME_JOINS}
      WHERE t.status='actual' AND t.approved=true AND a.id = ANY($3) AND t.txn_date >= $1 AND t.txn_date <= $2
        AND GREATEST(t.updated_at, COALESCE(t.deleted_at, t.updated_at))
            > (((t.txn_date + $4::time) - ($5::int * interval '1 minute')) AT TIME ZONE 'UTC')
      ORDER BY t.txn_date, t.id`, [from, to, ids, cutoffHm, MX_OFFSET_MIN])).rows;
  const seen = new Set();
  return rows.filter((r) => { const k = Number(r.id); if (seen.has(k)) return false; seen.add(k); return true; })
    .map((r) => ({ ...toItem({ ...r, amount: Number(r.amount), amount_mxn: Number(r.amount_mxn) }), d: r.d, changed_at: r.changed_at, deleted: r.deleted === true }));
}
function markLate(days, late) {
  const byDay = new Map();
  for (const x of late) { if (!byDay.has(x.d)) byDay.set(x.d, []); byDay.get(x.d).push(x); }
  for (const d of days) {
    const xs = byDay.get(d.date);
    if (!xs) continue;
    const ids = new Set(xs.map((x) => x.id));
    for (const it of d.items || []) if (ids.has(it.id)) it.late_entry = true;
    d.late = { n: xs.length, deleted_n: xs.filter((x) => x.deleted).length, items: xs.map((x) => ({ id: x.id, name: x.private ? null : x.name, dir: x.dir, cur: x.cur, amount: x.amount, deleted: x.deleted, changed_at: x.changed_at })) };
  }
}

// 주간 보기(유첨 양식): 월~일 — 과거는 실적, 오늘부터 예정. 일요일은 화면에서 거래가 있을 때만 표시
//   (일요일 거래를 빼면 토요일 마감 ≠ 다음 월요일 기초가 되므로 서버는 7일을 모두 준다)
//   1019 · opts.weeks=2 이거나 지난 주 날짜에 사후 반영이 있으면 지난 주(prev)도 함께 준다(이번 주를 볼 때만 자동).
export async function computeWeek(anyDate, today, q = query, opts = {}) {
  const w = await computeOneWeek(anyDate, today, q);
  const yday = addDays(today, -1);
  const prevFrom = addDays(w.from, -7), prevTo = addDays(w.from, -1);
  let cutoff = '18:00';
  try { cutoff = (await loadSchedules(q)).treasury_daily.send_time || '18:00'; } catch (_) { /* 0262 전 */ }
  let late = [];
  try { late = await loadLateEntries(prevFrom, w.to < yday ? w.to : yday, cutoff, q); } catch (_) { late = []; }
  markLate(w.days, late);
  const prevLate = late.filter((x) => x.d <= prevTo);
  const isCurrent = today >= w.from && today <= w.to;
  const reason = opts.weeks === 2 ? 'manual' : (opts.weeks !== 1 && isCurrent && prevLate.length ? 'late' : null);   // weeks=1 = 직접 접음
  let prev = null;
  if (reason) { prev = await computeOneWeek(prevFrom, today, q); markLate(prev.days, late); }
  return { ...w, prev, expand_reason: reason, settings: await loadTreasurySettings(q), late_cutoff: cutoff,
    late_summary: { n: late.length, prev_n: prevLate.length, days: [...new Set(late.map((x) => x.d))] } };
}
async function computeOneWeek(anyDate, today, q = query) {
  const from = weekStart(anyDate), to = addDays(from, 6);
  const actualTo = to < today ? to : addDays(today, -1);
  const actual = actualTo >= from ? await computeActualDays(from, actualTo, q) : [];
  let plan = [];
  if (to >= today) {
    plan = await computePlanDays(today, to, q);
    plan = plan.filter((d) => d.date >= from);
  }
  return { from, to, today, days: [...actual, ...plan] };
}

// 스냅샷 저장(최초본 first_data 는 보존)
export async function upsertSnapshots(days, q = query) {
  for (const d of days) {
    const data = JSON.stringify({ ...d, cum: d.cum });
    await q(
      `INSERT INTO treasury_daily_snapshots
         (snap_date, fx_rate, open_mxn, open_usd, in_mxn, in_usd, out_mxn, out_usd, close_mxn, close_usd, data, first_data, first_at, computed_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$11::jsonb,now(),now())
       ON CONFLICT (snap_date) DO UPDATE SET
         fx_rate=EXCLUDED.fx_rate, open_mxn=EXCLUDED.open_mxn, open_usd=EXCLUDED.open_usd,
         in_mxn=EXCLUDED.in_mxn, in_usd=EXCLUDED.in_usd, out_mxn=EXCLUDED.out_mxn, out_usd=EXCLUDED.out_usd,
         close_mxn=EXCLUDED.close_mxn, close_usd=EXCLUDED.close_usd, data=EXCLUDED.data, computed_at=now()`,
      [d.date, d.fx, d.open.MXN, d.open.USD, d.in.MXN, d.in.USD, d.out.MXN, d.out.USD, d.close.MXN, d.close.USD, data]);
  }
  return days.length;
}

export async function loadSnapshotMeta(from, to, q = query) {
  const rows = (await q(
    `SELECT to_char(snap_date,'YYYY-MM-DD') AS d, first_data, first_at, computed_at
       FROM treasury_daily_snapshots WHERE snap_date >= $1 AND snap_date <= $2`, [from, to])).rows;
  const m = new Map();
  for (const r of rows) {
    const f = r.first_data && typeof r.first_data === 'string' ? JSON.parse(r.first_data) : r.first_data;
    m.set(r.d, { first: f ? flatOf(f) : null, first_at: r.first_at, computed_at: r.computed_at });
  }
  return m;
}

// ───────────────────────── 수신자 · 발송 ─────────────────────────
export async function activeRecipients(kind, q = query) {
  const col = kind === 'monthly' ? 'get_monthly' : 'get_daily';
  return (await q(`SELECT id, name, phone, lang FROM treasury_wa_recipients
                    WHERE active=true AND deleted_at IS NULL AND ${col}=true ORDER BY id`)).rows;
}
export const maskPhone = (p) => { const s = String(p || ''); return s ? s.slice(0, 3) + '****' + s.slice(-4) : null; };

export function reportUrl() { return process.env.TREASURY_REPORT_URL || DEFAULT_REPORT_URL; }

// 1명 발송 + 원장 기록. force=false 면 성공 이력·시도 상한을 지킨다.
export const DEFAULT_IMG_API = { upload: uploadWaMedia, image: sendWaImage, imageTemplate: sendWaImageTemplate };
export const imageFormatOn = () => process.env.TREASURY_WA_FORMAT !== 'text';

// 이미지 경로: ① 업로드(언어별 1회, mediaCache) → ② image 메시지(캡션) → ③ 이미지 헤더 템플릿. 모두 실패하면 null(→ 텍스트).
//   windowOpen === false(웹훅이 24시간 창이 닫힌 것을 안다, 0253) → ③ 템플릿을 먼저. 창 밖 자유 이미지는
//   API 가 접수만 하고 나중에 실패하므로(131047), 아는 경우엔 처음부터 템플릿으로 보낸다.
// 1009 · 24시간 창 밖 수신자용 이미지 헤더 템플릿 — 비우면 resumen_diario_fondos · 「-」 = 안 씀
export const treasuryImageTemplate = () => (process.env.TREASURY_WA_IMAGE_TEMPLATE === '-' ? '' : (process.env.TREASURY_WA_IMAGE_TEMPLATE || 'resumen_diario_fondos'));
export const treasuryTemplateLang = () => process.env.TREASURY_WA_TEMPLATE_LANG || process.env.WHATSAPP_TEMPLATE_LANG || 'es_MX';
//   1009 · 창이 「열림」으로 확실할 때만 자유 이미지(무료). 닫힘·모름이면 이미지 템플릿 먼저.
//     닫힘 + 템플릿 실패 → 보내지 않고 실패 기록(자유 이미지는 API 가 접수만 하고 도착하지 않음 · #131047).
//     모름(웹훅 미설정) + 템플릿 실패 → 마지막 수단으로 자유 이미지, 원장에 「창 밖이면 도착 안 함」 사유.
async function tryImage({ rcpt, png, headline, tplParam = null, cacheKey, mediaCache, imgApi, windowOpen = null }) {
  const tplText = tplParam || headline;   // 템플릿 {{1}} — 날짜(승인 본문), 없으면 예전처럼 한 줄 요약
  if (!png) return null;
  let mid = mediaCache[cacheKey];
  if (!mid) {
    const up = await imgApi.upload(png, { mime: 'image/png', filename: `refatrix_${cacheKey}.png` });
    if (!up.ok) return { ok: false, error: `upload: ${up.error}` };
    mid = mediaCache[cacheKey] = up.id;
  }
  const tpl = treasuryImageTemplate();
  const lang = treasuryTemplateLang();
  let tErr = '';
  if (windowOpen !== true) {
    if (tpl) {
      const r0 = await imgApi.imageTemplate({ to: rcpt.phone, mediaId: mid, param: tplText, name: tpl, lang });
      if (r0.ok) return { ok: true, mode: 'image_template', message_id: r0.message_id };
      tErr = `이미지 템플릿 ${tpl}(${lang}) 실패${r0.code ? ' #' + r0.code : ''}: ${r0.error}`
        + (Number(r0.code) === 132001 ? ' — Meta 에 템플릿이 없거나 아직 승인 전' : '');
    } else tErr = '이미지 템플릿 안 씀(「-」)';
    if (windowOpen === false) return { ok: false, error: `${tErr} · 24시간 창 밖이라 자유 이미지는 보내지 않음` };
  }
  const r1 = await imgApi.image({ to: rcpt.phone, mediaId: mid, caption: headline });
  if (r1.ok) return { ok: true, mode: 'image', message_id: r1.message_id,
    text_error: tErr ? `${tErr} — 자유 이미지로 보냄(24시간 창 밖 수신자에게는 도착 안 함)` : null };
  if (windowOpen === true && tpl) {
    const r2 = await imgApi.imageTemplate({ to: rcpt.phone, mediaId: mid, param: tplText, name: tpl, lang });
    if (r2.ok) return { ok: true, mode: 'image_template', message_id: r2.message_id, text_error: `image: ${r1.error}` };
    return { ok: false, error: `image: ${r1.error} / image_template: ${r2.error}` };
  }
  return { ok: false, error: `${tErr ? tErr + ' / ' : ''}image: ${r1.error}` };
}

export async function sendOne({ kind, period, rcpt, text, headline, tplParam = null, png = null, cacheKey = null, mediaCache = {}, force = false, sender = sendWaTo, imgApi = DEFAULT_IMG_API, windowOpen }, q = query) {
  const prev = (await q(`SELECT sent_at, attempts FROM treasury_wa_sends WHERE kind=$1 AND period=$2 AND recipient_id=$3`,
    [kind, period, rcpt.id])).rows[0];
  if (!force && prev && prev.sent_at) return { skipped: 'already_sent', recipient_id: Number(rcpt.id) };
  if (!force && prev && Number(prev.attempts) >= MAX_ATTEMPTS) return { skipped: 'max_attempts', recipient_id: Number(rcpt.id) };
  if (windowOpen === undefined) windowOpen = (await windowState(rcpt.phone, q)).open;   // 웹훅 미설정이면 null(기존 동작)
  let res = png ? await tryImage({ rcpt, png, headline, tplParam, cacheKey: cacheKey || `${kind}_${period}`, mediaCache, imgApi, windowOpen }) : null;
  let imgErr = null;
  if (!res || !res.ok) {
    imgErr = res ? res.error : null;
    res = await sender({ to: rcpt.phone, text, headline, templateName: process.env.TREASURY_WA_TEMPLATE || null, windowOpen });
    if (res.ok && imgErr) res.text_error = imgErr;
    if (!res.ok && imgErr) res.error = `${imgErr} / ${res.error}`;
  }
  const MODE = { image: 'sent_image', image_template: 'sent_image_template', template: 'sent_template', text: 'sent_text' };
  const status = res.ok ? (MODE[res.mode] || 'sent_text') : 'failed';
  await q(
    `INSERT INTO treasury_wa_sends (kind, period, recipient_id, to_masked, status, message_id, error, attempts, sent_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,1, CASE WHEN $8 THEN now() ELSE NULL END, now())
     ON CONFLICT (kind, period, recipient_id) DO UPDATE SET
       to_masked=EXCLUDED.to_masked, status=EXCLUDED.status,
       message_id=COALESCE(EXCLUDED.message_id, treasury_wa_sends.message_id),
       error=EXCLUDED.error, attempts=treasury_wa_sends.attempts+1,
       sent_at=CASE WHEN $8 THEN now() ELSE treasury_wa_sends.sent_at END, updated_at=now()`,
    [kind, period, rcpt.id, maskPhone(rcpt.phone), status, res.message_id || null, res.ok ? (res.text_error || null) : (res.error || 'error'), !!res.ok]);
  return { recipient_id: Number(rcpt.id), ok: !!res.ok, status, error: res.ok ? null : res.error };
}

// 일일 발송 본문 준비(언어별)
//   이미지 열(유첨 양식): 발송일이 요약일 다음날이면 [최근 실적 2일 + 오늘 + 예정 3일], 아니면(과거 재발송) 최근 실적 6일.
//   일요일은 거래가 있을 때만 열로 쓴다.
export const IMG_ACTUAL_COLS = 2, IMG_PLAN_COLS = 4;
//   opts.sameDay=true(당일 마감 발송, 0262 기본 18:00): 보고일 = 발송일, 예정은 「내일」부터, 보고일 열을 「오늘」로 표시.
//   opts.sendTime: 이미지 머리말 「… HH:MM 기준」.
export async function prepareDaily(dateStr, sendDay, q = query, opts = {}) {
  const sameDay = opts.sameDay === true;
  const sendTime = opts.sendTime || null;
  if (sameDay) sendDay = dateStr;
  const planStart = sameDay ? addDays(dateStr, 1) : sendDay;
  const { from } = monthBounds(dateStr.slice(0, 7));
  const winFrom = addDays(dateStr, -9);
  const all = await computeActualDays(winFrom < from ? winFrom : from, dateStr, q);
  const days = all.filter((d) => d.date >= from);
  const day = days[days.length - 1];
  const mtd = summarizeMonth(days, { mask: true });
  const keep = (d) => d.dow !== 0 || d.moved;
  let plan = null, planDays = [];
  if (planStart && planStart > dateStr) {
    try { planDays = await computePlanDays(planStart, addDays(planStart, 7), q); plan = planDays[0] || null; } catch (_) { planDays = []; plan = null; }
  }
  // 당일 마감: 보고일 열 = 「오늘」(실적), 내일 열 = 「예정」(projectDays 가 첫날을 today 로 표시하므로 바로잡음)
  if (sameDay && planDays.length) planDays = planDays.map((d) => (d.kind === 'today' ? { ...d, kind: 'plan' } : d));
  const actualCols = all.filter(keep).map((d) => (sameDay && d.date === dateStr ? { ...d, kind: 'today' } : d));
  const cols = (planStart === addDays(dateStr, 1) && planDays.length)
    ? [...actualCols.slice(-IMG_ACTUAL_COLS), ...planDays.filter(keep).slice(0, IMG_PLAN_COLS)]
    : actualCols.slice(-(IMG_ACTUAL_COLS + IMG_PLAN_COLS));
  const sd = sendDay || addDays(dateStr, 1);
  const build = (lang) => ({ text: buildDailyText(day, { mtd, plan, lang, planTomorrow: sameDay }), headline: buildDailyHeadline(day, lang), tplParam: templateDate(dateStr),
    svg: dailyImageSvg({ cols, reportDay: dateStr, sendDay: sd, mtd, lang, sendTime }) });
  return { days, day, mtd, plan, cols, build };
}
//   opts.includeToday=true: 말일 당일 마감 발송(0262 기본) — 오늘까지 포함
export async function prepareMonthly(month, today, q = query, opts = {}) {
  const { from, to } = monthBounds(month);
  const last = to < today ? to : (opts.includeToday ? today : addDays(today, -1));
  const days = await computeActualDays(from, last, q);
  const sum = summarizeMonth(days, { mask: true });
  const partial = last < to;
  const build = (lang) => ({ text: buildMonthlyText(sum, { lang, link: reportUrl() }), headline: buildMonthlyHeadline(sum, lang), tplParam: `${templateDate(last)} (resultado mensual de ${monthLabel(month, 'es')})`,
    svg: monthlyImageSvg({ sum, days, lang, partial }) });
  return { days, sum, partial, build };
}

// 언어별로 문구·PNG 를 한 번만 만들고, 업로드한 미디어 id 도 언어별로 재사용
export async function sendReport({ kind, period, recipients, prepared, force = false, sender, imgApi }, q = query) {
  const cache = {};
  const mediaCache = {};
  const results = [];
  for (const r of recipients) {
    const lang = r.lang === 'ko' ? 'ko' : 'es';
    if (!cache[lang]) {
      const b = prepared.build(lang);
      const png = imageFormatOn() ? await svgToWaPng(b.svg) : null;   // 1028 · 가로 1280 이하
      cache[lang] = { text: b.text, headline: b.headline, tplParam: b.tplParam || null, png, cacheKey: `${kind}_${period}_${lang}` };
    }
    const opt = { kind, period, rcpt: r, ...cache[lang], mediaCache, force };
    if (sender) opt.sender = sender;
    if (imgApi) opt.imgApi = imgApi;
    results.push(await sendOne(opt, q));
  }
  return results;
}

// ── 스케줄 1회 실행 (5분마다 호출) ──
//   시각·대상일은 관리 › WhatsApp 발송 시각(wa_schedules, 0262). 기본: 일일 18:00 당일 마감 · 월간 18:00 말일(그달).
//   · 일일: 설정 시각 ~ +6시간 창 안에서 1회(수신자별 성공 1회 가드). 일요일 무거래는 생략(설정).
//   · 월간: today = 말일 설정 시각에 그달(오늘 포함) · yesterday = 1일 설정 시각에 지난달.
//           어느 쪽이든 놓치면 다음 달 1~3일 설정 시각 이후 지난달로 따라잡는다(이미 보냈으면 가드).
//   · 스냅샷 누적은 시각과 무관하게 매 실행(어제까지 + 당일 마감 발송 시 오늘).
export async function runTreasuryJob({ nowMs, sender, imgApi, q = query, schedules = null } = {}) {
  if (process.env.TREASURY_DAILY_ENABLED === '0') return { skipped: 'disabled' };
  const now = mxParts(nowMs);
  const cfg = schedules || await loadSchedules(q);
  const cd = cfg.treasury_daily, cm = cfg.treasury_monthly;
  const yday = addDays(now.ymd, -1);
  const out = { yday, snapshots: 0, daily: [], monthly: [] };
  // 1) 스냅샷: 어제가 속한 달 1일~어제
  const days = await computeActualDays(monthBounds(yday.slice(0, 7)).from, yday, q);
  out.snapshots = await upsertSnapshots(days, q);
  const canSend = waApiReady() || !!sender;
  if (!canSend) return { ...out, wa: 'not_configured' };
  // 2) 일일
  if (isDue(cd, now)) {
    const period = targetDate(cd, now);
    const sameDay = cd.target_day === 'today';
    let day = days[days.length - 1];
    if (sameDay) { const td = await computeActualDays(period, period, q); out.snapshots += await upsertSnapshots(td, q); day = td[0]; }
    out.daily_period = period;
    if (!(cd.skip_empty_sunday && day.dow === 0 && !day.moved)) {
      const rc = await activeRecipients('daily', q);
      if (rc.length) {
        const prepared = await prepareDaily(period, sameDay ? period : now.ymd, q, { sameDay, sendTime: cd.send_time });
        out.daily = await sendReport({ kind: 'daily', period, recipients: rc, prepared, sender, imgApi }, q);
      }
    } else out.daily_skipped = 'empty_sunday';
  }
  // 3) 월간
  if (cm.enabled !== false && now.minutes >= toMinutes(cm.send_time)) {
    const lastDay = monthBounds(now.ymd.slice(0, 7)).to === now.ymd;
    let month = null, includeToday = false;
    if (cm.target_day === 'today' && lastDay) { month = now.ymd.slice(0, 7); includeToday = true; }
    else if (now.day <= MONTHLY_CATCHUP_DAYS) month = prevMonth(now.ymd.slice(0, 7));
    if (month) {
      const rc = await activeRecipients('monthly', q);
      if (rc.length) {
        const { from, to } = monthBounds(month);
        await upsertSnapshots(await computeActualDays(from, includeToday ? now.ymd : to, q), q);
        const prepared = await prepareMonthly(month, now.ymd, q, { includeToday });
        out.monthly_period = month;
        out.monthly = await sendReport({ kind: 'monthly', period: month, recipients: rc, prepared, sender, imgApi }, q);
      }
    }
  }
  return out;
}

export function startTreasuryWorker(app) {
  if (globalThis.__refatrixTreasuryWorker) return;
  let busy = false;
  const tick = async () => {
    if (busy) return; busy = true;
    try { await runTreasuryJob({}); } catch (e) { app && app.log && app.log.warn({ err: String(e && e.message) }, '[treasury] job failed'); }
    finally { busy = false; }
  };
  globalThis.__refatrixTreasuryWorker = setInterval(() => { tick(); }, 300000);
  setTimeout(() => { tick(); }, 25000);
}
