import { round2 } from './permissions.js';

// =====================================================================
// 매출 인보이스 금액 계산 (순수 함수)
//  - 라인: 판매단가 = 정가 × (1 - 할인율/100), 라인금액 = 판매단가 × 수량
//  - 합계: 소계 = Σ 라인금액, IVA = 소계 × 세율/100, 총액 = 소계 + IVA
//  - 원가: applied_unit_cost(그 시점 평균원가) × 수량 = COGS (라인별)
//  - 예상 입금일 = 인보이스일 + 외상일(credit_days)
// =====================================================================

// 한 라인 계산. cost(평균원가)는 주어지면 COGS도 계산.
export function computeLine({ qty, listPrice, discountRate = 0, cost = null }) {
  const unitPrice = round2(Number(listPrice) * (1 - Number(discountRate) / 100));
  const lineAmount = round2(unitPrice * Number(qty));
  const out = {
    qty: Number(qty),
    listPrice: round2(Number(listPrice)),
    discountRate: Number(discountRate),
    unitPrice,
    lineAmountMxn: lineAmount,
  };
  if (cost != null) {
    out.appliedUnitCost = round2(Number(cost));
    out.cogsMxn = round2(Number(cost) * Number(qty));
  }
  return out;
}

// 인보이스 합계. lines: computeLine 결과 배열. ivaRate %(기본 16)
export function computeInvoiceTotals(lines, ivaRate = 16) {
  const subtotal = round2(lines.reduce((s, l) => s + Number(l.lineAmountMxn), 0));
  const iva = round2(subtotal * Number(ivaRate) / 100);
  const total = round2(subtotal + iva);
  const cogs = round2(lines.reduce((s, l) => s + (l.cogsMxn != null ? Number(l.cogsMxn) : 0), 0));
  const grossMargin = round2(subtotal - cogs); // 매출총이익(ex-IVA 소계 - COGS)
  return { subtotalMxn: subtotal, ivaMxn: iva, totalMxn: total, cogsMxn: cogs, grossMarginMxn: grossMargin };
}

// 날짜를 YYYY-MM-DD 문자열로 정규화 (Date 객체·ISO 문자열 모두 처리)
export function ymd(v) {
  if (v instanceof Date) {
    const y = v.getUTCFullYear(), m = String(v.getUTCMonth() + 1).padStart(2, '0'), d = String(v.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  return String(v).slice(0, 10);
}

// 예상 입금일 = inv_date + creditDays (YYYY-MM-DD 문자열/Date 입력 모두 허용)
export function dueDate(invDate, creditDays) {
  const d = new Date(ymd(invDate) + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + Number(creditDays || 0));
  return d.toISOString().slice(0, 10);
}

// 외상일이 기준(고객 마스터)과 다른지 판정
export function isCreditException(appliedDays, customerDefaultDays) {
  return Number(appliedDays) !== Number(customerDefaultDays);
}

// =====================================================================
// 매출 수정/삭제 되돌림·재적용 계산 (순수 함수)
//  매출 1건의 효과: 재고 -qty(out), COGS=+(qty×appliedUnitCost), 매출(소계)·AR(총액) 발생.
//  - 삭제: 원본 효과를 취소(재고 +복원, COGS·매출·AR 취소).
//  - 수정: 원본 취소 + 새 내용 적용의 합산(순효과).
//  마감월 규칙:
//   · 미마감: 과거(COGS·매출)를 소급 취소/정정. 재고는 원가 스냅샷으로 복원.
//   · 마감:   과거(COGS·매출)는 고정. 재고는 원가 스냅샷으로 복원하되,
//            그로 인한 손익 차액(취소되었어야 할 COGS-매출의 순액)을 현재 시점 "정산차액"으로 인식.
// =====================================================================

// 원본 라인들의 효과 합계 (재고/원가/매출 기준)
//  lines: [{ productId, qty, appliedUnitCost, lineAmountMxn }]
function sumEffect(lines) {
  let cogs = 0, sales = 0;
  const perProduct = {};
  for (const l of lines) {
    const c = round2(Number(l.appliedUnitCost) * Number(l.qty));
    cogs = round2(cogs + c);
    sales = round2(sales + Number(l.lineAmountMxn));
    perProduct[l.productId] = round2((perProduct[l.productId] || 0) + Number(l.qty));
  }
  return { cogs, sales, perProduct };
}

// 삭제 되돌림 계산
//  origLines: 원본 라인, closedMonth: 그 인보이스 달이 마감됐는지
//  반환: { stockRestore:{productId:qty}, cogsReversal, salesReversal, varianceMxn, mode }
export function computeDeleteReversal({ origLines, closedMonth }) {
  const e = sumEffect(origLines);
  if (!closedMonth) {
    // 미마감: 과거 소급 취소 — COGS·매출 모두 원복, 재고 복원
    return { mode: 'retro', stockRestore: e.perProduct, cogsReversal: e.cogs, salesReversal: e.sales, varianceMxn: 0 };
  }
  // 마감: 과거 고정 — 재고만 현재 시점 복원, 손익 순액(매출-COGS=매출총이익)을 정산차액으로
  // 삭제했어야 할 매출총이익만큼이 과거에 남아있으므로, 그 반대 부호를 현재 정산차액으로 인식.
  const variance = round2(e.sales - e.cogs); // 마감으로 되돌리지 못한 매출총이익
  return { mode: 'closed', stockRestore: e.perProduct, cogsReversal: 0, salesReversal: 0, varianceMxn: variance };
}

// 수정 순효과 계산 (원본 취소 + 새 내용 적용)
//  origLines/newLines: [{ productId, qty, appliedUnitCost, lineAmountMxn }]
//   - newLines.appliedUnitCost 는 "현재 평균원가"(수정 적용 시점 스냅샷)
//  반환: { stockDelta:{productId: +복원-신규}, cogsDelta, salesDelta, mode, varianceMxn }
export function computeEditNetEffect({ origLines, newLines, closedMonth }) {
  const o = sumEffect(origLines);
  const n = sumEffect(newLines);
  // 재고 순변화: 원본은 되돌려 +, 신규는 빠져 -
  const stockDelta = {};
  for (const [pid, q] of Object.entries(o.perProduct)) stockDelta[pid] = round2((stockDelta[pid] || 0) + q);
  for (const [pid, q] of Object.entries(n.perProduct)) stockDelta[pid] = round2((stockDelta[pid] || 0) - q);

  if (!closedMonth) {
    return {
      mode: 'retro', stockDelta,
      cogsDelta: round2(n.cogs - o.cogs),   // 매출원가 순증감(소급 반영)
      salesDelta: round2(n.sales - o.sales),
      varianceMxn: 0,
    };
  }
  // 마감: 과거(원본) 고정. 신규분만 현재 시점에 반영, 원본 취소분의 손익은 정산차액으로.
  return {
    mode: 'closed', stockDelta,
    cogsDelta: round2(n.cogs),  // 신규 COGS는 현재 반영
    salesDelta: round2(n.sales),
    varianceMxn: round2(o.sales - o.cogs), // 원본 매출총이익(되돌리지 못한 과거분)을 정산차액으로
  };
}

// =====================================================================
// 2026-10-13 · 매출확정 인보이스 「할인율로 매출액 수정」 (순수 함수)
//   basis='list'    : 정가 대비 할인율 → 모든 라인 단가 = 정가 × (1 − r/100)   (덮어쓰기, 누적 안 됨)
//   basis='current' : 현재 매출액에서 추가 할인 → 단가 = 현재 실효단가 × (1 − r/100)
//   단가는 소수 2자리, 라인금액 = 단가 × 수량 → 엑셀 「수량 × 최종단가 = 금액」이 정확히 맞는다.
//   소계(IVA 제외) = Σ 라인금액, IVA = 소계 × 세율, 총계 = 소계 + IVA (computeInvoiceTotals 와 동일).
//   lines: [{ id, qty, list_price, unit_price, line_amount_mxn }]
//   반환: { ok, lines:[{ id, unit_price, line_amount_mxn, discount_rate }], subtotal, iva, total }
//        또는 { error: 'bad_basis'|'bad_rate'|'no_lines'|'no_list_price'|'zero_qty', codes? }
// =====================================================================
export function repriceByDiscount(lines, { basis, rate, ivaRate = 16 } = {}) {
  if (basis !== 'list' && basis !== 'current') return { error: 'bad_basis' };
  const r = Number(rate);
  if (rate === '' || rate == null || !Number.isFinite(r) || r < 0 || r >= 100) return { error: 'bad_rate' };
  if (!Array.isArray(lines) || !lines.length) return { error: 'no_lines' };
  if (basis === 'list') {
    const np = lines.filter((l) => !(Number(l.list_price) > 0));
    if (np.length) return { error: 'no_list_price', codes: np.map((l) => l.code || String(l.id)) };
  }
  const out = [];
  for (const l of lines) {
    const qty = Number(l.qty) || 0;
    const list = Number(l.list_price) || 0;
    let unit;
    if (basis === 'list') unit = round2(list * (1 - r / 100));
    else {
      if (!(qty > 0)) return { error: 'zero_qty', codes: [l.code || String(l.id)] };
      // 실효단가 = 라인금액 ÷ 수량 (총액 비례 수정 뒤에는 단가×수량이 라인금액과 몇 센트 다를 수 있어 라인금액을 기준으로)
      const eff = Number(l.line_amount_mxn) / qty;
      unit = round2(eff * (1 - r / 100));
    }
    const amt = round2(unit * qty);
    // 정가 대비 실효 할인율(라인 discount_rate 를 실제 값과 맞춘다). 정가 0 이면 기존 값 유지.
    const disc = list > 0 ? Math.min(999.99, Math.max(-999.99, round2((1 - unit / list) * 100))) : (Number(l.discount_rate) || 0);
    out.push({ id: l.id, qty, list_price: list, unit_price: unit, line_amount_mxn: amt, discount_rate: basis === 'list' ? round2(r) : disc });
  }
  const subtotal = round2(out.reduce((s, l) => s + l.line_amount_mxn, 0));
  const iva = round2(subtotal * Number(ivaRate) / 100);
  const total = round2(subtotal + iva);
  return { ok: true, lines: out, subtotal, iva, total };
}

// 정가 대비 가중 실효 할인율(%) — 화면에 「현재 정가 대비 N%」 표시용. 정가 합이 0 이면 null.
export function effectiveDiscountPct(lines) {
  let list = 0, amt = 0;
  for (const l of lines || []) { list += (Number(l.list_price) || 0) * (Number(l.qty) || 0); amt += Number(l.line_amount_mxn) || 0; }
  if (!(list > 0)) return null;
  return round2((1 - amt / list) * 100);
}

// =====================================================================
// 2026-10-13 · 매출액 수정 내역(0274) — 화면·엑셀에 「추가 할인 N% 적용」을 보이기 위한 기록값 계산 (순수 함수)
//   「수정 전」 금액 = 같은 방식의 수정이 이어지는 동안 처음 값을 유지한다.
//     예) 추가 할인 10% → 또 10%  : 수정 전 = 첫 10% 직전 금액, 누적 추가 할인율 = 19%
//         정가 대비 45% → 50%     : 수정 전 = 첫 수정 직전 금액, 할인율 = 50
//     방식이 바뀌면(추가 할인 → 정가 대비 등) 그 직전 금액이 새 「수정 전」이 된다.
//   prev : { price_adj_basis, price_adj_rate, pre_adj_subtotal_mxn, pre_adj_total_mxn }
//   cur  : { subtotal, total }  — 이번 수정 직전 인보이스 금액
//   반환 : { basis, rate, pre_subtotal, pre_total, keepLinePre }  (keepLinePre=true → 라인 pre_adj_unit_price 유지)
// =====================================================================
export function priceAdjMeta(prev, cur, { basis, rate }) {
  const p = prev || {};
  const same = p.price_adj_basis === basis && p.pre_adj_subtotal_mxn != null;
  const preSub = same ? round2(p.pre_adj_subtotal_mxn) : round2(cur.subtotal);
  const preTot = same && p.pre_adj_total_mxn != null ? round2(p.pre_adj_total_mxn) : round2(cur.total);
  let r = null;
  if (basis === 'list') r = round2(Number(rate));
  else if (basis === 'current') {
    const prevR = same ? Number(p.price_adj_rate) || 0 : 0;
    r = round2((1 - (1 - prevR / 100) * (1 - Number(rate) / 100)) * 100);
  }
  return { basis, rate: r, pre_subtotal: preSub, pre_total: preTot, keepLinePre: same };
}
