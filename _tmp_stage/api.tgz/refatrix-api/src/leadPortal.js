// =====================================================================
// Refatrix ERP · leadPortal.js — Meta 광고 문의 → refaccionaria 고객 포털 (0297 · 2026-10-26 디렉터 지시)
//
//   「ERP 주소는 공개하지 않고, 우리 refaccionaria 고객에게 Meta 광고 문의를 보여 줘서 우리 부품을 팔게 한다」
//
//   고객 화면 = REFATRIX Platform(Netlify) leads.html — 브라우저는 같은 사이트의 /lp-api/* 만 부른다.
//   Netlify(_redirects, 200 proxy)가 그 요청을 여기 /api/lead-portal/* 로 넘기므로 ERP · Railway 주소는 브라우저에 안 나온다.
//
//   ── 디렉터 결정 (2026-10-26) ──
//     · 접속코드는 고객별로 디렉터만 발급 · 통제. 열람 기한 = 디렉터가 **만료일을 직접 입력**(기준표 자동 계산 없음).
//       기준 금액 · 조건 메모는 기록용, 발급 화면에 그 고객 ERP 매출(30일 · 3개월 · 12개월, IVA 제외)을 참고로 보여 준다.
//     · 열람 범위: 지금은 전체 문의. 코드별로 주(州)를 골라 제한할 수 있게 칸만 둔다(scope_states).
//     · 연락처(이름 · 전화)는 「Ver contacto」를 눌러야 나오고, 그때마다 ERP 에 기록(같은 고객 × 같은 문의는 한 줄).
//     · 부품번호 · Refatrix **정확한 가용수량**(현재고 − 다른 견적 예약) · 운송중 수량/ETA · 고객 할인가(IVA 별도)를 보여 준다.
//     · 「Mi stock」(고객 매장 재고) = 고객이 포털에서, 담당 영업사원 · 디렉터가 ERP 에서 고친다. 최근 값 + 입력자 · 날짜, 이력.
//       최근 12개월 우리에게 산 수량(자동 · 참고)도 함께.
//     · 주문 → 그 고객 이름의 ERP 견적(초안) — CRM 견적요청과 같은 조립기(할인율 · 재고 예약 · 부족분 · 개발요청 대장 ·
//       신규견적 WhatsApp 알림). 담당 영업사원이 확인 후 확정.
//
//   ── 고객에게 보내지 않는 것 ──
//     대화 원문 · 우리 직원 답변 · 내부 메모 · 진행 상태 · 다른 refaccionaria 의 열람/주문 · 원가 · 다른 고객 이름.
//
//   ── 보안 ──
//     · 코드 RFX-XXXX-XXXX(31자 알파벳 8자리 ≈ 40bit) · DB 에는 sha256 해시와 끝 4자리만
//     · 토큰 {sub:'lp:<id>', typ:'lead_portal', tv} — authGuard 가 typ 이 붙은 토큰을 **ERP API 전부 401** 로 막는다
//     · 요청마다 코드 상태를 다시 읽는다 — 정지 · 기한 경과 · 재발급 · 삭제는 **다음 요청부터 즉시** 막힌다
//     · 틀린 코드: 같은 IP 8회 → 15분 잠금(429)
// =====================================================================
import crypto from 'node:crypto';
import { query, withTx } from './db.js';
import { logEvent } from './audit.js';
import { authGuard, requirePageAny, requirePageEditAny } from './middleware/authGuard.js';
import { visibleTeamIds } from './teams.js';
import { computeQuoteLine, computeQuoteTotals } from './quotes.js';
import { buildLines, assignReservations, stampLineMeta } from './quoteBuild.js';
import { isKitCode, kitsFor, kitCompositions, normKitNo } from './vioPromos.js';   // 1106d · 키트 주문
import { DEV_CATS, classifyCategory } from './devDemand.js';                         // 1106d · 구성품 분류(Rótula · Horquilla …)
import { reserveExpiresAt } from './quoteExpiry.js';
import { syncQuoteShortages } from './quoteShortage.js';
import { recordQuoteDevDemand } from './quoteDevDemand.js';
import { kickQuoteNotify } from './quoteWaNotify.js';
import { resolveSeller, exclusivityReady } from './exclusivity.js';
import { META_STATES } from './metaLeadExtract.js';
import { AD_EXPR, cleanAdId } from './metaAds.js';
import { internalWaPhones } from './metaLeads.js';   // 1105e · 사내 번호 WhatsApp 은 포털에 안 보임   // 1105 · 광고별 열람 범위
import { isBotText } from './metaLeadsAi.js';   // 1104 · 우리 정해진 안내문 = 자동 응답
import { oeReady, oeByProduct } from './oeCodes.js';
import { normOe, oeToken } from './oeParse.js';
import { chatReady, claimDays, sendMessengerSmart, commentRefOf } from './metaPageMsgs.js';   // 0300 · Messenger 대화

export const LP_TYP = 'lead_portal';
export const LP_BUILD = 'lp-1106f';

// 1105c · 개인정보 보호 · 비밀유지 확약서(포털 로그인 후 전자서명) — 2026-11-05 디렉터
//   본문을 바꾸면 CONSENT_VERSION 을 올린다 → 모든 고객 코드가 다시 서명한다.
export const CONSENT_VERSION = '2026-11-05';
export const CONSENT_TEXT = [
  'CARTA COMPROMISO DE CONFIDENCIALIDAD Y PROTECCIÓN DE DATOS PERSONALES',
  'Plataforma de oportunidades de venta Refatrix',
  '',
  'Declaro que:',
  '1. Los datos personales de los clientes que consulto en esta plataforma (nombres, teléfonos, conversaciones, ubicación, vehículos y piezas buscadas) me son compartidos por Refatrix únicamente para atender esas solicitudes de venta de piezas CTR.',
  '2. Usaré estos datos solo dentro de esta plataforma y solo para ese fin. No los copiaré, venderé, compartiré, publicaré ni entregaré a terceros, ni los usaré para otros fines.',
  '3. Protegeré mi código de acceso y no lo compartiré con personas ajenas a mi negocio.',
  '4. Registraré con verdad lo que hable con cada cliente.',
  '5. Si incumplo este compromiso, asumo personalmente toda la responsabilidad civil y penal que corresponda conforme a la legislación mexicana aplicable en materia de protección de datos personales, y Refatrix podrá cancelar mi código de acceso de inmediato.',
  '',
  'Al firmar, confirmo que leí y acepto esta carta compromiso.',
].join('\n');
const consentHash = () => crypto.createHash('sha256').update(CONSENT_VERSION + '\n' + CONSENT_TEXT).digest('hex');
// 1105c · 포털에서 입력하는 문의 정보 — ERP 「Meta 광고 문의」 칸과 같은 것(m_*)
export const INFO_FIELDS = { name: ['m_name', 120], tipo: ['m_tipo', 60], state: ['m_state', 60], city: ['m_city', 80], phone: ['m_phone', 40], vehicles: ['m_vehicles', 300], parts: ['m_parts', 300] };
export const INFO_TIPOS = ['Refaccionaria', 'Mayorista', 'Taller mecánico', 'Flotilla', 'Taxi / app', 'Particular'];
export const INFO_RESULTS = ['contactado', 'cotizado', 'vendido', 'no_interesa'];
const TOKEN_TTL = '7d';
const ALPHA = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';           // 0 · O · 1 · I · L 없음(전화로 불러도 헷갈리지 않게)
const MAX_FAIL = 8;
const LOCK_MS = 15 * 60 * 1000;
const MAX_LEADS = 1000;
const MAX_ORDER_LINES = 60;
const MAX_QTY = 9999;
// 「제품·마케팅」 그룹 화면 권한키 — metaLeadsRoutes.js PM_KEYS 와 같은 목록(순환 import 를 피해 여기 둔다)
const PM_KEYS = ['products', 'marketing', 'pricemaster', 'devrequest', 'quote', 'sales'];

const idOf = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };
const num = (v) => (v == null || v === '' ? null : Number(v));
const ymd = (s) => (/^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && !isNaN(new Date(String(s) + 'T00:00:00Z')) ? String(s) : null);
const clip = (s, n) => { const t = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return t ? t.slice(0, n) : null; };

// ── 코드 ───────────────────────────────────────────────────────────
export function newCode(rand = crypto.randomBytes) {
  const b = rand(8); let s = '';
  for (let i = 0; i < 8; i++) s += ALPHA[b[i] % ALPHA.length];
  return 'RFX-' + s.slice(0, 4) + '-' + s.slice(4);
}
// 사용자가 친 코드 → 비교용(대문자 · 영숫자만 · 앞 RFX 생략 가능)
export function normCode(v) {
  let s = String(v == null ? '' : v).toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (s.startsWith('RFX')) s = s.slice(3);
  return /^[A-Z0-9]{8}$/.test(s) ? s : null;
}
export const codeHash = (norm) => crypto.createHash('sha256').update('lp:' + norm).digest('hex');

// ── 포털 준비 여부(마이그레이션 0297 전이면 포털은 503, 기존 화면은 그대로) ──
let ready = false; let probe = 0;
export async function portalReady() {
  if (ready) return true;
  if (Date.now() - probe < 30000) return false;
  probe = Date.now();
  try { ready = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_codes'`)).rows.length > 0; }
  catch (_) { ready = false; }
  return ready;
}
export function setPortalReady(v) { ready = !!v; probe = Date.now(); }

// ── 상태(목록 · 고객 화면 공통) ──────────────────────────────────────
//   today = 멕시코시티 날짜. 만료일 당일까지 열람.
export function codeState(row, todayYmd) {
  if (!row || row.deleted_at) return 'deleted';
  if (row.active === false) return 'paused';
  const exp = typeof row.expires_on === 'string' ? row.expires_on.slice(0, 10) : row.expires_on;
  if (exp < todayYmd) return 'expired';
  const days = daysBetween(todayYmd, exp);
  return days <= 7 ? 'soon' : 'active';
}
export function daysBetween(a, b) {
  return Math.round((Date.UTC(+b.slice(0, 4), +b.slice(5, 7) - 1, +b.slice(8, 10)) - Date.UTC(+a.slice(0, 4), +a.slice(5, 7) - 1, +a.slice(8, 10))) / 86400000);
}
export function todayMx(now = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Mexico_City' }).format(now);
}
const fmtDmy = (s) => (s ? s.slice(8, 10) + '/' + s.slice(5, 7) + '/' + s.slice(0, 4) : '');

// 고객 안내문(스페인어) — 발급 · 재발급 직후 한 번만(코드 전체가 들어 있다)
export function inviteText({ customerName, code, expiresOn, url }) {
  return [
    `Hola, ${customerName} 👋`,
    'Ya tienes acceso a las solicitudes de clientes que llegan por nuestros anuncios en Facebook, Instagram y WhatsApp.',
    '',
    `🔗 ${url}`,
    `🔑 Código: ${code}`,
    `📅 Vigente hasta: ${fmtDmy(expiresOn)}`,
    '',
    'El código es personal: no lo compartas. Cada vez que veas un contacto queda registrado.',
    'Ofrece piezas CTR a estos clientes y haz tu pedido desde la misma página.',
  ].join('\n');
}
export const portalUrl = () => process.env.LEAD_PORTAL_URL || 'https://refatrix-platform.netlify.app/leads';

// ── 2026-10-26 디렉터 지시: ERP 화면 · CRM 이 아닌 곳(= Meta 광고 문의 포털)에서 온 견적은 「FB」로 시작 ──
//   FB-YYYY-#### (연도별 일련번호, ERP Q-YYYY-#### 와 같은 모양 · 따로 센다)
//   같은 순간 두 주문이 같은 번호를 잡지 않도록 트랜잭션 잠금(pg_advisory_xact_lock) 안에서 최대값 + 1.
export const FB_PREFIX = 'FB';
export function formatFbQuoteNo(year, seq) { return `${FB_PREFIX}-${year}-${String(seq).padStart(4, '0')}`; }
export async function nextFbQuoteNo(c, year) {
  await c.query(`SELECT pg_advisory_xact_lock(hashtext('lead_portal_fb_quote_no'))`);
  const r = (await c.query(
    `SELECT COALESCE(MAX((regexp_match(quote_no, '^FB-[0-9]{4}-([0-9]+)$'))[1]::int), 0) AS n
       FROM quotes WHERE quote_no LIKE $1`, [`${FB_PREFIX}-${year}-%`])).rows[0];
  return formatFbQuoteNo(year, (Number(r.n) || 0) + 1);
}

// ── 마스킹 ─────────────────────────────────────────────────────────
export function maskName(n) {
  const s = String(n || '').trim();
  if (!s) return null;
  return s.split(/\s+/).slice(0, 2).map((w) => w[0] + '••••').join(' ');
}
export function maskPhone(p) {
  const d = String(p || '').replace(/\D/g, '');
  if (d.length < 6) return null;
  const local = d.length > 10 ? d.slice(-10) : d;
  return local.slice(0, 2) + ' •••• ••' + local.slice(-2);
}
// 문의의 전화(사람 > AI > 규칙, WhatsApp 은 번호 자체가 연락처)
const PHONE_EXPR = `COALESCE(t.m_phone, t.ai_phone, t.a_phone, CASE WHEN t.platform='whatsapp' AND t.user_id ~ '^[0-9]{10,13}$' THEN t.user_id END)`;
const STATE_EXPR = `COALESCE(t.m_state, t.ai_state, t.a_state)`;

// 문의 → 고객 화면용(연락처 · 원문 · 상태 · 메모 제외)
export function shapeLead(r) {
  const items = Array.isArray(r.items) ? r.items : [];
  const seen = new Set(); const parts = []; const open = [];
  for (const it of items) {
    if (!it || typeof it !== 'object') continue;
    if (it.status === 'ok' && it.code) {
      if (seen.has(it.code)) { const p = parts.find((x) => x.code === it.code); if (p && it.qty) p.qty = Math.max(p.qty || 0, Number(it.qty) || 0); continue; }
      seen.add(it.code);
      parts.push({ code: String(it.code), qty: Math.max(1, Math.min(MAX_QTY, Math.round(Number(it.qty) || 1))), veh: clip(it.veh, 60) });
    } else if (it.pieza) {
      const k = clip(it.pieza, 60);
      if (k && !open.includes(k)) open.push(k);
    }
  }
  const tipo = clip(r.tipo, 40);
  return {
    id: Number(r.id), platform: r.platform, first_mx: r.first_mx || null, last_mx: r.last_mx || null,
    state: r.state || null, city: r.city || null, tipo,
    vehicles: clip(r.vehicles, 160), parts_text: clip(r.parts, 200), summary: clip(r.summary, 400),
    parts, open_parts: open.slice(0, 6),
    name_masked: maskName(r.name) || (r.username ? '@' + String(r.username).slice(0, 1) + '••••' : null),
    phone_masked: maskPhone(r.phone), has_phone: !!maskPhone(r.phone),
    revealed: !!r.revealed,
  };
}

// 부품 정보 — 가용(현재고 − 살아 있는 다른 견적 예약) · 운송중 · 고객가 · 12개월 구매 · 매장 재고
export async function productInfo(customerId, discount, codes, exec = query) {
  const out = {};
  const list = [...new Set((codes || []).filter(Boolean).map(String))];
  if (!list.length) return out;
  const rows = (await exec(
    `SELECT p.id, p.code, p.name, p.list_price, p.is_active, p.stock_qty,
            COALESCE(inc.incoming_qty,0) AS incoming_qty, inc.incoming_eta::text AS incoming_eta,
            COALESCE((SELECT SUM(ql.reserved_qty) FROM quote_lines ql JOIN quotes q ON q.id = ql.quote_id
                       WHERE ql.product_id = p.id AND q.status IN ('draft','confirmed') AND q.deleted_at IS NULL
                         AND (q.reserve_expires_at > now() OR q.packing_printed_at IS NOT NULL)),0) AS reserved
       FROM products p LEFT JOIN v_incoming_stock inc ON inc.product_id = p.id
      WHERE p.code = ANY($1::text[]) AND p.deleted_at IS NULL`, [list])).rows;
  const ids = rows.map((r) => Number(r.id));
  const bought = {}; const shelf = {};
  if (ids.length) {
    for (const b of (await exec(
      `SELECT sil.product_id, SUM(sil.qty) AS qty, to_char(MAX(si.inv_date),'YYYY-MM-DD') AS last
         FROM sales_invoice_lines sil JOIN sales_invoices si ON si.id = sil.invoice_id
        WHERE si.customer_id = $1 AND si.status = 'posted' AND si.deleted_at IS NULL
          AND si.inv_date >= CURRENT_DATE - 365 AND sil.product_id = ANY($2::bigint[])
        GROUP BY sil.product_id`, [customerId, ids])).rows) bought[Number(b.product_id)] = { qty: Number(b.qty) || 0, last: b.last };
    for (const s of (await exec(
      `SELECT product_id, qty, src, to_char(updated_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD') AS at
         FROM customer_shelf_stock WHERE customer_id = $1 AND product_id = ANY($2::bigint[])`, [customerId, ids])).rows) {
      shelf[Number(s.product_id)] = { qty: Number(s.qty), src: s.src, at: s.at };
    }
  }
  for (const r of rows) {
    const pid = Number(r.id);
    const stock = r.stock_qty == null ? 0 : Number(r.stock_qty);
    const price = computeQuoteLine({ listPrice: r.list_price, discountRate: discount, qty: 1, ivaRate: 16 }).finalPrice;
    out[r.code] = {
      code: r.code, name: r.name || '', active: r.is_active !== false, list: Number(r.list_price) || 0,   // 1106d · 정가(할인 전)
      avail: Math.max(0, stock - (Number(r.reserved) || 0)),
      incoming: Number(r.incoming_qty) || 0, eta: r.incoming_eta ? String(r.incoming_eta).slice(0, 10) : null,
      price, bought12: bought[pid] ? bought[pid].qty : 0, bought_last: bought[pid] ? bought[pid].last : null,
      shelf: shelf[pid] ? shelf[pid].qty : null, shelf_src: shelf[pid] ? shelf[pid].src : null, shelf_at: shelf[pid] ? shelf[pid].at : null,
    };
  }
  // 1106d · 키트(K0001 …) — 가격 · 가용은 구성품으로(견적에서 구성품 줄로 풀리므로 같은 금액) + 구성품 목록
  const kitCodes = Object.keys(out).filter(isKitCode);
  if (kitCodes.length) {
    let kits = new Map();
    try { kits = await kitsFor({ codes: kitCodes }, exec); } catch (_) { kits = new Map(); }
    for (const kt of kits.values()) {
      const o = out[kt.kit_code] || out[Object.keys(out).find((c) => c.toUpperCase() === String(kt.kit_code).toUpperCase())];
      if (!o) continue;
      const parts = await productInfo(customerId, discount, kt.items.map((i) => i.ctr_code), exec);
      Object.assign(o, kitShape(kt, parts, discount));
    }
  }
  return out;
}
// 1106d · 키트 한 세트 — 구성품(분류 · 코드 · 이름 · 수량 · 정가 · 할인가) · 합계 · 만들 수 있는 세트
const CAT_ES = Object.fromEntries(DEV_CATS.map((c) => [c.key, c.es]));
export function kitShape(kt, parts, discount) {
  let list = 0, price = 0, avail = Infinity, incoming = Infinity, active = true;
  const items = kt.items.map((it) => {
    const p = parts[it.ctr_code] || {};
    const q = Math.max(1, Number(it.qty) || 1);
    const ul = Number(p.list) || 0, up = Number(p.price) || 0;
    list += ul * q; price += up * q;
    avail = Math.min(avail, Math.floor((Number(p.avail) || 0) / q));
    incoming = Math.min(incoming, Math.floor((Number(p.incoming) || 0) / q));
    if (p.active === false || !parts[it.ctr_code]) active = false;
    const name = p.name || it.name || '';
    return { code: it.ctr_code, name, qty: q, category: CAT_ES[classifyCategory(name, it.ctr_code)] || 'Otros', list: ul, price: up };
  });
  const r2 = (n) => Math.round(n * 100) / 100;
  return { kit: { kit_no: kt.promo_no, items }, list: r2(list), price: r2(price), discount: Number(discount) || 0,
    avail: Number.isFinite(avail) ? avail : 0, incoming: Number.isFinite(incoming) ? incoming : 0, active: active && items.length > 0 };
}

// 고객 매장 재고 저장(고객 · 직원 공통) — qty null = 지움. 이력 한 줄.
export async function saveShelf(c, { customerId, productId, qty, src, userId = null, codeId = null }) {
  const old = (await c.query(`SELECT qty FROM customer_shelf_stock WHERE customer_id=$1 AND product_id=$2 FOR UPDATE`, [customerId, productId])).rows[0];
  const oldQty = old ? Number(old.qty) : null;
  if (qty == null) {
    if (!old) return { changed: false, qty: null };
    await c.query(`DELETE FROM customer_shelf_stock WHERE customer_id=$1 AND product_id=$2`, [customerId, productId]);
  } else {
    await c.query(
      `INSERT INTO customer_shelf_stock (customer_id, product_id, qty, src, user_id, code_id, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,now())
       ON CONFLICT (customer_id, product_id) DO UPDATE SET qty=EXCLUDED.qty, src=EXCLUDED.src, user_id=EXCLUDED.user_id, code_id=EXCLUDED.code_id, updated_at=now()`,
      [customerId, productId, qty, src, userId, codeId]);
  }
  await c.query(
    `INSERT INTO customer_shelf_stock_log (customer_id, product_id, old_qty, new_qty, src, user_id, code_id) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [customerId, productId, oldQty, qty, src, userId, codeId]);
  return { changed: true, qty, old: oldQty };
}
export function parseQty(v) {
  if (v === null || v === undefined || v === '') return { ok: true, qty: null };
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0 || n > 999999 || Math.round(n) !== n) return { ok: false };
  return { ok: true, qty: n };
}

// 0297 · Meta 문의 목록(ERP)에 「공개된 곳」 — 고객 이름들
export async function revealedMap(threadIds) {
  const m = new Map();
  if (!threadIds || !threadIds.length || !(await portalReady())) return m;
  try {
    // 0298 · 그 refaccionaria 가 기록한 「찾는 부품」을 이름 옆에 — 「El Puente (CQ0271L×2, CB0412×1)」
    const w = await wantsReady();
    for (const r of (await query(
      `SELECT r.thread_id, string_agg(c.name ${w ? `|| COALESCE(' (' || (SELECT string_agg(p.code || '×' || x.qty, ', ' ORDER BY p.code)
                                                    FROM lead_portal_wants x JOIN products p ON p.id = x.product_id
                                                   WHERE x.customer_id = r.customer_id AND x.thread_id = r.thread_id) || ')', '')` : ''}, ' · ' ORDER BY r.first_at) AS names
         FROM lead_portal_reveals r JOIN customers c ON c.id = r.customer_id
        WHERE r.thread_id = ANY($1::bigint[]) GROUP BY r.thread_id`, [threadIds])).rows) m.set(Number(r.thread_id), r.names);
  } catch (_) { /* 표 없음 등 — 목록은 그대로 */ }
  return m;
}

// ── 0298 · 「이 손님이 찾는 부품」(연락처를 본 문의에 refaccionaria 가 기록) ─────────────
let wReady = false; let wProbe = 0;
export async function wantsReady() {
  if (wReady) return true;
  if (Date.now() - wProbe < 30000) return false;
  wProbe = Date.now();
  try { wReady = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_wants'`)).rows.length > 0; }
  catch (_) { wReady = false; }
  return wReady;
}
export function setWantsReady(v) { wReady = !!v; wProbe = Date.now(); }
export const IMG_BASE = () => (process.env.PRODUCT_IMG_BASE || 'https://pub-d34920cb200c42ce91c5cbda135f16d6.r2.dev/products').replace(/\/$/, '');
const imgOf = (code) => `${IMG_BASE()}/${encodeURIComponent(code)}/${encodeURIComponent(code)}_1.webp`;
let xrefOk = null;
async function xrefReady() {
  if (xrefOk !== null) return xrefOk;
  try { xrefOk = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='product_xref_codes'`)).rows.length > 0; } catch (_) { xrefOk = false; }
  return xrefOk;
}

// 제품 찾기 — ERP 견적 자동완성 · 제품찾기와 같은 규칙: CTR 코드 · 품명 · SYD 코드 · OE(정규화, 4자 이상) · 경쟁사 교차참조.
//   정확히 같은 번호가 먼저, 그다음 부분일치, 품명 일치는 맨 뒤. 최대 limit 건.
export async function searchProducts(q, { limit = 15 } = {}, exec = query) {
  const raw = String(q == null ? '' : q).trim().slice(0, 60);
  const n = normOe(raw);
  if (n.length < 2) return [];
  const like = '%' + n + '%';
  const nameLike = '%' + raw.replace(/[%_\\]/g, '') + '%';
  const parts = [
    `SELECT p.id, CASE WHEN regexp_replace(upper(p.code),'[^A-Z0-9]','','g') = $1 THEN 0 ELSE 1 END AS pri, 'ctr' AS via
       FROM products p WHERE p.deleted_at IS NULL AND regexp_replace(upper(p.code),'[^A-Z0-9]','','g') LIKE $2`,
    `SELECT s.product_id, CASE WHEN regexp_replace(upper(s.syd_code),'[^A-Z0-9]','','g') = $1 THEN 0 ELSE 1 END, 'syd'
       FROM product_syd_codes s WHERE regexp_replace(upper(s.syd_code),'[^A-Z0-9]','','g') LIKE $2`,
    `SELECT p.id, 2, 'name' FROM products p WHERE p.deleted_at IS NULL AND (p.name ILIKE $3 OR p.app ILIKE $3)`,
  ];
  if (n.length >= 4 && (await oeReady(exec))) {
    parts.push(`SELECT o.product_id, CASE WHEN o.oe_norm = $1 THEN 0 ELSE 1 END, 'oe' FROM product_oe_codes o WHERE o.oe_norm LIKE $2`);
  }
  if (await xrefReady()) {
    parts.push(`SELECT x.product_id, CASE WHEN x.norm_code = $1 THEN 0 ELSE 1 END, 'xref' FROM product_xref_codes x WHERE x.norm_code LIKE $2`);
  }
  const hits = (await exec(
    `SELECT h.id, MIN(h.pri) AS pri, (array_agg(h.via ORDER BY h.pri))[1] AS via
       FROM (${parts.join(' UNION ALL ')}) h JOIN products p ON p.id = h.id AND p.deleted_at IS NULL
      GROUP BY h.id, p.code ORDER BY MIN(h.pri), p.code LIMIT ${Math.max(1, Math.min(30, Number(limit) || 15))}`,
    [n, like, nameLike])).rows;
  if (!hits.length) return [];
  const ids = hits.map((h) => Number(h.id));
  const prods = (await exec(`SELECT id, code, name, app, is_active FROM products WHERE id = ANY($1::bigint[])`, [ids])).rows;
  const byId = new Map(prods.map((p) => [Number(p.id), p]));
  const syd = {};
  for (const r of (await exec(`SELECT product_id, syd_code FROM product_syd_codes WHERE product_id = ANY($1::bigint[])`, [ids])).rows) (syd[Number(r.product_id)] ||= []).push(r.syd_code);
  let oe = new Map(); try { if (await oeReady(exec)) oe = await oeByProduct(ids, exec); } catch (_) { oe = new Map(); }
  return hits.map((h) => {
    const p = byId.get(Number(h.id)); if (!p) return null;
    const oeList = oe.get(Number(h.id)) || [];
    const oeHit = h.via === 'oe' ? oeList.find((x) => x.oe_norm && x.oe_norm.includes(n)) : null;
    const sydHit = h.via === 'syd' ? (syd[Number(h.id)] || []).find((c) => normOe(c).includes(n)) : null;
    return {
      code: p.code, name: p.name || '', app: clip(p.app, 300), active: p.is_active !== false,
      syd: (syd[Number(h.id)] || []).slice(0, 4), oe: oeList.filter((x) => x.rel !== 'for').slice(0, 3).map((x) => x.oe_code),
      via: h.via, exact: Number(h.pri) === 0,
      hit: h.via === 'oe' && oeHit ? 'OE ' + oeHit.oe_code : (h.via === 'syd' && sydHit ? 'SYD ' + sydHit : (h.via === 'xref' ? 'Equivalencia' : null)),
      img: imgOf(p.code),
    };
  }).filter(Boolean);
}

// 2026-10-26f · ERP 「한 건 열기」 대화에 웹훅 메시지(포털 · 직원 · 손님)를 바로 합친다.
//   기존 대화(meta_threads.messages)는 Graph 동기화(30분)로만 갱신돼 포털에서 보낸 「hola」가 바로 안 보였다.
//   같은 메시지(방향 · 글자 같고 2분 안)는 하나로 — 포털에서 보낸 것은 「🔑 가게 이름」 표시를 붙인다.
// 1105 · 0316(직원 답장 · 보낸 사람) 칸이 있나
let suReady = false, suProbe = 0;
export async function staffUserReady() {
  if (suReady) return true;
  if (Date.now() - suProbe < 30000) return false;
  suProbe = Date.now();
  try { suReady = (await query(`SELECT 1 FROM information_schema.columns WHERE table_name='meta_page_messages' AND column_name='user_id'`)).rows.length > 0; } catch (_) { suReady = false; }
  return suReady;
}
export async function liveMessages(psid) {
  if (!psid || !(await chatReady())) return [];
  try {
    const su = await staffUserReady();
    return (await query(
      `SELECT m.direction, m.source, m.text, m.at, m.customer_id, c.name AS shop${su ? ', u.name AS staff' : ''} FROM meta_page_messages m LEFT JOIN customers c ON c.id = m.customer_id
         ${su ? 'LEFT JOIN users u ON u.id = m.user_id' : ''}
        WHERE m.psid = $1 ORDER BY m.at, m.id LIMIT 500`, [String(psid)])).rows;
  } catch (_) { return []; }
}
export function mergeConversation(graph, live) {
  const out = (Array.isArray(graph) ? graph : []).map((m) => ({ ...m }));
  const norm = (t) => String(t || '').replace(/\s+/g, ' ').trim();
  for (const l of live || []) {
    const me = l.direction === 'out'; const at = new Date(l.at).getTime(); const tx = norm(l.text);
    const hit = out.find((g) => !!g.me === me && norm(g.text) === tx && Math.abs(new Date(g.at).getTime() - at) <= 120000);
    const tag = l.source === 'portal' ? { src: 'portal', shop: l.shop || null, customer_id: l.customer_id == null ? null : Number(l.customer_id) } : (l.source === 'staff' ? { src: 'staff', ...(l.staff ? { by: String(l.staff) } : {}) } : {});
    if (hit) Object.assign(hit, tag);
    else out.push({ at: new Date(l.at).toISOString(), me, text: l.text || '', live: true, ...tag });
  }
  out.sort((a, b) => new Date(a.at) - new Date(b.at));
  return markMetaKinds(out);
}

// 1028c · Meta 가 스스로 남기는 「액션」을 대화와 구분 — 2026-10-28 디렉터: 대화처럼 보이면 안 된다.
//   kind='event' : Meta 시스템 기록(「Se detectó y se capturó la información de clientes potenciales」 등)
//   kind='auto'  : 광고의 자동 응답(손님 첫 메시지 전 · 직후 60초 안의 첫 페이지 메시지, 포털 메시지 제외)
const META_EVENT_RE = [
  /se\s+detect[oó]\s+y\s+se\s+captur[oó]/i,
  /informaci[oó]n\s+de\s+(los\s+)?clientes\s+potenciales/i,
  /\blead\s+(info|information|details|form)\b.{0,40}\b(detected|captured|submitted)\b/i,
  /\b(detected|captured)\b.{0,40}\blead\s+(info|information|details)\b/i,
  /\b(respondi[oó]|replied)\s+(a\s+|to\s+)?(un|an|your|tu|el|the)\s+(anuncio|ad)\b/i,   // 1104 · 「X respondió un anuncio.」(a 없음)
  /\b(inici[oó]|started)\s+(una\s+|a\s+|this\s+)?(conversaci[oó]n|conversation)\b.{0,40}\b(anuncio|ad)\b/i,
  /^(t[uú]|you)\s+(asignaste|assigned)\b/i,
  // 1119g · 디렉터: 「Luis Oscar Guzmán Palomino asignó esta conversación a …」가 대화처럼 보이던 것 — 받은편지함 작업 기록(담당 · 완료 · 라벨 · 스팸)
  /\b(asign[oó]|reasign[oó]|desasign[oó]|assigned|reassigned|unassigned)\s+(esta|la|this|the)\s+(conversaci[oó]n|conversation)\b/i,
  /\bse\s+(asign[oó]|reasign[oó])\s+(esta\s+conversaci[oó]n\s+)?a\b/i,
  /\b(quit[oó]|elimin[oó]|removed)\s+(la\s+)?(asignaci[oó]n|assignment)\b/i,
  /\b(marc[oó]|movi[oó]|marked|moved)\s+(esta|la|this|the)\s+(conversaci[oó]n|conversation)\s+(como|a|as|to)\b/i,
  /\b(agreg[oó]|a[nñ]adi[oó]|quit[oó]|elimin[oó]|added|removed)\s+(la\s+|el\s+|the\s+)?(etiqueta|label)\b/i,
  /\b(cambi[oó]|changed)\s+(la\s+|el\s+|the\s+)?(etapa|estado|stage|status)\s+(de[l]?\s+cliente\s+potencial|del\s+pedido|of\s+(the\s+)?(lead|order))\b/i,
  /^facebook\s+(cre[oó]\s+este\s+chat|created\s+this\s+chat)\b/i,   // 1105d · 댓글로 생긴 대화 안내
];
const AD_EVENT_RE = /\b(respondi[oó]|replied|anuncio|ad)\b/i;
export function isMetaEvent(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  if (/^facebook\s+(cre[oó]\s+este\s+chat|created\s+this\s+chat)\b/i.test(t)) return true;   // 1105d · 링크가 길어도 Meta 안내
  return !!t && t.length <= 220 && META_EVENT_RE.some((re) => re.test(t));
}
export function markMetaKinds(list) {
  const ms = Array.isArray(list) ? list : [];
  for (const m of ms) if (isMetaEvent(m.text)) m.kind = 'event';
  const firstIn = ms.find((m) => !m.me && m.kind !== 'event');
  const limit = firstIn ? new Date(firstIn.at).getTime() + 60000 : -Infinity;   // 손님 메시지가 없으면 자동 응답으로 보지 않는다
  const firstOut = ms.find((m) => m.me && m.kind !== 'event');
  if (firstOut && firstOut.src !== 'portal' && new Date(firstOut.at).getTime() <= limit) firstOut.kind = 'auto';
  // 1104 · 같은 손님이 다시 광고로 들어온 경우 — 「X respondió un anuncio」 직후 60초 안의 페이지 메시지 · 우리 정해진 안내문 = 자동 응답
  let adAt = -Infinity;
  for (const m of ms) {
    if (m.kind === 'event') { if (AD_EVENT_RE.test(String(m.text || ''))) adAt = new Date(m.at).getTime(); continue; }
    if (!m.me || m.kind || m.src === 'portal') continue;
    if (isBotText(m.text) || new Date(m.at).getTime() - adAt <= 60000) m.kind = 'auto';
  }
  return ms;
}

// 1105e · 포털에 안 내보내는 문의 — ① 사내 번호(직원 · 알림 수신 번호)의 WhatsApp ② ERP 에서 「플랫폼에서 숨기기」(0319)
//   ③ (1106d · 0322) ERP WhatsApp 마케팅을 받은 번호의 회신 — 기본 숨김, ERP 「플랫폼에 보이기」(portal_show)를 누른 것만
let hidCache = { at: 0, phones: [], col: false, show: false, wa: false };
export async function portalHideInfo(force = false) {
  if (!force && Date.now() - hidCache.at < 60000) return hidCache;
  let phones = [], col = false, show = false, wa = false;
  try { phones = [...(await internalWaPhones())].map((p) => String(p).replace(/\D/g, '').slice(-10)).filter((p) => p.length === 10); } catch (_) { phones = []; }
  try {
    const cs = (await query(`SELECT column_name FROM information_schema.columns WHERE table_name='meta_threads' AND column_name IN ('portal_hidden','portal_show')`)).rows.map((r) => r.column_name);
    col = cs.includes('portal_hidden'); show = cs.includes('portal_show');
    wa = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='wa_messages'`)).rows.length > 0;
  } catch (_) { col = false; show = false; wa = false; }
  hidCache = { at: Date.now(), phones, col, show, wa };
  return hidCache;
}
// 1106d · 「ERP WhatsApp 마케팅을 받은 번호」 — 그 번호로 캠페인(이미지 광고)이 나간 적이 있으면
//   1106e · 디렉터: 동의 요청(consent)에 대한 회신은 보이게 → 캠페인만 센다
export const MKT_SQL = `(t.platform = 'whatsapp' AND EXISTS (SELECT 1 FROM wa_messages wm WHERE wm.phone = t.user_id AND wm.direction = 'out' AND wm.source = 'campaign'))`;
export const mktExpr = (hi) => (hi && hi.wa ? MKT_SQL : 'false');
// 포털에서 빼는 조건(사내 번호 · 숨김 · 허락 안 한 마케팅 회신) — 「 AND …」
export function portalHideSql(hi, args) {
  let sql = '';
  if (hi.phones.length) { args.push(hi.phones); sql += ` AND NOT (t.platform = 'whatsapp' AND right(regexp_replace(COALESCE(t.user_id, ''), '\\D', '', 'g'), 10) = ANY($${args.length}::text[]))`; }
  if (hi.col) sql += ` AND NOT t.portal_hidden`;
  if (hi.wa) sql += hi.show ? ` AND NOT (${MKT_SQL} AND NOT t.portal_show)` : ` AND NOT ${MKT_SQL}`;
  return sql;
}
export const resetPortalHideCache = () => { hidCache.at = 0; };
export const isInternalPhone = (v, phones) => { const d = String(v || '').replace(/\D/g, '').slice(-10); return d.length === 10 && phones.includes(d); };

// 1105c · ERP 상세 — 포털에서 refaccionaria 가 넣은 문의 정보 · 결과 · 변경 기록
export async function portalInfoFor(threadId) {
  try {
    const items = (await query(
      `SELECT i.result, i.fields, c.name AS customer_name, to_char(i.updated_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at
         FROM lead_portal_info i JOIN customers c ON c.id = i.customer_id WHERE i.thread_id=$1 ORDER BY i.updated_at DESC`, [threadId])).rows;
    const log = (await query(
      `SELECT l.changes, c.name AS customer_name, to_char(l.at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at
         FROM lead_portal_info_log l LEFT JOIN customers c ON c.id = l.customer_id WHERE l.thread_id=$1 ORDER BY l.at DESC, l.id DESC LIMIT 30`, [threadId])).rows;
    return { items, log };
  } catch (_) { return null; }   // 0318 전
}

// 0300 · Meta 문의 목록(ERP)에 「💬 고객명 대화 중 · ~만료일」
export async function claimMap(threadIds) {
  const m = new Map();
  if (!threadIds || !threadIds.length || !(await chatReady())) return m;
  try {
    for (const r of (await query(
      `SELECT DISTINCT ON (c.thread_id) c.thread_id, cu.name, to_char(c.expires_at AT TIME ZONE 'America/Mexico_City','MM-DD') AS until,
              (SELECT count(*)::int FROM meta_page_messages pm JOIN meta_threads t ON t.id = c.thread_id
                WHERE pm.psid = t.user_id AND pm.source = 'portal' AND pm.customer_id = c.customer_id) AS sent
         FROM lead_portal_claims c JOIN customers cu ON cu.id = c.customer_id
        WHERE c.thread_id = ANY($1::bigint[]) AND c.released_at IS NULL AND c.expires_at > now()
        ORDER BY c.thread_id, c.claimed_at DESC`, [threadIds])).rows) m.set(Number(r.thread_id), `${r.name} 선점${Number(r.sent) ? ` · Messenger 보냄 ${r.sent}` : ''} · ~${r.until}`);
  } catch (_) { /* 표 없음 */ }
  return m;
}

// ── 0299 · 문의 메모 · 디렉터 전용 코드 ─────────────────────────────
let nReady = false; let nProbe = 0;
export async function notesReady() {
  if (nReady) return true;
  if (Date.now() - nProbe < 30000) return false;
  nProbe = Date.now();
  try { nReady = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_notes'`)).rows.length > 0; }
  catch (_) { nReady = false; }
  return nReady;
}
export function setNotesReady(v) { nReady = !!v; nProbe = Date.now(); }
export const DIRECTOR_NAME = 'Dirección Refatrix';
// 포털에 보내는 메모 — 고객 코드에는 작성자 이름을 보내지 않는다(자기 것뿐), 디렉터 코드에는 누가 썼는지
export function noteOut(n, k) {
  const mine = isDirCode(k) ? n.customer_id == null : n.customer_id != null && Number(n.customer_id) === Number(k.customer_id);
  const o = { id: Number(n.id), body: n.body, at: n.at, mine };
  if (isDirCode(k)) o.author = n.customer_id == null ? DIRECTOR_NAME : n.author;
  return o;
}
export const isDirCode = (k) => !!k && k.kind === 'director';
export function directorInviteText({ code, expiresOn, url }) {
  return [`🔐 Código de dirección — REFATRIX`, '', `🔗 ${url}`, `🔑 Código: ${code}`, `📅 Vigente hasta: ${fmtDmy(expiresOn)}`, '',
    'Ve todas las solicitudes y todas las notas de los clientes. Sin pedidos. No lo compartas.'].join('\n');
}

// ── 틀린 코드 잠금(IP) ─────────────────────────────────────────────
const fails = new Map();
export function clientIp(req) {
  return String(req.headers['x-nf-client-connection-ip'] || req.ip || '').split(',')[0].trim() || '?';
}
function locked(ip, now = Date.now()) {
  const f = fails.get(ip);
  if (!f) return false;
  if (f.until && f.until > now) return true;
  if (f.first + LOCK_MS < now) { fails.delete(ip); return false; }
  return false;
}
function failOnce(ip, now = Date.now()) {
  const f = fails.get(ip) && fails.get(ip).first + LOCK_MS > now ? fails.get(ip) : { n: 0, first: now, until: 0 };
  f.n += 1; if (f.n >= MAX_FAIL) f.until = now + LOCK_MS;
  fails.set(ip, f);
  if (fails.size > 5000) { for (const [k, v] of fails) if (v.first + LOCK_MS < now && (!v.until || v.until < now)) fails.delete(k); }
}
export function resetFails() { fails.clear(); }

// ── 직원 쪽: 이 고객을 볼 수 있나(디렉터 · 영업지원 = 전체, 영업 = 담당 · 팀) ──
async function customerVisible(perm, customerId) {
  const c = (await query(`SELECT id, owner_id, team_id FROM customers WHERE id=$1 AND deleted_at IS NULL`, [customerId])).rows[0];
  if (!c) return null;
  const vis = visibleTeamIds(perm);
  if (vis === null) return c;
  if (c.owner_id != null && Number(c.owner_id) === Number(perm.userId)) return c;
  if (c.team_id != null && vis.map(Number).includes(Number(c.team_id))) return c;
  return false;
}

export default async function leadPortalRoutes(app) {
  const need = async (reply) => {
    if (await portalReady()) return true;
    reply.code(503).send({ error: 'migration_required', note: '0297_lead_portal 마이그레이션이 필요합니다(npm run migrate).' });
    return false;
  };

  // ════════════════════════════════════════════════════════════════
  //  고객 포털 (Netlify /lp-api/* → /api/lead-portal/*) — 스페인어 오류코드
  // ════════════════════════════════════════════════════════════════
  // 1105 · 이 코드가 볼 수 있는 문의 — 주(scope_states) · 광고(scope_ads). 디렉터 코드는 전부. 「 AND …」 또는 ''
  function scopeSql(k, args) {
    let sql = '';
    // 1105e · 사내 번호 WhatsApp · 플랫폼에서 숨긴 문의 — 디렉터 코드도 안 보임(직원 대화 보호)
    sql += portalHideSql(k.__hide || { phones: [], col: false }, args);   // 1106d · 마케팅 회신 포함
    if (isDirCode(k)) return sql;
    if (Array.isArray(k.scope_states) && k.scope_states.length) { args.push(k.scope_states); sql += ` AND ${STATE_EXPR} = ANY($${args.length}::text[])`; }
    if (Array.isArray(k.scope_ads) && k.scope_ads.length) { args.push(k.scope_ads); sql += ` AND ${AD_EXPR} = ANY($${args.length}::text[])`; }
    return sql;
  }
  // 1105 · 접속 기록(0317) — 로그인 · 화면 열기 · 사용 중(5분마다)
  let acReady = false, acProbe = 0;
  async function accessReady() {
    if (acReady) return true;
    if (Date.now() - acProbe < 30000) return false;
    acProbe = Date.now();
    try { acReady = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_access'`)).rows.length > 0; } catch (_) { acReady = false; }
    return acReady;
  }
  async function recordAccess(k, kind, req) {
    if (!k || !(await accessReady())) return;
    const ua = String((req && req.headers && req.headers['user-agent']) || '').slice(0, 200) || null;
    await query(`INSERT INTO lead_portal_access (code_id, kind, ip, ua) VALUES ($1,$2,$3,$4)`, [k.id, kind, req ? clientIp(req) : null, ua]).catch(() => {});
  }
  // 1106 · 광고 카드(0320)
  let cdReady = false, cdProbe = 0;
  async function cardsReady() {
    if (cdReady) return true;
    if (Date.now() - cdProbe < 30000) return false;
    cdProbe = Date.now();
    try { cdReady = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_cards'`)).rows.length > 0; } catch (_) { cdReady = false; }
    return cdReady;
  }
  const CARD_KINDS = ['producto', 'anuncio', 'capacitacion'];
  // 1106c · 이미지 뱅크 이미지(bank:<id>)는 포털에서 /lp-api/card-image/<카드> 로 보여 준다(로그인 없이 · 켜진 카드만)
  const bankId = (u) => { const m = String(u || '').match(/^bank:(\d{1,12})$/); return m ? Number(m[1]) : null; };
  const cardOut = (r, forPortal = true) => ({ id: Number(r.id), kind: r.kind, title: r.title, body: r.body || '',
    image_url: forPortal && bankId(r.image_url) ? `/lp-api/card-image/${Number(r.id)}?v=${bankId(r.image_url)}` : (r.image_url || null),
    cta_text: r.cta_text || null, cta_url: r.cta_url || null, every_n: Number(r.every_n) || 6, kit_no: r.kit_no || null });
  async function activeCards(k = null) {
    if (!(await cardsReady())) return [];
    const cards = (await query(
      `SELECT * FROM lead_portal_cards WHERE deleted_at IS NULL AND active
          AND (starts_on IS NULL OR starts_on <= $1::date) AND (ends_on IS NULL OR ends_on >= $1::date)
        ORDER BY sort, id LIMIT 20`, [todayMx()])).rows.map(cardOut);
    // 1106d · 키트 카드 — 이 고객 할인율로 구성품 · 가격 · 가용(주문 코드 = 키트 제품 코드)
    const nos = cards.map((c) => c.kit_no).filter(Boolean);
    if (k && nos.length) {
      let comps = new Map();
      try { comps = await kitCompositions(nos); } catch (_) { comps = new Map(); }
      const codes = [...comps.values()].map((x) => x.kit_code).filter(Boolean);
      const info = codes.length ? await productInfo(Number(k.customer_id) || 0, isDirCode(k) ? 0 : (Number(k.discount) || 0), codes) : {};
      for (const c of cards) {
        const cp = c.kit_no && comps.get(c.kit_no);
        const p = cp && info[cp.kit_code];
        c.kit = p && p.kit ? { kit_no: c.kit_no, code: cp.kit_code, title: [cp.title, cp.years].filter(Boolean).join(' '), items: p.kit.items,
          list: p.list, price: p.price, discount: p.discount, avail: p.avail, incoming: p.incoming, active: p.active } : null;
        if (p) info[cp.kit_code] = p;
      }
    }
    return cards;
  }
  let ciReady = false, ciProbe = 0;
  async function infoConsentReady() {
    if (ciReady) return true;
    if (Date.now() - ciProbe < 30000) return false;
    ciProbe = Date.now();
    try { ciReady = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_consents'`)).rows.length > 0; } catch (_) { ciReady = false; }
    return ciReady;
  }
  // 이 코드가 지금 버전 확약서에 서명했나(디렉터 코드는 필요 없음)
  const signedCache = new Map();   // code_id → 서명 시각(같은 버전) — 매 요청 조회를 줄인다
  async function consentOf(k) {
    if (!k || isDirCode(k) || !(await infoConsentReady())) return { required: false };
    const ck = k.id + '|' + CONSENT_VERSION;
    if (signedCache.has(ck)) return { required: false, signed_at: signedCache.get(ck) };
    const r = (await query(`SELECT id, to_char(signed_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at FROM lead_portal_consents WHERE code_id=$1 AND version=$2 ORDER BY id DESC LIMIT 1`, [k.id, CONSENT_VERSION])).rows[0];
    if (r) { signedCache.set(ck, r.at); return { required: false, signed_at: r.at }; }
    return { required: true };
  }
  async function loadCode(id) {
    return (await query(
      `SELECT k.*, to_char(k.expires_on,'YYYY-MM-DD') AS expires_ymd, c.name AS customer_name, c.code AS customer_code,
              c.discount, c.owner_id, COALESCE(c.approval_status,'approved') AS approval_status
         FROM lead_portal_codes k LEFT JOIN customers c ON c.id = k.customer_id WHERE k.id=$1`, [id])).rows.map((r) => (
      isDirCode(r) ? { ...r, customer_name: DIRECTOR_NAME, customer_code: 'DIR', discount: 0, owner_id: null, approval_status: 'approved' } : r))[0];
  }
  function blocked(k) {
    const st = codeState({ ...k, expires_on: k.expires_ymd }, todayMx());
    if (st === 'deleted') return { code: 401, body: { error: 'session_ended' } };
    if (st === 'paused') return { code: 403, body: { error: 'paused', customer_name: k.customer_name } };
    if (st === 'expired') return { code: 403, body: { error: 'expired', customer_name: k.customer_name, expires_on: k.expires_ymd } };
    return null;
  }
  async function portalGuard(req, reply) {
    if (!(await portalReady())) return reply.code(503).send({ error: 'not_ready' });
    try { await req.jwtVerify(); } catch { return reply.code(401).send({ error: 'session_ended' }); }
    const u = req.user || {};
    if (u.typ !== LP_TYP) return reply.code(401).send({ error: 'session_ended' });
    const id = idOf(String(u.sub || '').replace(/^lp:/, ''));
    const k = id && await loadCode(id);
    if (!k || Number(k.token_version) !== Number(u.tv)) return reply.code(401).send({ error: 'session_ended' });
    const b = blocked(k);
    if (b) return reply.code(b.code).send(b.body);
    req.lp = k;
    k.__hide = await portalHideInfo();   // 1105e
    // 1105c · 확약서 서명 전에는 「내 정보 · 확약서」만
    const url = String((req.routeOptions && req.routeOptions.url) || req.url || '');
    if (!/\/api\/lead-portal\/(me|consent)$/.test(url) && (await consentOf(k)).required) return reply.code(403).send({ error: 'consent_required' });
    if (!k.last_seen_at || Date.now() - new Date(k.last_seen_at).getTime() > 5 * 60 * 1000) {
      query(`UPDATE lead_portal_codes SET last_seen_at=now() WHERE id=$1`, [k.id]).catch(() => {});
      recordAccess(k, 'active', req);   // 1105 · 사용 중(5분마다 1번)
    }
  }
  const P = { preHandler: portalGuard };
  const meOut = (k) => {
    const today = todayMx();
    return { customer_name: k.customer_name, expires_on: k.expires_ymd, days_left: daysBetween(today, k.expires_ymd),
      discount: Number(k.discount) || 0, scope_states: k.scope_states || null, role: isDirCode(k) ? 'director' : 'customer', build: LP_BUILD };
  };
  const sign = (k) => app.jwt.sign({ sub: 'lp:' + k.id, typ: LP_TYP, tv: Number(k.token_version) }, { expiresIn: TOKEN_TTL });

  // 1106c · 광고 카드 이미지(이미지 뱅크) — 로그인 전 화면에도 쓰이므로 토큰 없이, 켜진 카드의 이미지만
  app.get('/api/lead-portal/card-image/:id', async (req, reply) => {
    const id = idOf(req.params.id);
    if (!id || !(await cardsReady())) return reply.code(404).send({ error: 'not_found' });
    const c = (await query(`SELECT image_url FROM lead_portal_cards WHERE id=$1 AND deleted_at IS NULL AND active`, [id])).rows[0];
    const bid = c && bankId(c.image_url);
    if (!bid) return reply.code(404).send({ error: 'not_found' });
    const im = (await query(`SELECT bytes, mime FROM wa_images WHERE id=$1 AND deleted_at IS NULL`, [bid]).catch(() => ({ rows: [] }))).rows[0];
    if (!im) return reply.code(404).send({ error: 'not_found' });
    return reply.type(im.mime).header('cache-control', 'public, max-age=86400').send(im.bytes);
  });
  // 1106c · 로그인 첫 화면 숫자 — 포털에 나가는 문의 수(사내 번호 · 숨김 · 제외 문의 빼고). 5분 캐시
  let statsCache = { at: 0, v: null };
  app.get('/api/lead-portal/stats', async (req, reply) => {
    if (!(await portalReady())) return reply.code(503).send({ error: 'not_ready' });
    if (!statsCache.v || Date.now() - statsCache.at > 300000) {
      // 1106e · 디렉터: 첫 화면 숫자 = 광고로 들어온 **전체 리드** — 포털 숨김 · 마케팅 회신 · 제외(descartado)와 상관없이
      //   ERP 「Meta 광고 문의」 목록 전체와 같은 기준. 사내 번호(직원 · 알림 수신) WhatsApp 만 뺀다. 7일 = 그 기간에 처음 들어온 리드.
      const hi = await portalHideInfo(); const args = []; let extra = '';
      if (hi.phones.length) { args.push(hi.phones); extra = ` AND NOT (t.platform = 'whatsapp' AND right(regexp_replace(COALESCE(t.user_id, ''), '\\D', '', 'g'), 10) = ANY($1::text[]))`; }
      const r = (await query(
        `SELECT count(*)::int AS total,
                count(*) FILTER (WHERE t.first_at > now() - interval '7 days')::int AS week,
                count(*) FILTER (WHERE (t.first_at AT TIME ZONE 'America/Mexico_City')::date = (now() AT TIME ZONE 'America/Mexico_City')::date)::int AS today
           FROM meta_threads t WHERE true${extra}`, args)).rows[0];
      statsCache = { at: Date.now(), v: { total: r.total, week: r.week, today: r.today } };
    }
    reply.header('cache-control', 'public, max-age=120');
    return statsCache.v;
  });

  app.post('/api/lead-portal/login', async (req, reply) => {
    if (!(await portalReady())) return reply.code(503).send({ error: 'not_ready' });
    const ip = clientIp(req);
    if (locked(ip)) return reply.code(429).send({ error: 'too_many' });
    const norm = normCode(req.body && req.body.code);
    const k0 = norm && (await query(`SELECT id FROM lead_portal_codes WHERE code_hash=$1 AND deleted_at IS NULL`, [codeHash(norm)])).rows[0];
    if (!k0) {
      failOnce(ip);
      await logEvent({ userId: null, action: 'login_fail', target: 'lead_portal', detail: { ip } });
      return reply.code(401).send({ error: 'invalid_code' });
    }
    const k = await loadCode(k0.id);
    const b = blocked(k);
    if (b) return reply.code(b.code).send(b.body);
    await query(`UPDATE lead_portal_codes SET last_seen_at=now() WHERE id=$1`, [k.id]);
    await logEvent({ userId: null, action: 'login', target: `lead_portal:${k.id}`, detail: { ip, customer: k.customer_code } });
    await recordAccess(k, 'login', req);
    return { token: sign(k), me: meOut(k) };
  });

  // 열 때마다 토큰을 새로 준다(7일 미접속이면 코드 다시 입력)
  app.get('/api/lead-portal/me', P, async (req) => {
    await recordAccess(req.lp, 'open', req);
    const c = await consentOf(req.lp);
    return { token: sign(req.lp), me: { ...meOut(req.lp), consent_required: !!c.required, consent_signed_at: c.signed_at || null } };
  });
  // 1105c · 확약서 — 본문 · (같은 고객이 전에 쓴) 이름 · 휴대폰 미리 채우기
  app.get('/api/lead-portal/consent', P, async (req) => {
    const k = req.lp; let prev = null;
    if (!isDirCode(k) && (await infoConsentReady())) {
      prev = (await query(`SELECT first_name, last_name, phone FROM lead_portal_consents WHERE customer_id=$1 ORDER BY id DESC LIMIT 1`, [k.customer_id])).rows[0] || null;
    }
    return { version: CONSENT_VERSION, text: CONSENT_TEXT, customer_name: k.customer_name, prev, ...(await consentOf(k)) };
  });
  app.post('/api/lead-portal/consent', P, async (req, reply) => {
    const k = req.lp; const b = req.body || {};
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (!(await infoConsentReady())) return reply.code(503).send({ error: 'not_ready' });
    const fn = clip(b.first_name, 80), ln = clip(b.last_name, 80);
    const ph = String(b.phone || '').replace(/\D/g, '');
    const sig = String(b.signature || '');
    if (!fn || !ln) return reply.code(400).send({ error: 'name_required' });
    if (ph.length < 10 || ph.length > 13) return reply.code(400).send({ error: 'bad_phone' });
    if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(sig) || sig.length < 400 || sig.length > 300000) return reply.code(400).send({ error: 'signature_required' });
    if (b.accept !== true) return reply.code(400).send({ error: 'accept_required' });
    if (b.version && b.version !== CONSENT_VERSION) return reply.code(409).send({ error: 'consent_changed' });
    const ua = String(req.headers['user-agent'] || '').slice(0, 300) || null;
    const r = (await query(
      `INSERT INTO lead_portal_consents (code_id, customer_id, version, first_name, last_name, phone, signature, text, text_hash, ip, ua)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id, to_char(signed_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at`,
      [k.id, k.customer_id, CONSENT_VERSION, fn, ln, ph, sig, CONSENT_TEXT, consentHash(), clientIp(req), ua])).rows[0];
    await logEvent({ userId: null, action: 'create', target: `lead_portal_consent:${r.id}`, detail: { code_id: Number(k.id), customer_id: Number(k.customer_id), version: CONSENT_VERSION } });
    return { ok: true, signed_at: r.at };
  });

  app.get('/api/lead-portal/leads', P, async (req) => {
    const k = req.lp;
    const args = [k.customer_id]; const conds = [`t.status <> 'descartado'`, `COALESCE(t.in_count,0) > 0`];
    { const sc = scopeSql(k, args); if (sc) conds.push(sc.replace(/^ AND /, '')); }   // 1105 · 주 + 광고 범위
    const rows = (await query(
      `SELECT t.id, t.platform, COALESCE(t.m_name, t.name) AS name, t.username,
              to_char(t.first_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS first_mx,
              to_char(t.last_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS last_mx,
              COALESCE(t.m_tipo, t.ai_tipo, t.a_tipo) AS tipo, ${STATE_EXPR} AS state, COALESCE(t.m_city, t.ai_city, t.a_city) AS city,
              ${PHONE_EXPR} AS phone,
              COALESCE(t.m_vehicles, t.ai_vehicles, t.a_vehicles) AS vehicles, COALESCE(t.m_parts, t.ai_parts, t.a_parts) AS parts,
              t.ai_summary AS summary, COALESCE(t.m_items, t.ai_items) AS items, t.user_id AS psid, t.last_in_at,
              EXISTS (SELECT 1 FROM lead_portal_reveals r WHERE r.thread_id = t.id AND r.customer_id = $1) AS revealed
         FROM meta_threads t WHERE ${conds.join(' AND ')}
        ORDER BY t.last_at DESC NULLS LAST LIMIT ${MAX_LEADS}`, args)).rows;
    const leads = rows.map(shapeLead);
    // 0298 · 이 고객이 기록한 「찾는 부품」
    const wants = new Map();
    if (await wantsReady()) {
      for (const w of (await query(
        `SELECT w.thread_id, p.code, w.qty, w.input_code FROM lead_portal_wants w JOIN products p ON p.id = w.product_id AND p.deleted_at IS NULL
          WHERE w.customer_id = $1 ORDER BY w.created_at, w.id`, [k.customer_id])).rows) {
        const t = Number(w.thread_id); if (!wants.has(t)) wants.set(t, []);
        wants.get(t).push({ code: w.code, qty: Number(w.qty), input: w.input_code || null });
      }
    }
    for (const l of leads) l.wants = wants.get(l.id) || [];
    // 0299 · 메모 — 고객 코드는 자기(그 고객) 메모만, 디렉터 코드는 전부(누가 썼는지 포함)
    const notes = new Map();
    if (await notesReady()) {
      const dir = isDirCode(k);
      for (const n of (await query(
        `SELECT n.id, n.thread_id, n.body, n.customer_id, COALESCE(c.name, '${DIRECTOR_NAME}') AS author,
                to_char(n.created_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at
           FROM lead_portal_notes n LEFT JOIN customers c ON c.id = n.customer_id
          WHERE n.deleted_at IS NULL AND ${dir ? 'true' : 'n.customer_id = $1'} ORDER BY n.created_at, n.id`, dir ? [] : [k.customer_id])).rows) {
        const t = Number(n.thread_id); if (!notes.has(t)) notes.set(t, []);
        notes.get(t).push(noteOut(n, k));
      }
    }
    for (const l of leads) l.notes = notes.get(l.id) || [];
    // 1105c · 이 고객이 입력한 결과(문의 정보)
    if (!isDirCode(k) && (await infoConsentReady()) && leads.length) {
      const res = new Map((await query(`SELECT thread_id, result FROM lead_portal_info WHERE customer_id=$1 AND thread_id = ANY($2::bigint[])`, [k.customer_id, leads.map((l) => l.id)])).rows.map((r) => [Number(r.thread_id), r.result]));
      for (const l of leads) l.result = res.get(l.id) || null;
    }
    // 0305 · 선점(모든 채널) — 다른 refaccionaria 가 선점한 문의는 연락처(가린 것 포함)를 보내지 않는다
    const cl = await activeClaims(leads.map((l) => l.id));
    for (const l of leads) {
      const c = cl.get(l.id);
      l.claim = c ? { state: !isDirCode(k) && Number(c.customer_id) === Number(k.customer_id) ? 'mine' : 'other', until: new Date(c.expires_at).toISOString() } : null;
      if (l.claim && l.claim.state === 'other' && !isDirCode(k)) { l.name_masked = null; l.phone_masked = null; l.has_phone = false; l.revealed = false; }
    }
    // 0300 · Facebook(Messenger) 대화 — 24시간 창 · 선점(내 것 / 다른 refaccionaria)
    const chat = await chatInfo(rows.filter((r) => r.platform === 'messenger'), k);
    for (const l of leads) l.chat = l.platform === 'messenger' ? (chat.get(l.id) || null) : null;
    const basket = await basketRead(k);   // 1104c · 오늘의 주문 모음
    const products = await productInfo(Number(k.customer_id), Number(k.discount) || 0,
      leads.flatMap((l) => l.parts.map((p) => p.code).concat(l.wants.map((w) => w.code))).concat(basket.map((i) => i.code)));
    // 카탈로그에서 사라진 코드는 부품표에서 뺀다(주문할 수 없는 줄을 보여 주지 않게)
    for (const l of leads) l.parts = l.parts.filter((p) => products[p.code]);
    const states = [...new Set(leads.map((l) => l.state).filter(Boolean))].sort((a, b) => META_STATES.indexOf(a) - META_STATES.indexOf(b));
    return { me: { ...meOut(k), claim_days: await claimDays() }, leads, products, states, basket, cards: await activeCards(k) };
  });

  app.post('/api/lead-portal/leads/:id/contact', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    const args = [id]; let scope = '';
    scope = scopeSql(k, args);   // 1105 · 주 + 광고 범위
    const t = (await query(
      `SELECT t.id, t.platform, COALESCE(t.m_name, t.name) AS name, t.username, ${PHONE_EXPR} AS phone
         FROM meta_threads t WHERE t.id=$1 AND t.status <> 'descartado'${scope}`, args)).rows[0];
    if (!t) return reply.code(404).send({ error: 'not_found' });
    // 0305 · 다른 refaccionaria 가 선점한 문의 — 연락처를 열 수 없다(선점 기간 동안)
    if (!isDirCode(k)) {
      const oc = await otherClaim(k, id);
      if (oc) return reply.code(409).send({ error: 'claimed_other', until: new Date(oc.expires_at).toISOString() });
    }
    if (isDirCode(k)) {   // 디렉터 코드 — 공개 기록(고객 영업 실적)에 섞지 않는다. 감사 로그에만.
      await logEvent({ userId: null, action: 'page_view', target: `lead_portal_contact:${id}`, detail: { code_id: Number(k.id), director: true } });
      const d0 = String(t.phone || '').replace(/\D/g, '');
      const wa0 = d0.length >= 10 ? (d0.length === 10 ? '52' + d0 : d0.replace(/^521(\d{10})$/, '52$1')) : null;
      return { id: Number(t.id), platform: t.platform, name: t.name || null, username: t.username || null,
        phone: t.phone || null, wa_link: null, first_seen: null, first_time: false };   // 0300 · wa.me 버튼 제거(디렉터 결정)
    }
    const r = (await query(
      `INSERT INTO lead_portal_reveals (customer_id, code_id, thread_id) VALUES ($1,$2,$3)
       ON CONFLICT (customer_id, thread_id) DO UPDATE SET last_at=now(), n=lead_portal_reveals.n+1
       RETURNING to_char(first_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS first_mx, n`,
      [k.customer_id, k.id, id])).rows[0];
    const digits = String(t.phone || '').replace(/\D/g, '');
    const wa = digits.length >= 10 ? (digits.length === 10 ? '52' + digits : digits.replace(/^521(\d{10})$/, '52$1')) : null;
    return { id: Number(t.id), platform: t.platform, name: t.name || null, username: t.username || null,
      phone: t.phone || null, wa_link: null, first_seen: r.first_mx, first_time: Number(r.n) === 1 };   // 0300 · wa.me 버튼 제거
  });

  // 고객 매장 재고(Mi stock) — 고객이 고침
  app.put('/api/lead-portal/stock', P, async (req, reply) => {
    const k = req.lp; const b = req.body || {};
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    const q = parseQty(b.qty);
    if (!q.ok) return reply.code(400).send({ error: 'bad_qty' });
    const p = (await query(`SELECT id, code FROM products WHERE code=$1 AND deleted_at IS NULL`, [String(b.code || '').trim()])).rows[0];
    if (!p) return reply.code(404).send({ error: 'unknown_code' });
    await withTx((c) => saveShelf(c, { customerId: Number(k.customer_id), productId: Number(p.id), qty: q.qty, src: 'customer', codeId: Number(k.id) }));
    return { ok: true, code: p.code, shelf: q.qty, shelf_src: q.qty == null ? null : 'customer', shelf_at: todayMx() };
  });

  // 0298 · 제품 찾기(포털) — SYD · CTR · OE · 경쟁사 번호 · 품명. 결과마다 가용 · 운송중 · 고객가 · 12개월 구매 · 매장 재고.
  app.get('/api/lead-portal/search', P, async (req) => {
    const k = req.lp;
    const items = await searchProducts(req.query.q, { limit: 15 });
    const info = await productInfo(Number(k.customer_id), Number(k.discount) || 0, items.map((x) => x.code));
    return { q: String(req.query.q || ''), items: items.map((x) => ({ ...x, ...(info[x.code] || {}), code: x.code, name: x.name, active: x.active })) };
  });

  // 0298 · 「이 손님이 찾는 부품」 저장 — 그 문의의 목록을 통째로 바꾼다.
  //   2026-10-28 디렉터: 모든 문의에서 기록(연락처를 안 봐도) — 다른 refaccionaria 가 선점한 문의만 막는다.
  // ── 1105c · 문의 정보(고객관리) — 연락처를 본 뒤 · 다른 곳이 선점하지 않았을 때. ERP 같은 칸(m_*)에 들어간다 ──
  const INFO_COLS = `COALESCE(t.m_name, t.name) AS name, COALESCE(t.m_tipo, t.ai_tipo, t.a_tipo) AS tipo, ${STATE_EXPR} AS state,
                     COALESCE(t.m_city, t.ai_city, t.a_city) AS city, ${PHONE_EXPR} AS phone,
                     COALESCE(t.m_vehicles, t.ai_vehicles, t.a_vehicles) AS vehicles, COALESCE(t.m_parts, t.ai_parts, t.a_parts) AS parts`;
  async function infoGate(k, id, reply) {
    if (!(await infoConsentReady())) { reply.code(503).send({ error: 'not_ready' }); return false; }
    if (!(await threadVisible(k, id))) { reply.code(404).send({ error: 'not_found' }); return false; }
    if (isDirCode(k)) return true;
    const oc = await otherClaim(k, id);
    if (oc) { reply.code(409).send({ error: 'claimed_other', until: new Date(oc.expires_at).toISOString() }); return false; }
    if (!(await hasRevealed(k, id))) { reply.code(409).send({ error: 'need_contact' }); return false; }
    return true;
  }
  async function infoOut(k, id) {
    const t = (await query(`SELECT ${INFO_COLS} FROM meta_threads t WHERE t.id=$1`, [id])).rows[0] || {};
    const mine = isDirCode(k) ? null : (await query(`SELECT result, to_char(updated_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at FROM lead_portal_info WHERE thread_id=$1 AND customer_id=$2`, [id, k.customer_id])).rows[0];
    const o = {}; for (const f of Object.keys(INFO_FIELDS)) o[f] = t[f] == null ? '' : String(t[f]);
    return { fields: o, result: mine ? mine.result : null, updated_mx: mine ? mine.at : null, states: META_STATES, tipos: INFO_TIPOS, results: INFO_RESULTS };
  }
  app.get('/api/lead-portal/leads/:id/info', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (!(await infoGate(k, id, reply))) return;
    return infoOut(k, id);
  });
  app.put('/api/lead-portal/leads/:id/info', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id); const b = req.body || {};
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (!(await infoGate(k, id, reply))) return;
    const cur = (await query(`SELECT ${INFO_COLS}, t.status FROM meta_threads t WHERE t.id=$1`, [id])).rows[0];
    const sets = []; const args = [id]; const changes = {}; const vals = {};
    for (const [f, [col, max]] of Object.entries(INFO_FIELDS)) {
      if (b[f] === undefined) continue;
      let v = b[f] == null ? '' : String(b[f]).replace(/\s+/g, ' ').trim().slice(0, max);
      if (f === 'state' && v && !META_STATES.includes(v)) return reply.code(400).send({ error: 'bad_state' });
      if (f === 'phone' && v) { v = v.replace(/[^\d+ ]/g, '').trim(); if (v.replace(/\D/g, '').length < 10) return reply.code(400).send({ error: 'bad_phone' }); }
      vals[f] = v;
      if (!v || v === String(cur[f] || '')) continue;   // 빈 칸 = 그대로(포털에서 지우지는 않는다) · 같은 값 = 그대로
      args.push(v); sets.push(`${col} = $${args.length}`); changes[f] = [cur[f] || null, v];
    }
    let result = b.result === undefined ? undefined : (b.result || null);
    if (result && !INFO_RESULTS.includes(result)) return reply.code(400).send({ error: 'bad_result' });
    // 결과 → ERP 상태: 연락함(신규일 때만) · 판매. 「관심 없음 · 견적함」은 ERP 상태를 바꾸지 않고 기록만
    if (result === 'contactado' && cur.status === 'nuevo') sets.push(`status = 'contactado'`);
    if (result === 'vendido' && cur.status !== 'venta') sets.push(`status = 'venta'`);
    const prev = (await query(`SELECT result FROM lead_portal_info WHERE thread_id=$1 AND customer_id=$2`, [id, k.customer_id])).rows[0];
    if (result !== undefined && (prev ? prev.result : null) !== result) changes.result = [prev ? prev.result : null, result];
    if (!Object.keys(changes).length) return { ok: true, unchanged: true, ...(await infoOut(k, id)) };
    await withTx(async (c) => {
      if (sets.length) await c.query(`UPDATE meta_threads SET ${sets.join(', ')}, updated_at = now() WHERE id = $1`, args);
      await c.query(
        `INSERT INTO lead_portal_info (thread_id, customer_id, code_id, result, fields) VALUES ($1,$2,$3,$4,$5::jsonb)
         ON CONFLICT (thread_id, customer_id) DO UPDATE SET code_id=EXCLUDED.code_id, result=CASE WHEN $6::boolean THEN EXCLUDED.result ELSE lead_portal_info.result END, fields=EXCLUDED.fields, updated_at=now()`,
        [id, k.customer_id, k.id, result === undefined ? (prev ? prev.result : null) : result, JSON.stringify(vals), result !== undefined]);
      await c.query(`INSERT INTO lead_portal_info_log (thread_id, customer_id, code_id, changes) VALUES ($1,$2,$3,$4::jsonb)`, [id, k.customer_id, k.id, JSON.stringify(changes)]);
    });
    // 차종 · 부품을 고치면 CTR 부품번호 다시 찾기(ERP 와 같은 규칙)
    if (changes.vehicles || changes.parts) import('./metaLeadsMatch.js').then((m) => m.matchThreads({ ids: [id] })).catch(() => {});
    // 기록 = 연락 기록 → 선점(0305 규칙)
    const cl = await takeClaim(k, id, 'info');
    return { ok: true, ...(await infoOut(k, id)), claim: cl ? { state: cl.state, until: cl.until || null, created: !!cl.created } : null };
  });

  app.put('/api/lead-portal/leads/:id/wants', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (!(await wantsReady())) return reply.code(503).send({ error: 'not_ready' });
    const raw = Array.isArray(req.body && req.body.items) ? req.body.items : null;
    if (!raw) return reply.code(400).send({ error: 'bad_items' });
    if (raw.length > 30) return reply.code(400).send({ error: 'too_many_lines' });
    const want = new Map();
    for (const it of raw) {
      const code = String((it && it.code) || '').trim(); const qty = Number(it && it.qty);
      if (!code || !Number.isInteger(qty) || qty < 1 || qty > MAX_QTY) return reply.code(400).send({ error: 'bad_line', code });
      const prev = want.get(code);
      want.set(code, { qty: (prev ? prev.qty : 0) + qty, input: clip(it.input, 60) || (prev && prev.input) || null });
    }
    if (!(await threadVisible(k, id))) return reply.code(404).send({ error: 'not_found' });
    const oc = await otherClaim(k, id);
    if (oc) return reply.code(409).send({ error: 'claimed_other', until: new Date(oc.expires_at).toISOString() });
    const prods = want.size ? (await query(`SELECT id, code FROM products WHERE code = ANY($1::text[]) AND deleted_at IS NULL`, [[...want.keys()]])).rows : [];
    const byCode = new Map(prods.map((p) => [p.code, Number(p.id)]));
    const unknown = [...want.keys()].filter((c) => !byCode.has(c));
    if (unknown.length) return reply.code(400).send({ error: 'unknown_code', codes: unknown });
    await withTx(async (c) => {
      await c.query(`DELETE FROM lead_portal_wants WHERE customer_id=$1 AND thread_id=$2 AND NOT (product_id = ANY($3::bigint[]))`, [k.customer_id, id, [...byCode.values()]]);
      for (const [code, w] of want) {
        await c.query(
          `INSERT INTO lead_portal_wants (customer_id, thread_id, product_id, qty, input_code, code_id) VALUES ($1,$2,$3,$4,$5,$6)
           ON CONFLICT (customer_id, thread_id, product_id) DO UPDATE SET qty=EXCLUDED.qty, input_code=COALESCE(EXCLUDED.input_code, lead_portal_wants.input_code), code_id=EXCLUDED.code_id, updated_at=now()`,
          [k.customer_id, id, byCode.get(code), w.qty, w.input, k.id]);
      }
    });
    const items = (await query(
      `SELECT p.code, w.qty, w.input_code FROM lead_portal_wants w JOIN products p ON p.id = w.product_id
        WHERE w.customer_id=$1 AND w.thread_id=$2 ORDER BY w.created_at, w.id`, [k.customer_id, id])).rows;
    const products = await productInfo(Number(k.customer_id), Number(k.discount) || 0, items.map((x) => x.code));
    return { ok: true, wants: items.map((x) => ({ code: x.code, qty: Number(x.qty), input: x.input_code || null })), products };
  });

  // ════════ 0300 · Facebook(Messenger) 대화 ════════
  //   디렉터 결정(2026-10-26): Facebook 만(WhatsApp · Instagram 은 대화 없음) · 선점 기본 3일(디렉터가 조정) ·
  //   refaccionaria 에게는 선점한 뒤의 메시지만 · 선점 중에도 직원(Business Suite) 답장 허용 · 메시지 앞에 [가게 이름]
  async function lastInMap(threads) {
    const m = new Map(); const ps = [...new Set(threads.map((t) => t.psid).filter(Boolean))];
    for (const t of threads) m.set(Number(t.id), t.last_in_at ? new Date(t.last_in_at) : null);
    if (ps.length && (await chatReady())) {
      const r = (await query(`SELECT psid, max(at) AS at FROM meta_page_messages WHERE direction='in' AND psid = ANY($1::text[]) GROUP BY psid`, [ps])).rows;
      const byPs = new Map(r.map((x) => [x.psid, new Date(x.at)]));
      for (const t of threads) { const a = byPs.get(t.psid); const b = m.get(Number(t.id)); if (a && (!b || a > b)) m.set(Number(t.id), a); }
    }
    return m;
  }
  async function activeClaims(threadIds) {
    const m = new Map();
    if (!threadIds.length || !(await chatReady())) return m;
    for (const c of (await query(
      `SELECT DISTINCT ON (c.thread_id) c.id, c.thread_id, c.customer_id, c.claimed_at, c.expires_at
         FROM lead_portal_claims c WHERE c.thread_id = ANY($1::bigint[]) AND c.released_at IS NULL AND c.expires_at > now()
        ORDER BY c.thread_id, c.claimed_at DESC`, [threadIds])).rows) m.set(Number(c.thread_id), c);
    return m;
  }
  async function chatInfo(threads, k) {
    const out = new Map();
    if (!threads.length || !(await chatReady())) return out;
    const li = await lastInMap(threads);
    const cl = await activeClaims(threads.map((t) => Number(t.id)));
    const now = Date.now();
    for (const t of threads) {
      const id = Number(t.id); const last = li.get(id);
      // 1104d · 2026-11-04 디렉터: Facebook 대화는 막지 않는다 — 시간으로 미리 막지 않고 언제나 보내 본다.
      //   (광고로 시작한 대화는 Meta 가 2026-09-28 부터 최대 7일 보통 답장을 허용. 거절되면 Human Agent 태그로 한 번 더, 그래도 안 되면 안내)
      const c = cl.get(id);
      out.set(id, {
        window_until: null, open: true, last_in: last ? last.toISOString() : null,
        claim: c ? (!isDirCode(k) && Number(c.customer_id) === Number(k.customer_id) ? 'mine' : 'other') : null,
        claim_until: c ? new Date(c.expires_at).toISOString() : null,
      });
    }
    return out;
  }
  async function messengerThread(k, id) {
    const args = [id]; let scope = '';
    scope = scopeSql(k, args);   // 1105 · 주 + 광고 범위
    return (await query(
      `SELECT t.id, t.platform, t.user_id AS psid, t.last_in_at, t.status, t.ai_summary AS summary, t.messages,
              COALESCE(t.m_vehicles, t.ai_vehicles, t.a_vehicles) AS vehicles, COALESCE(t.m_parts, t.ai_parts, t.a_parts) AS parts
         FROM meta_threads t WHERE t.id=$1 AND t.status <> 'descartado'${scope}`, args)).rows[0] || null;
  }
  async function chatState(k, t) {
    const info = (await chatInfo([t], k)).get(Number(t.id)) || { open: false };
    const c = (await activeClaims([Number(t.id)])).get(Number(t.id)) || null;
    return { info, claim: c };
  }

  // ── 0305 · 선점 규칙(2026-10-28 디렉터 결정) ──
  //   선점 = 「Ver contacto」로 연락처를 본 뒤 연락한 내용을 기록(메모) — Messenger 는 포털에서 보낸 첫 메시지도 기록으로 친다.
  //   선점하면 기본 일수(디렉터 설정, 기본 3일) 동안 다른 refaccionaria 는 그 문의의 연락처를 열 수 없다.
  //   이미 내 선점이면 기록할 때마다 만료를 「지금 + 기본 일수」로 늘린다. 「Atender」 버튼(0300)은 없앴다.
  async function otherClaim(k, id) {
    if (isDirCode(k) || !(await chatReady())) return null;
    const c = (await activeClaims([id])).get(Number(id));
    return c && Number(c.customer_id) !== Number(k.customer_id) ? c : null;
  }
  async function hasRevealed(k, id) {
    return !!(await query(`SELECT 1 FROM lead_portal_reveals WHERE customer_id=$1 AND thread_id=$2`, [k.customer_id, id])).rows[0];
  }
  //   → { state: 'mine', until, created } | { state: 'other', until } | { state: 'need_contact' } | null(준비 안 됨 · 디렉터)
  async function takeClaim(k, id, via, noteId = null) {
    if (isDirCode(k) || !(await chatReady())) return null;
    if (!(await hasRevealed(k, id))) return { state: 'need_contact' };
    const days = await claimDays();
    const res = await withTx(async (c) => {
      await c.query(`SELECT pg_advisory_xact_lock(hashtext('lp_claim:' || $1::text))`, [id]);
      const cur = (await c.query(
        `SELECT id, customer_id, expires_at FROM lead_portal_claims WHERE thread_id=$1 AND released_at IS NULL AND expires_at > now() ORDER BY claimed_at DESC LIMIT 1`, [id])).rows[0];
      if (cur && Number(cur.customer_id) !== Number(k.customer_id)) return { state: 'other', until: cur.expires_at };
      if (cur) {
        const u = (await c.query(`UPDATE lead_portal_claims SET expires_at = GREATEST(expires_at, now() + ($2 || ' days')::interval) WHERE id=$1 RETURNING expires_at`, [cur.id, String(days)])).rows[0];
        return { state: 'mine', until: u.expires_at, created: false, id: cur.id };
      }
      const n = (await c.query(
        `INSERT INTO lead_portal_claims (thread_id, customer_id, code_id, expires_at, via, note_id) VALUES ($1,$2,$3, now() + ($4 || ' days')::interval, $5, $6)
         RETURNING id, expires_at`, [id, k.customer_id, k.id, String(days), via, noteId])).rows[0];
      await c.query(
        `UPDATE meta_threads SET status='derivado', derived_customer_id=$2, derived_to=$3, updated_at=now()
          WHERE id=$1 AND status IN ('nuevo','contactado')`, [id, k.customer_id, k.customer_name]);
      return { state: 'mine', until: n.expires_at, created: true, id: n.id };
    });
    if (res.created) await logEvent({ userId: null, action: 'update', target: `meta_thread:${id}`, detail: { op: 'lead_portal_claim', via, customer_id: Number(k.customer_id), code_id: Number(k.id), days } });
    return { ...res, until: new Date(res.until).toISOString() };
  }

  // 대화 한 줄(포털용) — 손님 · Refatrix(직원 · 예전 대화) · 나 · 다른 refaccionaria(이름 숨김) · 디렉터 코드는 가게 이름까지
  function convOut(m, k) {
    const who = !m.me ? 'cliente'
      : m.src === 'portal' ? (isDirCode(k) ? 'portal' : (Number(m.customer_id) === Number(k.customer_id) ? 'yo' : 'otro'))
      : 'refatrix';
    let text = m.text || '';
    // 다른 refaccionaria 가 보낸 메시지 — 앞의 「[가게 이름]」을 가린다(경쟁 가게 이름 노출 방지)
    if (who === 'otro') text = text.replace(/^\[[^\]]{1,120}\]\s*/, '[Otra refaccionaria] ');
    const d0 = m.at ? new Date(m.at) : null;
    const o = { dir: m.me ? 'out' : 'in', who, text, at: d0 && !isNaN(d0) ? d0.toISOString() : null };   // 1104 · 시각 없는 기록도 안전
    if (m.kind) o.kind = m.kind;   // 1028c · event(Meta 기록) · auto(자동 응답)
    if (isDirCode(k) && m.src === 'portal') o.shop = m.shop || null;
    return o;
  }
  // 대화 보기 — 2026-10-28 디렉터: 요약 아래에 **실제로 이루어진 대화 전체**(광고 문의부터 · Graph 동기화 + 웹훅 실시간).
  //   refaccionaria 는 연락처를 본(「Ver contacto」) 뒤에, 다른 곳이 선점하지 않았을 때만. 디렉터 코드는 언제나(읽기 전용).
  // 1028b · 호환 — 아직 예전 leads.html(「Atender por Messenger」 버튼)이 열려 있는 휴대폰용.
  //   새 규칙에서는 버튼만으로 선점하지 않는다: 대화창만 열어 주고(claim_until 없음), 첫 메시지를 보내면 그때 선점.
  app.post('/api/lead-portal/leads/:id/claim', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (!(await chatReady())) return reply.code(503).send({ error: 'not_ready' });
    const t = await messengerThread(k, id);
    if (!t) return reply.code(404).send({ error: 'not_found' });
    if (t.platform !== 'messenger') return reply.code(409).send({ error: 'chat_not_allowed' });
    const oc = await otherClaim(k, id);
    if (oc) return reply.code(409).send({ error: 'claimed_other', until: new Date(oc.expires_at).toISOString() });
    if (!(await hasRevealed(k, id))) return reply.code(409).send({ error: 'need_contact' });
    const mine = (await activeClaims([id])).get(Number(id));
    return { ok: true, compat: true, claim_until: mine ? new Date(mine.expires_at).toISOString() : null };
  });
  app.get('/api/lead-portal/leads/:id/chat', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (!(await chatReady())) return reply.code(503).send({ error: 'not_ready' });
    const t = await messengerThread(k, id);
    if (!t) return reply.code(404).send({ error: 'not_found' });
    if (t.platform === 'whatsapp') {
      // 1104 · 2026-11-04 디렉터(방법 1): WhatsApp 대화는 **보기만** — 연락처를 본 뒤, 다른 곳이 선점하지 않았을 때.
      //   보내기는 없음(refaccionaria 가 자기 전화로 연락 → 메모로 선점). ERP 번호 대화 · 앱 번호 파일 모두 meta_threads.messages.
      const claim = (await activeClaims([Number(t.id)])).get(Number(t.id)) || null;
      if (!isDirCode(k)) {
        if (claim && Number(claim.customer_id) !== Number(k.customer_id)) return reply.code(409).send({ error: 'claimed_other', until: new Date(claim.expires_at).toISOString() });
        if (!(await hasRevealed(k, id))) return reply.code(409).send({ error: 'need_contact' });
      }
      const conv = markMetaKinds((Array.isArray(t.messages) ? t.messages : []).map((m) => ({ ...m }))).slice(-300);
      const mine = claim && !isDirCode(k) && Number(claim.customer_id) === Number(k.customer_id);
      return { channel: 'whatsapp', readonly: true, messages: conv.map((m) => convOut(m, k)), window_until: null, open: false,
        claim_until: mine ? new Date(claim.expires_at).toISOString() : null, claimed: !!mine,
        summary: clip(t.summary, 300) || clip([t.vehicles, t.parts].filter(Boolean).join(' · '), 300), can_send: false };
    }
    if (t.platform !== 'messenger') return reply.code(409).send({ error: 'chat_not_allowed' });
    const { info, claim } = await chatState(k, t);
    if (!isDirCode(k)) {
      if (claim && Number(claim.customer_id) !== Number(k.customer_id)) return reply.code(409).send({ error: 'claimed_other', until: new Date(claim.expires_at).toISOString() });
      if (!(await hasRevealed(k, id))) return reply.code(409).send({ error: 'need_contact' });
    }
    const conv = mergeConversation(t.messages, await liveMessages(t.psid)).slice(-300);
    const mine = claim && !isDirCode(k) && Number(claim.customer_id) === Number(k.customer_id);
    return { messages: conv.map((m) => convOut(m, k)), window_until: info.window_until || null, open: !!info.open,
      claim_until: mine ? new Date(claim.expires_at).toISOString() : null, claimed: !!mine,
      summary: clip(t.summary, 300) || clip([t.vehicles, t.parts].filter(Boolean).join(' · '), 300),
      can_send: !isDirCode(k) };
  });

  // 보내기 — 자기 선점 · 24시간 창 안 · 앞에 [가게 이름]
  app.post('/api/lead-portal/leads/:id/chat', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (!(await chatReady())) return reply.code(503).send({ error: 'not_ready' });
    const text = String((req.body && req.body.text) || '').replace(/\r/g, '').trim();
    if (!text) return reply.code(400).send({ error: 'empty' });
    if (text.length > 1000) return reply.code(400).send({ error: 'too_long' });
    const t = await messengerThread(k, id);
    if (!t) return reply.code(404).send({ error: 'not_found' });
    if (t.platform !== 'messenger' || !t.psid) return reply.code(409).send({ error: 'chat_not_allowed' });
    const { info } = await chatState(k, t);
    // 0305 · 포털에서 보낸 메시지 = 연락 기록 → 선점(이미 내 것이면 연장). 연락처를 먼저 봐야 한다.
    const cl = await takeClaim(k, id, 'messenger');
    if (!cl || cl.state === 'need_contact') return reply.code(409).send({ error: 'need_contact' });
    if (cl.state === 'other') return reply.code(409).send({ error: 'claimed_other', until: cl.until });
    const full = `[${k.customer_name}] ${text}`;
    // 1104d · 보통 답장(RESPONSE) 먼저 → Meta 가 「창 밖」이라 거절하면 Human Agent 태그로 한 번 더
    const s0 = await sendMessengerSmart(t.psid, full, req.log, { comment: commentRefOf(t.messages) });
    if (!s0.ok) {
      if (cl.created) await query(`DELETE FROM lead_portal_claims WHERE id=$1`, [cl.id]);   // 못 보냈으면 방금 만든 선점은 되돌린다
      const closed = !!s0.window;
      req.log?.warn({ err: s0.error }, 'lead portal messenger send failed');
      return reply.code(closed ? 409 : 502).send({ error: s0.comment_used ? 'comment_used' : (closed ? 'meta_window' : 'send_failed'), detail: s0.error });
    }
    const m = (await query(
      `INSERT INTO meta_page_messages (psid, mid, direction, source, text, at, customer_id, code_id) VALUES ($1,$2,'out','portal',$3,now(),$4,$5)
       ON CONFLICT (mid) DO UPDATE SET source='portal', customer_id=EXCLUDED.customer_id, code_id=EXCLUDED.code_id, text=EXCLUDED.text
       RETURNING id, direction, source, text, at, customer_id`, [t.psid, s0.mid, full, k.customer_id, k.id])).rows[0];
    return { ok: true, via: s0.via || 'message', message: convOut({ me: true, src: 'portal', customer_id: m.customer_id, text: m.text, at: m.at }, k), claim: { state: 'mine', until: cl.until, created: !!cl.created } };
  });

  // 0299 · 문의 메모 — 쓰기 · 지우기(자기 것만). 지운 메모는 디렉터 화면에 「삭제됨」으로 남는다.
  async function threadVisible(k, id) {
    const args = [id]; let scope = '';
    scope = scopeSql(k, args);   // 1105 · 주 + 광고 범위
    return !!(await query(`SELECT 1 FROM meta_threads t WHERE t.id=$1 AND t.status <> 'descartado'${scope}`, args)).rows[0];
  }
  app.post('/api/lead-portal/leads/:id/notes', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (!(await notesReady())) return reply.code(503).send({ error: 'not_ready' });
    const body = String((req.body && req.body.body) || '').replace(/\r/g, '').trim();
    if (!body) return reply.code(400).send({ error: 'empty' });
    if (body.length > 1000) return reply.code(400).send({ error: 'too_long' });
    if (!(await threadVisible(k, id))) return reply.code(404).send({ error: 'not_found' });
    const n = (await query(
      `INSERT INTO lead_portal_notes (thread_id, customer_id, code_id, body) VALUES ($1,$2,$3,$4)
       RETURNING id, thread_id, body, customer_id, to_char(created_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at`,
      [id, isDirCode(k) ? null : k.customer_id, k.id, body])).rows[0];
    // 0305 · 연락처를 본 뒤 남긴 메모 = 연락 기록 → 선점(다른 곳이 먼저 선점했으면 메모만 저장)
    const cl = await takeClaim(k, id, 'note', Number(n.id));
    return { ok: true, note: noteOut({ ...n, author: k.customer_name }, k), claim: cl ? { state: cl.state, until: cl.until || null, created: !!cl.created } : null };
  });
  app.delete('/api/lead-portal/notes/:nid', P, async (req, reply) => {
    const k = req.lp; const nid = idOf(req.params.nid);
    if (!nid) return reply.code(400).send({ error: 'bad_id' });
    if (!(await notesReady())) return reply.code(503).send({ error: 'not_ready' });
    // 고객 = 그 고객이 쓴 것만 · 디렉터 코드 = 디렉터 코드로 쓴 것만(고객 메모는 못 지움)
    const r = (await query(
      `UPDATE lead_portal_notes SET deleted_at=now() WHERE id=$1 AND deleted_at IS NULL AND ${isDirCode(k) ? 'customer_id IS NULL' : 'customer_id = $2'} RETURNING id`,
      isDirCode(k) ? [nid] : [nid, k.customer_id])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    return { ok: true };
  });

  // 주문 → ERP 견적(초안)
  app.post('/api/lead-portal/order', P, async (req, reply) => {
    const k = req.lp; const b = req.body || {};
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (k.approval_status === 'pending') return reply.code(409).send({ error: 'customer_pending' });
    const key = String(b.key || '').trim();
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(key)) return reply.code(400).send({ error: 'bad_key' });
    return placeOrder(req, reply, k, Array.isArray(b.items) ? b.items : [], b.note, key);
  });
  // 1104c · 주문 만들기(바로 주문 · 「주문 모음」 확정이 같이 쓴다)
  async function placeOrder(req, reply, k, raw, noteIn, key) {
    const b = { note: noteIn };
    // 같은 키 = 이미 받은 주문(버튼 두 번 · 재전송)
    const dupOf = async () => (await query(
      `SELECT q.quote_no, q.total_mxn FROM quotes q WHERE q.lead_portal_key=$1 AND q.lead_portal_code_id IN (SELECT id FROM lead_portal_codes WHERE customer_id=$2)`,
      [key, k.customer_id])).rows[0];
    const d0 = await dupOf();
    if (d0) return { ok: true, duplicate: true, quote_no: d0.quote_no, total: Number(d0.total_mxn) || 0, asesor: await asesorName(k) };
    if (!raw.length) return reply.code(400).send({ error: 'empty' });
    if (raw.length > MAX_ORDER_LINES) return reply.code(400).send({ error: 'too_many_lines' });
    const merged = new Map(); const threads = new Set();
    for (const it of raw) {
      const code = String((it && it.code) || '').trim();
      const qty = Number(it && it.qty);
      if (!code || !Number.isInteger(qty) || qty < 1 || qty > MAX_QTY) return reply.code(400).send({ error: 'bad_line', code });
      merged.set(code, (merged.get(code) || 0) + qty);
      const th = idOf(it && it.thread_id); if (th) threads.add(th);
      if (it && Array.isArray(it.thread_ids)) for (const x of it.thread_ids.slice(0, 50)) { const v = idOf(x); if (v) threads.add(v); }
    }
    const prods = (await query(`SELECT id, code, is_active FROM products WHERE code = ANY($1::text[]) AND deleted_at IS NULL`, [[...merged.keys()]])).rows;
    const byCode = new Map(prods.map((p) => [p.code, p]));
    const unknown = [...merged.keys()].filter((c) => !byCode.has(c));
    if (unknown.length) return reply.code(400).send({ error: 'unknown_code', codes: unknown });
    const inactive = prods.filter((p) => p.is_active === false).map((p) => p.code);
    if (inactive.length) return reply.code(409).send({ error: 'discontinued', codes: inactive });
    // 문의 번호는 이 코드가 볼 수 있는 것만 남긴다
    let threadIds = [...threads];
    if (threadIds.length) {
      const args = [threadIds]; let scope = '';
      scope = scopeSql(k, args);   // 1105 · 주 + 광고 범위
      threadIds = (await query(`SELECT t.id FROM meta_threads t WHERE t.id = ANY($1::bigint[]) AND t.status <> 'descartado'${scope}`, args)).rows.map((r) => Number(r.id));
    }
    const discount = Number(k.discount) || 0;
    const note = clip(b.note, 300);
    const memo = ['🔑 Portal oportunidades', 'código …' + k.code_last4,
      threadIds.length ? 'Meta #' + threadIds.join(', #') : null, note ? '· ' + note : null].filter(Boolean).join(' · ');
    let seller = null;
    try {
      const r = await resolveSeller(query, { customerId: Number(k.customer_id), requestedSeller: null, perm: null });
      if (r && r.ok) seller = r.seller_id || null;
    } catch (_) { seller = null; }
    const assignee = seller || (k.owner_id ? Number(k.owner_id) : null);
    let res;
    try {
      res = await withTx(async (c) => {
        const year = todayMx().slice(0, 4);
        const quoteNo = await nextFbQuoteNo(c, year);   // FB-YYYY-####
        const lines = await buildLines(discount, 16, [...merged.entries()].map(([code, qty]) => ({ product_id: Number(byCode.get(code).id), code, qty })));
        const totals = computeQuoteTotals(lines.filter((l) => l.product_id)
          .map((l) => ({ lineSubtotal: l.line_subtotal, lineIva: l.line_iva, lineTotal: l.line_total, qty: l.qty })));
        const q = (await c.query(
          `INSERT INTO quotes (quote_no, customer_id, quote_date, discount_rate, iva_rate, memo, status,
                               subtotal_mxn, iva_mxn, total_mxn, total_qty, sku_count, origin, reserve_expires_at,
                               assigned_to, assigned_at, lead_portal_code_id, lead_portal_key, lead_thread_ids)
           VALUES ($1,$2,CURRENT_DATE,$3,16,$4,'draft',$5,$6,$7,$8,$9,'lead_portal',$10::timestamptz,$11,CASE WHEN $11::bigint IS NULL THEN NULL ELSE now() END,$12,$13,$14::bigint[])
           RETURNING id, quote_no, total_mxn`,
          [quoteNo, k.customer_id, discount, memo, totals.subtotal, totals.iva, totals.total, totals.totalQty, totals.skuCount,
            reserveExpiresAt(new Date()), assignee, k.id, key, threadIds])).rows[0];
        for (const l of lines) {
          await c.query(
            `INSERT INTO quote_lines (quote_id, line_no, product_id, input_code, ctr_code, syd_codes,
                                      product_name, app_text, qty, list_price, discount_rate, final_price,
                                      line_subtotal, line_iva, line_total, avail_stock, stock_flag, issue)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)`,
            [q.id, l.line_no, l.product_id, l.input_code, l.ctr_code, l.syd_codes, l.product_name,
              l.app_text, l.qty, l.list_price, l.discount_rate, l.final_price, l.line_subtotal,
              l.line_iva, l.line_total, l.avail_stock, l.stock_flag, l.issue || null]);
        }
        await stampLineMeta(c, q.id, lines);
        if (seller && (await exclusivityReady())) await c.query(`UPDATE quotes SET seller_id=$1 WHERE id=$2`, [seller, q.id]);
        await assignReservations(c, q.id);
        await syncQuoteShortages(c, q.id, { userId: null });
        await recordQuoteDevDemand(c, q.id, { userId: null });
        // 문의 상태: 신규 · 연락함 → refaccionaria 연결(이 고객). 판매 · 제외 · 이미 연결은 건드리지 않는다.
        if (threadIds.length) {
          await c.query(
            `UPDATE meta_threads SET status='derivado', derived_customer_id=$2, derived_to=$3, updated_at=now()
              WHERE id = ANY($1::bigint[]) AND status IN ('nuevo','contactado')`, [threadIds, k.customer_id, k.customer_name]);
        }
        return q;
      });
    } catch (e) {
      if (e && e.code === '23505') {
        const d1 = await dupOf();
        if (d1) return { ok: true, duplicate: true, quote_no: d1.quote_no, total: Number(d1.total_mxn) || 0, asesor: await asesorName(k) };
      }
      req.log?.error({ err: e }, 'lead portal order failed');
      return reply.code(500).send({ error: 'internal' });
    }
    await logEvent({ userId: null, action: 'create', target: `quote:${res.id}`, detail: { origin: 'lead_portal', code_id: Number(k.id), customer: k.customer_code, threads: threadIds } });
    kickQuoteNotify(res.id, app);
    return { ok: true, quote_no: res.quote_no, total: Number(res.total_mxn) || 0, asesor: await asesorName(k, assignee) };
  }

  // ── 1104c · 「Pedido del día」 — 하루 동안 모은 주문(서버 저장) → 확인 → 「주문 확정」 1번에 Refatrix 로 ──
  let bReady = false, bProbe = 0;
  async function basketReady() {
    if (bReady) return true;
    if (Date.now() - bProbe < 30000) return false;
    bProbe = Date.now();
    try { bReady = (await query(`SELECT 1 FROM information_schema.tables WHERE table_name='lead_portal_basket'`)).rows.length > 0; } catch (_) { bReady = false; }
    return bReady;
  }
  async function basketRead(k) {
    if (isDirCode(k) || !(await basketReady())) return [];
    return (await query(
      `SELECT b.code, b.qty, b.thread_ids, to_char(b.created_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS added_mx,
              to_char(b.updated_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS updated_mx
         FROM lead_portal_basket b WHERE b.customer_id=$1 ORDER BY b.created_at, b.id`, [k.customer_id])).rows
      .map((r) => ({ code: r.code, qty: Number(r.qty), thread_ids: (r.thread_ids || []).map(Number), added_mx: r.added_mx, updated_mx: r.updated_mx }));
  }
  // 1106 · 광고 카드 버튼(click) · 「Quiero participar」(interest)
  app.post('/api/lead-portal/cards/:id/click', P, async (req, reply) => {
    const k = req.lp; const id = idOf(req.params.id);
    if (!id) return reply.code(400).send({ error: 'bad_id' });
    if (!(await cardsReady())) return reply.code(503).send({ error: 'not_ready' });
    const kind = req.body && req.body.kind === 'interest' ? 'interest' : 'click';
    const c = (await query(`SELECT id FROM lead_portal_cards WHERE id=$1 AND deleted_at IS NULL AND active`, [id])).rows[0];
    if (!c) return reply.code(404).send({ error: 'not_found' });
    if (kind === 'interest' && !isDirCode(k)) {
      const dup = (await query(`SELECT 1 FROM lead_portal_card_clicks WHERE card_id=$1 AND customer_id=$2 AND kind='interest'`, [id, k.customer_id])).rows[0];
      if (dup) return { ok: true, already: true };
    }
    await query(`INSERT INTO lead_portal_card_clicks (card_id, code_id, customer_id, kind) VALUES ($1,$2,$3,$4)`, [id, k.id, isDirCode(k) ? null : k.customer_id, kind]);
    return { ok: true };
  });

  app.get('/api/lead-portal/basket', P, async (req) => {
    const k = req.lp; const items = await basketRead(k);
    return { items, products: await productInfo(Number(k.customer_id), Number(k.discount) || 0, items.map((i) => i.code)) };
  });
  // 한 줄 저장(수량 · 고른 문의). qty 0 = 줄 삭제
  app.put('/api/lead-portal/basket', P, async (req, reply) => {
    const k = req.lp; const b = req.body || {};
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (!(await basketReady())) return reply.code(503).send({ error: 'not_ready' });
    const code = String(b.code || '').trim();
    const qty = Number(b.qty);
    if (!code || !Number.isInteger(qty) || qty < 0 || qty > MAX_QTY) return reply.code(400).send({ error: 'bad_line' });
    if (!qty) {
      await query(`DELETE FROM lead_portal_basket WHERE customer_id=$1 AND code=$2`, [k.customer_id, code]);
    } else {
      const p = (await query(`SELECT code, is_active FROM products WHERE code=$1 AND deleted_at IS NULL`, [code])).rows[0];
      if (!p) return reply.code(400).send({ error: 'unknown_code', codes: [code] });
      if (p.is_active === false) return reply.code(409).send({ error: 'discontinued', codes: [code] });
      const n = (await query(`SELECT count(*)::int AS n FROM lead_portal_basket WHERE customer_id=$1 AND code<>$2`, [k.customer_id, code])).rows[0].n;
      if (n >= MAX_ORDER_LINES) return reply.code(400).send({ error: 'too_many_lines' });
      let th = [...new Set((Array.isArray(b.thread_ids) ? b.thread_ids : []).slice(0, 50).map(idOf).filter(Boolean))];
      if (th.length) th = (await query(`SELECT id FROM meta_threads WHERE id = ANY($1::bigint[]) AND status <> 'descartado'`, [th])).rows.map((r) => Number(r.id));
      await query(
        `INSERT INTO lead_portal_basket (customer_id, code, qty, thread_ids, code_id) VALUES ($1,$2,$3,$4::bigint[],$5)
         ON CONFLICT (customer_id, code) DO UPDATE SET qty=EXCLUDED.qty, thread_ids=EXCLUDED.thread_ids, code_id=EXCLUDED.code_id, updated_at=now()`,
        [k.customer_id, code, qty, th, k.id]);
    }
    const items = await basketRead(k);
    return { ok: true, items, products: await productInfo(Number(k.customer_id), Number(k.discount) || 0, items.map((i) => i.code)) };
  });
  // 「Confirmar y enviar a Refatrix」 — 모은 줄 전부 → FB 견적 초안 1건 → 모음 비우기
  app.post('/api/lead-portal/basket/confirm', P, async (req, reply) => {
    const k = req.lp; const b = req.body || {};
    if (isDirCode(k)) return reply.code(403).send({ error: 'director_view' });
    if (k.approval_status === 'pending') return reply.code(409).send({ error: 'customer_pending' });
    if (!(await basketReady())) return reply.code(503).send({ error: 'not_ready' });
    const key = String(b.key || '').trim();
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(key)) return reply.code(400).send({ error: 'bad_key' });
    const t0 = (await query(`SELECT clock_timestamp() AS t`)).rows[0].t;
    const items = await basketRead(k);
    const r = await placeOrder(req, reply, k, items.map((i) => ({ code: i.code, qty: i.qty, thread_ids: i.thread_ids })), b.note, key);
    if (r && r.ok) {
      // 보낸 줄만 지운다(확정하는 사이 다른 기기에서 고친 줄은 남김)
      await query(`DELETE FROM lead_portal_basket WHERE customer_id=$1 AND code = ANY($2::text[]) AND updated_at <= $3`, [k.customer_id, items.map((i) => i.code), t0]);
      await logEvent({ userId: null, action: 'update', target: `customer:${k.customer_id}`, detail: { op: 'lead_portal_basket_confirm', quote_no: r.quote_no, lines: items.length, code_id: Number(k.id) } });
    }
    return r;
  });
  async function asesorName(k, uid) {
    const id = uid || (k.owner_id ? Number(k.owner_id) : null);
    if (!id) return null;
    try { const u = (await query(`SELECT name FROM users WHERE id=$1`, [id])).rows[0]; return u ? String(u.name).split(/\s+/)[0] : null; }
    catch (_) { return null; }
  }

  // ════════════════════════════════════════════════════════════════
  //  ERP — 접속코드 관리(디렉터) · 고객 매장 재고(담당 영업사원 · 디렉터)
  // ════════════════════════════════════════════════════════════════
  const DIR = { preHandler: [authGuard, async (req, reply) => { if (req.ctx.perm.role !== 'director') return reply.code(403).send({ error: 'director_only' }); }] };
  const R = { preHandler: [authGuard, requirePageAny(PM_KEYS)] };
  const W = { preHandler: [authGuard, requirePageEditAny(PM_KEYS)] };
  const clog = (c, codeId, action, detail, userId) => c.query(
    `INSERT INTO lead_portal_code_log (code_id, action, detail, user_id) VALUES ($1,$2,$3,$4)`, [codeId, action, detail ? JSON.stringify(detail) : null, userId]);
  const cleanStates = (v) => {
    if (v == null || v === '' || (Array.isArray(v) && !v.length)) return null;
    const list = (Array.isArray(v) ? v : [v]).map((s) => String(s).trim()).filter((s) => META_STATES.includes(s));
    return list.length ? [...new Set(list)] : null;
  };
  // 1105 · 광고 범위 — 광고 ID 목록(빈 값 = 모든 광고)
  const cleanAds = (v) => {
    if (v == null || v === '' || (Array.isArray(v) && !v.length)) return null;
    const list = (Array.isArray(v) ? v : String(v).split(',')).map(cleanAdId).filter(Boolean);
    return list.length ? [...new Set(list)].slice(0, 100) : null;
  };
  const cleanAmount = (v) => { if (v == null || v === '') return null; const n = Number(String(v).replace(/[,\s$]/g, '')); return Number.isFinite(n) && n >= 0 && n < 1e12 ? Math.round(n * 100) / 100 : undefined; };

  app.get('/api/lead-portal-admin/status', R, async (req) => {
    // 1105 · 광고 범위 고르기용 — 등록된 광고 + 문의에서 보인 광고 ID(문의 수)
    let ads = [];
    try {
      ads = (await query(
        `SELECT x.ad_id, a.name, x.n FROM (SELECT ${AD_EXPR} AS ad_id, count(*)::int AS n FROM meta_threads t WHERE t.status <> 'descartado' GROUP BY 1) x
           LEFT JOIN meta_ads a ON a.ad_id = x.ad_id WHERE x.ad_id IS NOT NULL
         UNION
         SELECT a.ad_id, a.name, 0 FROM meta_ads a WHERE NOT EXISTS (SELECT 1 FROM meta_threads t WHERE ${AD_EXPR} = a.ad_id)
         ORDER BY 3 DESC, 1`)).rows.map((r) => ({ ad_id: String(r.ad_id), name: r.name || null, n: Number(r.n) || 0 }));
    } catch (_) { ads = []; }
    return { ready: await portalReady(), build: LP_BUILD, url: portalUrl(), states: META_STATES,
      director: req.ctx.perm.role === 'director', today: todayMx(), ads, access: await accessReady() };
  });

  // 1106 · 포털 광고 카드 관리 — 보기: 화면 권한 · 만들기/고치기/지우기: 디렉터
  const cleanCard = (b) => {
    const o = {};
    if (b.kind !== undefined) { if (!CARD_KINDS.includes(b.kind)) return { error: 'bad_kind' }; o.kind = b.kind; }
    if (b.title !== undefined) { o.title = clip(b.title, 120); if (!o.title) return { error: 'title_required' }; }
    if (b.body !== undefined) o.body = clip(b.body, 600);
    for (const f of ['image_url', 'cta_url']) if (b[f] !== undefined) {
      const v = String(b[f] || '').trim();
      if (v && !/^(https:\/\/|img\/)[^\s"'<>]{1,600}$/.test(v) && !(f === 'image_url' && bankId(v))) return { error: 'bad_url', field: f };
      o[f] = v || null;
    }
    if (b.cta_text !== undefined) o.cta_text = clip(b.cta_text, 40);
    if (b.kit_no !== undefined) { const kn = b.kit_no ? normKitNo(b.kit_no) : null; if (b.kit_no && !kn) return { error: 'bad_kit' }; o.kit_no = kn; }
    if (b.every_n !== undefined) { const n = Number(b.every_n); if (!Number.isInteger(n) || n < 1 || n > 50) return { error: 'bad_every_n' }; o.every_n = n; }
    if (b.sort !== undefined) o.sort = Number(b.sort) || 0;
    if (b.active !== undefined) o.active = !!b.active;
    for (const f of ['starts_on', 'ends_on']) if (b[f] !== undefined) { if (b[f] && !ymd(b[f])) return { error: 'bad_date' }; o[f] = b[f] || null; }
    return { o };
  };
  // 1106d · 키트 번호 확인 — 0321 전이면 칸을 빼고, 없는 키트면 400
  let ckReady = false;
  async function kitCheck(o, reply) {
    if (!('kit_no' in o)) return true;
    if (!ckReady) { try { ckReady = (await query(`SELECT 1 FROM information_schema.columns WHERE table_name='lead_portal_cards' AND column_name='kit_no'`)).rows.length > 0; } catch (_) { ckReady = false; } }
    if (!ckReady) { if (o.kit_no) { reply.code(503).send({ error: 'migration_required', note: '0321 마이그레이션이 필요합니다.' }); return false; } delete o.kit_no; return true; }
    if (!o.kit_no) return true;
    const cp = (await kitCompositions([o.kit_no]).catch(() => new Map())).get(o.kit_no);
    if (!cp || !cp.kit_code) { reply.code(400).send({ error: 'unknown_kit', kit_no: o.kit_no }); return false; }
    return true;
  }
  // 1106d · 키트 찾기 — 번호(K0001) 또는 이미지 뱅크 이미지(키트 사진 연결 · 이름/설명 속 K0…)
  app.get('/api/lead-portal-admin/kit-lookup', R, async (req, reply) => {
    let no = normKitNo(req.query.no);
    const img = idOf(req.query.image_id);
    if (!no && img) {
      const v = (await query(`SELECT promo_no FROM vio_promos WHERE image_id=$1 ORDER BY id DESC LIMIT 1`, [img]).catch(() => ({ rows: [] }))).rows[0];
      if (v) no = normKitNo(v.promo_no);
      if (!no) {
        const im = (await query(`SELECT name, memo FROM wa_images WHERE id=$1`, [img]).catch(() => ({ rows: [] }))).rows[0];
        const m = im && String((im.name || '') + ' ' + (im.memo || '')).match(/\bK0\d{2,5}\b/i);
        if (m) no = normKitNo(m[0]);
      }
    }
    if (!no) return { kit: null };
    const cp = (await kitCompositions([no]).catch(() => new Map())).get(no);
    if (!cp || !cp.kit_code) return { kit: null, kit_no: no, missing: true };
    const info = await productInfo(0, 0, [cp.kit_code]);
    const p = info[cp.kit_code] || {};
    return { kit: { kit_no: no, code: cp.kit_code, title: [cp.title, cp.years].filter(Boolean).join(' '), items: (p.kit && p.kit.items) || [], list: p.list || 0, avail: p.avail || 0, active: p.active !== false } };
  });

  app.get('/api/lead-portal-admin/cards', R, async (req, reply) => {
    if (!(await cardsReady())) return reply.code(503).send({ error: 'migration_required', note: '0320 마이그레이션이 필요합니다.' });
    const rows = (await query(
      `SELECT c.*, to_char(c.starts_on,'YYYY-MM-DD') AS starts_ymd, to_char(c.ends_on,'YYYY-MM-DD') AS ends_ymd,
              (SELECT count(*)::int FROM lead_portal_card_clicks x WHERE x.card_id=c.id AND x.kind='click') AS clicks,
              (SELECT count(*)::int FROM lead_portal_card_clicks x WHERE x.card_id=c.id AND x.kind='interest') AS interests,
              (SELECT string_agg(DISTINCT cu.name, ', ') FROM lead_portal_card_clicks x JOIN customers cu ON cu.id=x.customer_id WHERE x.card_id=c.id AND x.kind='interest') AS interested
         FROM lead_portal_cards c WHERE c.deleted_at IS NULL ORDER BY c.sort, c.id`)).rows;
    return { items: rows.map((r) => ({ ...cardOut(r, false), bank_id: bankId(r.image_url), sort: Number(r.sort) || 0, active: !!r.active, starts_on: r.starts_ymd, ends_on: r.ends_ymd,
      clicks: r.clicks, interests: r.interests, interested: r.interested || null })), kinds: CARD_KINDS, director: req.ctx.perm.role === 'director', can_edit: true };
  });
  // 1106d · 디렉터: 이 화면을 볼 수 있는 직원이면 누구나 광고 카드를 만들고 고친다(R)
  app.post('/api/lead-portal-admin/cards', R, async (req, reply) => {
    if (!(await cardsReady())) return reply.code(503).send({ error: 'migration_required' });
    const b = req.body || {};
    const c = cleanCard({ kind: b.kind || 'anuncio', title: b.title, body: b.body, image_url: b.image_url, cta_text: b.cta_text, cta_url: b.cta_url, every_n: b.every_n == null ? 6 : b.every_n, sort: b.sort, active: b.active == null ? true : b.active, starts_on: b.starts_on, ends_on: b.ends_on, kit_no: b.kit_no || undefined });
    if (c.error) return reply.code(400).send(c);
    if (!(await kitCheck(c.o, reply))) return;
    const o = c.o; const cols = Object.keys(o);
    const r = (await query(`INSERT INTO lead_portal_cards (${cols.join(',')}, created_by, updated_by) VALUES (${cols.map((_, i) => '$' + (i + 1)).join(',')}, $${cols.length + 1}, $${cols.length + 1}) RETURNING id`,
      [...cols.map((x) => o[x]), req.ctx.perm.userId])).rows[0];
    await logEvent({ userId: req.ctx.perm.userId, action: 'create', target: `lead_portal_card:${r.id}`, detail: { kind: o.kind, title: o.title } });
    return { ok: true, id: Number(r.id) };
  });
  app.patch('/api/lead-portal-admin/cards/:id', R, async (req, reply) => {
    if (!(await cardsReady())) return reply.code(503).send({ error: 'migration_required' });
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const c = cleanCard(req.body || {}); if (c.error) return reply.code(400).send(c);
    if (!(await kitCheck(c.o, reply))) return;
    const cols = Object.keys(c.o); if (!cols.length) return { ok: true, unchanged: true };
    const r = (await query(`UPDATE lead_portal_cards SET ${cols.map((x, i) => `${x}=$${i + 2}`).join(', ')}, updated_by=$${cols.length + 2}, updated_at=now() WHERE id=$1 AND deleted_at IS NULL RETURNING id`,
      [id, ...cols.map((x) => c.o[x]), req.ctx.perm.userId])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await logEvent({ userId: req.ctx.perm.userId, action: 'update', target: `lead_portal_card:${id}`, detail: { fields: cols } });
    return { ok: true };
  });
  app.delete('/api/lead-portal-admin/cards/:id', R, async (req, reply) => {
    if (!(await cardsReady())) return reply.code(503).send({ error: 'migration_required' });
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const r = (await query(`UPDATE lead_portal_cards SET deleted_at=now(), active=false, updated_by=$2 WHERE id=$1 AND deleted_at IS NULL RETURNING id`, [id, req.ctx.perm.userId])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await logEvent({ userId: req.ctx.perm.userId, action: 'delete', target: `lead_portal_card:${id}` });
    return { ok: true };
  });

  // 1105c · 확약서 서명 기록(이 화면 접근 권한) · 서명 이미지
  app.get('/api/lead-portal-admin/consents', R, async (req, reply) => {
    if (!(await infoConsentReady())) return reply.code(503).send({ error: 'migration_required', note: '0318 마이그레이션이 필요합니다.' });
    const rows = (await query(
      `SELECT s.id, s.code_id, s.version, s.first_name, s.last_name, s.phone, s.ip,
              to_char(s.signed_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS signed_mx, k.code_last4,
              COALESCE(c.name, '') AS customer_name, COALESCE(c.code, '') AS customer_code, (s.version = $1) AS current
         FROM lead_portal_consents s JOIN lead_portal_codes k ON k.id = s.code_id LEFT JOIN customers c ON c.id = s.customer_id
        ORDER BY s.signed_at DESC, s.id DESC LIMIT 500`, [CONSENT_VERSION])).rows;
    const pending = (await query(
      `SELECT k.id AS code_id, k.code_last4, c.name AS customer_name, c.code AS customer_code
         FROM lead_portal_codes k JOIN customers c ON c.id = k.customer_id
        WHERE k.deleted_at IS NULL AND k.active AND COALESCE(to_jsonb(k)->>'kind','customer') <> 'director'
          AND NOT EXISTS (SELECT 1 FROM lead_portal_consents s WHERE s.code_id = k.id AND s.version = $1)
        ORDER BY c.name`, [CONSENT_VERSION])).rows;
    return { version: CONSENT_VERSION, text: CONSENT_TEXT, items: rows.map((r) => ({ ...r, id: Number(r.id), code_id: Number(r.code_id) })), pending: pending.map((r) => ({ ...r, code_id: Number(r.code_id) })) };
  });
  app.get('/api/lead-portal-admin/consents/:id', R, async (req, reply) => {
    if (!(await infoConsentReady())) return reply.code(503).send({ error: 'migration_required' });
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const r = (await query(`SELECT s.*, to_char(s.signed_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI:SS') AS signed_mx FROM lead_portal_consents s WHERE s.id=$1`, [id])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    return { id: Number(r.id), version: r.version, first_name: r.first_name, last_name: r.last_name, phone: r.phone, signature: r.signature, text: r.text, text_hash: r.text_hash, ip: r.ip, ua: r.ua, signed_mx: r.signed_mx };
  });

  // 1105 · 접속 기록 — 고객(접속코드)별 · 날짜별(멕시코 시간) 접속 시각. 이 화면에 접근 권한이 있는 직원 모두(R)
  app.get('/api/lead-portal-admin/access', R, async (req, reply) => {
    if (!(await accessReady())) return reply.code(503).send({ error: 'migration_required', note: '0317 마이그레이션이 필요합니다.' });
    const to = ymd(req.query.to) || todayMx();
    const from = ymd(req.query.from) || new Date(Date.parse(to + 'T12:00:00Z') - 13 * 86400000).toISOString().slice(0, 10);
    const args = [from, to]; let extra = '';
    const cid = idOf(req.query.code_id); if (cid) { args.push(cid); extra = ` AND a.code_id = $${args.length}`; }
    const rows = (await query(
      `SELECT a.code_id, to_char(a.at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD') AS d,
              to_char(min(a.at) AT TIME ZONE 'America/Mexico_City','HH24:MI') AS first_t,
              to_char(max(a.at) AT TIME ZONE 'America/Mexico_City','HH24:MI') AS last_t,
              count(*) FILTER (WHERE a.kind = 'login')::int AS logins,
              count(*) FILTER (WHERE a.kind IN ('login','open'))::int AS opens,
              count(*) FILTER (WHERE a.kind = 'active')::int AS active,
              (array_agg(to_char(a.at AT TIME ZONE 'America/Mexico_City','HH24:MI') ORDER BY a.at) FILTER (WHERE a.kind IN ('login','open')))[1:40] AS times,
              COALESCE(c.name, '${DIRECTOR_NAME}') AS customer_name, COALESCE(c.code, 'DIR') AS customer_code, k.code_last4, (to_jsonb(k)->>'kind') AS kind
         FROM lead_portal_access a JOIN lead_portal_codes k ON k.id = a.code_id LEFT JOIN customers c ON c.id = k.customer_id
        WHERE (a.at AT TIME ZONE 'America/Mexico_City')::date BETWEEN $1::date AND $2::date${extra}
        GROUP BY a.code_id, d, k.id, c.id
        ORDER BY d DESC, max(a.at) DESC LIMIT 2000`, args)).rows;
    return { from, to, items: rows.map((r) => ({ code_id: Number(r.code_id), date: r.d, first: r.first_t, last: r.last_t,
      logins: r.logins, opens: r.opens, active: r.active, times: r.times || [], customer_name: r.customer_name, customer_code: r.customer_code, last4: r.code_last4, kind: r.kind || 'customer' })) };
  });

  // 고객 찾기 — 직원이 볼 수 있는 고객만
  app.get('/api/lead-portal-admin/customers', R, async (req) => {
    const kw = String(req.query.q || '').trim();
    const vis = visibleTeamIds(req.ctx.perm);
    const args = []; const conds = ['c.deleted_at IS NULL', `COALESCE(c.approval_status,'approved') <> 'pending'`];
    if (kw) { args.push('%' + kw + '%'); conds.push(`(c.name ILIKE $${args.length} OR c.code ILIKE $${args.length} OR c.rfc ILIKE $${args.length})`); }
    if (vis !== null) {
      args.push(req.ctx.perm.userId); const u = args.length;
      args.push(vis.length ? vis : [-1]); const tv = args.length;
      conds.push(`(c.owner_id = $${u} OR c.team_id = ANY($${tv}::bigint[]))`);
    }
    const rows = (await query(
      `SELECT c.id, c.code, c.name, c.discount FROM customers c WHERE ${conds.join(' AND ')} ORDER BY c.name LIMIT 30`, args)).rows;
    return { items: rows.map((r) => ({ id: Number(r.id), code: r.code, name: r.name, discount: Number(r.discount) || 0 })) };
  });

  // 발급 화면 참고 — 그 고객 ERP 매출(IVA 제외)
  app.get('/api/lead-portal-admin/customer-ref/:id', DIR, async (req, reply) => {
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const r = (await query(
      `SELECT COALESCE(SUM(subtotal_mxn) FILTER (WHERE inv_date >= CURRENT_DATE - 30),0) AS d30,
              COALESCE(SUM(subtotal_mxn) FILTER (WHERE inv_date >= CURRENT_DATE - 91),0) AS d90,
              COALESCE(SUM(subtotal_mxn) FILTER (WHERE inv_date >= CURRENT_DATE - 365),0) AS d365,
              to_char(MAX(inv_date),'YYYY-MM-DD') AS last_date
         FROM sales_invoices WHERE customer_id=$1 AND status='posted' AND deleted_at IS NULL`, [id])).rows[0];
    const last = r.last_date ? (await query(
      `SELECT COALESCE(SUM(subtotal_mxn),0) AS amt FROM sales_invoices WHERE customer_id=$1 AND status='posted' AND deleted_at IS NULL AND inv_date=$2::date`, [id, r.last_date])).rows[0] : null;
    const codes = (await portalReady())
      ? (await query(`SELECT count(*)::int AS n FROM lead_portal_codes WHERE customer_id=$1 AND deleted_at IS NULL`, [id])).rows[0].n : 0;
    return { d30: Number(r.d30) || 0, d90: Number(r.d90) || 0, d365: Number(r.d365) || 0, last_date: r.last_date, last_amount: last ? Number(last.amt) || 0 : null, codes };
  });

  const CODE_SELECT = `
    SELECT k.id, k.customer_id, COALESCE(c.code, 'DIR') AS customer_code, COALESCE(c.name, '${DIRECTOR_NAME}') AS customer_name, k.code_last4,
           (to_jsonb(k)->>'kind') AS kind,
           to_char(k.expires_on,'YYYY-MM-DD') AS expires_on, k.basis_amount, k.memo, k.scope_states, (to_jsonb(k)->'scope_ads') AS scope_ads, k.active,
           k.last_seen_at, k.created_at, to_char(k.created_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD') AS created_on,
           (SELECT count(*)::int FROM lead_portal_reveals r WHERE r.code_id = k.id) AS reveals,
           (SELECT count(*)::int FROM quotes q WHERE q.lead_portal_code_id = k.id AND q.deleted_at IS NULL AND q.status <> 'cancelled') AS orders,
           (SELECT COALESCE(SUM(q.total_mxn),0) FROM quotes q WHERE q.lead_portal_code_id = k.id AND q.deleted_at IS NULL AND q.status <> 'cancelled') AS orders_total
      FROM lead_portal_codes k LEFT JOIN customers c ON c.id = k.customer_id`;
  const codeOut = (r, today) => ({
    id: Number(r.id), customer_id: r.customer_id == null ? null : Number(r.customer_id), kind: r.kind || 'customer', customer_code: r.customer_code, customer_name: r.customer_name,
    last4: r.code_last4, expires_on: r.expires_on, days_left: daysBetween(today, r.expires_on),
    basis_amount: num(r.basis_amount), memo: r.memo || null, scope_states: r.scope_states || null,
    scope_ads: Array.isArray(r.scope_ads) && r.scope_ads.length ? r.scope_ads.map(String) : null, active: !!r.active,
    state: codeState(r, today), last_seen_at: r.last_seen_at, created_on: r.created_on,
    reveals: Number(r.reveals) || 0, orders: Number(r.orders) || 0, orders_total: Number(r.orders_total) || 0,
  });

  app.get('/api/lead-portal-admin/codes', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const today = todayMx();
    const rows = (await query(`${CODE_SELECT} WHERE k.deleted_at IS NULL ORDER BY (k.active AND k.expires_on >= $1::date) DESC, k.expires_on ASC, k.id DESC`, [today])).rows;
    return { today, url: portalUrl(), items: rows.map((r) => codeOut(r, today)) };
  });

  app.post('/api/lead-portal-admin/codes', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const b = req.body || {};
    const cid = idOf(b.customer_id); const exp = ymd(b.expires_on); const amt = cleanAmount(b.basis_amount);
    // 0299 · 디렉터 전용 코드 — 고객 없음 · 전체 문의 · 모든 메모 · 주문 불가
    if (b.kind === 'director') {
      if (!(await notesReady())) return reply.code(503).send({ error: 'migration_required', note: '0299 마이그레이션이 필요합니다(npm run migrate).' });
      if (!exp) return reply.code(400).send({ error: 'expires_required', note: '만료일을 입력하세요.' });
      if (exp < todayMx()) return reply.code(400).send({ error: 'expires_past', note: '만료일이 오늘보다 앞입니다.' });
      const code = newCode(); const norm = normCode(code);
      const row = await withTx(async (c) => {
        const k = (await c.query(
          `INSERT INTO lead_portal_codes (customer_id, kind, code_hash, code_last4, expires_on, memo, created_by, updated_by)
           VALUES (NULL,'director',$1,$2,$3,$4,$5,$5) RETURNING id`,
          [codeHash(norm), norm.slice(-4), exp, clip(b.memo, 500), req.ctx.perm.userId])).rows[0];
        await clog(c, k.id, 'issue', { kind: 'director', expires_on: exp }, req.ctx.perm.userId);
        return k;
      });
      await logEvent({ userId: req.ctx.perm.userId, action: 'create', target: `lead_portal_code:${row.id}`, detail: { kind: 'director', expires_on: exp } });
      const r0 = (await query(`${CODE_SELECT} WHERE k.id=$1`, [row.id])).rows[0];
      return { ok: true, code, invite: directorInviteText({ code, expiresOn: exp, url: portalUrl() }), item: codeOut(r0, todayMx()) };
    }
    if (!cid) return reply.code(400).send({ error: 'customer_required', note: '고객을 고르세요.' });
    if (!exp) return reply.code(400).send({ error: 'expires_required', note: '만료일을 입력하세요.' });
    if (exp < todayMx()) return reply.code(400).send({ error: 'expires_past', note: '만료일이 오늘보다 앞입니다.' });
    if (amt === undefined) return reply.code(400).send({ error: 'bad_amount', note: '기준 금액은 숫자로 입력하세요.' });
    const cust = (await query(`SELECT id, name, COALESCE(approval_status,'approved') AS st FROM customers WHERE id=$1 AND deleted_at IS NULL`, [cid])).rows[0];
    if (!cust) return reply.code(404).send({ error: 'customer_not_found' });
    if (cust.st === 'pending') return reply.code(409).send({ error: 'customer_pending', note: '승인 대기 고객에게는 발급할 수 없습니다.' });
    const code = newCode(); const norm = normCode(code);
    const row = await withTx(async (c) => {
      const k = (await c.query(
        `INSERT INTO lead_portal_codes (customer_id, code_hash, code_last4, expires_on, basis_amount, memo, scope_states, created_by, updated_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8) RETURNING id`,
        [cid, codeHash(norm), norm.slice(-4), exp, amt, clip(b.memo, 500), cleanStates(b.scope_states), req.ctx.perm.userId])).rows[0];
      const ads = cleanAds(b.scope_ads);
      if (ads && (await accessReady())) await c.query(`UPDATE lead_portal_codes SET scope_ads=$2 WHERE id=$1`, [k.id, ads]);
      await clog(c, k.id, 'issue', { expires_on: exp, basis_amount: amt, scope_states: cleanStates(b.scope_states), ...(ads ? { scope_ads: ads } : {}) }, req.ctx.perm.userId);
      return k;
    });
    await logEvent({ userId: req.ctx.perm.userId, action: 'create', target: `lead_portal_code:${row.id}`, detail: { customer_id: cid, expires_on: exp } });
    const today = todayMx();
    const r = (await query(`${CODE_SELECT} WHERE k.id=$1`, [row.id])).rows[0];
    return { ok: true, code, invite: inviteText({ customerName: cust.name, code, expiresOn: exp, url: portalUrl() }), item: codeOut(r, today) };
  });

  // 기한 · 기준 금액 · 메모 · 범위 · 정지/재개
  app.patch('/api/lead-portal-admin/codes/:id', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const b = req.body || {};
    const cur = (await query(`SELECT *, to_char(expires_on,'YYYY-MM-DD') AS exp FROM lead_portal_codes WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
    if (!cur) return reply.code(404).send({ error: 'not_found' });
    const sets = []; const args = []; const changes = {};
    const add = (col, v) => { args.push(v); sets.push(`${col}=$${args.length}`); };
    if ('expires_on' in b) {
      const exp = ymd(b.expires_on); if (!exp) return reply.code(400).send({ error: 'expires_required', note: '만료일을 입력하세요.' });
      if (exp !== cur.exp) { add('expires_on', exp); changes.expires_on = [cur.exp, exp]; }
    }
    if ('basis_amount' in b) {
      const amt = cleanAmount(b.basis_amount); if (amt === undefined) return reply.code(400).send({ error: 'bad_amount' });
      if (num(cur.basis_amount) !== amt) { add('basis_amount', amt); changes.basis_amount = [num(cur.basis_amount), amt]; }
    }
    if ('memo' in b) { const m = clip(b.memo, 500); if ((cur.memo || null) !== m) { add('memo', m); changes.memo = true; } }
    if ('scope_states' in b) {
      const s = cleanStates(b.scope_states);
      if (JSON.stringify(cur.scope_states || null) !== JSON.stringify(s)) { add('scope_states', s); changes.scope_states = [cur.scope_states || null, s]; }
    }
    if ('scope_ads' in b) {   // 1105
      if (!(await accessReady())) return reply.code(503).send({ error: 'migration_required', note: '0317 마이그레이션이 필요합니다.' });
      const s2 = cleanAds(b.scope_ads);
      if (JSON.stringify(cur.scope_ads || null) !== JSON.stringify(s2)) { add('scope_ads', s2); changes.scope_ads = [cur.scope_ads || null, s2]; }
    }
    if ('active' in b) { const a = !!b.active; if (a !== !!cur.active) { add('active', a); changes.active = a; } }
    if (!sets.length) return { ok: true, unchanged: true };
    args.push(req.ctx.perm.userId); sets.push(`updated_by=$${args.length}`, 'updated_at=now()');
    args.push(id);
    await withTx(async (c) => {
      await c.query(`UPDATE lead_portal_codes SET ${sets.join(', ')} WHERE id=$${args.length}`, args);
      const action = 'active' in changes && Object.keys(changes).length === 1 ? (changes.active ? 'resume' : 'pause') : 'update';
      await clog(c, id, action, changes, req.ctx.perm.userId);
    });
    await logEvent({ userId: req.ctx.perm.userId, action: 'update', target: `lead_portal_code:${id}`, detail: changes });
    const today = todayMx();
    return { ok: true, item: codeOut((await query(`${CODE_SELECT} WHERE k.id=$1`, [id])).rows[0], today) };
  });

  // 재발급 — 새 코드, 옛 코드 · 옛 토큰 즉시 무효. 기한 · 범위는 그대로.
  app.post('/api/lead-portal-admin/codes/:id/reissue', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const cur = (await query(`SELECT k.id, to_char(k.expires_on,'YYYY-MM-DD') AS exp, COALESCE(c.name, '${DIRECTOR_NAME}') AS name, (to_jsonb(k)->>'kind') AS kind FROM lead_portal_codes k LEFT JOIN customers c ON c.id=k.customer_id WHERE k.id=$1 AND k.deleted_at IS NULL`, [id])).rows[0];
    if (!cur) return reply.code(404).send({ error: 'not_found' });
    const code = newCode(); const norm = normCode(code);
    await withTx(async (c) => {
      await c.query(`UPDATE lead_portal_codes SET code_hash=$1, code_last4=$2, token_version=token_version+1, updated_by=$3, updated_at=now() WHERE id=$4`,
        [codeHash(norm), norm.slice(-4), req.ctx.perm.userId, id]);
      await clog(c, id, 'reissue', { last4: norm.slice(-4) }, req.ctx.perm.userId);
    });
    await logEvent({ userId: req.ctx.perm.userId, action: 'update', target: `lead_portal_code:${id}`, detail: { op: 'reissue' } });
    const today = todayMx();
    return { ok: true, code, invite: cur.kind === 'director' ? directorInviteText({ code, expiresOn: cur.exp, url: portalUrl() }) : inviteText({ customerName: cur.name, code, expiresOn: cur.exp, url: portalUrl() }),
      item: codeOut((await query(`${CODE_SELECT} WHERE k.id=$1`, [id])).rows[0], today) };
  });

  app.delete('/api/lead-portal-admin/codes/:id', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const r = await withTx(async (c) => {
      const x = (await c.query(`UPDATE lead_portal_codes SET deleted_at=now(), token_version=token_version+1, updated_by=$1, updated_at=now() WHERE id=$2 AND deleted_at IS NULL RETURNING id`, [req.ctx.perm.userId, id])).rows[0];
      if (x) await clog(c, id, 'delete', null, req.ctx.perm.userId);
      return x;
    });
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await logEvent({ userId: req.ctx.perm.userId, action: 'delete', target: `lead_portal_code:${id}` });
    return { ok: true };
  });

  app.get('/api/lead-portal-admin/codes/:id/log', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const rows = (await query(
      `SELECT l.action, l.detail, u.name AS user_name, to_char(l.at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at
         FROM lead_portal_code_log l LEFT JOIN users u ON u.id = l.user_id WHERE l.code_id=$1 ORDER BY l.at DESC, l.id DESC LIMIT 100`, [id])).rows;
    return { items: rows };
  });

  // 연락처 공개 기록
  app.get('/api/lead-portal-admin/reveals', DIR, async (req, reply) => {
    if (!(await need(reply))) return;
    const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 100));
    const args = []; let w = 'true';
    const cid = idOf(req.query.code_id); if (cid) { args.push(cid); w = `r.code_id=$1`; }
    const rows = (await query(
      `SELECT r.thread_id, r.n, to_char(r.first_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS first_mx,
              to_char(r.last_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS last_mx,
              c.name AS customer_name, k.code_last4, t.platform, t.status,
              COALESCE(t.m_vehicles, t.ai_vehicles, t.a_vehicles) AS vehicles, COALESCE(t.m_parts, t.ai_parts, t.a_parts) AS parts,
              ${(await wantsReady()) ? `(SELECT string_agg(p.code || '×' || x.qty, ', ' ORDER BY p.code) FROM lead_portal_wants x JOIN products p ON p.id = x.product_id
                                        WHERE x.customer_id = r.customer_id AND x.thread_id = r.thread_id)` : 'NULL::text'} AS wants
         FROM lead_portal_reveals r JOIN customers c ON c.id = r.customer_id JOIN lead_portal_codes k ON k.id = r.code_id
         JOIN meta_threads t ON t.id = r.thread_id
        WHERE ${w} ORDER BY r.first_at DESC LIMIT ${limit}`, args)).rows;
    return { items: rows.map((r) => ({ ...r, thread_id: Number(r.thread_id), n: Number(r.n) })) };
  });

  // ════════ 0300 · 대화 선점 관리(디렉터) ════════
  app.get('/api/lead-portal-admin/settings', DIR, async (req, reply) => {
    if (!(await chatReady())) return reply.code(503).send({ error: 'migration_required', note: '0300 마이그레이션이 필요합니다(npm run migrate).' });
    return { claim_days: await claimDays() };
  });
  app.put('/api/lead-portal-admin/settings', DIR, async (req, reply) => {
    if (!(await chatReady())) return reply.code(503).send({ error: 'migration_required', note: '0300 마이그레이션이 필요합니다(npm run migrate).' });
    const d = Number(req.body && req.body.claim_days);
    if (!Number.isInteger(d) || d < 1 || d > 30) return reply.code(400).send({ error: 'bad_days', note: '1~30일 사이 정수로 입력하세요.' });
    await query(`UPDATE lead_portal_settings SET claim_days=$1, updated_by=$2, updated_at=now() WHERE id=1`, [d, req.ctx.perm.userId]);
    await logEvent({ userId: req.ctx.perm.userId, action: 'update', target: 'lead_portal_settings', detail: { claim_days: d } });
    return { ok: true, claim_days: d };
  });
  app.get('/api/lead-portal-admin/claims', DIR, async (req, reply) => {
    if (!(await chatReady())) return reply.code(503).send({ error: 'migration_required', note: '0300 마이그레이션이 필요합니다(npm run migrate).' });
    const rows = (await query(
      `SELECT c.id, c.thread_id, cu.name AS customer_name, k.code_last4, (to_jsonb(c)->>'via') AS via, t.platform,
              to_char(c.claimed_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS claimed_mx,
              to_char(c.expires_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS expires_mx,
              to_char(c.released_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS released_mx,
              (c.released_at IS NULL AND c.expires_at > now()) AS active,
              COALESCE(t.m_vehicles, t.ai_vehicles, t.a_vehicles) AS vehicles, COALESCE(t.m_name, t.name) AS lead_name,
              (SELECT count(*)::int FROM meta_page_messages pm WHERE pm.psid = t.user_id AND pm.source='portal' AND pm.customer_id = c.customer_id AND pm.at >= c.claimed_at) AS sent,
              (SELECT count(*)::int FROM meta_page_messages pm WHERE pm.psid = t.user_id AND pm.direction='in' AND pm.at >= c.claimed_at) AS received,
              (SELECT to_char(max(pm.at) AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') FROM meta_page_messages pm WHERE pm.psid = t.user_id AND pm.at >= c.claimed_at) AS last_mx
         FROM lead_portal_claims c JOIN customers cu ON cu.id = c.customer_id JOIN meta_threads t ON t.id = c.thread_id
         LEFT JOIN lead_portal_codes k ON k.id = c.code_id
        WHERE c.claimed_at > now() - interval '60 days'
        ORDER BY (c.released_at IS NULL AND c.expires_at > now()) DESC, c.claimed_at DESC LIMIT 300`)).rows;
    return { claim_days: await claimDays(), items: rows.map((r) => ({ ...r, id: Number(r.id), thread_id: Number(r.thread_id) })) };
  });
  app.post('/api/lead-portal-admin/claims/:id/release', DIR, async (req, reply) => {
    if (!(await chatReady())) return reply.code(503).send({ error: 'migration_required' });
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const r = (await query(`UPDATE lead_portal_claims SET released_at=now(), released_by=$2 WHERE id=$1 AND released_at IS NULL RETURNING thread_id`, [id, req.ctx.perm.userId])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await logEvent({ userId: req.ctx.perm.userId, action: 'update', target: `lead_portal_claim:${id}`, detail: { op: 'release' } });
    return { ok: true };
  });
  app.post('/api/lead-portal-admin/claims/:id/extend', DIR, async (req, reply) => {
    if (!(await chatReady())) return reply.code(503).send({ error: 'migration_required' });
    const id = idOf(req.params.id); if (!id) return reply.code(400).send({ error: 'bad_id' });
    const d = Number(req.body && req.body.days);
    if (!Number.isInteger(d) || d < 1 || d > 60) return reply.code(400).send({ error: 'bad_days', note: '1~60일' });
    const r = (await query(
      `UPDATE lead_portal_claims SET expires_at = GREATEST(expires_at, now()) + ($2 || ' days')::interval
        WHERE id=$1 AND released_at IS NULL RETURNING to_char(expires_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS expires_mx`, [id, String(d)])).rows[0];
    if (!r) return reply.code(404).send({ error: 'not_found' });
    await logEvent({ userId: req.ctx.perm.userId, action: 'update', target: `lead_portal_claim:${id}`, detail: { op: 'extend', days: d } });
    return { ok: true, expires_mx: r.expires_mx };
  });

  // 0299 · 문의 메모 전체(디렉터) — 언제 · 누가(고객 · 코드) · 어느 문의에 · 무엇을 · 지웠는지
  app.get('/api/lead-portal-admin/notes', DIR, async (req, reply) => {
    if (!(await notesReady())) return reply.code(503).send({ error: 'migration_required', note: '0299 마이그레이션이 필요합니다(npm run migrate).' });
    const limit = Math.min(500, Math.max(1, Number(req.query.limit) || 200));
    const args = []; const conds = ['true'];
    const cid = idOf(req.query.customer_id); if (cid) { args.push(cid); conds.push(`n.customer_id=$${args.length}`); }
    const tid = idOf(req.query.thread_id); if (tid) { args.push(tid); conds.push(`n.thread_id=$${args.length}`); }
    const kw = String(req.query.q || '').trim();
    if (kw) { args.push('%' + kw + '%'); conds.push(`(n.body ILIKE $${args.length} OR c.name ILIKE $${args.length})`); }
    const rows = (await query(
      `SELECT n.id, n.thread_id, n.body, n.customer_id, COALESCE(c.name, '${DIRECTOR_NAME}') AS author, k.code_last4,
              to_char(n.created_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at,
              to_char(n.deleted_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS deleted_at,
              t.platform, COALESCE(t.m_vehicles, t.ai_vehicles, t.a_vehicles) AS vehicles
         FROM lead_portal_notes n LEFT JOIN customers c ON c.id = n.customer_id
         JOIN lead_portal_codes k ON k.id = n.code_id JOIN meta_threads t ON t.id = n.thread_id
        WHERE ${conds.join(' AND ')} ORDER BY n.created_at DESC, n.id DESC LIMIT ${limit}`, args)).rows;
    return { items: rows.map((r) => ({ ...r, id: Number(r.id), thread_id: Number(r.thread_id), customer_id: r.customer_id == null ? null : Number(r.customer_id) })) };
  });

  // 고객 매장 재고 — 담당 영업사원 · 디렉터(자기가 볼 수 있는 고객만)
  app.get('/api/lead-portal-admin/shelf', R, async (req, reply) => {
    if (!(await need(reply))) return;
    const cid = idOf(req.query.customer_id); if (!cid) return reply.code(400).send({ error: 'customer_required' });
    const cv = await customerVisible(req.ctx.perm, cid);
    if (cv === null) return reply.code(404).send({ error: 'customer_not_found' });
    if (cv === false) return reply.code(403).send({ error: 'not_your_customer' });
    const rows = (await query(
      `SELECT p.code, p.name, s.qty, s.src, u.name AS user_name, k.code_last4,
              to_char(s.updated_at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at
         FROM customer_shelf_stock s JOIN products p ON p.id = s.product_id
         LEFT JOIN users u ON u.id = s.user_id LEFT JOIN lead_portal_codes k ON k.id = s.code_id
        WHERE s.customer_id=$1 ORDER BY p.code`, [cid])).rows;
    const cust = (await query(`SELECT discount FROM customers WHERE id=$1`, [cid])).rows[0];
    const info = await productInfo(cid, Number(cust && cust.discount) || 0, rows.map((r) => r.code));
    return { items: rows.map((r) => ({ code: r.code, name: r.name, qty: Number(r.qty), src: r.src,
      by: r.src === 'customer' ? '고객' + (r.code_last4 ? ' (…' + r.code_last4 + ')' : '') : (r.user_name || '직원'), at: r.at,
      bought12: info[r.code] ? info[r.code].bought12 : 0, avail: info[r.code] ? info[r.code].avail : null })) };
  });

  app.put('/api/lead-portal-admin/shelf', W, async (req, reply) => {
    if (!(await need(reply))) return;
    const b = req.body || {};
    const cid = idOf(b.customer_id); if (!cid) return reply.code(400).send({ error: 'customer_required' });
    const cv = await customerVisible(req.ctx.perm, cid);
    if (cv === null) return reply.code(404).send({ error: 'customer_not_found' });
    if (cv === false) return reply.code(403).send({ error: 'not_your_customer' });
    const q = parseQty(b.qty); if (!q.ok) return reply.code(400).send({ error: 'bad_qty', note: '0 이상의 정수를 입력하세요.' });
    const p = (await query(`SELECT id, code, name FROM products WHERE code=$1 AND deleted_at IS NULL`, [String(b.code || '').trim().toUpperCase()])).rows[0]
      || (await query(`SELECT id, code, name FROM products WHERE code=$1 AND deleted_at IS NULL`, [String(b.code || '').trim()])).rows[0];
    if (!p) return reply.code(404).send({ error: 'unknown_code', note: '없는 부품번호입니다.' });
    const r = await withTx((c) => saveShelf(c, { customerId: cid, productId: Number(p.id), qty: q.qty, src: 'staff', userId: req.ctx.perm.userId }));
    return { ok: true, code: p.code, name: p.name, qty: q.qty, changed: r.changed };
  });

  app.get('/api/lead-portal-admin/shelf/log', R, async (req, reply) => {
    if (!(await need(reply))) return;
    const cid = idOf(req.query.customer_id); if (!cid) return reply.code(400).send({ error: 'customer_required' });
    const cv = await customerVisible(req.ctx.perm, cid);
    if (!cv) return reply.code(cv === null ? 404 : 403).send({ error: cv === null ? 'customer_not_found' : 'not_your_customer' });
    const args = [cid]; let w = '';
    if (req.query.code) { args.push(String(req.query.code)); w = ` AND p.code=$2`; }
    const rows = (await query(
      `SELECT p.code, l.old_qty, l.new_qty, l.src, u.name AS user_name, k.code_last4,
              to_char(l.at AT TIME ZONE 'America/Mexico_City','YYYY-MM-DD HH24:MI') AS at
         FROM customer_shelf_stock_log l JOIN products p ON p.id = l.product_id
         LEFT JOIN users u ON u.id = l.user_id LEFT JOIN lead_portal_codes k ON k.id = l.code_id
        WHERE l.customer_id=$1${w} ORDER BY l.at DESC, l.id DESC LIMIT 200`, args)).rows;
    return { items: rows.map((r) => ({ code: r.code, old: num(r.old_qty), new: num(r.new_qty), at: r.at,
      by: r.src === 'customer' ? '고객' + (r.code_last4 ? ' (…' + r.code_last4 + ')' : '') : (r.user_name || '직원') })) };
  });
}
