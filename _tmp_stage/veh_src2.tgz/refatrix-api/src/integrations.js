// 외부 연동 등록부 — 연동 1건 = integration_endpoints 의 1행.
//
//   URL(테스트/운영) · 메서드 · 인증 · 성공코드 · 계약서를 DB 에 두고 관리자 화면에서 고친다.
//   0200 의 환경변수(CRM_SYNC_*)는 **되돌아갈 자리**로만 남는다:
//   테이블이 없거나(마이그레이션 전) 그 키의 행이 없으면 환경변수 설정으로 동작한다.
import { query } from './db.js';
import { config } from './config.js';

export const CUSTOMER_KEY = 'customer_commercial';

/**
 * 수신 창구별 **키 폴백** — 전용 키를 발급하지 않았으면 여기 적힌 연동의 키를 받아 준다.
 *
 *   상대에게 창구마다 다른 키를 요구하면 연동이 늦어질 뿐 얻는 게 없다.
 *   ⚠ 규칙은 여기 한 곳에만 둔다 — 수신부(검증)와 관리 화면(안내 문구)이 같은 표를 봐야
 *     "서버는 받아 주는데 화면은 안 받는다고 경고하는" 엇갈림이 생기지 않는다. 실제로 그랬다.
 */
export const INBOUND_KEY_FALLBACK = {
  crm_web_lead: 'crm_customer_registration',
  crm_quote_request: 'crm_customer_registration',
};

// ⚠ 준비 여부는 **긍정만 영구 캐시**한다. 예전에는 처음 한 번 확인하고 끝이라,
//   서버가 뜬 뒤에 `npm run migrate` 를 돌리면(=Railway 콘솔에서 하는 방식) 프로세스가
//   재시작될 때까지 계속 "마이그레이션 필요"로 답했다. 이제 없을 때만 30초마다 다시 본다.
let tableReady = false;
let lastProbe = 0;
const PROBE_MS = 30000;
const cache = new Map();          // key → { at, ep }
const CACHE_MS = 15000;           // 화면에서 고친 값이 15초 안에 반영된다

export async function endpointsReady() {
  if (tableReady) return true;
  if (Date.now() - lastProbe < PROBE_MS) return false;
  lastProbe = Date.now();
  try {
    const r = await query(`SELECT to_regclass('public.integration_endpoints') AS t`);
    tableReady = !!(r.rows[0] && r.rows[0].t);
    if (tableReady) cache.clear();   // 이제 막 생겼다면 환경변수 폴백 캐시를 버린다
  } catch (_) { tableReady = false; }
  return tableReady;
}

export function invalidateEndpointCache(key) {
  if (key) cache.delete(key); else cache.clear();
}

/** 환경변수로 만든 대체 설정 — 마이그레이션 전에도 고객 전송이 죽지 않게. */
function fallbackEndpoint(key) {
  if (key !== CUSTOMER_KEY) return null;
  return {
    key, category: 'customer', label: '고객 상거래정보', description: null,
    enabled: !!config.crm.enabled, env: 'test',
    url_test: config.crm.url, url_prod: null,
    method_upsert: config.crm.methodUpsert, method_delete: config.crm.methodDelete,
    auth_header: config.crm.tokenHeader, auth_token: config.crm.token,
    ok_code: config.crm.okCode, user_field: config.crm.userField,
    timeout_ms: config.crm.timeoutMs, contract: {}, source: 'env',
  };
}

export function activeUrl(ep) {
  if (!ep) return '';
  return String((ep.env === 'prod' ? ep.url_prod : ep.url_test) || '').trim();
}

/** 지금 환경의 인증 키. 환경별 키가 비어 있으면 예전 단일 키(auth_token)로 되돌아간다. */
export function activeToken(ep) {
  if (!ep) return '';
  const envTok = ep.env === 'prod' ? ep.auth_token_prod : ep.auth_token_test;
  return String((envTok != null && String(envTok) !== '' ? envTok : ep.auth_token) || '');
}

// 0202 적용 여부(반쪽 배포에서도 저장이 죽지 않게). 긍정만 영구 캐시.
let envTokCols = false;
let envTokProbe = 0;
export async function envTokenColsReady() {
  if (envTokCols) return true;
  if (Date.now() - envTokProbe < PROBE_MS) return false;
  envTokProbe = Date.now();
  try {
    const r = await query(
      `SELECT 1 FROM information_schema.columns
        WHERE table_name='integration_endpoints' AND column_name='auth_token_test' LIMIT 1`);
    envTokCols = r.rows.length > 0;
  } catch (_) { envTokCols = false; }
  return envTokCols;
}

/**
 * 전송에 쓸 설정. 못 찾으면 null.
 *
 *   0214 · 자기 키가 없고 `auth_from` 이 있으면 **그 창구의 키를 물려받는다.**
 *   키를 두 행에 각각 저장하면 나중에 바꿀 때 한쪽만 고치고 잊는다 — 그날부터 한 창구가
 *   조용히 401 을 맞는다. 키는 한 곳에만 두고, 나머지는 어디서 가져올지만 가리킨다.
 *   (자기 키를 발급하는 순간 물려받기는 멈춘다 — 분리하고 싶으면 그냥 발급하면 된다)
 */
export async function getEndpoint(key, _depth = 0) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.ep;
  let ep = null;
  if (await endpointsReady()) {
    try {
      const r = (await query(`SELECT * FROM integration_endpoints WHERE key=$1`, [key])).rows[0];
      if (r) ep = { ...r, timeout_ms: Number(r.timeout_ms), source: 'db' };
    } catch (_) { /* 조회 실패 시 환경변수로 */ }
  }
  if (!ep) ep = fallbackEndpoint(key);
  // 키 물려받기 — 사슬이 꼬여도 멈추게 깊이를 제한한다(자기 자신·순환 방지).
  if (ep && ep.auth_from && String(ep.auth_from) !== String(key) && _depth < 3
      && !activeToken(ep)) {
    try {
      const src = await getEndpoint(String(ep.auth_from), _depth + 1);
      if (src && activeToken(src)) {
        ep = borrowToken(ep, src);
      }
    } catch (_) { /* 물려받기 실패는 인증 없이 보내는 것과 같다 — 화면이 경고한다 */ }
  }
  cache.set(key, { at: Date.now(), ep });
  return ep;
}

export async function listEndpoints() {
  if (!(await endpointsReady())) {
    const f = fallbackEndpoint(CUSTOMER_KEY);
    return f ? [f] : [];
  }
  const rows = (await query(
    `SELECT * FROM integration_endpoints ORDER BY sort_order, id`)).rows;
  const list = rows.map((r) => ({ ...r, timeout_ms: Number(r.timeout_ms), source: 'db' }));
  // 0214 · 목록에서도 물려받은 키를 반영한다 — 목록은 「키 있음」인데 상세는 「없음」이면
  //   어느 쪽을 믿어야 할지 알 수 없다. (추가 조회 없이 같은 목록 안에서 찾는다)
  const byKey = new Map(list.map((e) => [e.key, e]));
  return list.map((e) => {
    if (!e.auth_from || activeToken(e)) return e;
    const src = byKey.get(String(e.auth_from));
    if (!src || !activeToken(src)) return e;
    return borrowToken(e, src);
  });
}

/**
 * 20260924 · 다른 창구의 키를 물려받는다 — **환경이 서로 달라도** 키가 비지 않게.
 *
 *   사고: 「오더상태 (전송)」을 테스트 서버로 켜고 연결 테스트를 하자 CRM 이
 *   `ERR_API_KEY — API key es requerida` 로 답했다. 키가 **아예 안 실려** 나갔다.
 *   예전 물려받기는 원천 창구의 칸(테스트 키·운영 키)을 **칸 그대로** 복사했다.
 *   원천(고객 상거래정보)은 운영으로 돌며 **운영 키만** 갖고 있었고, 받는 쪽은 테스트였다
 *   → 테스트 칸이 비어 「키 없음」으로 호출됐다.
 *
 *   이제: 같은 환경의 키가 원천에 있으면 그것을, 없으면 **원천이 지금 실제로 쓰는 키**를 쓴다.
 *   (디렉터 지시: 오더상태는 고객정보 연동과 **같은 키**를 쓴다 — 그 키가 곧 원천이 쓰는 키다)
 */
export function borrowToken(ep, src) {
  if (!ep || !src) return ep;
  const cur = activeToken(src);
  if (!cur) return ep;
  const pick = (v) => (v != null && String(v) !== '' ? v : cur);
  return { ...ep,
    auth_token: cur,
    auth_token_test: pick(src.auth_token_test),
    auth_token_prod: pick(src.auth_token_prod),
    token_borrowed_from: src.key, token_borrowed_label: src.label || src.key };
}

/** 화면으로 내려보낼 형태 — 토큰은 절대 값으로 내리지 않는다. */
export function publicEndpoint(ep) {
  if (!ep) return null;
  const url = activeUrl(ep);
  const direction = ep.direction === 'in' ? 'in' : 'out';
  return {
    key: ep.key, category: ep.category, label: ep.label, description: ep.description,
    enabled: !!ep.enabled, env: ep.env,
    // 0208 · 방향. 'in' 은 **상대가 우리에게 보낸다** — url_* 대신 inbound_path 가 우리 주소이고,
    //   auth_token_* 는 우리가 발급해서 상대에게 준 키다(전송 대상이 아니라 수신 검증용).
    direction,
    inbound_path: ep.inbound_path || null,
    // 전용 키가 없을 때 대신 받아 주는 연동(있으면). 화면의 안내 문구가 이걸 보고 갈린다.
    key_fallback_from: (direction === 'in' && INBOUND_KEY_FALLBACK[ep.key]) || null,
    url_test: ep.url_test || '', url_prod: ep.url_prod || '',
    active_url: url,
    active_host: url ? url.replace(/^https?:\/\//, '').split('/')[0] : null,
    secure: /^https:/i.test(url),
    method_upsert: ep.method_upsert, method_delete: ep.method_delete,
    auth_header: ep.auth_header,
    auth_in: ep.auth_in || 'header',
    auth_param: ep.auth_param || 'apiKey',
    has_token: !!activeToken(ep),                       // 지금 환경에서 실제로 쓰이는 키가 있는가
    // 0214 · 자기 키가 없어 다른 창구의 키를 쓰고 있으면 어디서 왔는지 알려 준다.
    auth_from: ep.auth_from || '',
    token_borrowed_from: ep.token_borrowed_from || null,
    token_borrowed_label: ep.token_borrowed_label || null,
    has_token_test: !!(ep.auth_token_test || ep.auth_token),
    has_token_prod: !!ep.auth_token_prod,
    ok_code: ep.ok_code, user_field: ep.user_field, timeout_ms: Number(ep.timeout_ms),
    no_retry_codes: ep.no_retry_codes == null ? 'ERR_CUSTOMER_NOT_FOUND' : ep.no_retry_codes,
    // 0213 · 이 창구가 아래 코드로 답하면 fallback_key 창구로 다시 보낸다(자동).
    fallback_key: ep.fallback_key || '',
    fallback_codes: ep.fallback_codes == null ? 'ERR_CUSTOMER_NOT_FOUND' : ep.fallback_codes,
    contract: ep.contract || {},
    // 0218 · 제품 카탈로그 전송 설정(제품 창구에서만 화면에 보인다)
    img_base_url: ep.img_base_url || '',
    body_shape: ep.body_shape || 'lote',
    field_map: ep.field_map || {},
    batch_size: ep.batch_size == null ? 500 : Number(ep.batch_size),
    send_hour_mx: ep.send_hour_mx == null ? 6 : Number(ep.send_hour_mx),
    auto_send: !!ep.auto_send,
    // 0236 · 변경분 자동 전송 · 전체 전송 요일(0236 전이면 null — 화면이 「마이그레이션 필요」로 안내)
    delta_auto: ep.delta_auto == null ? null : !!ep.delta_auto,
    delta_every_min: ep.delta_every_min == null ? null : Number(ep.delta_every_min),
    full_weekday: ep.full_weekday == null ? null : Number(ep.full_weekday),
    delta_ready: ep.delta_auto !== undefined,
    // 0237 · 프로모션 배너 규격(px). 비어 있으면 검사하지 않는다. 0237 전이면 promo_ready=false.
    banner_w: ep.banner_w == null ? null : Number(ep.banner_w),
    banner_h: ep.banner_h == null ? null : Number(ep.banner_h),
    promo_ready: ep.banner_w !== undefined,
    sort_order: ep.sort_order == null ? 100 : Number(ep.sort_order),
    source: ep.source || 'db',
    updated_at: ep.updated_at || null,
  };
}

const EDITABLE = ['category', 'label', 'description', 'enabled', 'env', 'url_test', 'url_prod',
  'method_upsert', 'method_delete', 'auth_header', 'auth_in', 'auth_param', 'ok_code', 'user_field',
  'timeout_ms', 'contract', 'sort_order', 'no_retry_codes', 'fallback_key', 'fallback_codes',
  'auth_from',
  // 0218 · 제품 카탈로그 전송 설정(제품 창구에서만 쓰인다. 다른 창구에서는 값이 있어도 무해).
  'img_base_url', 'batch_size', 'send_hour_mx', 'auto_send',
  // 0219 · 상대 규격에 맞추는 두 가지(추측이 틀려도 배포 없이 화면에서 고친다).
  'body_shape', 'field_map',
  // 0236 · 변경분 자동 전송(주기) · 전체 자동 전송 요일. 컬럼이 없으면(0236 전) 저장에서 조용히 뺀다.
  'delta_auto', 'delta_every_min', 'full_weekday',
  // 0237 · 프로모션 배너 규격. 칸이 없으면(0237 전) 저장에서 조용히 뺀다.
  'banner_w', 'banner_h'];
const DELTA_FIELDS = ['delta_auto', 'delta_every_min', 'full_weekday', 'banner_w', 'banner_h'];
const METHODS = ['POST', 'PUT', 'PATCH', 'DELETE', 'GET'];

/**
 * 메서드 값 정리 (2026-09-24 핫픽스).
 * 브라우저 자동번역이 켜진 채 저장하면 선택칸 글자가 번역돼(POST→CORREO 등) 엉뚱한 값이 오거나,
 * 선택칸에 없는 값이면 빈칸('')이 온다. 공백·소문자는 고쳐 받고, **빈칸은 「바꾸지 않음」**으로 본다.
 */
export function normalizeMethods(p) {
  if (!p || typeof p !== 'object') return p;
  const o = { ...p };
  for (const m of ['method_upsert', 'method_delete']) {
    if (o[m] === undefined) continue;
    const v = String(o[m] == null ? '' : o[m]).trim().toUpperCase();
    if (!v) delete o[m]; else o[m] = v;
  }
  return o;
}

export function validatePatch(p, cur = null) {
  // 수신(direction='in')은 상대 주소가 없다 — 운영 URL 을 요구하면 저장 자체가 막힌다.
  const inbound = String(p.direction || cur?.direction || 'out') === 'in';
  if (p.env != null && !['test', 'prod'].includes(String(p.env))) return 'env_invalid';
  // 인증 위치: 헤더 · 쿼리스트링 · 본문 (CRM 마다 다르다)
  if (p.auth_in != null && !['header', 'query', 'body'].includes(String(p.auth_in))) return 'auth_in_invalid';
  if (p.auth_param != null && String(p.auth_param).trim() && !/^[A-Za-z0-9_.-]{1,60}$/.test(String(p.auth_param).trim())) return 'auth_param_invalid';
  for (const m of ['method_upsert', 'method_delete']) {
    if (p[m] != null && !METHODS.includes(String(p[m]).toUpperCase())) return 'method_invalid';
  }
  if (p.user_field != null && !['login_id', 'name', 'role'].includes(String(p.user_field))) return 'user_field_invalid';
  // 폴백은 **자기 자신을 가리킬 수 없다** — 그러면 같은 실패로 무한히 새 전송이 쌓인다.
  if (p.fallback_key != null && String(p.fallback_key).trim()
      && cur && String(p.fallback_key).trim() === String(cur.key)) return 'fallback_self';
  // 키를 자기 자신에게서 물려받을 수는 없다.
  if (p.auth_from != null && String(p.auth_from).trim()
      && cur && String(p.auth_from).trim() === String(cur.key)) return 'auth_from_self';
  if (p.timeout_ms != null) {
    const n = Number(p.timeout_ms);
    if (!Number.isFinite(n) || n < 1000 || n > 60000) return 'timeout_invalid';
  }
  // 0218 · 제품 카탈로그 전송 설정
  if (p.batch_size != null) {
    const n = Number(p.batch_size);
    if (!Number.isFinite(n) || n < 10 || n > 2000) return 'batch_size_invalid';
  }
  if (p.send_hour_mx != null) {
    const n = Number(p.send_hour_mx);
    if (!Number.isInteger(n) || n < 0 || n > 23) return 'send_hour_invalid';
  }
  if (p.body_shape != null && !['lote', 'array', 'item'].includes(String(p.body_shape))) return 'body_shape_invalid';
  // 0236
  if (p.delta_every_min != null) {
    const n = Number(p.delta_every_min);
    if (!Number.isInteger(n) || n < 5 || n > 1440) return 'delta_every_invalid';
  }
  // 0237 · 배너 규격 — 비우면 검사 안 함. 값이 있으면 정수 px(10~5000).
  for (const f of ['banner_w', 'banner_h']) {
    if (p[f] == null || p[f] === '' || Number(p[f]) === 0) continue;
    const n = Number(p[f]);
    if (!Number.isInteger(n) || n < 10 || n > 5000) return 'banner_size_invalid';
  }
  if (p.full_weekday != null && p.full_weekday !== '') {
    const n = Number(p.full_weekday);
    if (!Number.isInteger(n) || n < 0 || n > 6) return 'full_weekday_invalid';
  }
  if (p.field_map != null) {
    let m = p.field_map;
    if (typeof m === 'string') { try { m = JSON.parse(m); } catch (_) { return 'field_map_invalid'; } }
    if (!m || typeof m !== 'object' || Array.isArray(m)) return 'field_map_invalid';
    const keys = Object.keys(m);
    if (keys.length > 40) return 'field_map_invalid';
    for (const k of keys) {
      const val = m[k] == null ? '' : String(m[k]).trim();
      // 빈 값은 「이 필드를 빼고 보낸다」는 뜻이라 허용한다. 값이 있으면 JSON 키로 쓸 수 있는 모양이어야 한다.
      if (val && !/^[A-Za-z0-9_.\-]{1,60}$/.test(val)) return 'field_map_name_invalid';
    }
  }
  if (p.img_base_url != null) {
    const v = String(p.img_base_url).trim();
    // 사진은 상대 브라우저가 직접 여는 주소다 — 형식이 틀리면 카탈로그 전체에 깨진 사진이 뜬다.
    if (v && !/^https?:\/\//i.test(v)) return 'img_base_invalid';
    if (v && /\s/.test(v)) return 'img_base_space';
  }
  for (const f of ['url_test', 'url_prod']) {
    const v = p[f] == null ? '' : String(p[f]).trim();
    if (v && !/^https?:\/\//i.test(v)) return 'url_invalid';
    // 주소 안에 공백이 있으면 붙여넣을 때 **뒷줄이 딸려온** 것이다.
    //   실제로 그랬다: url_prod 에 「… Content-Type: application/json」 이 붙어 저장돼 있었다.
    //   http 로 시작하기만 하면 통과시키던 검사가 그걸 놓쳤다.
    if (v && /\s/.test(v)) return 'url_space';
  }
  // 운영으로 전환하려면 운영 URL 이 있어야 한다. 빈 주소로 켜 두면 전송이 조용히 멈춘다.
  if (!inbound && String(p.env) === 'prod' && p.url_prod != null && !String(p.url_prod).trim()) return 'url_prod_required';
  return null;
}

/**
 * 붙여넣기 사고를 걸러 낸다 — 키 칸에는 **키만** 들어가야 한다.
 *
 *   개발자가 준 안내문을 그대로 복사하면 이런 게 딸려온다:
 *     `x-api-key: abc123`  ·  `"abc123"`  ·  `abc123 ` (뒤 공백)
 *   그대로 저장하면 헤더 값이 「x-api-key: abc123」 이 되어 상대는 키를 못 읽는다.
 *   화면은 「키 있음」인데 상대는 401 — 원인을 눈으로 찾을 수 없는 종류의 사고다.
 *
 *   names 에는 이 창구가 쓰는 헤더명·파라미터명을 넘긴다(그 이름으로 시작할 때만 떼어낸다.
 *   키 자체에 콜론이 들어갈 수도 있으므로 아무 콜론이나 자르지 않는다).
 */
export function cleanSecret(raw, names = []) {
  let v = String(raw == null ? '' : raw).trim();
  const notes = [];
  const q = v.match(/^(["'`])([\s\S]*)\1$/);
  if (q) { v = q[2].trim(); notes.push('quoted'); }
  for (const n of names) {
    const nm = String(n || '').trim();
    if (!nm) continue;
    const re = new RegExp('^' + nm.replace(/[.*+?^${}()|[\]\\-]/g, '\\$&') + '\\s*[:=]\\s*', 'i');
    if (re.test(v)) { v = v.replace(re, '').trim(); notes.push('name_prefix'); }
  }
  if (/\s/.test(v)) notes.push('has_space');   // 남은 공백은 거의 확실히 사고다 — 경고만 한다
  return { value: v, notes };
}

/** 키를 화면에 **보여 줘도 되는 형태**로. 앞뒤 4글자만 — 개발자가 준 값과 대조하기엔 충분하다. */
export function maskSecret(t) {
  const s = String(t == null ? '' : t);
  if (!s) return null;
  if (s.length <= 8) return '•'.repeat(s.length) + ` (${s.length}자)`;
  return s.slice(0, 4) + '…' + s.slice(-4) + ` (${s.length}자)`;
}

/**
 * 설정 저장 + 변경 이력. auth_token 은 별도 취급:
 *   undefined = 그대로, '' = 지움, 값 = 교체. 이력에는 값 대신 '(변경됨)' 만 남긴다.
 */
export async function saveEndpoint(key, patch, userId) {
  const cur = (await query(`SELECT * FROM integration_endpoints WHERE key=$1`, [key])).rows[0];
  if (!cur) return { error: 'not_found' };
  patch = normalizeMethods(patch);
  const bad = validatePatch(patch, cur);
  if (bad) return { error: bad };

  const sets = [];
  const params = [];
  const changes = {};
  for (const f of EDITABLE) {
    if (patch[f] === undefined) continue;
    if (DELTA_FIELDS.includes(f) && !(f in cur)) continue;       // 0236 전 — 칸이 없으면 건너뛴다
    let v = patch[f];
    if (f === 'enabled' || f === 'auto_send' || f === 'delta_auto') v = !!v;
    else if (f === 'delta_every_min') v = Number(v);
    else if (f === 'full_weekday') v = (v === '' || v == null) ? null : Number(v);
    else if (f === 'banner_w' || f === 'banner_h') v = (v === '' || v == null || Number(v) === 0) ? null : Number(v);
    else if (f === 'timeout_ms' || f === 'sort_order' || f === 'batch_size' || f === 'send_hour_mx') v = Number(v);
    else if (f === 'img_base_url') v = String(v == null ? '' : v).trim();
    else if (f === 'field_map') v = typeof v === 'string' ? v : JSON.stringify(v || {});
    else if (f === 'method_upsert' || f === 'method_delete') v = String(v).toUpperCase();
    else if (f === 'contract') v = typeof v === 'string' ? v : JSON.stringify(v);
    else if (f === 'url_test' || f === 'url_prod') v = String(v == null ? '' : v).trim();
    else if (v != null) v = String(v);
    const jsonCol = (f === 'contract' || f === 'field_map');
    const before = jsonCol ? JSON.stringify(cur[f] || {}) : cur[f];
    const after = v;
    if (String(before ?? '') === String(after ?? '')) continue;
    params.push(v);
    sets.push(`${f}=$${params.length}${jsonCol ? '::jsonb' : ''}`);
    changes[f] = f === 'contract'
      ? { old: '(계약서)', new: '(계약서 수정됨)' }
      : f === 'field_map' ? { old: String(before).slice(0, 300), new: String(v).slice(0, 300) }
      : { old: cur[f] === null ? null : String(cur[f]), new: v === null ? null : String(v) };
  }
  // 인증 키 — 값은 이력에 남기지 않는다('(변경됨)' 만).
  //   undefined = 그대로 · '' = 지움 · 값 = 교체
  const envCols = await envTokenColsReady();
  const tokenPatch = { ...patch };
  let tokenFallback = false;
  if (!envCols && (patch.auth_token_test !== undefined || patch.auth_token_prod !== undefined)) {
    // 0203/0202 미적용 상태(또는 아직 인식 전) — 환경별 컬럼이 없다.
    //   예전에는 이 값을 **조용히 버렸다**: 화면은 "저장되었습니다" 인데 키는 안 들어가서
    //   인증 없이 전송되어 401/403 이 났다. 지금 환경에 해당하는 키를 단일 컬럼에 넣어 준다.
    const envKey = String(patch.env || cur.env) === 'prod' ? 'auth_token_prod' : 'auth_token_test';
    if (patch[envKey] !== undefined) { tokenPatch.auth_token = patch[envKey]; tokenFallback = true; }
  }
  const tokenFields = envCols
    ? ['auth_token', 'auth_token_test', 'auth_token_prod']
    : ['auth_token'];
  // 붙여넣기 사고를 저장 **전에** 걸러 낸다(이름·따옴표·앞뒤 공백).
  const authNames = [patch.auth_header ?? cur.auth_header, patch.auth_param ?? cur.auth_param,
    'apikey', 'api-key', 'x-api-key', 'authorization'];
  const secretNotes = new Set();
  for (const f of tokenFields) {
    if (tokenPatch[f] === undefined) continue;
    const c = cleanSecret(tokenPatch[f], authNames);
    const t = c.value;
    for (const n of c.notes) secretNotes.add(n);
    params.push(t === '' ? null : t);
    sets.push(`${f}=$${params.length}`);
    changes[f] = { old: cur[f] ? '(설정됨)' : null, new: t === '' ? null : '(변경됨)' };
  }
  if (!sets.length) return { ok: true, unchanged: true };

  params.push(userId || null);
  sets.push(`updated_by=$${params.length}`);
  sets.push('updated_at=now()');
  params.push(key);
  await query(`UPDATE integration_endpoints SET ${sets.join(', ')} WHERE key=$${params.length}`, params);
  try {
    await query(
      `INSERT INTO integration_endpoint_changes (endpoint_id, changed_by, changes) VALUES ($1,$2,$3)`,
      [cur.id, userId || null, JSON.stringify(changes)]);
  } catch (_) { /* 이력 실패가 저장을 되돌리지는 않는다 */ }
  invalidateEndpointCache(key);
  return { ok: true, changes, token_fallback: tokenFallback, secret_notes: [...secretNotes] };
}

export async function createEndpoint(body, userId) {
  const key = String(body.key || '').trim();
  if (!/^[a-z0-9_]{3,40}$/.test(key)) return { error: 'key_invalid', note: '영문 소문자·숫자·밑줄 3~40자' };
  const dup = (await query(`SELECT 1 FROM integration_endpoints WHERE key=$1`, [key])).rows[0];
  if (dup) return { error: 'key_taken' };
  const bad = validatePatch(body);
  if (bad) return { error: bad };
  const r = (await query(
    `INSERT INTO integration_endpoints (key, category, label, description, env, url_test, url_prod, contract, sort_order, updated_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10) RETURNING *`,
    [key, String(body.category || 'other'), String(body.label || key), body.description || null,
     ['test', 'prod'].includes(body.env) ? body.env : 'test',
     body.url_test || null, body.url_prod || null,
     JSON.stringify(body.contract || { fields: [], sample_request: '', sample_response: '', raw: '', notes: '' }),
     Number(body.sort_order || 100), userId || null])).rows[0];
  invalidateEndpointCache();
  return { ok: true, endpoint: r };
}
