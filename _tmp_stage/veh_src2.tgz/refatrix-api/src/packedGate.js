import { query } from './db.js';
import { kickOrderStatus } from './orderStatusSync.js';   // 0227 · 포장완료 → CRM 「Preparando despacho」

// 포장완료(packed) 3조건이 처음 모두 충족되면 quotes.packed_at 을 정확히 한 번 기록.
//   ① 확보분이 있는 라인 전부 스캔 완료(packing_box_line 합 >= required · 부분 확보 줄은 확보분) — avl
//   ② 박스 1개 이상 (사진은 선택 — 더 이상 필수 아님)
//   ③ 종이 포장지시서 업로드(quote_packing_docs)
// 재호출 안전(WHERE packed_at IS NULL 가드). 재고·매출엔 영향 없음(packed_at 기록만).
export async function maybeMarkPacked(quoteId, exec = query) {
  const id = Number(quoteId);
  if (!id) return false;
  const cur = (await exec(`SELECT packed_at FROM quotes WHERE id=$1 AND deleted_at IS NULL`, [id])).rows[0];
  if (!cur || cur.packed_at) return false;                                  // 이미 packed 거나 없음
  const doc = (await exec(`SELECT 1 FROM quote_packing_docs WHERE quote_id=$1`, [id])).rows[0];
  if (!doc) return false;                                                   // ③ 미충족
  // ① 스캔 완료 — 즉시재고 라인 required vs scanned
  const lines = (await exec(
    `SELECT l.qty, l.product_id, l.reserved_qty, p.stock_qty
       FROM quote_lines l LEFT JOIN products p ON p.id=l.product_id
      WHERE l.quote_id=$1`, [id])).rows;
  const req = [];
  for (const l of lines) {
    if (!l.product_id) continue;
    const qty = Number(l.qty) || 0;
    const phys = l.stock_qty != null ? Number(l.stock_qty) : 0;
    const ful = Math.max(0, Math.min(Number(l.reserved_qty) || 0, phys));
    if (ful <= 0) continue;   // 2026-11-05 avl · 부분 확보 줄은 확보분만큼 스캔하면 된다(포장 화면과 같은 기준)
    req.push({ product_id: Number(l.product_id), required: Math.min(qty, ful) });
  }
  if (!req.length) return false;
  const scanned = {};
  (await exec(`SELECT product_id, SUM(qty)::int AS s FROM packing_box_line WHERE quote_id=$1 GROUP BY product_id`, [id]))
    .rows.forEach((r) => { scanned[Number(r.product_id)] = Number(r.s) || 0; });
  // 0306 · 같은 SKU 가 여러 줄(키트 둘 · 키트+단품)이면 합계로 비교한다
  const need = {}; req.forEach((l) => { need[l.product_id] = (need[l.product_id] || 0) + l.required; });
  if (!Object.keys(need).every((k) => (scanned[k] || 0) >= need[k])) return false;
  // ② 박스 1개 이상(사진은 선택 — 필수 아님)
  const boxes = (await exec(`SELECT id FROM packing_box WHERE quote_id=$1`, [id])).rows;
  if (!boxes.length) return false;
  // 3조건 충족 → 한 번만 기록
  const r = (await exec(`UPDATE quotes SET packed_at=now() WHERE id=$1 AND packed_at IS NULL RETURNING packed_at`, [id])).rows[0];
  // 트랜잭션 안에서 불릴 수 있다 — 훅은 잠깐 미뤄 커밋 뒤에 읽고, 그래도 놓치면 감시가 줍는다.
  if (r) kickOrderStatus(id, { origin: 'packed' });
  return !!r;
}
