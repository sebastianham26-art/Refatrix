// =====================================================================
// Refatrix ERP · metaAds.js — Meta 광고 문의를 광고별로 나누기 (0295 · 2026-10-23 디렉터 지시)
//
//   「광고별 고유번호(광고 ID)를 ERP 에 넣으면 그 번호에 광고 이름을 내가 붙이고, 광고별로 고객 문의를 골라 보고 싶다」
//
//   문의가 어느 광고에서 왔는지 — 우선순위:
//     ① 사람이 고른 광고(meta_threads.m_ad_id)
//     ② Meta 웹훅의 광고 출처(meta_ad_touches) — 그 고객이 가장 먼저 누른 광고
//        · WhatsApp(ERP Cloud API 번호): messages[].referral { source_type:'ad', source_id = 광고 ID, headline, ctwa_clid }
//        · Messenger / Instagram: messaging[].referral { source:'ADS', ad_id, ads_context_data.ad_title } (message · postback 안에 올 때도 있음)
//     ③ 광고 등록 때 적은 「구분 문구」가 고객 메시지에 들어 있으면 그 광고(웹훅 기록 전 예전 문의용)
//   Graph API 의 대화 목록(/conversations)에는 광고 정보가 없다 — 그래서 웹훅으로 받아 둔다.
// =====================================================================
import { query } from './db.js';
import { savePageMessages } from './metaPageMsgs.js';   // 0300
import { normalizeWaNumber } from './waSend.js';

export const AD_ID_RE = /^[0-9]{5,25}$/;
export const cleanAdId = (v) => { const s = String(v == null ? '' : v).replace(/[\s-]/g, ''); return AD_ID_RE.test(s) ? s : null; };
const cut = (v, n) => { const s = v == null ? '' : String(v).trim(); return s ? s.slice(0, n) : null; };

// ── SQL 조각(meta_threads 별칭 t) — 목록 · 집계가 같은 규칙을 쓰게 한 곳에 ──
export const AD_TOUCH_SQL = `(SELECT x.ad_id FROM meta_ad_touches x WHERE x.platform = t.platform AND x.user_id = t.user_id ORDER BY x.at, x.id LIMIT 1)`;
// 1112 · 2026-11-12 디렉터: 「구분 문구」는 고객 말뿐 아니라 **우리 쪽 메시지(광고 자동 응답 첫 줄 「Meta_0001」 등)**에서도 찾는다.
//   Buen Fin 광고의 Messenger 자동 응답 첫 줄이 「Meta_0001」인데 고객 말만 보느라 「광고 외」로 빠지던 것.
//   대화 전체(Graph 로 가져온 messages) + Messenger 웹훅으로 받은 메시지(meta_page_messages)
export const AD_TEXT_SQL = `(SELECT a.ad_id FROM meta_ads a WHERE COALESCE(a.match_text, '') <> '' AND (
                               strpos(lower(COALESCE(t.customer_text, '')), lower(a.match_text)) > 0
                               OR strpos(lower(CASE WHEN jsonb_typeof(t.messages) = 'array' THEN t.messages::text ELSE '' END), lower(a.match_text)) > 0
                               OR (t.platform = 'messenger' AND EXISTS (SELECT 1 FROM meta_page_messages pm WHERE pm.psid = t.user_id AND strpos(lower(COALESCE(pm.text, '')), lower(a.match_text)) > 0)))
                             ORDER BY length(a.match_text) DESC, a.ad_id LIMIT 1)`;
// 1105 · 대화 메시지에 광고 ID(12로 시작하는 15~20자리 숫자 — 예: 120258634372340339)가 보이면 그 광고
//   전화번호(10~13자리)와 겹치지 않게 15자리 이상만. 등록 안 된 광고여도 그 ID 로 나눈다(목록에 「미등록 …」).
export const AD_ID_TEXT_RE = '(?:^|[^0-9])(12[0-9]{13,18})(?:[^0-9]|$)';
//   1105c · 앞 3개만이 아니라 대화 전체에서 처음 보이는 것(봇 안내문 첫 줄에 오는 경우) + Messenger 웹훅 메시지
export const AD_MSG_SQL = `COALESCE((SELECT substring(e->>'text' from '${AD_ID_TEXT_RE}')
                             FROM jsonb_array_elements(CASE WHEN jsonb_typeof(t.messages) = 'array' THEN t.messages ELSE '[]'::jsonb END) WITH ORDINALITY AS mm(e, o)
                            WHERE (e->>'text') ~ '${AD_ID_TEXT_RE}' ORDER BY mm.o LIMIT 1),
                           (SELECT substring(pm.text from '${AD_ID_TEXT_RE}') FROM meta_page_messages pm
                             WHERE t.platform = 'messenger' AND pm.psid = t.user_id AND pm.text ~ '${AD_ID_TEXT_RE}' ORDER BY pm.at, pm.id LIMIT 1))`;
export const AD_EXPR = `COALESCE(t.m_ad_id, ${AD_TOUCH_SQL}, ${AD_MSG_SQL}, ${AD_TEXT_SQL})`;
export const AD_SRC_EXPR = `CASE WHEN t.m_ad_id IS NOT NULL THEN 'manual' WHEN ${AD_TOUCH_SQL} IS NOT NULL THEN 'meta' WHEN ${AD_MSG_SQL} IS NOT NULL THEN 'mensaje' WHEN ${AD_TEXT_SQL} IS NOT NULL THEN 'texto' END`;
export function adIdInText(text) { const m = String(text || '').match(new RegExp(AD_ID_TEXT_RE)); return m ? m[1] : null; }

// ── 웹훅 → 광고 출처 기록 ──
async function saveTouch(q, t) {
  if (!t.ad_id || !t.user_id) return false;
  const r = await q(
    `INSERT INTO meta_ad_touches (platform, user_id, ad_id, at, headline, source_url, ref, ctwa_clid, event_key)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (event_key) DO NOTHING RETURNING id`,
    [t.platform, t.user_id, t.ad_id, t.at.toISOString(), cut(t.headline, 300), cut(t.source_url, 600), cut(t.ref, 200), cut(t.ctwa_clid, 300), t.event_key]);
  return !!(r.rows && r.rows[0]);
}

// WhatsApp 수신 메시지 1건(웹훅 value.messages[i])의 광고 출처
export function waReferralOf(m) {
  const r = m && m.referral;
  if (!r) return null;
  const ad = cleanAdId(r.source_id);
  if (!ad || (r.source_type && String(r.source_type).toLowerCase() !== 'ad')) return null;
  const from = normalizeWaNumber(m.from);
  if (!from) return null;
  const n = Number(m.timestamp);
  return { platform: 'whatsapp', user_id: from, ad_id: ad, at: Number.isFinite(n) && n > 0 ? new Date(n * 1000) : new Date(),
    headline: r.headline || null, source_url: r.source_url || null, ref: null, ctwa_clid: r.ctwa_clid || null,
    event_key: 'wa:' + (m.id || `${from}:${ad}:${m.timestamp || ''}`) };
}
export async function recordWaReferral(m, q = query) {
  const t = waReferralOf(m);
  if (!t) return false;
  try { return await saveTouch(q, t); } catch (_) { return false; }   // 0295 전이면 테이블 없음
}

// Messenger(object=page) · Instagram(object=instagram) 웹훅 본문의 광고 출처들
export function pageReferralsOf(body) {
  const out = [];
  if (!body || !['page', 'instagram'].includes(body.object) || !Array.isArray(body.entry)) return out;
  const platform = body.object === 'instagram' ? 'instagram' : 'messenger';
  for (const e of body.entry) {
    for (const ev of (e && e.messaging) || []) {
      if (!ev || (ev.message && ev.message.is_echo)) continue;   // 우리 페이지가 보낸 메시지
      const ref = ev.referral || (ev.message && ev.message.referral) || (ev.postback && ev.postback.referral) || null;
      if (!ref) continue;
      const ad = cleanAdId(ref.ad_id);
      if (!ad) continue;
      const user = ev.sender && ev.sender.id ? String(ev.sender.id) : null;
      if (!user || (e.id && user === String(e.id))) continue;
      const ts = Number(ev.timestamp);
      const ctx = ref.ads_context_data || {};
      out.push({ platform, user_id: user, ad_id: ad, at: Number.isFinite(ts) && ts > 0 ? new Date(ts > 1e12 ? ts : ts * 1000) : new Date(),
        headline: ctx.ad_title || null, source_url: ctx.photo_url || ctx.video_url || null, ref: ref.ref || null, ctwa_clid: null,
        event_key: `${platform}:${(ev.message && ev.message.mid) || `${user}:${ad}:${ev.timestamp || ''}`}` });
    }
  }
  return out;
}
export async function applyPageWebhook(body, q = query) {
  const out = { referrals: 0, stored: 0 };
  for (const t of pageReferralsOf(body)) {
    out.referrals++;
    try { if (await saveTouch(q, t)) out.stored++; } catch (_) { /* 0295 전 */ }
  }
  // 0300 · Messenger 메시지 실시간 기록(고객 포털 대화) — 실패해도 광고 기록은 그대로
  try { const m = await savePageMessages(body, q); out.messages = m.stored; } catch (_) { /* 0300 전 */ }
  return out;
}

// ── 페이지를 앱 웹훅에 연결(Messenger 광고 출처를 받으려면 한 번) ──
//   POST /{page-id}/subscribed_apps?subscribed_fields=messages,messaging_referrals,messaging_postbacks — 페이지 토큰 · pages_manage_metadata 필요
let postOverride = null;          // 시험용 — (url) => {ok,status,json}
export function setMetaAdsPost(fn) { postOverride = fn || null; }
// 0300 · message_echoes — 직원이 Business Suite 에서 보낸 답장도 받아 포털 대화창 · ERP 에 같이 보인다
export const PAGE_FIELDS = 'messages,messaging_referrals,messaging_postbacks,message_echoes';
export async function subscribePage({ pageId, token, version = 'v20.0' }) {
  const url = `https://graph.facebook.com/${version}/${encodeURIComponent(pageId)}/subscribed_apps?subscribed_fields=${PAGE_FIELDS}&access_token=${encodeURIComponent(token)}`;
  let r;
  if (postOverride) r = await postOverride(url);
  else {
    try { const res = await fetch(url, { method: 'POST' }); const j = await res.json().catch(() => ({})); r = { ok: res.ok && !j.error, status: res.status, json: j }; }
    catch (e) { r = { ok: false, status: 0, json: { error: { message: 'network' } } }; }
  }
  if (r.ok && r.json && r.json.success !== false) return { ok: true };
  const e = (r.json && r.json.error) || {};
  return { ok: false, error: `${e.code ? '#' + e.code + ' ' : ''}${e.message || 'http_' + r.status}`.slice(0, 300) };
}
