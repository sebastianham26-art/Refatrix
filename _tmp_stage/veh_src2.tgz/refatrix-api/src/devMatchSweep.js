// =====================================================================
// Refatrix ERP · devMatchSweep.js — 개발목록 ↔ 제품 카탈로그 자동 매칭
//   목적(디렉터 요청 2026-08-01): 제품 카탈로그(교차참조)·제품마스터가
//   정기/비정기로 업데이트될 때, 개발목록(개발필요내용)의 미완료 경쟁사
//   코드가 우리 제품과 매칭되면 → 경쟁사 코드 옆에 우리 CTR 코드를 붙이고
//   자동으로 「개발완료(developed)」 처리한다.
//
//   매칭 기준(개발필요내용 화면과 동일): 정규화 코드(대소문자·기호 무시)로
//   ① products.code(CTR) ② product_syd_codes ③ product_oe_codes(직접 OE · 0228) ④ product_xref_codes 순,
//   ⑤ (0325) 크로스레퍼런스 마스터 — 경쟁사 코드 → 마스터 같은 행의 SYD → ERP 에 등록된 SYD → CTR.
//   요청에 경쟁사 브랜드(input_brand: BAW·GROB·VAZLO·KYB·MOOG)가 적혀 있으면 견적과 같은 규칙:
//     ⑤마스터(그 브랜드 칸만) → ④교차참조 → ①CTR. (경쟁사 숫자 코드가 SYD 와 우연히 같을 수 있어 ②③은 쓰지 않는다)
//   대조하는 코드(2026-10-12 확대): 경쟁사 코드(input_code) 전체 + 한 칸에 여러 코드를
//   「/ , ; |」·줄바꿈으로 적은 경우 각각 + 검토 단계에서 넣은 SYD 코드(review_syd_code).
//   ⚠ 가장 높은 우선순위에서 서로 다른 제품이 2개 이상 걸리면 「후보 여럿」으로 두고
//     자동 완료하지 않는다(엉뚱한 제품으로 고객 오퍼가 나가는 것을 막음) — 결과의 ambiguous 로 보고.
//
//   호출 지점:
//   · 제품마스터 업로드 커밋 / 신규 제품 수동 생성 (productRoutes)
//   · 제품 수정(코드·SYD·OE 변경) / 파생 데이터 재동기화 (productRoutes — 2026-10-12, scheduleDevMatchSweep 비동기)
//   · 교차참조 카탈로그 업로드 / 스냅샷 복원 (xrefRoutes)
//   · 12시간 주기 + 서버 기동 시 1회 스위퍼 (devRequestRoutes — 다른 경로 보강)
//   · 수동 점검 버튼 POST /api/dev-requests/match-sweep
//
//   완료 처리 시: result_product_id·result_ctr_code·developed_at(오늘) 기록,
//   감사로그(행별) + 관련자(고객 담당영업+디렉터)에게 집계 1건씩
//   dev_complete 알림 할일(기존 수동 개발완료와 동일 kind, 스팸 방지 위해 묶음).
// =====================================================================
import { query } from './db.js';
import { logEvent } from './audit.js';
import { normCode } from './devDemand.js';
import { generateOfferSheets } from './offerSheets.js';
import { scheduleDevReqPush } from './devReqPush.js';   // 2026-11-09 · 자동 개발완료 → 플랫폼 목록에서 해제
import { xrefMasterReady, masterIndexFor, normBrand, COMPETITOR_BRANDS } from './xrefMaster.js';   // 0325 · 크로스레퍼런스 마스터(경쟁사 → SYD → CTR)

function clip1(s, max) { s = String(s == null ? '' : s); return s.length > max ? s.slice(0, max) + '…' : s; }

// ── 개발완료 후속 파이프라인 (디렉터 요청 2026-08-01) ──
//   "개발완료 = 고객 오퍼 + 재고검증 → 구매 제안"
//   ① 개발요청의 수요를 부족분 대장(stock_shortages)에 적재
//      — 부족분 대장은 이미 ⓐ 부족분/발주 화면(공장 주문 근거) ⓑ Offer Sheet 생성기
//        ⓒ 판매 시 자동 해소(0156) 에 연결돼 있어, 여기 한 번만 적으면
//        구매 제안·오퍼·판매 추적이 전부 기존 흐름을 탄다.
//   ② 재고검증: 재고가 있으면 → 즉시 고객별 Offer Sheet 생성(기존 생성기 재사용).
//      재고가 없으면 → 부족분(open)이 그대로 "즉시 구매 제안"이 되고,
//      이후 수입입고 승인 시 기존 훅이 자동으로 오퍼시트를 만든다.
//   중복 가드: note 의 [devreq:<id>] 마커로 같은 개발요청의 재적재 방지(멱등).
// 개발요청 수요 → 부족분 대장 적재만(멱등). 오퍼시트 생성은 호출자가 정한다.
//   반환: 새로 적재한 건수
export async function ensureDevDemand({ productId, rows, userId = null, exec = query }) {
  let n = 0;
  if (!productId || !Array.isArray(rows) || !rows.length) return n;
  for (const r of rows) {
    const marker = `[devreq:${Number(r.id)}]`;
    const qty = Number(r.requested_qty) > 0 ? Number(r.requested_qty) : 1;   // 수량 미입력 접수도 최소 1개 신호
    const note = clip1(`개발완료 오퍼·발주 제안 — 개발요청 ${marker} 경쟁사코드 ${r.input_code || '-'}`, 300);
    const ins = await exec(
      `INSERT INTO stock_shortages
         (product_id, customer_id, sales_invoice_id, requested_qty, fulfilled_qty, shortage_qty,
          occurred_at, source_quote_id, note, created_by)
       SELECT $1::bigint,$2::bigint,NULL,$3::numeric,0,$3::numeric,CURRENT_DATE,$4::bigint,$5,$6::bigint
        WHERE NOT EXISTS (SELECT 1 FROM stock_shortages ss WHERE ss.note LIKE $7)`,
      [productId, r.customer_id || null, qty, r.source_quote_id || null, note, userId, `%${marker}%`]);
    if (ins.rowCount) n += ins.rowCount;
  }
  return n;
}

export async function pushDevDemandAndOffer({ productId, rows, userId = null }) {
  const out = { shortages: 0, stock_qty: null, offer_sheets: 0, offer_items: 0 };
  if (!productId || !Array.isArray(rows) || !rows.length) return out;
  out.shortages = await ensureDevDemand({ productId, rows, userId });

  // 재고검증
  try {
    const p = (await query(`SELECT stock_qty FROM products WHERE id=$1`, [productId])).rows[0];
    out.stock_qty = p && p.stock_qty != null ? Number(p.stock_qty) : 0;
  } catch (_) { out.stock_qty = null; }

  // 재고가 있으면 → 기다리던 수요(방금 적재분 포함)로 고객별 오퍼시트 즉시 생성
  if (out.stock_qty != null && out.stock_qty > 0) {
    try {
      const gen = await generateOfferSheets(query, { productIds: [Number(productId)], userId, origin: 'auto' });
      out.offer_sheets = Number(gen.sheets) || 0;
      out.offer_items = Number(gen.items) || 0;
    } catch (_) { /* 0151 미적용 등 — 부족 적재는 유지 */ }
  }
  return out;
}

// 개발요청 1건이 대조할 정규화 코드들 — 전체 코드, 구분자로 나눈 각 코드, 검토 SYD 코드.
//   나눈 조각은 4자 미만이면 버린다(「L」「R」「2」 같은 꼬리표가 짧은 코드와 우연히 맞는 것을 막음).
const SPLIT_RE = /[,;/|\n\r]+/;
export function devRequestKeys(r) {
  const keys = new Set();
  const add = (v, min = 1) => { const n = normCode(v); if (n && n.length >= min) keys.add(n); };
  const raw = String(r && r.input_code != null ? r.input_code : '');
  add(raw);
  const parts = raw.split(SPLIT_RE).map((x) => x.trim()).filter(Boolean);
  if (parts.length > 1) for (const p of parts) add(p, 4);
  if (r && r.review_syd_code) {
    const sp = String(r.review_syd_code).split(SPLIT_RE).map((x) => x.trim()).filter(Boolean);
    for (const p of sp) add(p, sp.length > 1 ? 4 : 1);
  }
  return [...keys];
}

// 요청 1건 판정(순수 함수 — 테스트용 분리).
//   index: Map(norm → Map(productId → pri))
//   반환: {product_id, pri} | {ambiguous:[pid...], pri} | null
export function pickDevMatch(keys, index, allow = null) {
  let best = null; const pids = new Set();
  for (const k of keys) {
    const m = index.get(k); if (!m) continue;
    for (const [pid, pri] of m) {
      if (allow && !allow.has(pri)) continue;
      if (best == null || pri < best) { best = pri; pids.clear(); pids.add(pid); }
      else if (pri === best) pids.add(pid);
    }
  }
  if (best == null) return null;
  if (pids.size > 1) return { ambiguous: [...pids], pri: best };
  return { product_id: [...pids][0], pri: best };
}

// 0325 · 우선순위 → 매칭 경로 이름(개발필요내용 「매칭결과」 열 · 팝업 표시)
export const VIA_BY_PRI = { 1: 'ctr', 2: 'syd', 3: 'oe', 4: 'xref', 5: 'master' };

// 0325 · 마스터 판정(순수 함수) — master: Map(norm → Map(brand → Set(pid)))
//   brand 가 있으면 그 브랜드 칸에서만. 1개 → {product_id, pri:5} · 여러 개 → {ambiguous} · 없음 → null
export function pickMasterMatch(keys, master, brand = null) {
  const pids = new Set();
  for (const k of keys) {
    const byBrand = master && master.get(k); if (!byBrand) continue;
    for (const [b, set] of byBrand) {
      if (brand && b !== brand) continue;
      for (const pid of set) pids.add(pid);
    }
  }
  if (!pids.size) return null;
  if (pids.size > 1) return { ambiguous: [...pids], pri: 5 };
  return { product_id: [...pids][0], pri: 5 };
}

// 0325 · 요청 1건 최종 판정 — 브랜드 규칙 포함(순수 함수)
export function decideDevMatch(keys, index, master, inputBrand) {
  const b = normBrand(inputBrand);
  const comp = b && COMPETITOR_BRANDS.includes(b) ? b : null;
  if (!comp) {
    return pickDevMatch(keys, index) || pickMasterMatch(keys, master, null);
  }
  return pickMasterMatch(keys, master, comp)
    || pickDevMatch(keys, index, new Set([4]))
    || pickDevMatch(keys, index, new Set([1]));
}

// 미완료 개발요청을 카탈로그와 대조해 매칭분을 developed 로 전환.
// 반환: { checked, matched, items:[…], ambiguous:[{id, input_code, customer_name, candidates:[CTR…]}] }
export async function sweepDevRequestMatches({ userId = null, notify = true } = {}) {
  const xm = await xrefMasterReady();   // 0325 칸(input_brand · result_match_via …)과 마스터가 있나
  const reqs = (await query(
    `SELECT d.id, d.input_code, d.review_syd_code, d.customer_id, d.requested_qty, d.source_quote_id,
            ${xm ? 'd.input_brand' : 'NULL::text AS input_brand'},
            c.name AS customer_name, c.owner_id AS customer_owner_id
       FROM product_dev_requests d
       LEFT JOIN customers c ON c.id = d.customer_id
      WHERE d.deleted_at IS NULL
        AND d.status IN ('received','reviewed','factory_requested')
        AND (NULLIF(TRIM(d.input_code),'') IS NOT NULL OR NULLIF(TRIM(d.review_syd_code),'') IS NOT NULL)`)).rows;
  if (!reqs.length) return { checked: 0, matched: 0, items: [], ambiguous: [] };

  const keysById = new Map();
  const wanted = new Set();
  for (const r of reqs) { const ks = devRequestKeys(r); keysById.set(Number(r.id), ks); for (const k of ks) wanted.add(k); }
  if (!wanted.size) return { checked: reqs.length, matched: 0, items: [], ambiguous: [] };

  // norm → Map(productId → 최고 우선순위)  (CTR 1 > SYD 2 > OE 3 > xref 4)
  const index = new Map();
  const claim = (norm, productId, pri) => {
    if (!norm || !wanted.has(norm)) return;
    const pid = Number(productId); if (!pid) return;
    if (!index.has(norm)) index.set(norm, new Map());
    const m = index.get(norm);
    if (!m.has(pid) || m.get(pid) > pri) m.set(pid, pri);
  };
  const prods = (await query(`SELECT id, code FROM products WHERE deleted_at IS NULL`)).rows;
  const codeById = new Map();
  for (const p of prods) { codeById.set(Number(p.id), p.code); claim(normCode(p.code), p.id, 1); }
  const syds = (await query(`SELECT product_id, syd_code FROM product_syd_codes`)).rows;
  for (const s of syds) claim(normCode(s.syd_code), s.product_id, 2);
  // 0228 — ③ OE(직접 OE 만 — FOR 는 조립품 번호라 「개발완료」 근거가 못 된다). oe_norm 은 normCode 와 같은 규칙.
  try {
    const oes = (await query(`SELECT product_id, oe_norm FROM product_oe_codes WHERE rel='oe'`)).rows;
    for (const o of oes) claim(String(o.oe_norm || ''), o.product_id, 3);
  } catch (_) { /* 0228 미적용 시 무시 */ }
  try {
    const xrefs = (await query(`SELECT product_id, norm_code FROM product_xref_codes`)).rows;
    for (const x of xrefs) claim(String(x.norm_code || ''), x.product_id, 4);
  } catch (_) { /* 0130 미적용 시 무시 */ }
  // 삭제된 제품(활성 제품 목록에 없음)은 후보에서 뺀다
  for (const m of index.values()) for (const pid of [...m.keys()]) if (!codeById.has(pid)) m.delete(pid);
  // 0325 · ⑤ 크로스레퍼런스 마스터(경쟁사 코드 → SYD → CTR)
  let master = new Map();
  if (xm) {
    try { master = await masterIndexFor([...wanted]); } catch (_) { master = new Map(); }
    for (const byBrand of master.values()) for (const set of byBrand.values()) for (const pid of [...set]) if (!codeById.has(pid)) set.delete(pid);
  }

  const items = [];
  const ambiguous = [];
  for (const r of reqs) {
    const h = decideDevMatch(keysById.get(Number(r.id)) || [], index, master, r.input_brand);
    if (!h) continue;
    if (h.ambiguous) {
      const cands = h.ambiguous.map((pid) => codeById.get(pid)).filter(Boolean).sort();
      ambiguous.push({ id: Number(r.id), input_code: r.input_code, input_brand: r.input_brand || null, customer_name: r.customer_name || null,
        candidates: cands, via: VIA_BY_PRI[h.pri] || null });
      continue;
    }
    const ctr = codeById.get(h.product_id);
    if (!ctr) continue;
    const via = VIA_BY_PRI[h.pri] || null;
    const upd = await query(
      `UPDATE product_dev_requests
          SET status='developed',
              developed_at=COALESCE(developed_at, CURRENT_DATE),
              result_product_id=$1, result_ctr_code=$2,
              updated_by=$3, updated_at=now()${xm ? `,
              result_match_via=$5, auto_matched_at=now(), match_candidates=NULL, match_checked_at=now()` : ''}
        WHERE id=$4 AND deleted_at IS NULL AND status IN ('received','reviewed','factory_requested')
        RETURNING id`,
      xm ? [h.product_id, ctr, userId, Number(r.id), via] : [h.product_id, ctr, userId, Number(r.id)]);
    if (!upd.rows.length) continue;   // 동시 실행 등으로 이미 전환된 행 — 후속 처리 제외
    logEvent({
      userId, action: 'update', target: `dev_request:${r.id}`,
      detail: { auto_match: true, input_code: r.input_code, ctr, via },
    });
    items.push({
      via, input_brand: r.input_brand || null,
      id: Number(r.id), input_code: r.input_code, ctr_code: ctr, product_id: h.product_id,
      customer_id: r.customer_id != null ? Number(r.customer_id) : null,
      requested_qty: r.requested_qty != null ? Number(r.requested_qty) : null,
      source_quote_id: r.source_quote_id != null ? Number(r.source_quote_id) : null,
      customer_name: r.customer_name || null, customer_owner_id: r.customer_owner_id != null ? Number(r.customer_owner_id) : null,
    });
  }

  if (items.length) scheduleDevReqPush();

  // 0325 · 후보 여럿(자동 완료 안 함)은 요청에 후보를 적어 둔다 — 「매칭결과」 열에 「후보: A / B」로 보인다.
  //   이번에 후보가 사라진 요청은 지운다.
  if (xm) {
    try {
      for (const a of ambiguous) {
        await query(`UPDATE product_dev_requests SET match_candidates=$1, match_checked_at=now() WHERE id=$2 AND status IN ('received','reviewed','factory_requested')`,
          [a.candidates.join(' / ').slice(0, 500) || null, a.id]);
      }
      const ambIds = ambiguous.map((a) => a.id);
      await query(
        `UPDATE product_dev_requests SET match_candidates=NULL
          WHERE match_candidates IS NOT NULL AND status IN ('received','reviewed','factory_requested')
            AND NOT (id = ANY($1::bigint[]))`, [ambIds]);
    } catch (_) { /* 표시용 — 실패해도 매칭 결과는 유지 */ }
  }

  // 개발완료 후속: 수요 → 부족분 대장 + 재고검증 → 오퍼시트/구매 제안 (제품 단위로 묶어 처리)
  let offerSheets = 0, shortageRecords = 0, noStockProducts = 0;
  if (items.length) {
    const byProduct = new Map();
    for (const it of items) {
      if (!byProduct.has(it.product_id)) byProduct.set(it.product_id, []);
      byProduct.get(it.product_id).push(it);
    }
    for (const [pid, rows] of byProduct) {
      try {
        const res = await pushDevDemandAndOffer({ productId: pid, rows, userId });
        offerSheets += res.offer_sheets; shortageRecords += res.shortages;
        if (res.stock_qty != null && res.stock_qty <= 0) noStockProducts++;
      } catch (_) { /* best-effort */ }
    }
  }

  // 집계 알림(스팸 방지: 수신자별 1건) — 고객 담당영업 + 디렉터. 기존 개발완료 알림과 동일 kind.
  if (notify && items.length) {
    try {
      const recipients = new Set();
      for (const it of items) if (it.customer_owner_id) recipients.add(it.customer_owner_id);
      const dirs = (await query(`SELECT id FROM users WHERE role='director' AND deleted_at IS NULL`)).rows;
      for (const u of dirs) recipients.add(Number(u.id));
      const lines = items.slice(0, 15).map((it) =>
        `${it.input_brand ? it.input_brand + ' ' : ''}${it.input_code} → ${it.ctr_code}${it.via === 'master' ? ' (크로스레퍼런스·SYD 경유)' : ''}${it.customer_name ? ' (' + it.customer_name + ')' : ''}`);
      const more = items.length > 15 ? ` 외 ${items.length - 15}건` : '';
      const title = `개발완료(카탈로그 자동 매칭): ${items.length}건`;
      const tail = `\n— 오퍼시트 ${offerSheets}건 자동 생성 · 부족분(발주 근거) ${shortageRecords}건 기록`
        + (noStockProducts ? ` · 재고 없는 제품 ${noStockProducts}종 → 즉시 구매 검토 필요(부족분/발주 화면)` : '');
      const detail = clip1(`카탈로그/제품마스터 업데이트로 개발목록의 경쟁사 코드가 우리 제품과 매칭되어 자동 개발완료 처리되었습니다(경쟁사 코드 → CTR 코드). 고객에게 안내하세요 — 영업 > 개발 필요 [고객별]에서 오퍼시트를 만들 수 있습니다.\n` + lines.join('\n') + more + tail, 1800);
      for (const uid of recipients) {
        await query(
          `INSERT INTO todos (title, detail, assignee_id, due_date, kind, created_by)
           VALUES ($1,$2,$3,CURRENT_DATE,'dev_complete',$4)`,
          [title, detail, uid, userId]);
      }
    } catch (_) { /* 알림 실패해도 완료 처리 자체는 유지 */ }
  }
  return { checked: reqs.length, matched: items.length, items, ambiguous, offer_sheets: offerSheets, shortage_records: shortageRecords, no_stock_products: noStockProducts };
}

// ── 제품 수정 등 잦은 변경용 비동기 예약 (2026-10-12) ──
//   요청 응답을 기다리게 하지 않고, 짧은 시간 안의 연속 수정은 1회로 묶는다(디바운스).
//   이미 도는 중이면 끝난 뒤 1회 더 돌린다(그 사이 바뀐 코드를 놓치지 않음).
let _dmTimer = null, _dmRunning = false, _dmAgain = false, _dmUser = null;
export function scheduleDevMatchSweep({ userId = null, delayMs = 3000 } = {}) {
  _dmUser = userId;
  if (_dmRunning) { _dmAgain = true; return; }
  if (_dmTimer) clearTimeout(_dmTimer);
  _dmTimer = setTimeout(async () => {
    _dmTimer = null; _dmRunning = true;
    try { await sweepDevRequestMatches({ userId: _dmUser, notify: true }); } catch (_) { /* best-effort */ }
    _dmRunning = false;
    if (_dmAgain) { _dmAgain = false; scheduleDevMatchSweep({ userId: _dmUser, delayMs }); }
  }, Math.max(0, Number(delayMs) || 0));
  if (_dmTimer && typeof _dmTimer.unref === 'function') _dmTimer.unref();
}
