// =====================================================================
// Refatrix ERP · priceMaster.js  (2026-09-24 · v2 · 마이그레이션 0229)
// 가격 마스터 — FOB 구매가(USD) · List 정가(MXN) 테이블 + 날짜별 이력 + 변경 도구
//             + 경쟁사 SYD 리스트 보관·비교 + 구매 기록의 FOB 검증.
//
// 가격의 흐름(설계서 REFATRIX_설계_2026-09-24_price_master_v2.md)
//   · List → 판매가 = List × (1 − 고객 할인율)  (견적이 이미 이렇게 계산 — 무변경)
//   · FOB  → 구매 기록 단가를 주문일 당시 FOB 와 비교
//   · SYD  → 날짜별 리스트 · 직전 리스트와 비교 · 우리 List 제안가
//
// 현재값은 제품 행(products.list_price · fob_usd · list_price_syd), 이력은 product_price_history.
// 계산식은 **SQL 한 곳**(nvSql)에만 있다 — 미리보기와 실제 적용이 같은 식을 쓴다.
//
// 결정(2026-09-24 디렉터)
//   반올림 기본 0.01 · 정가만(고객가는 할인율) · 기본 활성만 · PIN 확인
//   구매 검증 허용 오차 0(1센트라도 다르면 표시) · CTR 1개에 SYD 여럿이면 **가장 높은 SYD**
//   SYD 목표 비율 기본값 = 현재 실제 평균(CTR ÷ SYD)
// =====================================================================
import { query, withTx } from './db.js';

export const PRICE_TYPES = ['list', 'fob'];
export const PRICE_COL = { list: 'list_price', fob: 'fob_usd' };   // SQL 에 끼워 넣는 칼럼 — 이 표 밖의 값은 쓰지 않는다
export const ROUNDINGS = { list: [0.01, 1, 10], fob: [0.001, 0.01] };
export const DEFAULT_ROUNDING = 0.01;
export const MAX_SELECTED = 20000;
const MX_OFFSET_MIN = -360;              // 멕시코 중부시간(UTC-6, 서머타임 없음)
const PROBE_MS = 30000;

const colOf = (t) => { const c = PRICE_COL[t]; if (!c) throw new Error('bad_price_type'); return c; };
export const normType = (t) => (t === 'fob' ? 'fob' : 'list');

// ── 준비 여부(0229) — 긍정만 영구 캐시 ─────────────────────────────────
let ready = false; let probeAt = 0;
export async function priceMasterReady(force = false) {
  if (ready) return true;
  if (!force && Date.now() - probeAt < PROBE_MS) return false;
  probeAt = Date.now();
  try {
    const r = await query(`SELECT to_regclass('public.product_price_history') AS h, to_regclass('public.syd_price_lists') AS s`);
    ready = !!(r.rows[0] && r.rows[0].h && r.rows[0].s);
  } catch (_) { ready = false; }
  return ready;
}
export function _resetReadyForTest() { ready = false; probeAt = 0; }

// ── 날짜 · 환율 ──────────────────────────────────────────────────────
export function mxToday(now = Date.now()) {
  return new Date(now + MX_OFFSET_MIN * 60000).toISOString().slice(0, 10);
}
export function isYmd(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s || ''))) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}
/** 최신 USD→MXN 환율(재무 › 환율). 없으면 null — 배수 칸만 비고 나머지는 동작한다. */
export async function latestFx(exec = query) {
  try {
    const r = (await exec(
      `SELECT rate, to_char(rate_date,'YYYY-MM-DD') AS d FROM fx_rates
        WHERE base='USD' AND quote='MXN' ORDER BY rate_date DESC LIMIT 1`)).rows[0];
    return r ? { rate: Number(r.rate), date: r.d } : null;
  } catch (_) { return null; }
}

// ── SYD 코드 정규화 — 대응품번 표(product_syd_codes) 매칭과 같은 규칙 ─────
export function sydNorm(s) { return String(s == null ? '' : s).toUpperCase().replace(/[^A-Z0-9]/g, ''); }
export const SYD_NORM_SQL = (col) => `regexp_replace(upper(${col}),'[^A-Z0-9]','','g')`;

// ── 입력 정규화 ──────────────────────────────────────────────────────
const NONE = '__none__';
const cleanList = (v, max = 400) => (Array.isArray(v) ? v : [])
  .map((x) => String(x == null ? '' : x).trim()).filter(Boolean).slice(0, max);
const numOr = (v) => {
  if (v == null || v === '') return null;
  const n = Number(String(v).replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : null;
};

export function normalizeFilter(f) {
  const src = f && typeof f === 'object' ? f : {};
  const codes = (Array.isArray(src.codes) ? src.codes : String(src.codes || '').split(/[\s,;]+/))
    .map((x) => String(x || '').trim().toUpperCase()).filter(Boolean);
  return {
    origin: [...new Set(cleanList(src.origin).map((x) => (x === NONE ? NONE : x.toUpperCase())))],
    cat: [...new Set(cleanList(src.cat).map((x) => x.toUpperCase()))],
    maker: [...new Set(cleanList(src.maker).map((x) => x.toUpperCase()))],
    material: [...new Set(cleanList(src.material).map((x) => (x === NONE ? NONE : x.toLowerCase())))],
    codes: [...new Set(codes)].slice(0, MAX_SELECTED),
    q: String(src.q || '').trim().slice(0, 80),
    active_only: src.active_only !== false,          // 기본 활성만
    list_min: numOr(src.list_min), list_max: numOr(src.list_max),
    ratio_min: numOr(src.ratio_min), ratio_max: numOr(src.ratio_max),   // CTR List ÷ SYD List
    mult_min: numOr(src.mult_min), mult_max: numOr(src.mult_max),       // List ÷ (FOB × 환율)
  };
}

/**
 * 변경 내용 검증. mode: pct | ratio (set 은 items 로 따로)
 *   반환 { price_type, mode, direction, pct, ratio, rounding } 또는 { error }
 */
export function normalizeChange(b) {
  const price_type = normType(b && b.price_type);
  const mode = b && b.mode === 'ratio' ? 'ratio' : 'pct';
  if (mode === 'ratio' && price_type !== 'list') return { error: 'ratio_list_only' };
  const r = b && b.rounding != null && b.rounding !== '' ? Number(b.rounding) : DEFAULT_ROUNDING;
  if (!ROUNDINGS[price_type].includes(r)) return { error: 'bad_rounding' };
  if (mode === 'ratio') {
    const ratio = numOr(b.ratio);
    if (ratio == null || ratio <= 0 || ratio > 10) return { error: 'bad_ratio' };
    return { price_type, mode, direction: null, pct: null, ratio: Math.round(ratio * 10000) / 10000, rounding: r };
  }
  const direction = Number(b && b.direction);
  if (direction !== 1 && direction !== -1) return { error: 'bad_direction' };
  const pct = numOr(String(b && b.pct != null ? b.pct : '').replace(',', '.'));
  if (pct == null || pct <= 0 || pct > 100) return { error: 'bad_pct' };
  const pct3 = Math.round(pct * 1000) / 1000;
  if (direction === -1 && pct3 >= 100) return { error: 'bad_pct' };   // 0 은 만들 수 없다
  return { price_type, mode, direction, pct: pct3, ratio: null, rounding: r };
}

/**
 * 새 가격 식(SQL). 파라미터 번호: dir · pct · rnd · ratio.
 *   pct   : 반올림( 현재 × (100 ± %) / 100 ÷ 단위 ) × 단위
 *   ratio : 반올림( SYD List × 비율 ÷ 단위 ) × 단위
 *   set   : 제품별 목표가(price_change_items.target_price — 저장 때 이미 반올림)
 */
export function nvSql(mode, curExpr, P, itemAlias = 'i') {
  const R = `$${P.rnd}::numeric`;
  if (mode === 'set') return `${itemAlias}.target_price`;
  if (mode === 'ratio') return `(ROUND(p.list_price_syd * $${P.ratio}::numeric / ${R}) * ${R})`;
  return `(ROUND(${curExpr} * (100 + $${P.dir}::numeric * $${P.pct}::numeric) / 100 / ${R}) * ${R})`;
}
/** 이 방식으로 계산 가능한 제품인가(SQL 조건) */
export function eligibleSql(mode, curExpr) {
  if (mode === 'ratio') return `p.list_price_syd > 0`;
  if (mode === 'set') return `TRUE`;
  return `${curExpr} > 0`;
}
// 호환: v1 식(= pct, list)
export function newPriceSql(oldExpr, dirP, pctP, rndP) {
  return nvSql('pct', oldExpr, { dir: dirP, pct: pctP, rnd: rndP });
}

/** JS 사본 — 화면 예상값·테스트 대조용. 센타보(또는 단위) 정수로 계산해 부동소수 오차를 피한다. */
export function roundTo(v, unit = 0.01) {
  const x = Number(v);
  if (!Number.isFinite(x)) return null;
  const k = Math.round(1 / unit);                                // 0.001→1000 · 0.01→100 · 1→1 · 10→0.1
  if (unit >= 1) { const q = Math.floor(Math.round(x * 1e6) / 1e6 / unit + 0.5 + 1e-9); return q * unit; }
  const scaled = Math.round(x * k * 1e6) / 1e6;
  return Math.sign(scaled) * Math.floor(Math.abs(scaled) + 0.5 + 1e-9) / k;
}
export function calcNewPrice(old, direction, pct, rounding = DEFAULT_ROUNDING) {
  const o = Number(old);
  if (!Number.isFinite(o) || o <= 0) return null;
  return roundTo(o * (100 + direction * pct) / 100, rounding);
}

/**
 * 조건 → WHERE (p = products). fx = 최신 환율(배수 조건에 필요).
 * 조건끼리는 AND, 한 조건 안의 여러 값은 OR.
 */
export function buildFilterWhere(filter, params, { fx = null } = {}) {
  const f = normalizeFilter(filter);
  const parts = ['p.deleted_at IS NULL'];
  if (f.active_only) parts.push('p.is_active');
  if (f.origin.length) {
    params.push(f.origin);
    parts.push(`COALESCE(NULLIF(upper(trim(p.origin)),''),'${NONE}') = ANY($${params.length}::text[])`);
  }
  if (f.cat.length) {
    params.push(f.cat);
    parts.push(`upper(trim(COALESCE(p.name,''))) = ANY($${params.length}::text[])`);
  }
  if (f.maker.length) {
    params.push(f.maker);
    parts.push(`p.id IN (SELECT pa.product_id FROM product_applications pa WHERE upper(pa.maker) = ANY($${params.length}::text[]))`);
  }
  if (f.material.length) {
    params.push(f.material);
    parts.push(`COALESCE(NULLIF(lower(trim(p.material)),''),'${NONE}') = ANY($${params.length}::text[])`);
  }
  if (f.codes.length) {
    params.push(f.codes);
    parts.push(`upper(p.code) = ANY($${params.length}::text[])`);
  }
  if (f.q) {
    params.push(`%${f.q}%`);
    const i = params.length;
    parts.push(`(p.code ILIKE $${i} OR COALESCE(p.name,'') ILIKE $${i} OR COALESCE(p.app,'') ILIKE $${i}
      OR p.id IN (SELECT pa2.product_id FROM product_applications pa2
                   WHERE pa2.app_text ILIKE $${i} OR COALESCE(pa2.model,'') ILIKE $${i}))`);
  }
  const range = (expr, lo, hi) => {
    if (lo != null) { params.push(lo); parts.push(`${expr} >= $${params.length}::numeric`); }
    if (hi != null) { params.push(hi); parts.push(`${expr} <= $${params.length}::numeric`); }
  };
  range('p.list_price', f.list_min, f.list_max);
  if (f.ratio_min != null || f.ratio_max != null) {
    parts.push('p.list_price > 0 AND p.list_price_syd > 0');
    range('(p.list_price / p.list_price_syd)', f.ratio_min, f.ratio_max);
  }
  if ((f.mult_min != null || f.mult_max != null)) {
    if (!(fx > 0)) parts.push('FALSE');                       // 환율이 없으면 배수 조건은 아무것도 고르지 않는다
    else {
      params.push(fx);
      const fxP = params.length;
      parts.push('p.list_price > 0 AND p.fob_usd > 0');
      range(`(p.list_price / (p.fob_usd * $${fxP}::numeric))`, f.mult_min, f.mult_max);
    }
  }
  return parts.join(' AND ');
}

/** 대상 WHERE — selected 면 체크한 id 만, 아니면 조건 결과. */
export function buildTargetWhere({ scope, filter, product_ids }, params, opt = {}) {
  if (scope === 'selected') {
    const ids = [...new Set((Array.isArray(product_ids) ? product_ids : []).map(Number)
      .filter((n) => Number.isInteger(n) && n > 0))].slice(0, MAX_SELECTED);
    params.push(ids);
    return `p.deleted_at IS NULL AND p.id = ANY($${params.length}::bigint[])`;
  }
  return buildFilterWhere(filter, params, opt);
}

/** 조건을 사람 말로 */
export function describeFilter(scope, filter, count) {
  if (scope === 'selected' || scope === 'items') return `선택 ${count ?? ''}개`.trim();
  const f = normalizeFilter(filter);
  const out = [];
  if (f.origin.length) out.push('원산지 ' + f.origin.map((x) => (x === NONE ? '(없음)' : x)).join(', '));
  if (f.cat.length) out.push('품목 ' + f.cat.join(', '));
  if (f.maker.length) out.push('메이커 ' + f.maker.join(', '));
  if (f.material.length) out.push('소재 ' + f.material.map((x) => (x === NONE ? '(미지정)' : x)).join(', '));
  if (f.codes.length) out.push(`코드 ${f.codes.length}개`);
  if (f.q) out.push(`검색 「${f.q}」`);
  const rg = (lab, lo, hi) => { if (lo != null || hi != null) out.push(`${lab} ${lo ?? ''}~${hi ?? ''}`); };
  rg('List', f.list_min, f.list_max); rg('CTR÷SYD', f.ratio_min, f.ratio_max); rg('배수', f.mult_min, f.mult_max);
  if (!out.length) out.push('전체');
  if (!f.active_only) out.push('비활성 포함');
  return out.join(' · ');
}

// ── 가격 변경 훅(화면 수정·제품 엑셀 업로드) ─────────────────────────────
// 트랜잭션 안에서 호출. 장부 기록이 실패해도 제품 저장은 살아야 하므로 SAVEPOINT 로 감싼다.
const numOrNull = (v) => (v == null || v === '' ? null : (Number.isFinite(Number(v)) ? Number(v) : null));
export function priceChanged(a, b) {
  const x = numOrNull(a); const y = numOrNull(b);
  if (x == null && y == null) return false;
  return x !== y;
}
export async function recordPriceChange(c, { productId, oldPrice, newPrice, source, userId = null, today = null, priceType = 'list' }) {
  if (!priceChanged(oldPrice, newPrice)) return false;
  if (!(await priceMasterReady())) return false;          // 0229 전 — 조용히 쉰다
  try {
    await c.query('SAVEPOINT price_hist');
    await c.query(
      `INSERT INTO product_price_history (product_id, price_type, effective_date, old_price, new_price, source, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [productId, normType(priceType), today || mxToday(), numOrNull(oldPrice), numOrNull(newPrice), source, userId]);
    await c.query('RELEASE SAVEPOINT price_hist');
    return true;
  } catch (e) {
    try { await c.query('ROLLBACK TO SAVEPOINT price_hist'); } catch (_) {}
    try { console.error('[price_history] failed:', source, productId, e.message); } catch (_) {}
    return false;
  }
}

// ── 묶음 만들기 ──────────────────────────────────────────────────────
/**
 * 묶음 1건을 만든다(트랜잭션 c 안). 오늘이면 바로 적용.
 *   spec: { price_type, mode, origin, direction, pct, ratio, rounding, effective_date, note, scope,
 *           filter, product_ids, items:[{product_id, price}], syd_list_id, fx, userId, today }
 *   반환 { id, product_count, applied }  — 대상 0 이면 Error('no_targets')
 */
export async function createBatch(c, spec) {
  const t = normType(spec.price_type);
  const col = colOf(t);
  const mode = spec.mode === 'set' ? 'set' : spec.mode === 'ratio' ? 'ratio' : 'pct';
  const scope = mode === 'set' ? 'items' : (spec.scope === 'selected' ? 'selected' : 'filter');
  const filter = scope === 'filter' ? normalizeFilter(spec.filter) : null;
  const rounding = spec.rounding != null ? Number(spec.rounding) : DEFAULT_ROUNDING;
  const ins = (await c.query(
    `INSERT INTO price_change_batches (price_type, mode, origin, effective_date, direction, pct, ratio, rounding, scope, filter,
                                       syd_list_id, status, note, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'scheduled',$12,$13) RETURNING id`,
    [t, mode, spec.origin || 'bulk', spec.effective_date, spec.direction ?? null, spec.pct ?? null, spec.ratio ?? null,
     rounding, scope, filter ? JSON.stringify(filter) : null, spec.syd_list_id || null, spec.note || null, spec.userId || null])).rows[0];
  const id = Number(ins.id);
  let n = 0;
  if (mode === 'set') {
    const ids = []; const prices = [];
    const seen = new Set();
    for (const it of (Array.isArray(spec.items) ? spec.items : []).slice(0, MAX_SELECTED)) {
      const pid = Number(it && it.product_id); const pr = numOr(it && it.price);
      if (!Number.isInteger(pid) || pid <= 0 || pr == null || pr <= 0 || seen.has(pid)) continue;
      seen.add(pid); ids.push(pid); prices.push(roundTo(pr, rounding));
    }
    if (ids.length) {
      const r = await c.query(
        `INSERT INTO price_change_items (batch_id, product_id, target_price)
         SELECT $1, x.pid, x.price FROM unnest($2::bigint[], $3::numeric[]) AS x(pid, price)
           JOIN products p ON p.id = x.pid AND p.deleted_at IS NULL`, [id, ids, prices]);
      n = r.rowCount || 0;
    }
  } else {
    const tp = [id];
    const tw = buildTargetWhere({ scope, filter, product_ids: spec.product_ids }, tp, { fx: spec.fx });
    const r = await c.query(
      `INSERT INTO price_change_items (batch_id, product_id)
       SELECT $1, p.id FROM products p WHERE ${tw} AND ${eligibleSql(mode, 'p.' + col)}`, tp);
    n = r.rowCount || 0;
  }
  if (!n) { const e = new Error('no_targets'); e.code = 'NO_TARGETS'; throw e; }
  await c.query(`UPDATE price_change_batches SET product_count=$2 WHERE id=$1`, [id, n]);
  let applied = null;
  if (spec.effective_date <= (spec.today || mxToday())) applied = await applyBatch(c, id, { userId: spec.userId, lockWait: true });
  return { id, product_count: n, applied };
}

// ── 묶음 적용 ────────────────────────────────────────────────────────
/**
 * 예약 묶음 1건 적용(트랜잭션 c 안). 이미 적용·취소된 묶음이면 아무것도 하지 않는다.
 * 다른 워커가 같은 묶음을 잡고 있으면(SKIP LOCKED) 건너뛴다 — 두 번 적용될 수 없다.
 */
export async function applyBatch(c, batchId, { userId = null, lockWait = false } = {}) {
  const b = (await c.query(
    `SELECT id, status, price_type, mode, direction, pct, ratio, rounding, to_char(effective_date,'YYYY-MM-DD') AS eff
       FROM price_change_batches WHERE id=$1 FOR UPDATE${lockWait ? '' : ' SKIP LOCKED'}`, [batchId])).rows[0];
  if (!b || b.status !== 'scheduled') return null;
  const t = normType(b.price_type); const col = colOf(t); const cur = 'p.' + col;
  const P = { dir: 2, pct: 3, rnd: 4, ratio: 5 };
  const nv = nvSql(b.mode, cur, P);
  const params = [batchId, b.direction == null ? 0 : Number(b.direction), b.pct == null ? 0 : Number(b.pct),
    Number(b.rounding), b.ratio == null ? 0 : Number(b.ratio), userId, b.eff, t];
  const res = await c.query(
    `WITH tgt AS (
        SELECT p.id, ${cur} AS old, ${nv} AS nv,
               $2::numeric AS _d, $3::numeric AS _p, $4::numeric AS _r, $5::numeric AS _q
          FROM price_change_items i JOIN products p ON p.id = i.product_id
         WHERE i.batch_id = $1 AND p.deleted_at IS NULL AND ${eligibleSql(b.mode, cur)}
         FOR UPDATE OF p
     ), upd AS (
        UPDATE products p SET ${col} = t.nv, updated_by = $6, updated_at = now()
          FROM tgt t
         WHERE p.id = t.id AND t.nv > 0 AND t.nv IS DISTINCT FROM t.old
        RETURNING p.id, t.old, t.nv
     ), hist AS (
        INSERT INTO product_price_history (product_id, price_type, effective_date, old_price, new_price, source, batch_id, created_by)
        SELECT id, $8, $7::date, old, nv, 'batch', $1, $6 FROM upd
        RETURNING product_id, old_price, new_price
     )
     UPDATE price_change_items i SET old_price = h.old_price, new_price = h.new_price, result = 'applied'
       FROM hist h WHERE i.batch_id = $1 AND i.product_id = h.product_id`, params);
  const applied = res.rowCount || 0;
  const sk = await c.query(
    `UPDATE price_change_items i
        SET result = COALESCE((SELECT CASE WHEN p.deleted_at IS NOT NULL THEN 'deleted'
                                           WHEN NOT (${eligibleSql(b.mode, cur)}) THEN ${b.mode === 'ratio' ? `'no_syd'` : `'no_price'`}
                                           WHEN ${nv} <= 0 THEN 'to_zero'
                                           ELSE 'no_change' END
                                 FROM products p WHERE p.id = i.product_id), 'deleted'),
            old_price = (SELECT ${cur} FROM products p WHERE p.id = i.product_id),
            new_price = NULL
      WHERE i.batch_id = $1 AND i.result IS NULL
        AND $2::numeric IS NOT NULL AND $3::numeric IS NOT NULL AND $4::numeric IS NOT NULL AND $5::numeric IS NOT NULL`,
    params.slice(0, 5));
  const skipped = sk.rowCount || 0;
  await c.query(
    `UPDATE price_change_batches SET status='applied', applied_at=now(), applied_by=$2,
            applied_count=$3, skipped_count=$4 WHERE id=$1`, [batchId, userId, applied, skipped]);
  return { applied, skipped };
}

/** 적용일이 된 예약 묶음을 만든 순서대로 적용(같은 날 여러 묶음 = 차례로 복리). */
export async function applyDue({ today = mxToday(), log = null } = {}) {
  if (!(await priceMasterReady())) return { ran: 0 };
  const due = (await query(
    `SELECT id FROM price_change_batches
      WHERE status='scheduled' AND effective_date <= $1::date
      ORDER BY effective_date, id`, [today])).rows;
  let ran = 0;
  for (const r of due) {
    try {
      const out = await withTx((c) => applyBatch(c, Number(r.id), { userId: null }));
      if (out) { ran++; try { log && log.info && log.info(`[priceMaster] 예약 #${r.id} 적용 — ${out.applied}개 변경, ${out.skipped}개 제외`); } catch (_) {} }
    } catch (e) {
      try { console.error('[priceMaster] apply failed', r.id, e.message); } catch (_) {}
      break;           // 순서가 중요하다(복리) — 앞 묶음이 실패하면 뒤 묶음도 멈춘다
    }
  }
  return { ran };
}

let timer = null;
export function startPriceMasterWorker(app) {
  if (timer) return;
  const tick = () => { applyDue({ log: app && app.log }).catch(() => {}); };
  timer = setInterval(tick, 5 * 60000);        // 5분 — 00:00(멕시코) 예약은 00:05 안에 적용
  if (timer.unref) timer.unref();
  const t0 = setTimeout(tick, 20000);          // 기동 20초 뒤 한 번(밤사이 재배포로 놓친 예약 줍기)
  if (t0.unref) t0.unref();
  try { app?.log?.info?.('[priceMaster] 가격 예약 감시 시작 — 5분 주기'); } catch (_) {}
}

// ── 되돌리기 ─────────────────────────────────────────────────────────
/** 묶음 단위. 그 뒤에 같은 가격 종류의 다른 변경이 없고 현재값 = 이 묶음이 넣은 값인 제품만. */
export async function revertBatch(c, batchId, { userId = null, today = mxToday() } = {}) {
  const b = (await c.query(`SELECT id, status, price_type FROM price_change_batches WHERE id=$1 FOR UPDATE`, [batchId])).rows[0];
  if (!b) return { error: 'not_found' };
  if (b.status !== 'applied') return { error: 'not_applied', status: b.status };
  const t = normType(b.price_type); const col = colOf(t);
  const res = await c.query(
    `WITH h AS (
        SELECT x.id, x.product_id, x.old_price, x.new_price
          FROM product_price_history x
         WHERE x.batch_id = $1 AND x.source = 'batch'
     ), ok AS (
        SELECT h.id, h.product_id, h.old_price, h.new_price
          FROM h JOIN products p ON p.id = h.product_id
         WHERE p.deleted_at IS NULL
           AND p.${col} = h.new_price
           AND NOT EXISTS (SELECT 1 FROM product_price_history y
                            WHERE y.product_id = h.product_id AND y.price_type = $4 AND y.id > h.id)
         FOR UPDATE OF p
     ), upd AS (
        UPDATE products p SET ${col} = ok.old_price, updated_by = $2, updated_at = now()
          FROM ok WHERE p.id = ok.product_id
        RETURNING p.id, ok.new_price AS was, ok.old_price AS back
     ), hist AS (
        INSERT INTO product_price_history (product_id, price_type, effective_date, old_price, new_price, source, batch_id, created_by)
        SELECT id, $4, $3::date, was, back, 'revert', $1, $2 FROM upd
        RETURNING product_id
     )
     UPDATE price_change_items i SET result = 'reverted'
       FROM hist WHERE i.batch_id = $1 AND i.product_id = hist.product_id`,
    [batchId, userId, today, t]);
  const reverted = res.rowCount || 0;
  const skippedRows = (await c.query(
    `SELECT p.code,
            CASE WHEN p.id IS NULL OR p.deleted_at IS NOT NULL THEN 'deleted'
                 WHEN EXISTS (SELECT 1 FROM product_price_history y
                               WHERE y.product_id = i.product_id AND y.price_type = $2
                                 AND y.batch_id IS DISTINCT FROM i.batch_id
                                 AND y.id > (SELECT MAX(z.id) FROM product_price_history z
                                              WHERE z.batch_id = i.batch_id AND z.product_id = i.product_id AND z.source='batch'))
                      THEN 'later_change'
                 ELSE 'price_differs' END AS reason
       FROM price_change_items i LEFT JOIN products p ON p.id = i.product_id
      WHERE i.batch_id = $1 AND i.result = 'applied'
      ORDER BY p.code`, [batchId, t])).rows;
  if (reverted === 0) return { error: 'nothing_to_revert', skipped: skippedRows };
  await c.query(`UPDATE price_change_items SET result='revert_skipped' WHERE batch_id=$1 AND result='applied'`, [batchId]);
  await c.query(
    `UPDATE price_change_batches SET status='reverted', reverted_at=now(), reverted_by=$2,
            reverted_count=$3, revert_skipped_count=$4 WHERE id=$1`,
    [batchId, userId, reverted, skippedRows.length]);
  return { reverted, skipped: skippedRows };
}

// ── 경쟁사 SYD 리스트 ────────────────────────────────────────────────
/**
 * 업로드 행 정리: [{code, price, familia}] → { items:[{norm, code, price, familia}], dup, errors:[{row, code, reason}] }
 * 같은 코드가 두 번 나오면 **첫 값**을 쓰고 dup 로 센다.
 */
export function parseSydRows(rows) {
  const items = []; const errors = []; const seen = new Set(); let dup = 0;
  (Array.isArray(rows) ? rows : []).forEach((r, i) => {
    const code = String(r && r.code != null ? r.code : '').trim();
    const norm = sydNorm(code);
    const price = numOr(r && r.price);
    const rowNo = (r && r._row) || i + 1;
    if (!norm) { errors.push({ row: rowNo, code, reason: 'no_code' }); return; }
    if (price == null || price <= 0) { errors.push({ row: rowNo, code, reason: 'bad_price' }); return; }
    if (seen.has(norm)) { dup++; return; }
    seen.add(norm);
    const fam = String(r && r.familia != null ? r.familia : '').trim().toUpperCase().slice(0, 80) || null;
    // 0324 · SYD 품명(DESCRIPCIÓN) — 보낸 경우만(옛 화면은 안 보냄 → null)
    const desc = String(r && r.descripcion != null ? r.descripcion : '').replace(/\s+/g, ' ').trim().toUpperCase().slice(0, 160) || null;
    items.push({ norm, code: code.slice(0, 80), price: Math.round(price * 100) / 100, familia: fam, descripcion: desc });
  });
  return { items, dup, errors };
}

/** 이 리스트 바로 앞 리스트(기준일이 앞서거나, 같은 날이면 먼저 올린 것) */
export async function prevSydList(exec, listId) {
  const r = (await exec(
    `SELECT p.id FROM syd_price_lists p, syd_price_lists c
      WHERE c.id = $1 AND (p.list_date < c.list_date OR (p.list_date = c.list_date AND p.id < c.id))
      ORDER BY p.list_date DESC, p.id DESC LIMIT 1`, [listId])).rows[0];
  return r ? Number(r.id) : null;
}
// 0324 · syd_price_items.descripcion 이 있는가 — 배포 후 migrate 전에도 SYD 리스트 올리기가 깨지지 않게.
//   긍정은 영구, 부정은 30초마다 다시 본다(pfCatalogReady 와 같은 방식).
let sydDescFlag = false; let sydDescAt = 0;
export async function sydDescReady(exec = query) {
  if (sydDescFlag) return true;
  if (Date.now() - sydDescAt < 30000) return false;
  sydDescAt = Date.now();
  try {
    sydDescFlag = !!(await exec(`SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name='syd_price_items' AND column_name='descripcion'`)).rows.length;
  } catch (_) { sydDescFlag = false; }
  return sydDescFlag;
}
export function setSydDescReady(v) { sydDescFlag = !!v; sydDescAt = Date.now(); }

/**
 * 0324 · SYD 코드 → 최신 리스트의 품명 · 품목. 코드 표기는 대문자+영숫자로 맞춘다(sydNorm).
 *   returns { list_date, items: { NORM: { code, desc, familia } } }
 *   최신 리스트에 품명이 없으면 그 코드의 가장 최근 품명(예전 리스트)을 쓴다 — 리스트에 품명 열이 빠진 달이 있어도 이름이 사라지지 않게.
 */
export async function sydNamesFor(codes, exec = query) {
  const norms = [...new Set((codes || []).map(sydNorm).filter(Boolean))].slice(0, 5000);
  if (!norms.length) return { list_date: null, items: {} };
  const hasDesc = await sydDescReady(exec);
  const rows = (await exec(
    `SELECT DISTINCT ON (it.syd_norm) it.syd_norm, it.syd_code, ${hasDesc ? 'it.descripcion' : 'NULL::text AS descripcion'}, it.familia,
            to_char(l.list_date,'YYYY-MM-DD') AS d
       FROM syd_price_items it JOIN syd_price_lists l ON l.id = it.list_id
      WHERE it.syd_norm = ANY($1::text[])
      ORDER BY it.syd_norm, ${hasDesc ? "(COALESCE(btrim(it.descripcion),'') <> '') DESC," : ''} l.list_date DESC, l.id DESC`, [norms])).rows;
  const items = {}; let latest = null;
  for (const r of rows) {
    items[r.syd_norm] = { code: r.syd_code, desc: r.descripcion || null, familia: r.familia || null, list_date: r.d };
    if (!latest || r.d > latest) latest = r.d;
  }
  return { list_date: latest, items };
}

export async function latestSydListId(exec = query) {
  const r = (await exec(`SELECT id FROM syd_price_lists ORDER BY list_date DESC, id DESC LIMIT 1`)).rows[0];
  return r ? Number(r.id) : null;
}

/** 두 리스트 비교 집계 */
export async function compareSydCounts(exec, listId, prevId) {
  if (!prevId) {
    const n = (await exec(`SELECT COUNT(*)::int AS n FROM syd_price_items WHERE list_id=$1`, [listId])).rows[0].n;
    return { up: 0, down: 0, same: 0, new: n, gone: 0 };
  }
  const r = (await exec(
    `SELECT COALESCE(SUM(CASE WHEN a.price > b.price THEN 1 ELSE 0 END),0)::int AS up,
            COALESCE(SUM(CASE WHEN a.price < b.price THEN 1 ELSE 0 END),0)::int AS down,
            COALESCE(SUM(CASE WHEN a.price = b.price THEN 1 ELSE 0 END),0)::int AS same,
            COALESCE(SUM(CASE WHEN b.syd_norm IS NULL THEN 1 ELSE 0 END),0)::int AS new
       FROM syd_price_items a
       LEFT JOIN syd_price_items b ON b.list_id = $2 AND b.syd_norm = a.syd_norm
      WHERE a.list_id = $1`, [listId, prevId])).rows[0];
  const gone = (await exec(
    `SELECT COUNT(*)::int AS n FROM syd_price_items b
      WHERE b.list_id = $2 AND NOT EXISTS (SELECT 1 FROM syd_price_items a WHERE a.list_id = $1 AND a.syd_norm = b.syd_norm)`,
    [listId, prevId])).rows[0].n;
  return { up: r.up, down: r.down, same: r.same, new: r.new, gone };
}

/**
 * 최신 리스트로 products.list_price_syd 를 맞춘다(결정: 한 CTR 에 SYD 여럿이면 **가장 높은 값**).
 * 최신 리스트에 없는 제품은 건드리지 않는다. 반환: 바뀐 제품 수
 */
export async function syncProductSydPrices(exec, listId) {
  const r = await exec(
    `WITH ref AS (
        SELECT sc.product_id, MAX(it.price) AS ref
          FROM product_syd_codes sc
          JOIN syd_price_items it ON it.list_id = $1 AND it.syd_norm = ${SYD_NORM_SQL('sc.syd_code')}
         GROUP BY sc.product_id
     )
     UPDATE products p SET list_price_syd = ref.ref
       FROM ref WHERE p.id = ref.product_id AND p.deleted_at IS NULL
        AND p.list_price_syd IS DISTINCT FROM ref.ref`, [listId]);
  return r.rowCount || 0;
}

// ── 구매 기록 FOB 검증 ───────────────────────────────────────────────
/**
 * 구매 줄마다 **주문일 당시 FOB**(그날까지의 마지막 FOB 이력). 그날 이전 이력이 없으면 가장 이른 FOB 를 쓰고
 * basis='earliest' 로 표시(가격 마스터를 켜기 전 구매도 볼 수 있게).
 *   status: ok(같음) · over(비쌈) · under(쌈) · no_fob · unmatched(미등록 코드)
 *   tolPct: 허용 오차 %(결정: 0 — 1센트라도 다르면 표시)
 */
export const FOB_AT_SQL = (pidExpr, dateExpr) => `
  LEFT JOIN LATERAL (SELECT h.new_price AS fob FROM product_price_history h
                      WHERE h.product_id = ${pidExpr} AND h.price_type = 'fob' AND h.effective_date <= ${dateExpr}
                        AND h.new_price IS NOT NULL
                      ORDER BY h.effective_date DESC, h.id DESC LIMIT 1) fa ON TRUE
  LEFT JOIN LATERAL (SELECT h.new_price AS fob FROM product_price_history h
                      WHERE h.product_id = ${pidExpr} AND h.price_type = 'fob' AND h.new_price IS NOT NULL
                      ORDER BY h.effective_date, h.id LIMIT 1) fe ON TRUE`;

export function fobStatus(cost, fob, productId, tolPct = 0) {
  if (productId == null) return 'unmatched';
  if (fob == null) return 'no_fob';
  const c = Number(cost); const f = Number(fob);
  const diff = Math.round((c - f) * 10000) / 10000;
  if (Math.abs(diff) <= Math.abs(f) * (tolPct / 100) + 1e-9) return 'ok';
  return diff > 0 ? 'over' : 'under';
}

export async function purchaseLinesWithFob(exec, poIds) {
  if (!poIds.length) return [];
  const rows = (await exec(
    `SELECT l.id, l.po_id, l.product_id, l.input_code, l.qty, l.unit_cost_usd, l.amount_usd,
            pr.code, pr.name, pr.fob_usd AS fob_now, to_char(po.order_date,'YYYY-MM-DD') AS order_date,
            COALESCE(fa.fob, fe.fob) AS fob, CASE WHEN fa.fob IS NULL AND fe.fob IS NOT NULL THEN 'earliest' ELSE 'at_date' END AS basis
       FROM purchase_order_lines l
       JOIN purchase_orders po ON po.id = l.po_id
       LEFT JOIN products pr ON pr.id = l.product_id
       ${FOB_AT_SQL('l.product_id', 'po.order_date')}
      WHERE l.po_id = ANY($1::bigint[])
      ORDER BY l.po_id, l.id`, [poIds])).rows;
  return rows;
}

export function summarizeFob(lines, tolPct = 0) {
  const s = { lines: 0, ok: 0, over: 0, under: 0, no_fob: 0, unmatched: 0, diff_usd: 0, over_usd: 0, under_usd: 0 };
  for (const l of lines) {
    const st = fobStatus(l.unit_cost_usd, l.fob, l.product_id, tolPct);
    l.fob_status = st; s.lines++; s[st]++;
    if (st === 'over' || st === 'under') {
      const d = Math.round((Number(l.unit_cost_usd) - Number(l.fob)) * Number(l.qty) * 100) / 100;
      l.diff_usd = d; s.diff_usd += d; if (d > 0) s.over_usd += d; else s.under_usd += d;
    } else l.diff_usd = null;
  }
  s.diff_usd = Math.round(s.diff_usd * 100) / 100; s.over_usd = Math.round(s.over_usd * 100) / 100; s.under_usd = Math.round(s.under_usd * 100) / 100;
  return s;
}

/** 구매 화면용: PO 별 FOB 불일치 줄 수(비쌈+쌈). 0229 전이면 빈 맵. */
export async function fobMismatchByPo(poIds) {
  const out = new Map();
  if (!poIds.length || !(await priceMasterReady())) return out;
  const lines = await purchaseLinesWithFob(query, poIds);
  for (const l of lines) {
    const st = fobStatus(l.unit_cost_usd, l.fob, l.product_id, 0);
    const o = out.get(Number(l.po_id)) || { bad: 0, over: 0, under: 0, no_fob: 0 };
    if (st === 'over' || st === 'under') { o.bad++; o[st]++; }
    if (st === 'no_fob') o.no_fob++;
    out.set(Number(l.po_id), o);
  }
  return out;
}

/** 구매 업로드 미리보기·상세용: 제품별 날짜 기준 FOB. 0229 전이면 null */
export async function fobAtDate(productIds, ymd) {
  if (!(await priceMasterReady())) return null;             // 0229 전 — 검증 자체를 쉰다(「FOB 없음」으로 보이지 않게)
  const out = new Map();
  const ids = [...new Set(productIds.filter((x) => x != null).map(Number))];
  if (!ids.length) return out;
  const r = (await query(
    `SELECT x.pid, COALESCE(fa.fob, fe.fob) AS fob
       FROM unnest($1::bigint[]) AS x(pid)
       ${FOB_AT_SQL('x.pid', '$2::date')}`, [ids, ymd])).rows;
  for (const row of r) out.set(Number(row.pid), row.fob == null ? null : Number(row.fob));
  return out;
}

export const RESULT_KO = {
  applied: '적용', no_price: '가격 없음', no_syd: 'SYD 없음', deleted: '삭제됨', no_change: '변화 없음',
  to_zero: '0 이하 → 제외', reverted: '되돌림', revert_skipped: '되돌리기 제외',
};
export const SKIP_REASON_KO = { later_change: '뒤에 다른 변경이 있음', price_differs: '현재 값이 다름', deleted: '삭제된 제품' };

// =====================================================================
// ⑦ 제품 수익성 (2026-09-24) — 누적 판매수량 × 1개당 이익
//   결정(디렉터 09-24):
//     · 1개당 판매가 = 실제 평균 판매가(기간 누적 매출 ÷ 누적 판매수량, IVA 제외, 게시·미삭제 인보이스)
//     · 1개당 원가   = FOB(가격표, USD) × 최신 환율 × (1 + 부대비율)
//         부대비율 = 그 제품이 들어온 승인 수입 배치들의 (배치 부대비용 ÷ 배치 FOB 금액)을 FOB 금액으로 가중평균.
//                    수입 이력이 없으면 전체 평균 부대비율. → 새 배치가 승인되면 다음 조회부터 자동 반영.
//     · FOB 가 없는 제품 = 판매 시점 실제 원가(sales_invoice_lines.cogs_mxn — 매출총이익 화면과 같은 동결 원가)로 대체
//     · 판관비 = 매출 × 판관비율(디렉터가 정함 — price_master_settings.sga_pct, 0231)
//   차종 지역: 적용차종 메이커 → 유럽 · 아시아(일본·한국) · 미국 · 중국. 한 제품이 여러 지역에 걸칠 수 있다.
// =====================================================================
export const REGIONS = [
  { key: 'eu', label: '유럽', makers: ['VOLKSWAGEN', 'VW', 'AUDI', 'SEAT', 'CUPRA', 'SKODA', 'BMW', 'MINI', 'MERCEDES', 'MERCEDES BENZ', 'MERCEDES-BENZ', 'SMART',
    'PORSCHE', 'PEUGEOT', 'CITROEN', 'DS', 'RENAULT', 'FIAT', 'ALFA ROMEO', 'LANCIA', 'MASERATI', 'FERRARI', 'VOLVO', 'SAAB', 'OPEL', 'LAND ROVER', 'JAGUAR'] },
  { key: 'asia', label: '아시아', makers: ['NISSAN', 'TOYOTA', 'HONDA', 'MAZDA', 'MITSUBISHI', 'SUBARU', 'SUZUKI', 'ISUZU', 'INFINITI', 'LEXUS', 'ACURA', 'DATSUN',
    'HINO', 'HYUNDAI', 'KIA', 'DAEWOO', 'SSANGYONG', 'GENESIS'] },
  { key: 'us', label: '미국', makers: ['CHEVROLET', 'FORD', 'DODGE', 'CHRYSLER', 'JEEP', 'RAM', 'GMC', 'CADILLAC', 'BUICK', 'LINCOLN', 'PONTIAC', 'MERCURY',
    'OLDSMOBILE', 'SATURN', 'HUMMER', 'PLYMOUTH', 'TESLA'] },
  { key: 'cn', label: '중국', makers: ['MG', 'JAC', 'CHIREY', 'CHERY', 'OMODA', 'JAECOO', 'CHANGAN', 'BYD', 'GWM', 'GREAT WALL', 'HAVAL', 'GEELY', 'DONGFENG',
    'FAW', 'BAIC', 'FOTON', 'JETOUR', 'EXEED', 'WULING', 'BAOJUN', 'MAXUS', 'JMC', 'ZEEKR', 'HONGQI', 'LYNK', 'NIO', 'XPENG', 'LEAPMOTOR', 'SERES',
    'BESTUNE', 'ORA', 'TANK', 'ROEWE', 'BAW', 'JETTA'] },
];
const REGION_KEYS = REGIONS.map((r) => r.key);
/** 메이커 → 지역 키(없으면 null). 정확히 같거나 「목록 이름 + 공백」으로 시작하면 인정(예: 'MERCEDES BENZ SPRINTER'). */
export function regionOf(maker) {
  const m = String(maker || '').trim().toUpperCase().replace(/\s+/g, ' ');
  if (!m) return null;
  for (const r of REGIONS) for (const x of r.makers) if (m === x || m.startsWith(x + ' ') || m.startsWith(x + '-')) return r.key;
  return null;
}

// ── 판관비율 설정(0231) ──
let setReady = false; let setProbe = 0;
export async function settingsReady(force = false) {
  if (setReady) return true;
  if (!force && Date.now() - setProbe < PROBE_MS) return false;
  setProbe = Date.now();
  try { setReady = !!(await query(`SELECT to_regclass('public.price_master_settings') AS t`)).rows[0].t; } catch (_) { setReady = false; }
  return setReady;
}
export function _resetSettingsForTest() { setReady = false; setProbe = 0; }
export async function getSga() {
  if (!(await settingsReady())) return { pct: null, ready: false };
  const r = (await query(
    `SELECT s.num_value, s.updated_at, u.name AS by_name FROM price_master_settings s LEFT JOIN users u ON u.id = s.updated_by
      WHERE s.key = 'sga_pct'`)).rows[0];
  return { ready: true, pct: r && r.num_value != null ? Number(r.num_value) : null, updated_at: r ? r.updated_at : null, by_name: r ? r.by_name : null };
}
export async function setSga(pct, userId) {
  await query(
    `INSERT INTO price_master_settings (key, num_value, updated_by, updated_at) VALUES ('sga_pct', $1, $2, now())
     ON CONFLICT (key) DO UPDATE SET num_value = EXCLUDED.num_value, updated_by = EXCLUDED.updated_by, updated_at = now()`, [pct, userId]);
}

/**
 * 제품별 수익성 원자료(판관비 전). 필터는 JS 에서(칩 개수를 전체 기준으로 세기 위해).
 *   반환 { fx, overhead:{rate, batches}, rows:[...] }
 */
// 배치별 FOB 금액(base) · 부대비(oh) — 승인 · 미삭제 · 원가 제외(0069) 아닌 배치만. 상관 서브쿼리 대신 한 번씩 집계(제품 수 × 줄 수로 커지지 않게)
const FXL_SQL = `CASE WHEN upper(COALESCE(l.currency, b.currency, 'USD')) = 'MXN' THEN 1 ELSE COALESCE(b.fx_rate, 0) END`;
const FXO_SQL = `CASE WHEN upper(COALESCE(o.currency, b.currency, 'USD')) = 'MXN' THEN 1 ELSE COALESCE(b.fx_rate, 0) END`;
const BB_SQL = `SELECT b.id, COALESCE(bl.base, 0) AS base, COALESCE(bo.oh, 0) AS oh
     FROM import_batches b
     LEFT JOIN (SELECT l.batch_id, SUM(l.qty * l.import_price * ${FXL_SQL}) AS base
                  FROM import_lines l JOIN import_batches b ON b.id = l.batch_id GROUP BY l.batch_id) bl ON bl.batch_id = b.id
     LEFT JOIN (SELECT o.batch_id, SUM(o.amount * ${FXO_SQL}) AS oh
                  FROM import_overheads o JOIN import_batches b ON b.id = o.batch_id GROUP BY o.batch_id) bo ON bo.batch_id = b.id
    WHERE b.status = 'approved' AND b.deleted_at IS NULL AND b.exclude_from_cost IS NOT TRUE`;

/** 견적 목록 매출총이익(디렉터) — 평균원가가 없는 제품의 추정 원가 기준.
 *  1개당 = FOB × 최신 환율 × (1 + 전체 평균 수입부대비율). ⑦ 제품 수익성에서 수입 기록 없는 제품에 쓰는 식과 같다.
 *  5분 캐시(목록을 열 때마다 배치 전체를 다시 집계하지 않게). */
let fobBasisCache = { at: 0, v: null };
export async function fobCostBasis() {
  if (fobBasisCache.v && Date.now() - fobBasisCache.at < 5 * 60 * 1000) return fobBasisCache.v;
  const fx = await latestFx();
  let ohRate = 0;
  try {
    const g = (await query(`SELECT COALESCE(SUM(base),0) AS base, COALESCE(SUM(oh),0) AS oh FROM (${BB_SQL}) bb`)).rows[0];
    ohRate = Number(g.base) > 0 ? Number(g.oh) / Number(g.base) : 0;
  } catch (_) { ohRate = 0; }
  const v = { fx: fx ? fx.rate : null, fx_date: fx ? fx.date : null, oh_rate: Math.round(ohRate * 10000) / 10000 };
  fobBasisCache = { at: Date.now(), v };
  return v;
}
export function _resetFobBasisForTest() { fobBasisCache = { at: 0, v: null }; }

export async function profitBase({ from = null, to = null } = {}) {
  const p = []; let dw = '';
  if (from) { p.push(from); dw += ` AND si.inv_date >= $${p.length}::date`; }
  if (to) { p.push(to); dw += ` AND si.inv_date <= $${p.length}::date`; }
  const fx = await latestFx();
  const FXL = FXL_SQL; const bbSql = BB_SQL;
  const g = (await query(`SELECT COALESCE(SUM(base),0) AS base, COALESCE(SUM(oh),0) AS oh, COUNT(*)::int AS n FROM (${bbSql}) bb`)).rows[0];
  const gRate = Number(g.base) > 0 ? Number(g.oh) / Number(g.base) : 0;
  const rows = (await query(
    `WITH s AS MATERIALIZED (
        SELECT sil.product_id, SUM(sil.qty) AS qty, SUM(sil.line_amount_mxn) AS rev,
               SUM(COALESCE(sil.cogs_mxn, sil.qty * sil.applied_unit_cost, 0)) AS cogs_act,
               to_char(MAX(si.inv_date),'YYYY-MM-DD') AS last_sale, COUNT(DISTINCT si.id)::int AS inv_n
          FROM sales_invoice_lines sil JOIN sales_invoices si ON si.id = sil.invoice_id
         WHERE si.status = 'posted' AND si.deleted_at IS NULL AND sil.product_id IS NOT NULL${dw}
         GROUP BY sil.product_id HAVING SUM(sil.qty) > 0
     ), bb AS MATERIALIZED (${bbSql}),
     pl AS MATERIALIZED (
        SELECT l.product_id,
               SUM(l.qty * l.import_price * ${FXL}) AS val,
               SUM(l.qty * l.import_price * ${FXL} * CASE WHEN bb.base > 0 THEN bb.oh / bb.base ELSE 0 END) AS oh
          FROM import_lines l JOIN import_batches b ON b.id = l.batch_id JOIN bb ON bb.id = b.id
         GROUP BY l.product_id),
     pa AS MATERIALIZED (
        SELECT product_id, string_agg(DISTINCT upper(trim(maker)), '|') AS makers FROM product_applications
         WHERE COALESCE(trim(maker),'') <> '' GROUP BY product_id)
     SELECT p.id, p.code, p.name, p.origin, p.is_active, p.fob_usd, p.list_price,
            s.qty, s.rev, s.cogs_act, s.last_sale, s.inv_n, pl.val AS imp_val, pl.oh AS imp_oh,
            pa.makers
       FROM s JOIN products p ON p.id = s.product_id
       LEFT JOIN pl ON pl.product_id = p.id
       LEFT JOIN pa ON pa.product_id = p.id
      WHERE p.deleted_at IS NULL`, p)).rows;
  const rate = fx ? fx.rate : null;
  const r4 = (x) => Math.round(x * 10000) / 10000;
  const out = rows.map((r) => {
    const qty = Number(r.qty); const rev = Number(r.rev); const cogsAct = Number(r.cogs_act);
    const fob = r.fob_usd == null ? null : Number(r.fob_usd);
    const ohOwn = Number(r.imp_val) > 0;
    const ohRate = ohOwn ? Number(r.imp_oh) / Number(r.imp_val) : gRate;
    const makers = r.makers ? String(r.makers).split('|') : [];
    const regions = [...new Set(makers.map(regionOf).filter(Boolean))];
    let basis; let unitFob = null; let unitOh = null; let unitCost;
    if (fob > 0 && rate > 0) {
      basis = 'fob'; unitFob = fob * rate; unitOh = unitFob * ohRate; unitCost = unitFob + unitOh;
    } else { basis = 'actual'; unitCost = qty > 0 ? cogsAct / qty : 0; }
    const cogs = unitCost * qty;
    return {
      id: Number(r.id), code: r.code, name: r.name, cat: String(r.name || '').trim().toUpperCase(), origin: r.origin,
      is_active: r.is_active !== false, makers, regions, qty, revenue: Math.round(rev * 100) / 100,
      unit_price: qty > 0 ? r4(rev / qty) : null, fob_usd: fob, oh_rate: r4(ohRate), oh_source: ohOwn ? 'product' : 'global',
      unit_fob_mxn: unitFob == null ? null : r4(unitFob), unit_oh: unitOh == null ? null : r4(unitOh), unit_cost: r4(unitCost),
      basis, cogs: Math.round(cogs * 100) / 100, gp: Math.round((rev - cogs) * 100) / 100,
      cogs_actual: Math.round(cogsAct * 100) / 100, last_sale: r.last_sale, inv_n: r.inv_n, list_price: r.list_price == null ? null : Number(r.list_price),
    };
  });
  return { fx, overhead: { rate: r4(gRate), batches: g.n, base_mxn: Number(g.base), oh_mxn: Number(g.oh) }, rows: out };
}

/** 필터(칩): cat[] · region[](OR) · origin[] · q · include_inactive */
export function filterProfitRows(rows, f = {}) {
  const cats = new Set((f.cat || []).map((x) => String(x).toUpperCase()));
  const regs = new Set((f.region || []).filter((x) => REGION_KEYS.includes(x)));
  const origins = new Set((f.origin || []).map((x) => String(x).toUpperCase()));
  const q = String(f.q || '').trim().toUpperCase();
  return rows.filter((r) => (f.include_inactive || r.is_active)
    && (!cats.size || cats.has(r.cat))
    && (!regs.size || r.regions.some((x) => regs.has(x)))
    && (!origins.size || origins.has(String(r.origin || '').trim().toUpperCase() || '__NONE__'))
    && (!q || String(r.code).toUpperCase().includes(q) || r.cat.includes(q) || r.makers.some((m) => m.includes(q))));
}

// ═══ ⑧ 매출원가 분석 (2026-10-12) ══════════════════════════════════════
//   코드(CTR · SYD · 경쟁사 교차참조) → 제품 매칭 + 「현재 기준」 1개당 원가 구성.
//   1개당 FOB(MXN) = FOB USD × 최신 환율
//   1개당 수입부대비용 = FOB(MXN) × 수입부대비율
//     수입부대비율 = (배치 부대비용[import_overheads]의 FOB 금액 비율 몫 + 승인된 부대비용 문서[import_cost_docs]의 이 제품 배분액)
//                    ÷ 이 제품의 수입 FOB 금액(MXN). 수입 기록이 없으면 전체 평균 비율.
//   FOB 가 없는 제품은 저장 평균원가(products.avg_cost)를 같은 비율로 FOB : 부대비용으로 나눈다(basis='avg').
//   판매단가 · 할인율 · 매출총이익 계산은 화면에서(단가를 바꿀 때마다 서버를 다시 부르지 않도록).
export const COST_SIM_MAX = 1000;
const normCode = (s) => String(s == null ? '' : s).toUpperCase().replace(/[^A-Z0-9]/g, '');

/** 코드 정규화값 목록 → Map(norm → { via, candidates:[{product_id, via, brand, matched}] })
 *  우선순위: CTR 코드(1) > SYD 대응품번(2) > 경쟁사 교차참조(3). 같은 우선순위에 제품이 여럿이면 모두 후보로. */
export async function resolveSimCodes(norms, exec = query) {
  const out = new Map();
  if (!norms.length) return out;
  const rows = (await exec(
    `SELECT norm, pid, pri, brand, matched FROM (
       SELECT regexp_replace(upper(p.code), '[^A-Z0-9]', '', 'g') AS norm, p.id AS pid, 1 AS pri, NULL::text AS brand, p.code AS matched
         FROM products p WHERE p.deleted_at IS NULL
          AND regexp_replace(upper(p.code), '[^A-Z0-9]', '', 'g') = ANY($1)
       UNION ALL
       SELECT regexp_replace(upper(s.syd_code), '[^A-Z0-9]', '', 'g'), s.product_id, 2, 'SYD', s.syd_code
         FROM product_syd_codes s JOIN products p ON p.id = s.product_id AND p.deleted_at IS NULL
        WHERE regexp_replace(upper(s.syd_code), '[^A-Z0-9]', '', 'g') = ANY($1)
       UNION ALL
       SELECT x.norm_code, x.product_id, 3, x.brand, x.xref_code
         FROM product_xref_codes x JOIN products p ON p.id = x.product_id AND p.deleted_at IS NULL
        WHERE x.norm_code = ANY($1)
     ) t ORDER BY norm, pri, pid`, [norms])).rows;
  const VIA = { 1: 'ctr', 2: 'syd', 3: 'xref' };
  for (const r of rows) {
    const pri = Number(r.pri); const pid = Number(r.pid);
    let e = out.get(r.norm);
    if (!e) { e = { pri, via: VIA[pri], candidates: [] }; out.set(r.norm, e); }
    if (pri !== e.pri) continue;                                     // 더 높은 우선순위가 이미 잡힘
    if (e.candidates.some((c) => c.product_id === pid)) continue;
    const brand = r.brand ? String(r.brand).toUpperCase().replace(/[0-9]+$/, '') : null;   // SYD1→SYD
    if (e.candidates.length < 8) e.candidates.push({ product_id: pid, via: VIA[pri], brand, matched: r.matched });
  }
  return out;
}

/** 제품 id 목록 → { fx, global_oh_rate, products: Map(id → 원가 구성) } */
export async function costSimBasis(pids, exec = query) {
  const fx = await latestFx(exec);
  const rate = fx ? fx.rate : null;
  const g = (await exec(`SELECT COALESCE(SUM(base),0) AS base, COALESCE(SUM(oh),0) AS oh FROM (${BB_SQL}) bb`)).rows[0];
  const gd = (await exec(
    `SELECT COALESCE(SUM(a.alloc_amount_mxn),0) AS oh
       FROM import_cost_allocations a
       JOIN import_cost_docs d ON d.id = a.doc_id AND d.status = 'approved' AND d.deleted_at IS NULL
       JOIN (${BB_SQL}) bb ON bb.id = a.batch_id`)).rows[0];
  const gBase = Number(g.base); const gOh = Number(g.oh) + Number(gd.oh);
  const gRate = gBase > 0 ? gOh / gBase : 0;
  const map = new Map();
  if (!pids.length) return { fx, global_oh_rate: gRate, products: map };
  const rows = (await exec(
    `WITH bb AS MATERIALIZED (${BB_SQL}),
     pl AS (
        SELECT l.product_id,
               SUM(l.qty * l.import_price * ${FXL_SQL}) AS val,
               SUM(l.qty * l.import_price * ${FXL_SQL} * CASE WHEN bb.base > 0 THEN bb.oh / bb.base ELSE 0 END) AS oh
          FROM import_lines l JOIN import_batches b ON b.id = l.batch_id JOIN bb ON bb.id = b.id
         WHERE l.product_id = ANY($1)
         GROUP BY l.product_id),
     dc AS (
        SELECT a.product_id, SUM(a.per_unit_mxn * a.batch_qty) AS oh
          FROM import_cost_adjustments a
          JOIN import_cost_docs d ON d.id = a.doc_id AND d.status = 'approved' AND d.deleted_at IS NULL
          JOIN bb ON bb.id = a.batch_id
         WHERE a.product_id = ANY($1)
         GROUP BY a.product_id)
     SELECT p.id, p.code, p.name, p.origin, p.is_active, p.list_price, p.fob_usd, p.avg_cost,
            pl.val, pl.oh AS io_oh, dc.oh AS doc_oh
       FROM products p
       LEFT JOIN pl ON pl.product_id = p.id
       LEFT JOIN dc ON dc.product_id = p.id
      WHERE p.id = ANY($1) AND p.deleted_at IS NULL`, [pids])).rows;
  const r2 = (x) => Math.round(x * 100) / 100; const r4 = (x) => Math.round(x * 10000) / 10000;
  for (const r of rows) {
    const val = Number(r.val || 0);
    const own = val > 0;
    const ohRate = own ? (Number(r.io_oh || 0) + Number(r.doc_oh || 0)) / val : gRate;
    const fob = r.fob_usd == null ? null : Number(r.fob_usd);
    const avg = r.avg_cost == null ? null : Number(r.avg_cost);
    let basis = null; let unitFob = null; let unitOh = null;
    if (fob > 0 && rate > 0) { basis = 'fob'; unitFob = fob * rate; unitOh = unitFob * ohRate; }
    else if (avg > 0) { basis = 'avg'; unitFob = avg / (1 + ohRate); unitOh = avg - unitFob; }
    map.set(Number(r.id), {
      id: Number(r.id), code: r.code, name: r.name, origin: r.origin, is_active: r.is_active !== false,
      list_price: r.list_price == null ? null : Number(r.list_price),
      fob_usd: fob, avg_cost: avg == null ? null : r2(avg),
      oh_rate: r4(ohRate), oh_source: own ? 'product' : 'global', basis,
      unit_fob_mxn: unitFob == null ? null : r4(unitFob),
      unit_oh_mxn: unitOh == null ? null : r4(unitOh),
      unit_cost: unitFob == null ? null : r4(unitFob + unitOh),
    });
  }
  return { fx, global_oh_rate: r4(gRate), products: map };
}

/** items [{code}] → 줄별 매칭 결과 + 제품 원가 구성(중복 제품은 한 번만) */
export async function costSim(items, exec = query) {
  const clean = items.slice(0, COST_SIM_MAX).map((it) => String((it && it.code) || '').trim()).filter(Boolean);
  const norms = [...new Set(clean.map(normCode).filter(Boolean))];
  const res = await resolveSimCodes(norms, exec);
  const pids = [...new Set([...res.values()].flatMap((e) => e.candidates.map((c) => c.product_id)))];
  const basis = await costSimBasis(pids, exec);
  const lines = clean.map((code) => {
    const e = res.get(normCode(code));
    return { code, via: e ? e.via : null, candidates: e ? e.candidates.filter((c) => basis.products.has(c.product_id)) : [] };
  });
  return {
    fx: basis.fx, global_oh_rate: basis.global_oh_rate,
    lines, products: [...basis.products.values()],
    matched: lines.filter((l) => l.candidates.length).length, unmatched: lines.filter((l) => !l.candidates.length).length,
  };
}
