// =====================================================================
// Refatrix ERP · productDims.js — 제품 무게 · 포장 박스 코드 · 포장 박스 마스터
//   0327 (2026-11-18) 제품 무게 · 개별 박스 사이즈
//   0328 (2026-11-18 디렉터 지시) 제품에는 가로·세로·높이 대신 「포장 박스 코드」를 넣고,
//        박스 코드별 사이즈는 포장 박스 마스터에 나중에 넣는다 → 사이즈는 박스 마스터로 계산.
//
//   2026-11-19 디렉터 지시 — 공장 마스터 파일(master_peso_y_dimension.xlsx: NEW · Weight(g) · Inner Box 1 · L · W · H)을
//        그대로 올려 쓴다. 기준: **제품 자체 사이즈(파일의 그 줄) 우선 → 없으면 박스 코드의 박스 마스터 사이즈**.
//        같은 업로드에서 박스 마스터 사이즈도 채운다(박스별로 가장 많이 나온 사이즈 — 줄마다 다르면 미리보기에 표시).
//
//   ① 제품마스터 업로드 탭 「📦 제품 무게 · 포장 박스 · 사이즈」 (Clave CTR · Peso (kg) · Caja · Largo · Ancho · Alto)
//   ② 같은 탭 「📐 포장 박스 마스터」                         (Código caja · Largo · Ancho · Alto · Descripción)
//   ③ 견적 건별 대략 총무게 · 총사이즈 — 견적 목록 · 상세가 같은 함수를 쓴다
//
//   칸 규칙(양식 안내문과 같다)
//   · 빈 칸 = 바꾸지 않음 · 「-」 = 값 지우기 · 같은 코드 여러 줄 = 마지막 줄
//   · 무게 kg(머리글에 g 면 그램) · 사이즈 cm(머리글에 mm 면 mm) · 소수점 「.」「,」 둘 다
//   · 박스 코드는 대문자 · 앞뒤 공백 제거로 맞춘다(「caja 3」 = 「CAJA 3」)
//
//   대략 사이즈 계산(estimate)
//   · 순부피 = Σ 수량 × (그 제품 박스의) 가로 × 세로 × 높이
//   · 포장부피 = 순부피 ÷ 채움률 0.85 → 정육면체에 가깝게, 가장 큰 박스보다 작지 않게 · 1개면 그 박스 그대로
//   · 박스 코드가 없거나 박스 사이즈가 아직 없는 줄은 빼고 개수만 알린다(추정해서 채우지 않는다)
// =====================================================================
import { query } from './db.js';

export const DIM_FIELDS = ['weight_kg', 'box_code', 'box_l_cm', 'box_w_cm', 'box_h_cm'];   // 제품 업로드가 바꾸는 칸
export const BOX_FIELDS = ['box_l_cm', 'box_w_cm', 'box_h_cm', 'description'];
export const FIELD_LABEL = { weight_kg: '무게(kg)', box_code: '박스 코드', box_l_cm: '가로(cm)', box_w_cm: '세로(cm)', box_h_cm: '높이(cm)', description: '설명' };
export const LIMITS = { weight_kg: 500, box_l_cm: 300, box_w_cm: 300, box_h_cm: 300 };
export const FILL_RATE = 0.85;
export const VOL_DIVISOR = 5000;

export const TEMPLATE_HEADERS = ['Clave CTR', 'Peso (kg)', 'Caja', 'Largo (cm)', 'Ancho (cm)', 'Alto (cm)'];
export const BOX_TEMPLATE_HEADERS = ['Código caja', 'Largo (cm)', 'Ancho (cm)', 'Alto (cm)', 'Descripción'];

// ── 0327 + 0328 적용 여부(마이그레이션 전 서버에서도 견적 목록이 깨지지 않게) ─────
let readyCache = { v: null, at: 0 };
export async function dimsReady(exec = query) {
  const now = Date.now();
  if (readyCache.v === true) return true;
  if (readyCache.v === false && now - readyCache.at < 60000) return false;
  try {
    const r = await exec(
      `SELECT (SELECT COUNT(*) FROM information_schema.columns
                WHERE table_schema = current_schema() AND table_name = 'products'
                  AND column_name IN ('weight_kg','box_code'))::int AS c,
              (SELECT COUNT(*) FROM information_schema.tables
                WHERE table_schema = current_schema() AND table_name = 'packing_boxes')::int AS t`);
    readyCache = { v: Number(r.rows[0].c) === 2 && Number(r.rows[0].t) === 1, at: now };
  } catch (_) { readyCache = { v: false, at: now }; }
  return readyCache.v;
}
export function _resetDimsReady() { readyCache = { v: null, at: 0 }; }

// ── 머리글 해석 ─────────────────────────────────────────────────────
const fold = (v) => String(v == null ? '' : v).normalize('NFD').replace(/[̀-ͯ]/g, '').normalize('NFC')
  .toLowerCase().trim();
const keyOf = (v) => fold(v).replace(/\(.*?\)|\[.*?\]/g, '').replace(/[^a-z0-9가-힣]/g, '');

const W_WEIGHT = ['peso', 'pesokg', 'pesounitario', 'pesog', 'pesogr', 'weight', 'weightkg', 'kg', '무게', '중량', '무게kg', '개당무게', '단위무게'];
const W_BOXCODE = ['innerbox', 'innerbox1', 'innerbox2', 'cajainterior', 'caja', 'cajas', 'codigocaja', 'clavecaja', 'cajacodigo', 'tipodecaja', 'tipocaja', 'empaque', 'box', 'boxcode', 'boxname',
  '박스', '박스코드', '박스명', '박스명칭', '포장박스', '포장박스코드', '포장박스명칭', '포장박스명'];
const W_L = ['largo', 'largocm', 'length', 'longitud', 'l', '가로', '가로cm', '길이'];
const W_W = ['ancho', 'anchocm', 'width', 'w', '세로', '세로cm', '폭'];
const W_H = ['alto', 'altocm', 'altura', 'height', 'h', '높이', '높이cm'];
const W_DIMS = ['medidas', 'medida', 'medidascaja', 'medidasdecaja', 'dimensiones', 'dimensions', 'dimension', 'size', 'boxsize',
  '사이즈', '박스사이즈', '규격', '박스규격', '치수', 'lxwxh', 'largoxanchoxalto', '가로세로높이', '가로x세로x높이'];
const W_DESC = ['descripcion', 'description', 'nombre', 'nombrecaja', 'notas', 'nota', '설명', '비고', '메모'];

const HEAD_WORDS = {
  // 제품 업로드: CTR 코드 · 무게 · 박스 코드 · (그 제품 자체) 가로 · 세로 · 높이
  //   공장 마스터 파일은 CTR 열 머리글이 「NEW」 다.
  product: {
    code: ['clavectr', 'ctr', 'codigoctr', 'codigo', 'clave', 'code', 'sku', 'clavesku', 'new', 'newcode', '제품코드', '코드', 'ctr코드', '품번'],
    weight_kg: W_WEIGHT, box_code: W_BOXCODE, box_l_cm: W_L, box_w_cm: W_W, box_h_cm: W_H, dims: W_DIMS,
  },
  // 박스 마스터 업로드: 박스 코드 · 가로 · 세로 · 높이 · 설명
  box: {
    code: W_BOXCODE.concat(['codigo', 'clave', 'code', '코드']),
    box_l_cm: W_L, box_w_cm: W_W, box_h_cm: W_H, dims: W_DIMS, description: W_DESC,
  },
};
const PREFIX_FIELDS = { product: ['weight_kg', 'box_code', 'box_l_cm', 'box_w_cm', 'box_h_cm', 'dims'], box: ['box_l_cm', 'box_w_cm', 'box_h_cm', 'dims', 'description'] };
const MAPS = {};
for (const [mode, fields] of Object.entries(HEAD_WORDS)) {
  MAPS[mode] = new Map();
  for (const [f, words] of Object.entries(fields)) for (const w of words) if (!MAPS[mode].has(w)) MAPS[mode].set(w, f);
}

/** 머리글 칸 → { field, scale } | null.  scale = 값에 곱해 kg · cm 로 만드는 수 */
export function headerField(cell, mode = 'product') {
  const raw = fold(cell);
  if (!raw) return null;
  const k = keyOf(cell);
  let field = MAPS[mode].get(k) || null;
  if (!field) {
    for (const f of PREFIX_FIELDS[mode]) {
      if (HEAD_WORDS[mode][f].some((w) => w.length >= 4 && k.startsWith(w))) { field = f; break; }
    }
  }
  if (!field) return null;
  let scale = 1;
  if (field === 'weight_kg') {
    if (/\(\s*(g|gr|grs|gramos?|grams?|그램)\s*\)|\bgramos?\b|\bgrams?\b|그램/.test(raw) || k === 'pesog' || k === 'pesogr') scale = 0.001;
    else if (/\(\s*(lb|lbs)\s*\)|\blbs?\b|libras?/.test(raw)) scale = 0.45359237;
  } else if (['box_l_cm', 'box_w_cm', 'box_h_cm', 'dims'].includes(field)) {
    if (/\(\s*mm\s*\)|\bmm\b|밀리/.test(raw)) scale = 0.1;
    else if (/\(\s*m\s*\)|\bmetros?\b/.test(raw)) scale = 100;
    else if (/\(\s*(in|inch|pulg)\s*\)|pulgadas?|inch/.test(raw)) scale = 2.54;
  }
  return { field, scale };
}

const CLEAR = new Set(['-', '–', '—', '삭제', 'clear', 'borrar', 'null']);

/** 숫자 칸 → { skip } | { clear } | { value } | { error } */
export function parseNum(raw, field, scale = 1) {
  if (raw == null) return { skip: true };
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw)) return { error: '숫자가 아님' };
    return checkRange(raw * scale, field, raw);
  }
  let s = String(raw).trim();
  if (!s) return { skip: true };
  if (CLEAR.has(s.toLowerCase())) return { clear: true };
  s = s.replace(/\s+/g, '').replace(/(kgs?|grs?|g|cms?|mm|kilos?)$/i, '');
  if (/^\d+,\d+$/.test(s)) s = s.replace(',', '.');
  else if (/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, '');
  if (!/^\d*\.?\d+$/.test(s)) return { error: `숫자가 아님: "${String(raw).trim()}"` };
  return checkRange(Number(s) * scale, field, raw);
}
function checkRange(n, field, raw) {
  if (!(n > 0)) return { error: `0 보다 커야 함: "${String(raw).trim()}"` };
  const lim = LIMITS[field];
  if (lim && n > lim) return { error: `${FIELD_LABEL[field] || field} ${round(n, 3)} — 너무 큼(최대 ${lim})` };
  const v = round(n, field === 'weight_kg' ? 3 : 1);
  if (!(v > 0)) return { error: `너무 작음: "${String(raw).trim()}"` };
  return { value: v };
}

/** 「30x20x10」 · 「30 × 20 × 10 cm」 · 「30*20*10」 → [30,20,10] */
export function parseDimsCell(raw, scale = 1) {
  if (raw == null) return { skip: true };
  const s0 = String(raw).trim();
  if (!s0) return { skip: true };
  if (CLEAR.has(s0.toLowerCase())) return { clear: true };
  const s = s0.toLowerCase().replace(/cm|mm/g, '').replace(/,(?=\d)/g, '.');
  const parts = s.split(/\s*[x×*✕]\s*/).filter((p) => p !== '');
  if (parts.length !== 3) return { error: `사이즈는 「가로x세로x높이」 3개 숫자: "${s0}"` };
  const out = []; const flds = ['box_l_cm', 'box_w_cm', 'box_h_cm'];
  for (let i = 0; i < 3; i++) {
    const r = parseNum(parts[i], flds[i], scale);
    if (r.error) return { error: `사이즈 "${s0}" — ${r.error}` };
    if (!r.value) return { error: `사이즈 "${s0}" 를 읽을 수 없음` };
    out.push(r.value);
  }
  return { value: out };
}

export const normCode = (v) => String(v == null ? '' : v).trim().toUpperCase().replace(/\s+/g, '');
/** 박스 코드: 대문자 · 공백 하나로 · 40자 */
export const normBox = (v) => String(v == null ? '' : v).trim().toUpperCase().replace(/\s+/g, ' ');
export function parseText(raw, { box = false, max = 200 } = {}) {
  if (raw == null) return { skip: true };
  const s = String(raw).trim();
  if (!s) return { skip: true };
  if (CLEAR.has(s.toLowerCase())) return { clear: true };
  const v = box ? normBox(s) : s.replace(/\s+/g, ' ');
  if (box && v.length > 40) return { error: `박스 코드가 너무 김(40자): "${s}"` };
  return { value: v.slice(0, max) };
}

/**
 * 2차원 표(엑셀 첫 시트) → { rows:[{row, code, set}], errors, headerless, columns, dup }
 *   mode 'product' : 머리글이 없으면 CTR · 무게 · 박스 코드 순
 *   mode 'box'     : 머리글이 없으면 박스 코드 · 가로 · 세로 · 높이 · 설명 순
 */
export function tableToRows(table, mode = 'product') {
  const t = Array.isArray(table) ? table.filter((r) => Array.isArray(r)) : [];
  const valFields = mode === 'box' ? ['box_l_cm', 'box_w_cm', 'box_h_cm', 'dims', 'description'] : ['weight_kg', 'box_code', 'box_l_cm', 'box_w_cm', 'box_h_cm', 'dims'];
  let hIdx = -1; let cols = null;
  for (let i = 0; i < Math.min(t.length, 15); i++) {
    const m = {};
    t[i].forEach((c, j) => { const h = headerField(c, mode); if (h && !(h.field in m)) m[h.field] = { idx: j, scale: h.scale }; });
    if ('code' in m && valFields.some((f) => f in m)) { hIdx = i; cols = m; break; }
  }
  const headerless = hIdx < 0;
  if (headerless) {
    cols = mode === 'box'
      ? { code: { idx: 0, scale: 1 }, box_l_cm: { idx: 1, scale: 1 }, box_w_cm: { idx: 2, scale: 1 }, box_h_cm: { idx: 3, scale: 1 }, description: { idx: 4, scale: 1 } }
      : { code: { idx: 0, scale: 1 }, weight_kg: { idx: 1, scale: 1 }, box_code: { idx: 2, scale: 1 }, box_l_cm: { idx: 3, scale: 1 }, box_w_cm: { idx: 4, scale: 1 }, box_h_cm: { idx: 5, scale: 1 } };
  }
  const byCode = new Map(); const errors = []; const warnings = []; let dup = 0; let conflict = 0;
  const boxTally = new Map();     // 제품 업로드: 박스 코드 → { "l|w|h": 줄 수 } (박스 마스터 사이즈 추출)
  for (let i = hIdx + 1; i < t.length; i++) {
    const r = t[i];
    const code = mode === 'box' ? normBox(r[cols.code.idx]) : normCode(r[cols.code.idx]);
    if (!code) continue;
    if (headerless && i === 0 && (mode === 'box' ? headerField(r[0], 'box') : !/\d/.test(code))) continue;   // 머리글 같은 첫 줄
    if (mode === 'box' && code.length > 40) { errors.push({ row: i + 1, code, msg: '박스 코드가 너무 김(40자)' }); continue; }
    const set = {}; const errs = [];
    if (cols.dims) {
      const d = parseDimsCell(r[cols.dims.idx], cols.dims.scale);
      if (d.error) errs.push(d.error);
      else if (d.clear) { set.box_l_cm = null; set.box_w_cm = null; set.box_h_cm = null; }
      else if (d.value) { [set.box_l_cm, set.box_w_cm, set.box_h_cm] = d.value; }
    }
    for (const f of ['weight_kg', 'box_l_cm', 'box_w_cm', 'box_h_cm']) {
      if (!cols[f]) continue;
      const p = parseNum(r[cols[f].idx], f, cols[f].scale);
      if (p.error) errs.push(`${FIELD_LABEL[f]} ${p.error}`);
      else if (p.clear) set[f] = null;
      else if (p.value != null) set[f] = p.value;
    }
    for (const f of ['box_code', 'description']) {
      if (!cols[f]) continue;
      const p = parseText(r[cols[f].idx], { box: f === 'box_code' });
      if (p.error) errs.push(p.error);
      else if (p.clear) set[f] = null;
      else if (p.value != null) set[f] = p.value;
    }
    const rowNo = i + 1;
    if (errs.length) { errors.push({ row: rowNo, code, msg: errs.join(' · ') }); continue; }
    if (mode === 'product') {
      // 제품 사이즈는 3개가 모두 있을 때만(일부만 있으면 사이즈만 건너뛰고 경고). 「-」 지우기는 3개 함께.
      const dk = ['box_l_cm', 'box_w_cm', 'box_h_cm'];
      const has = dk.filter((f) => f in set);
      const vals = has.map((f) => set[f]);
      if (has.length) {
        const allNum = has.length === 3 && vals.every((v) => v > 0);
        const anyClear = vals.some((v) => v === null);
        if (anyClear) { for (const f of dk) set[f] = null; }
        else if (!allNum) { for (const f of dk) delete set[f]; warnings.push({ row: rowNo, code, msg: '가로 · 세로 · 높이 중 일부만 있음 — 사이즈는 건너뜀' }); }
      }
      if (set.box_code && dk.every((f) => set[f] > 0)) {
        const k = dk.map((f) => set[f]).join('|');
        const m = boxTally.get(set.box_code) || new Map(); m.set(k, (m.get(k) || 0) + 1); boxTally.set(set.box_code, m);
      }
    }
    if (!Object.keys(set).length && mode !== 'box') continue;    // 제품: 모두 빈 칸 = 바꿀 것 없음 (박스: 코드만 적어도 등록)
    const prev = byCode.get(code);
    if (prev) {
      dup++;
      if (Object.keys(set).some((f) => f in prev.set && !sameVal(prev.set[f], set[f]))) conflict++;
    }
    byCode.set(code, { row: rowNo, code, set: { ...(prev?.set || {}), ...set } });
  }
  const columns = Object.keys(cols).filter((k) => k !== 'code');
  // 박스별 가장 많이 나온 사이즈(같으면 먼저 나온 것) → 박스 마스터 후보
  const boxSizes = [];
  for (const [bc, m] of boxTally) {
    const variants = [...m.entries()].map(([k, n]) => { const [l, w, h] = k.split('|').map(Number); return { l, w, h, n }; });
    const best = variants.reduce((a, b) => (b.n > a.n ? b : a), variants[0]);
    boxSizes.push({ code: bc, l: best.l, w: best.w, h: best.h, rows: variants.reduce((x, v) => x + v.n, 0), variants: variants.sort((a, b) => b.n - a.n) });
  }
  boxSizes.sort((a, b) => a.code.localeCompare(b.code));
  return { rows: [...byCode.values()], errors, warnings, headerless, columns, dup, conflict, box_sizes: boxSizes };
}

// ── 공통 ────────────────────────────────────────────────────────────
const numOrNull = (v) => (v == null || v === '' ? null : Number(v));
const sameVal = (a, b) => {
  if (a == null && b == null) return true;
  if (a == null || b == null) return false;
  if (typeof a === 'number' || typeof b === 'number') return Math.abs(Number(a) - Number(b)) < 1e-9;
  return String(a) === String(b);
};
const newBatch = (p) => p + '-' + new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14) + '-' + Math.random().toString(36).slice(2, 6);

// ── 제품 무게 · 박스 코드 : 미리보기 · 반영 ─────────────────────────
/** → { items:[{code, product_id, name, changes}], unknown:[{row,code}], same, new_boxes:[code], nosize_boxes:[code] } */
export async function previewDims(exec, rows) {
  const codes = [...new Set(rows.map((r) => r.code))];
  const cur = new Map();
  if (codes.length) {
    const res = await exec(
      `SELECT id, code, name, weight_kg, box_code, box_l_cm, box_w_cm, box_h_cm
         FROM products WHERE deleted_at IS NULL AND UPPER(REPLACE(code,' ','')) = ANY($1::text[])`, [codes]);
    for (const p of res.rows) cur.set(normCode(p.code), p);
  }
  const items = []; const unknown = []; let same = 0; const boxesUsed = new Set();
  for (const r of rows) {
    const p = cur.get(r.code);
    if (!p) { unknown.push({ row: r.row, code: r.code }); continue; }
    if (r.set.box_code) boxesUsed.add(r.set.box_code);
    const changes = [];
    for (const f of DIM_FIELDS) {
      if (!(f in r.set)) continue;
      const o = f === 'box_code' ? (p[f] || null) : numOrNull(p[f]); const n = r.set[f];
      if (!sameVal(o, n)) changes.push({ field: f, old: o, new: n });
    }
    if (!changes.length) { same++; continue; }
    items.push({ row: r.row, code: p.code, product_id: Number(p.id), name: p.name || '', changes });
  }
  // 박스 마스터 대조 — 없는 박스 · 사이즈 없는 박스(나중에 박스 마스터에서 넣으면 계산된다)
  const newBoxes = []; const nosize = [];
  if (boxesUsed.size) {
    const b = await exec(`SELECT code, box_l_cm, box_w_cm, box_h_cm FROM packing_boxes WHERE code = ANY($1::text[])`, [[...boxesUsed]]);
    const m = new Map(b.rows.map((x) => [x.code, x]));
    for (const c of [...boxesUsed].sort()) {
      const x = m.get(c);
      if (!x) newBoxes.push(c);
      else if (!(Number(x.box_l_cm) > 0 && Number(x.box_w_cm) > 0 && Number(x.box_h_cm) > 0)) nosize.push(c);
    }
  }
  return { items, unknown, same, new_boxes: newBoxes, nosize_boxes: nosize };
}

/** 파일에서 뽑은 박스별 사이즈(tableToRows().box_sizes) → 박스 마스터 미리보기 줄 */
export const boxRowsFromSizes = (sizes) => (sizes || []).map((b) => ({ row: 0, code: b.code, set: { box_l_cm: b.l, box_w_cm: b.w, box_h_cm: b.h } }));
/** 박스별 사이즈가 줄마다 다른 것(가장 많은 값을 쓴다) */
export const boxConflicts = (sizes) => (sizes || []).filter((b) => b.variants.length > 1)
  .map((b) => ({ code: b.code, used: { l: b.l, w: b.w, h: b.h }, rows: b.rows, variants: b.variants }));

/**
 * 한 트랜잭션 안에서 실행(exec = client.query.bind(client)).
 *   · 새 박스 코드는 박스 마스터에 만든다 · boxSizes 가 있으면 박스 마스터 사이즈도 그 값으로(applyBoxes)
 *   · 제품 1만여 건도 한 번에 — 칸마다 UPDATE … FROM unnest 1문 + 이력 INSERT 1문
 */
export async function applyDims(exec, rows, { userId = null, source = 'excel', boxSizes = [] } = {}) {
  const pv = await previewDims(exec, rows);
  const batch = newBatch('dims');
  if (pv.new_boxes.length) {
    await exec(`INSERT INTO packing_boxes (code, updated_by) SELECT c, $2 FROM unnest($1::text[]) AS c ON CONFLICT (code) DO NOTHING`, [pv.new_boxes, userId]);
    await exec(`INSERT INTO packing_box_log (batch_id, box_code, field, old_value, new_value, changed_by)
                SELECT $1, c, '(new)', NULL, 'product upload', $3 FROM unnest($2::text[]) AS c`, [batch, pv.new_boxes, userId]);
  }
  const byField = {}; const log = { pid: [], code: [], field: [], on: [], nn: [], ot: [], nt: [] };
  for (const it of pv.items) {
    for (const ch of it.changes) {
      byField[ch.field] = byField[ch.field] || { id: [], v: [] };
      byField[ch.field].id.push(it.product_id); byField[ch.field].v.push(ch.new);
      const num = ch.field !== 'box_code';
      log.pid.push(it.product_id); log.code.push(it.code); log.field.push(ch.field);
      log.on.push(num ? ch.old : null); log.nn.push(num ? ch.new : null); log.ot.push(num ? null : ch.old); log.nt.push(num ? null : ch.new);
    }
  }
  for (const [f, d] of Object.entries(byField)) {
    if (!DIM_FIELDS.includes(f)) continue;
    const typ = f === 'box_code' ? 'text' : 'numeric';
    await exec(`UPDATE products p SET ${f} = v.val FROM unnest($1::bigint[], $2::${typ}[]) AS v(id, val) WHERE p.id = v.id`, [d.id, d.v]);
  }
  const ids = pv.items.map((it) => it.product_id);
  if (ids.length) {
    await exec(`UPDATE products SET dims_updated_at = now(), dims_updated_by = $2 WHERE id = ANY($1::bigint[])`, [ids, userId]);
    await exec(
      `INSERT INTO product_dims_log (batch_id, product_id, code, field, old_value, new_value, old_text, new_text, source, changed_by)
       SELECT $1, u.pid, u.code, u.field, u.ov, u.nv, u.ot, u.nt, $9, $10
         FROM unnest($2::bigint[], $3::text[], $4::text[], $5::numeric[], $6::numeric[], $7::text[], $8::text[]) AS u(pid, code, field, ov, nv, ot, nt)`,
      [batch, log.pid, log.code, log.field, log.on, log.nn, log.ot, log.nt, source, userId]);
  }
  const bx = boxSizes.length ? await applyBoxes(exec, boxRowsFromSizes(boxSizes), { userId }) : null;
  return { batch_id: batch, products: pv.items.length, fields: log.pid.length, unknown: pv.unknown, same: pv.same,
    new_boxes: pv.new_boxes, nosize_boxes: pv.nosize_boxes, boxes: bx };
}

/** 현재값 다운로드 — 전체 제품(삭제 제외). 제품 자체 사이즈 + 박스 마스터 사이즈(참고) + 계산에 쓰는 사이즈 */
export async function exportDims(exec = query) {
  const r = await exec(
    `SELECT p.code, p.name, p.weight_kg, p.box_code, p.is_active, p.box_l_cm AS pl, p.box_w_cm AS pw, p.box_h_cm AS ph,
            b.box_l_cm AS bl, b.box_w_cm AS bw, b.box_h_cm AS bh,
            to_char(p.dims_updated_at AT TIME ZONE 'America/Mexico_City', 'YYYY-MM-DD HH24:MI') AS updated_at
       FROM products p LEFT JOIN packing_boxes b ON b.code = p.box_code
      WHERE p.deleted_at IS NULL ORDER BY p.code`);
  const ok3 = (a, b, c) => a > 0 && b > 0 && c > 0;
  const items = r.rows.map((p) => {
    const pl = numOrNull(p.pl); const pw = numOrNull(p.pw); const ph = numOrNull(p.ph);
    const bl = numOrNull(p.bl); const bw = numOrNull(p.bw); const bh = numOrNull(p.bh);
    const own = ok3(pl, pw, ph); const fromBox = !own && !!p.box_code && ok3(bl, bw, bh);
    return {
      code: p.code, name: p.name || '', is_active: p.is_active !== false,
      weight_kg: numOrNull(p.weight_kg), box_code: p.box_code || null,
      box_l_cm: pl, box_w_cm: pw, box_h_cm: ph,                    // 제품 자체 사이즈(업로드 칸)
      caja_l_cm: bl, caja_w_cm: bw, caja_h_cm: bh,                 // 박스 마스터 사이즈(참고)
      used: own ? 'producto' : fromBox ? 'caja' : null,
      updated_at: p.updated_at || null,
    };
  });
  const stat = { total: items.length, weight: 0, box: 0, own: 0, sized: 0 };
  for (const it of items) {
    if (it.weight_kg > 0) stat.weight++;
    if (it.box_code) stat.box++;
    if (it.used === 'producto') stat.own++;
    if (it.used) stat.sized++;
  }
  return { items, stat };
}

// ── 포장 박스 마스터 : 미리보기 · 반영 · 다운로드 ────────────────────
export async function previewBoxes(exec, rows) {
  const codes = rows.map((r) => r.code);
  const cur = new Map();
  if (codes.length) {
    const res = await exec(`SELECT code, description, box_l_cm, box_w_cm, box_h_cm FROM packing_boxes WHERE code = ANY($1::text[])`, [codes]);
    for (const b of res.rows) cur.set(b.code, b);
  }
  const used = new Map();
  if (codes.length) {
    const u = await exec(`SELECT box_code, COUNT(*)::int AS n FROM products WHERE deleted_at IS NULL AND box_code = ANY($1::text[]) GROUP BY box_code`, [codes]);
    for (const x of u.rows) used.set(x.box_code, Number(x.n));
  }
  const items = []; let same = 0;
  for (const r of rows) {
    const b = cur.get(r.code);
    const changes = [];
    for (const f of BOX_FIELDS) {
      if (!(f in r.set)) continue;
      const o = b ? (f === 'description' ? (b[f] || null) : numOrNull(b[f])) : null; const n = r.set[f];
      if (!sameVal(o, n)) changes.push({ field: f, old: o, new: n });
    }
    if (b && !changes.length) { same++; continue; }
    items.push({ row: r.row, code: r.code, is_new: !b, products: used.get(r.code) || 0, changes });
  }
  return { items, same };
}

export async function applyBoxes(exec, rows, { userId = null } = {}) {
  const pv = await previewBoxes(exec, rows);
  const batch = newBatch('box');
  let fields = 0;
  for (const it of pv.items) {
    if (it.is_new) {
      await exec(`INSERT INTO packing_boxes (code, updated_by) VALUES ($1,$2) ON CONFLICT (code) DO NOTHING`, [it.code, userId]);
      await exec(`INSERT INTO packing_box_log (batch_id, box_code, field, old_value, new_value, changed_by) VALUES ($1,$2,'(new)',NULL,'box upload',$3)`, [batch, it.code, userId]);
    }
    if (it.changes.length) {
      const sets = []; const args = [it.code];
      for (const ch of it.changes) { args.push(ch.new); sets.push(`${ch.field} = $${args.length}`); }
      args.push(userId);
      await exec(`UPDATE packing_boxes SET ${sets.join(', ')}, updated_at = now(), updated_by = $${args.length} WHERE code = $1`, args);
      for (const ch of it.changes) {
        await exec(`INSERT INTO packing_box_log (batch_id, box_code, field, old_value, new_value, changed_by) VALUES ($1,$2,$3,$4,$5,$6)`,
          [batch, it.code, ch.field, ch.old == null ? null : String(ch.old), ch.new == null ? null : String(ch.new), userId]);
        fields++;
      }
    }
  }
  return { batch_id: batch, boxes: pv.items.length, created: pv.items.filter((x) => x.is_new).length, fields, same: pv.same };
}

/** 박스 마스터 다운로드 — 등록된 박스 + 제품에만 적혀 있고 아직 마스터에 없는 박스(사이즈 빈 칸) */
export async function exportBoxes(exec = query) {
  const r = await exec(
    `WITH used AS (SELECT box_code AS code, COUNT(*)::int AS n FROM products WHERE deleted_at IS NULL AND box_code IS NOT NULL GROUP BY box_code)
     SELECT COALESCE(b.code, u.code) AS code, b.description, b.box_l_cm, b.box_w_cm, b.box_h_cm, COALESCE(u.n, 0) AS products,
            (b.code IS NULL) AS missing,
            to_char(b.updated_at AT TIME ZONE 'America/Mexico_City', 'YYYY-MM-DD HH24:MI') AS updated_at
       FROM packing_boxes b FULL OUTER JOIN used u ON u.code = b.code
      ORDER BY 1`);
  const items = r.rows.map((b) => ({
    code: b.code, description: b.description || '', box_l_cm: numOrNull(b.box_l_cm), box_w_cm: numOrNull(b.box_w_cm), box_h_cm: numOrNull(b.box_h_cm),
    products: Number(b.products) || 0, in_master: !b.missing, updated_at: b.updated_at || null,
  }));
  const stat = { total: items.length, sized: 0, nosize: 0, nosize_products: 0 };
  for (const it of items) {
    if (it.box_l_cm > 0 && it.box_w_cm > 0 && it.box_h_cm > 0) stat.sized++;
    else { stat.nosize++; stat.nosize_products += it.products; }
  }
  return { items, stat };
}

// ── 현실 적재(박스 쌓기) — 2026-11-19 디렉터 지시: 「총 박스 사이즈는 현실에 맞게 합해서」 ─────────
//   박스를 실제로 놓아 본다(겹치지 않게, 빈틈은 빈틈대로 사이즈에 들어간다).
//   · 박스는 눕혀서 쌓는다 — 가장 짧은 변이 높이(실제 포장·적재 방식). 바닥에서는 90° 돌려 놓을 수 있다.
//   · 높은 박스부터 층(layer)을 만든다. 한 층 안에서는 줄(row)로 채운다(줄 깊이 = 그 줄 가장 깊은 박스).
//     층 높이 = 그 층에서 가장 높은 박스. 전체 높이 = 층 높이의 합.
//   · 바닥(가로×세로)을 여러 크기로 시험해 보고 고른다: ① 묶음 수가 적은 것 ② 탑처럼 좁고 높지 않은 것
//     (높이 ≤ 바닥의 짧은 변) ③ 전체 부피가 작은 것 — 한 줄로 길게 늘어선 모양은 벌점 ④ 가장 긴 변이 짧은 것.
//   · 바닥은 팔레트 크기(120×100 cm)를 넘지 않게 — 박스 하나가 그보다 크면 그 박스 크기까지.
//     높이가 170 cm 를 넘으면 층을 나눠 「묶음(팔레트) n개」로 낸다.
//   · 박스가 아주 많으면(1,500개 초과) 놓아 보는 대신 부피 ÷ 적재율 0.8 로 팔레트 수를 어림한다.
export const PACK_LIMIT = { l: 120, w: 100, h: 170 };
export const PACK_MAX_ITEMS = 1500;
const up1 = (x) => Math.ceil(x - 1e-9);

function shelfPack(items, X, Y, mode = 0) {
  // mode 0 = 줄마다 덜 깊어지는 쪽으로 돌려 놓기 · 1 = 긴 변을 가로로 고정 · 2 = 긴 변을 세로로 고정(안 들어가면 돌림)
  // items: [{a,b,h}] (a≥b, 높이 내림차순 정렬)  → { layers:[{h, n}], usedX, usedY, H }
  const layers = []; let usedX = 0; let usedY = 0;
  let layer = null; let rowY = 0; let rowDepth = 0; let rowX = 0;
  const newLayer = () => { layer = { h: 0, n: 0 }; layers.push(layer); rowY = 0; rowDepth = 0; rowX = 0; };
  newLayer();
  for (const it of items) {
    let placed = false;
    for (let tries = 0; tries < 3 && !placed; tries++) {
      // 같은 줄에 놓기: (a,b) 또는 (b,a) 중 들어가는 것 — 줄 깊이를 덜 늘리는 쪽 먼저
      const fit = ([dx, dy]) => rowX + dx <= X + 1e-9 && rowY + dy <= Y + 1e-9;
      let opts = [[it.a, it.b], [it.b, it.a]].filter(fit);
      if (mode && opts.length > 1) opts = [mode === 1 ? [it.a, it.b] : [it.b, it.a]];
      else if (mode && opts.length === 1 && rowX > 0) {
        // 고정 방향이 안 맞으면 다른 방향으로 이 줄에 끼우지 않고 다음 줄로(줄이 들쭉날쭉해지지 않게) — 박스가 커서 한 방향만 되는 경우는 그대로
        const want = mode === 1 ? [it.a, it.b] : [it.b, it.a];
        if (opts[0][0] !== want[0] && want[0] <= X + 1e-9 && want[1] <= Y + 1e-9) opts = [];
      }
      if (opts.length) {
        if (!mode) opts.sort((p, q) => Math.max(rowDepth, p[1]) - Math.max(rowDepth, q[1]) || p[0] - q[0]);
        const [dx, dy] = opts[0];
        rowX += dx; rowDepth = Math.max(rowDepth, dy);
        usedX = Math.max(usedX, rowX); usedY = Math.max(usedY, rowY + rowDepth);
        layer.h = Math.max(layer.h, it.h); layer.n++;
        placed = true;
      } else if (rowX > 0 && rowY + rowDepth < Y) { rowY += rowDepth; rowX = 0; rowDepth = 0; }   // 다음 줄
      else if (layer.n > 0) newLayer();                                                              // 다음 층
      else break;
    }
    if (!placed) return null;   // 바닥보다 큰 박스(후보 제외)
  }
  return { layers: layers.filter((l) => l.n > 0), usedX, usedY, H: layers.reduce((s, l) => s + l.h, 0) };
}

function splitStacks(layers, maxH) {
  const stacks = []; let cur = null;
  for (const l of layers) {
    if (!cur || (cur.h + l.h > maxH && cur.n > 0)) { cur = { h: 0, n: 0, layers: 0 }; stacks.push(cur); }
    cur.h += l.h; cur.n += l.n; cur.layers++;
  }
  return stacks;
}

/**
 * groups: [{l,w,h,n}] (cm · 개수) → { dims:{l,w,h}, stacks:[{l,w,h,boxes,layers}], boxes, layers, fill, method }
 *   dims = 묶음이 1개면 그 사이즈, 여러 개면 묶음 하나(가장 큰 것) 사이즈 · stacks 에 전부.
 */
const packCache = new Map();   // 같은 박스 구성은 다시 계산하지 않는다(견적 목록 · 미리보기 반복 호출)
export function packBoxes(groups, limit = PACK_LIMIT) {
  const ck = JSON.stringify([limit, (groups || []).map((g) => [g.l, g.w, g.h, g.n]).sort()]);
  if (packCache.has(ck)) return packCache.get(ck);
  const res = packBoxesRaw(groups, limit);
  if (packCache.size > 5000) packCache.clear();
  packCache.set(ck, res);
  return res;
}
function packBoxesRaw(groups, limit) {
  const gs = (groups || []).map((g) => { const s = [Number(g.l), Number(g.w), Number(g.h)].sort((x, y) => y - x); return { a: s[0], b: s[1], h: s[2], n: Math.max(0, Math.round(Number(g.n) || 0)) }; })
    .filter((g) => g.n > 0 && g.a > 0 && g.b > 0 && g.h > 0);
  const N = gs.reduce((s, g) => s + g.n, 0);
  if (!N) return null;
  const net = gs.reduce((s, g) => s + g.n * g.a * g.b * g.h, 0);
  const maxA = Math.max(...gs.map((g) => g.a)); const maxB = Math.max(...gs.map((g) => g.b));
  const capX = Math.max(limit.l, maxA); const capY = Math.max(limit.w, maxB);
  const maxH = Math.max(limit.h, ...gs.map((g) => g.h));
  if (N === 1) {
    const g = gs[0];
    return { dims: { l: g.a, w: g.b, h: g.h }, stacks: [{ l: g.a, w: g.b, h: g.h, boxes: 1, layers: 1 }], boxes: 1, layers: 1, fill: 1, method: 'single', net_cm3: net };
  }
  if (N > PACK_MAX_ITEMS) {
    const per = capX * capY * limit.h * 0.8;
    const k = Math.max(1, Math.ceil(net / per));
    const h = up1(Math.min(limit.h, net / 0.8 / k / (capX * capY)));
    return { dims: { l: capX, w: capY, h }, stacks: Array.from({ length: k }, () => ({ l: capX, w: capY, h, boxes: Math.ceil(N / k), layers: null })),
      boxes: N, layers: null, fill: 0.8, method: 'volume', net_cm3: net };
  }
  const items = [];
  for (const g of gs.sort((p, q) => q.h - p.h || q.a * q.b - p.a * p.b)) for (let i = 0; i < g.n; i++) items.push(g);
  const foot = items.reduce((s, it) => s + it.a * it.b, 0);
  // 바닥 후보: 층 수 k 마다 (바닥 넓이 ≈ 전체 바닥 ÷ k) + 박스 변의 배수 + 팔레트
  const cands = new Map();
  const addC = (x, y) => {
    let X = Math.min(capX, Math.max(maxA, x)); let Y = Math.min(capY, Math.max(maxB, y));
    if (Y > X && Y <= capX && X <= capY) [X, Y] = [Y, X];
    const key = X.toFixed(1) + 'x' + Y.toFixed(1); if (!cands.has(key)) cands.set(key, [X, Y]);
  };
  const kMax = Math.min(items.length, 20);
  for (let k = 1; k <= kMax; k++) {
    const area = foot / k;
    const s = Math.sqrt(area);
    addC(s, area / Math.max(s, 1e-9));
    addC(s * 1.25, area / (s * 1.25));
    addC(s / 1.25, area / (s / 1.25));
  }
  const big = gs[0];
  for (let m = 1; m <= 5; m++) for (let r = 1; r <= 5; r++) addC(big.a * m, big.b * r);
  addC(capX, capY);
  let best = null;
  for (const [X, Y] of cands.values()) for (const mode of [0, 1, 2]) {
    const p = shelfPack(items, X, Y, mode);
    if (!p) continue;
    const stacks = splitStacks(p.layers, maxH);
    const L = up1(p.usedX); const W = up1(p.usedY);
    const st = stacks.map((s) => ({ l: L, w: W, h: up1(s.h), boxes: s.n, layers: s.layers }));
    const vol = st.reduce((s, x) => s + x.l * x.w * x.h, 0);
    const dimMax = Math.max(L, W, st[0].h);
    // 안정성: 묶음 높이가 바닥의 짧은 변보다 높으면(탑처럼 좁고 높으면) 실제로 그렇게 쌓지 않는다 → 뒤로
    const tall = st.some((x) => x.h > Math.min(L, W) + 1e-9) ? 1 : 0;
    // 모양: 한 줄로 길게 늘어선 배치(가장 긴 변 ÷ 가장 짧은 변 > 2)는 부피에 벌점 — 실제로는 덩어리로 쌓는다
    const asp = Math.max(...st.map((x) => Math.max(x.l, x.w, x.h) / Math.max(1e-9, Math.min(x.l, x.w, x.h))));
    const shaped = vol * (1 + 0.15 * Math.max(0, asp - 2) ** 2);
    const score = [st.length, tall, shaped, dimMax];
    const better = (a, b) => { for (let i = 0; i < a.length; i++) { if (a[i] < b[i] - 1e-6) return true; if (a[i] > b[i] + 1e-6) return false; } return false; };
    if (!best || better(score, best.score)) best = { score, st, layers: p.layers.length, vol };
  }
  if (!best) return null;
  const main = best.st.reduce((a, b) => (b.h > a.h ? b : a), best.st[0]);
  return { dims: { l: main.l, w: main.w, h: main.h }, stacks: best.st, boxes: N, layers: best.layers,
    fill: Math.round(net / best.vol * 1000) / 1000, method: 'stack', net_cm3: net };
}

// ── 견적 무게 · 사이즈 ──────────────────────────────────────────────
function round(n, d = 1) { const k = 10 ** d; return Math.round(Number(n) * k) / k; }

/** 견적 줄 → 집계(목록 SQL 의 LATERAL 과 같은 모양)
 *   줄: { product_id, qty, weight_kg, box_code, p_l, p_w, p_h (제품 자체 사이즈), box_l_cm, box_w_cm, box_h_cm (박스 마스터) }
 *   사이즈 = 제품 자체 사이즈(3개 모두) → 없으면 박스 마스터 사이즈 */
export function aggregateLines(lines) {
  const a = { pcs: 0, wt: 0, wt_pcs: 0, wt_miss: 0, wt_miss_qty: 0, vol: 0, d_pcs: 0, d_miss: 0, d_miss_qty: 0,
    d_nobox: 0, d_nobox_qty: 0, d_nosize: 0, d_nosize_qty: 0, d_a: 0, d_b: 0, d_c: 0, unreg: 0, unreg_qty: 0 };
  const nosizeBoxes = new Set(); const grp = new Map();
  for (const l of lines || []) {
    const q = Number(l.qty) || 0;
    if (q <= 0) continue;
    if (l.product_id == null) { a.unreg++; a.unreg_qty += q; continue; }
    a.pcs += q;
    const w = Number(l.weight_kg) || 0;
    if (w > 0) { a.wt += q * w; a.wt_pcs += q; } else { a.wt_miss++; a.wt_miss_qty += q; }
    const own = [Number(l.p_l) || 0, Number(l.p_w) || 0, Number(l.p_h) || 0];
    const bxs = [Number(l.box_l_cm) || 0, Number(l.box_w_cm) || 0, Number(l.box_h_cm) || 0];
    const s = own.every((x) => x > 0) ? own : (l.box_code ? bxs : [0, 0, 0]);
    if (s.every((x) => x > 0)) {
      s.sort((x, y) => y - x);
      const gk = s.join('|'); const g = grp.get(gk) || { l: s[0], w: s[1], h: s[2], n: 0 }; g.n += q; grp.set(gk, g);
      a.vol += q * s[0] * s[1] * s[2]; a.d_pcs += q;
      a.d_a = Math.max(a.d_a, s[0]); a.d_b = Math.max(a.d_b, s[1]); a.d_c = Math.max(a.d_c, s[2]);
    } else {
      a.d_miss++; a.d_miss_qty += q;
      if (!l.box_code) { a.d_nobox++; a.d_nobox_qty += q; } else { a.d_nosize++; a.d_nosize_qty += q; nosizeBoxes.add(String(l.box_code)); }
    }
  }
  a.nosize_boxes = [...nosizeBoxes].sort();
  a.groups = [...grp.values()];
  return a;
}

/** 집계 → 화면용 { weight_kg, dims:{l,w,h}, vol_m3, vol_weight_kg, … } (줄이 하나도 없으면 null) */
export function estimateShipment(agg, groupsArg = null) {
  const n = (k) => Number(agg && agg[k]) || 0;
  const pcs = n('pcs'); const wtPcs = n('wt_pcs'); const dPcs = n('d_pcs');
  const miss = {
    wt_miss: n('wt_miss'), wt_miss_qty: n('wt_miss_qty'), d_miss: n('d_miss'), d_miss_qty: n('d_miss_qty'),
    d_nobox: n('d_nobox'), d_nobox_qty: n('d_nobox_qty'), d_nosize: n('d_nosize'), d_nosize_qty: n('d_nosize_qty'),
    unreg: n('unreg'), unreg_qty: n('unreg_qty'),
    ...(agg && Array.isArray(agg.nosize_boxes) ? { nosize_boxes: agg.nosize_boxes } : {}),
  };
  if (!wtPcs && !dPcs) return (pcs || n('unreg')) ? { weight_kg: null, dims: null, pcs, ...miss, nodata: true } : null;
  let dims = null; let volM3 = null; let volW = null; let netM3 = null;
  const groups = groupsArg || (agg && Array.isArray(agg.groups) ? agg.groups : null);
  let pack = null;
  if (dPcs > 0 && groups && groups.length) {
    // 현실 적재 — 박스를 실제로 눕혀 층으로 쌓은 배치
    pack = packBoxes(groups);
  }
  if (pack) {
    dims = pack.dims;
    const totV = pack.stacks.reduce((s, x) => s + x.l * x.w * x.h, 0);
    volM3 = round(totV / 1e6, 3);
    netM3 = round(pack.net_cm3 / 1e6, 3);
    volW = round(totV / VOL_DIVISOR, 1);
  } else if (dPcs > 0) {
    const a = n('d_a'); const b = n('d_b'); const c = n('d_c'); const V = n('vol');
    let L; let W; let H;
    if (dPcs === 1) { L = a; W = b; H = c; }
    else {
      const Vp = V / FILL_RATE;
      L = Math.max(Math.cbrt(Vp), a);
      W = Math.max(Math.sqrt(Vp / L), b);
      H = Math.max(Vp / (L * W), c);
      if (W > L) [L, W] = [W, L];
    }
    const up = (x) => Math.ceil(x - 1e-9);
    dims = { l: up(L), w: up(W), h: up(H) };
    volM3 = round(dims.l * dims.w * dims.h / 1e6, 3);
    netM3 = round(V / 1e6, 3);
    volW = round(dims.l * dims.w * dims.h / VOL_DIVISOR, 1);
  }
  return { weight_kg: wtPcs > 0 ? round(n('wt'), 1) : null, dims, vol_m3: volM3, net_m3: netM3, vol_weight_kg: volW,
    ...(pack ? { pack: { method: pack.method, boxes: pack.boxes, layers: pack.layers, fill: pack.fill,
      stacks: pack.stacks.length, stack_list: pack.stacks.length > 1 ? pack.stacks : undefined } } : {}),
    pcs, wt_pcs: wtPcs, d_pcs: dPcs, ...miss };
}

/** 견적 목록 SQL 조각 — 0327 · 0328 이 있을 때만 붙인다. (q = quotes 별칭) */
const SHIP_KEYS = ['pcs', 'wt', 'wt_pcs', 'wt_miss', 'wt_miss_qty', 'vol', 'd_pcs', 'd_miss', 'd_miss_qty',
  'd_nobox', 'd_nobox_qty', 'd_nosize', 'd_nosize_qty', 'd_a', 'd_b', 'd_c', 'unreg', 'unreg_qty'];
export const SHIP_SELECT = ', ' + SHIP_KEYS.map((k) => `shp.${k} AS shp_${k}`).join(', ');
// 사이즈 = 제품 자체(3개 모두) → 없으면 박스 마스터(박스 코드가 있을 때)
const OWN = `(p.box_l_cm > 0 AND p.box_w_cm > 0 AND p.box_h_cm > 0)`;
const EF = (c) => `(CASE WHEN ${OWN} THEN p.${c} WHEN p.box_code IS NOT NULL THEN pb.${c} END)`;
const EL = EF('box_l_cm'); const EW = EF('box_w_cm'); const EH = EF('box_h_cm');
const DOK = `(${EL} > 0 AND ${EW} > 0 AND ${EH} > 0)`;
const G = `GREATEST(${EL}, ${EW}, ${EH})`;
const LST = `LEAST(${EL}, ${EW}, ${EH})`;
const PR = `ql.product_id IS NOT NULL`;
export const SHIP_JOIN = `
         LEFT JOIN LATERAL (
           SELECT COALESCE(SUM(ql.qty) FILTER (WHERE ${PR}), 0)                                                       AS pcs,
                  COALESCE(SUM(ql.qty * p.weight_kg) FILTER (WHERE p.weight_kg > 0), 0)                               AS wt,
                  COALESCE(SUM(ql.qty) FILTER (WHERE p.weight_kg > 0), 0)                                             AS wt_pcs,
                  COUNT(*) FILTER (WHERE ${PR} AND COALESCE(p.weight_kg, 0) <= 0)::int                                AS wt_miss,
                  COALESCE(SUM(ql.qty) FILTER (WHERE ${PR} AND COALESCE(p.weight_kg, 0) <= 0), 0)                     AS wt_miss_qty,
                  COALESCE(SUM(ql.qty * ${EL} * ${EW} * ${EH}) FILTER (WHERE ${DOK}), 0)                                  AS vol,
                  COALESCE(SUM(ql.qty) FILTER (WHERE ${DOK}), 0)                                                      AS d_pcs,
                  COUNT(*) FILTER (WHERE ${PR} AND NOT COALESCE(${DOK}, FALSE))::int                                  AS d_miss,
                  COALESCE(SUM(ql.qty) FILTER (WHERE ${PR} AND NOT COALESCE(${DOK}, FALSE)), 0)                       AS d_miss_qty,
                  COUNT(*) FILTER (WHERE ${PR} AND p.box_code IS NULL AND NOT COALESCE(${OWN}, FALSE))::int            AS d_nobox,
                  COALESCE(SUM(ql.qty) FILTER (WHERE ${PR} AND p.box_code IS NULL AND NOT COALESCE(${OWN}, FALSE)), 0) AS d_nobox_qty,
                  COUNT(*) FILTER (WHERE ${PR} AND p.box_code IS NOT NULL AND NOT COALESCE(${DOK}, FALSE))::int       AS d_nosize,
                  COALESCE(SUM(ql.qty) FILTER (WHERE ${PR} AND p.box_code IS NOT NULL AND NOT COALESCE(${DOK}, FALSE)), 0) AS d_nosize_qty,
                  COALESCE(MAX(${G}) FILTER (WHERE ${DOK}), 0)                                                        AS d_a,
                  COALESCE(MAX(${EL} + ${EW} + ${EH} - ${G} - ${LST}) FILTER (WHERE ${DOK}), 0)                         AS d_b,
                  COALESCE(MAX(${LST}) FILTER (WHERE ${DOK}), 0)                                                      AS d_c,
                  COUNT(*) FILTER (WHERE ql.product_id IS NULL)::int                                                  AS unreg,
                  COALESCE(SUM(ql.qty) FILTER (WHERE ql.product_id IS NULL), 0)                                       AS unreg_qty
             FROM quote_lines ql
             LEFT JOIN products p ON p.id = ql.product_id
             LEFT JOIN packing_boxes pb ON pb.code = p.box_code
            WHERE ql.quote_id = q.id AND ql.qty > 0
         ) shp ON TRUE`;

/** 목록 행(shp_* 칸) → estimateShipment */
export function shipFromRow(r, groups = null) {
  const agg = {};
  for (const k of SHIP_KEYS) agg[k] = Number(r['shp_' + k]) || 0;
  return estimateShipment(agg, groups);
}

/** 견적 여러 건의 박스 묶음(사이즈별 개수) — 목록이 현실 적재를 계산할 때 한 번에 읽는다. → Map(quote_id → [{l,w,h,n}]) */
export async function shipGroupsFor(exec, quoteIds) {
  const out = new Map();
  if (!quoteIds || !quoteIds.length) return out;
  const r = await exec(
    `SELECT ql.quote_id, ${EL} AS l, ${EW} AS w, ${EH} AS h, SUM(ql.qty) AS n
       FROM quote_lines ql
       JOIN products p ON p.id = ql.product_id
       LEFT JOIN packing_boxes pb ON pb.code = p.box_code
      WHERE ql.quote_id = ANY($1::bigint[]) AND ql.qty > 0 AND ${DOK}
      GROUP BY 1, 2, 3, 4`, [quoteIds]);
  for (const x of r.rows) {
    const k = Number(x.quote_id);
    const a = out.get(k) || []; a.push({ l: Number(x.l), w: Number(x.w), h: Number(x.h), n: Number(x.n) }); out.set(k, a);
  }
  return out;
}

/** 견적 입력(미리보기) — 제품 id · 수량 목록 → 대략 총무게 · 현실 적재 사이즈 */
export async function shipForProducts(exec, lines) {
  const ids = [...new Set((lines || []).filter((l) => l.product_id != null).map((l) => Number(l.product_id)))];
  const info = new Map();
  if (ids.length) {
    const r = await exec(
      `SELECT p.id, p.weight_kg, p.box_code, p.box_l_cm AS p_l, p.box_w_cm AS p_w, p.box_h_cm AS p_h,
              pb.box_l_cm, pb.box_w_cm, pb.box_h_cm
         FROM products p LEFT JOIN packing_boxes pb ON pb.code = p.box_code WHERE p.id = ANY($1::bigint[])`, [ids]);
    for (const x of r.rows) info.set(Number(x.id), x);
  }
  const rows = (lines || []).map((l) => (l.product_id == null ? { product_id: null, qty: l.qty } : { product_id: l.product_id, qty: l.qty, ...(info.get(Number(l.product_id)) || {}) }));
  return estimateShipment(aggregateLines(rows));
}

/** 제품찾기 목록용 — id 목록 → Map(id → { weight_kg, box_code, l, w, h, src: 'producto'|'caja'|null }) */
export async function dimsMap(exec, ids) {
  const out = new Map();
  const list = [...new Set((ids || []).map(Number).filter((x) => x > 0))];
  if (!list.length) return out;
  const r = await exec(
    `SELECT p.id, p.weight_kg, p.box_code, p.box_l_cm AS pl, p.box_w_cm AS pw, p.box_h_cm AS ph,
            pb.box_l_cm AS bl, pb.box_w_cm AS bw, pb.box_h_cm AS bh
       FROM products p LEFT JOIN packing_boxes pb ON pb.code = p.box_code WHERE p.id = ANY($1::bigint[])`, [list]);
  const ok3 = (a, b, c) => Number(a) > 0 && Number(b) > 0 && Number(c) > 0;
  for (const x of r.rows) {
    const own = ok3(x.pl, x.pw, x.ph); const fromBox = !own && x.box_code && ok3(x.bl, x.bw, x.bh);
    const d = own ? [x.pl, x.pw, x.ph] : fromBox ? [x.bl, x.bw, x.bh] : null;
    if (x.weight_kg == null && !x.box_code && !d) continue;
    out.set(Number(x.id), {
      weight_kg: numOrNull(x.weight_kg), box_code: x.box_code || null,
      l: d ? Number(d[0]) : null, w: d ? Number(d[1]) : null, h: d ? Number(d[2]) : null,
      src: own ? 'producto' : fromBox ? 'caja' : null,
    });
  }
  return out;
}
