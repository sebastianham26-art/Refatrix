// =====================================================================
// refatrix-leadportal-admin.js — 제품·마케팅 › Meta 광고 문의 › 「🔑 고객 접속코드」 탭 (0297 · 2026-10-26 · build lp-1028a)
//   refatrix-metaleads.html 의 본 스크립트 뒤에 로드된다 — 그 페이지의 전역 api() · session · esc() · $() 를 쓴다.
//   · 디렉터: 접속코드 발급(만료일 직접 입력 · 기준 금액 · 조건 메모 · 열람 범위) · 목록(기한 변경 · 정지/재개 · 재발급 · 삭제 · 이력) · 연락처 공개 기록
//   · 담당 영업사원 · 디렉터: 고객 매장 재고(고객이 포털에서 고친 값과 같은 칸) — 칸을 벗어나면 저장, 이력
// =====================================================================
(function () {
  'use strict';
  var LP = { st: null, codes: [], cust: null, shelfCust: null, loaded: false, timer: null, timer2: null };
  var g = function (id) { return document.getElementById(id); };
  var money = function (n) { return n == null ? '—' : '$' + Number(n).toLocaleString('en-US', { maximumFractionDigits: 0 }); };
  var money2 = function (n) { return '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }); };
  var STATE = { active: ['사용 중', 's-on'], soon: ['곧 만료', 's-soon'], expired: ['만료', 's-exp'], paused: ['정지', 's-off'] };
  var ERRK = { bad_days: '1~30일(연장은 1~60일) 사이 정수로 입력하세요.', director_only: '디렉터만 할 수 있습니다.', migration_required: '서버에 0297 마이그레이션이 아직 없습니다 — Railway 콘솔에서 npm run migrate.',
    customer_required: '고객을 고르세요.', expires_required: '만료일을 입력하세요.', expires_past: '만료일이 오늘보다 앞입니다.', bad_amount: '기준 금액은 숫자로 입력하세요.',
    customer_pending: '승인 대기 고객에게는 발급할 수 없습니다.', not_your_customer: '담당 고객이 아닙니다.', unknown_code: '없는 부품번호입니다.', bad_qty: '0 이상의 정수를 입력하세요.' };
  function say(ok, t, el) { var m = g(el || 'lpMsg'); if (!m) return; m.className = 'msg ' + (ok ? 'ok' : 'err'); m.textContent = t; if (ok) setTimeout(function () { if (m.textContent === t) m.className = 'msg'; }, 5000); }
  function errT(e) { return ERRK[e && e.message] || (e && e.data && e.data.note) || ('오류: ' + (e && e.message)); }
  function today() { return (LP.st && LP.st.today) || new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Mexico_City' }).format(new Date()); }
  function days(a, b) { return Math.round((Date.UTC(+b.slice(0, 4), +b.slice(5, 7) - 1, +b.slice(8, 10)) - Date.UTC(+a.slice(0, 4), +a.slice(5, 7) - 1, +a.slice(8, 10))) / 86400000); }
  function ymd(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }

  async function load() {
    try { LP.st = await api('GET', '/api/lead-portal-admin/status'); }
    catch (e) { var m = g('lpMig'); if (m) { m.classList.remove('hidden'); m.textContent = e.message === 'http_404' ? '서버가 아직 이 기능을 모릅니다(백엔드 배포 · migrate 확인).' : errT(e); } return; }
    if (!LP.st.ready) { var mm = g('lpMig'); mm.classList.remove('hidden'); mm.textContent = ERRK.migration_required; }
    g('lpDirOnly').classList.toggle('hidden', !LP.st.director);
    if (LP.st.director) {
      var box = g('lpScopeBox');
      box.innerHTML = (LP.st.states || []).map(function (s) { return '<label class="lp-ck"><input type="checkbox" value="' + esc(s) + '"> ' + esc(s) + '</label>'; }).join('');
      if (!g('lpExp').value) { var d = new Date(Date.UTC(+today().slice(0, 4), +today().slice(5, 7) - 1, +today().slice(8, 10) + 30)); g('lpExp').value = d.toISOString().slice(0, 10); expHint(); }
      var abox = g('lpAdBox');
      if (abox) abox.innerHTML = (LP.st.ads || []).length ? (LP.st.ads || []).map(function (a) { return '<label class="lp-ck"><input type="checkbox" value="' + esc(a.ad_id) + '"> ' + esc(adLabel(a.ad_id)) + ' <span class="muted">' + a.n + '건</span></label>'; }).join('') : '<div class="hint">아직 광고가 없습니다(문의에서 광고 ID 가 보이거나 광고를 등록하면 나타납니다).</div>';
      if (LP.st.ready) { loadCodes(); loadReveals(); loadNotes(); loadClaims(); }
    }
    loadConsents(); loadCards();
    if (LP.st.access) { if (!g('lpAcTo').value) { g('lpAcTo').value = today(); var f0 = new Date(Date.UTC(+today().slice(0, 4), +today().slice(5, 7) - 1, +today().slice(8, 10) - 13)); g('lpAcFrom').value = f0.toISOString().slice(0, 10); } loadAccess(); }
    else if (g('lpAccess')) g('lpAccess').innerHTML = '<div class="hint">접속 기록은 서버에 0317 마이그레이션 뒤부터 쌓입니다(Railway 콘솔 npm run migrate).</div>';
    LP.loaded = true;
  }

  // 1105 · 광고 이름(없으면 미등록 …끝 6자리)
  function adLabel(id) { var a = ((LP.st && LP.st.ads) || []).filter(function (x) { return x.ad_id === String(id); })[0]; return a && a.name ? a.name : '미등록 …' + String(id).slice(-6); }
  // 1105 · 접속 기록(고객 · 날짜별)
  async function loadAccess(codeId) {
    if (codeId !== undefined) LP.acCode = codeId || null;
    var qs = '?from=' + encodeURIComponent(g('lpAcFrom').value || '') + '&to=' + encodeURIComponent(g('lpAcTo').value || '') + (LP.acCode ? '&code_id=' + LP.acCode : '');
    try { var d = await api('GET', '/api/lead-portal-admin/access' + qs); LP.access = d.items || []; renderAccess(); }
    catch (e) { g('lpAccess').innerHTML = '<div class="hint">' + esc(errT(e)) + '</div>'; }
  }
  function renderAccess() {
    var q = g('lpAcQ').value.trim().toLowerCase();
    var it = (LP.access || []).filter(function (x) { return !q || (x.customer_name + ' ' + x.customer_code).toLowerCase().indexOf(q) >= 0; });
    var who = {}; it.forEach(function (x) { who[x.code_id] = 1; });
    g('lpAcSum').textContent = Object.keys(who).length + '개 코드 · ' + it.length + '일-고객' + (LP.acCode ? ' · 코드 한 개만 보는 중' : '');
    if (!it.length) { g('lpAccess').innerHTML = '<div class="hint" style="margin-top:6px">이 기간에 접속 기록이 없습니다.</div>' + (LP.acCode ? ' <button type="button" class="btn sm ghost" id="lpAcAll">전체 코드 보기</button>' : ''); return; }
    g('lpAccess').innerHTML = (LP.acCode ? '<div style="margin:6px 0"><button type="button" class="btn sm ghost" id="lpAcAll">전체 코드 보기</button></div>' : '')
      + '<table><thead><tr><th>날짜</th><th>고객</th><th>코드</th><th>첫 접속</th><th>마지막 활동</th><th class="num">접속(열기)</th><th>접속 시각</th></tr></thead><tbody>'
      + it.map(function (x) {
        var isDir = x.kind === 'director';
        return '<tr><td style="white-space:nowrap">' + esc(x.date) + '</td><td><b>' + (isDir ? '🔐 디렉터 전용' : esc(x.customer_name)) + '</b><div class="muted">' + esc(isDir ? '' : x.customer_code) + '</div></td>'
          + '<td class="mono">…' + esc(x.last4) + '</td><td>' + esc(x.first) + '</td><td>' + esc(x.last) + '</td>'
          + '<td class="num">' + x.opens + (x.logins ? '<div class="muted">코드 입력 ' + x.logins + '</div>' : '') + '</td>'
          + '<td class="muted" style="max-width:420px">' + esc((x.times || []).join(' · ')) + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  // 1106 · 포털 광고 카드
  var CK = { producto: '우리 제품', anuncio: '광고', capacitacion: '교육' };
  async function loadCards() {
    if (!g('lpCards')) return;
    try {
      var d = await api('GET', '/api/lead-portal-admin/cards'); LP.cards = d.items || [];
      g('lcNew').classList.toggle('hidden', !d.can_edit);   // 1106d · 이 화면을 볼 수 있으면 누구나
      g('lpCards').innerHTML = LP.cards.length ? '<table><thead><tr><th>순서</th><th>종류</th><th>제목 · 내용</th><th>이미지</th><th>키트</th><th>버튼</th><th class="num">N장마다</th><th>기간</th><th>상태</th><th class="num">클릭</th><th>참여 신청</th><th></th></tr></thead><tbody>'
        + LP.cards.map(function (c) {
          return '<tr><td class="num">' + c.sort + '</td><td>' + esc(CK[c.kind] || c.kind) + '</td><td><b>' + esc(c.title) + '</b><div class="muted lp-memo">' + esc(c.body || '') + '</div></td>'
            + '<td>' + (c.image_url ? (c.bank_id ? '<img data-cbt="' + c.bank_id + '" alt="" style="max-width:80px;max-height:50px;object-fit:contain"><div class="muted" style="font-size:10.5px">뱅크 #' + c.bank_id + '</div>' : '<img src="' + esc(/^img\//.test(c.image_url) ? 'https://refatrix-platform.netlify.app/' + c.image_url : c.image_url) + '" alt="" style="max-width:80px;max-height:50px;object-fit:contain">') : '<span class="muted">—</span>') + '</td>'
            + '<td>' + (c.kit_no ? '<span class="tag" style="background:#111;color:#fff">🛒 ' + esc(c.kit_no) + '</span>' : '<span class="muted">—</span>') + '</td>'
            + '<td>' + esc(c.cta_text || (c.kind === 'capacitacion' && !c.cta_url ? 'Quiero participar' : '')) + (c.cta_url ? '<div class="muted mono" style="max-width:180px;overflow:hidden;text-overflow:ellipsis">' + esc(c.cta_url) + '</div>' : '') + '</td>'
            + '<td class="num">' + c.every_n + '</td><td style="white-space:nowrap">' + esc((c.starts_on || '…') + ' ~ ' + (c.ends_on || '…')) + '</td>'
            + '<td>' + (c.active ? '<span class="tag lp-on">사용</span>' : '<span class="tag">꺼짐</span>') + '</td><td class="num">' + c.clicks + '</td><td>' + (c.interests ? c.interests + '곳<div class="muted">' + esc(c.interested || '') + '</div>' : '—') + '</td>'
            + '<td>' + (d.can_edit ? '<div class="row lp-acts"><button type="button" class="btn sm ghost" data-card="edit" data-id="' + c.id + '">수정</button><button type="button" class="btn sm ghost" data-card="toggle" data-id="' + c.id + '">' + (c.active ? '끄기' : '켜기') + '</button><button type="button" class="btn sm lp-red" data-card="del" data-id="' + c.id + '">삭제</button></div>' : '') + '</td></tr>';
        }).join('') + '</tbody></table>' : '<div class="hint">카드가 없습니다.</div>';
      [].forEach.call(g('lpCards').querySelectorAll('img[data-cbt]'), function (im) { bankThumb(Number(im.dataset.cbt)).then(function (u) { if (u) im.src = u; }); });
    } catch (e) { g('lpCards').innerHTML = '<div class="hint">' + esc(e.message === 'migration_required' ? '광고 카드는 서버에 0320 마이그레이션 뒤부터 씁니다(Railway 콘솔 npm run migrate).' : errT(e)) + '</div>'; if (g('lcNew')) g('lcNew').classList.add('hidden'); }
  }
  // 1106c · 카드 이미지 — 이미지 뱅크(bank:id) · 파일 올리기(이미지 뱅크 「포털 광고」 폴더) · 크기 안내
  var CARD_FOLDER = '포털 광고', REC_W = 1200;
  LP.files = LP.files || {};
  async function bankFile(id) {   // 1106d · 원본(전체 크기)
    if (LP.files[id]) return LP.files[id];
    try { var r = await fetch(session.api + '/api/wa-promo/images/' + id + '/file', { headers: { Authorization: 'Bearer ' + session.token } }); if (!r.ok) return ''; var u = URL.createObjectURL(await r.blob()); LP.files[id] = u; return u; } catch (e) { return ''; }
  }
  LP.thumbs = LP.thumbs || {};
  async function bankThumb(id) {
    if (LP.thumbs[id]) return LP.thumbs[id];
    try { var r = await fetch(session.api + '/api/wa-promo/images/' + id + '/thumb', { headers: { Authorization: 'Bearer ' + session.token } }); if (!r.ok) return ''; var u = URL.createObjectURL(await r.blob()); LP.thumbs[id] = u; return u; } catch (e) { return ''; }
  }
  function sizeNote(w, h, bytes) {
    if (!w || !h) return '';
    // 1106d · 포털은 이미지 전체를 카드 가로에 맞춰 보여 준다(잘림 없음) → 가로 폭 · 세로 길이 · 용량만 본다
    var ratio = w / h, big = w >= 900, tall = ratio < 0.8, heavy = bytes && bytes > 2 * 1024 * 1024;
    var ok = big && !tall && !heavy;
    return '<span class="' + (ok ? 'ok-t' : 'warn-t') + '">' + w + ' × ' + h + ' px' + (bytes ? ' · ' + (bytes / 1024 / 1024).toFixed(2) + ' MB' : '') + '</span>'
      + (ok ? ' — 좋습니다' : ' — ' + [!big ? '가로가 900 px 보다 작아 흐리게 보일 수 있습니다(권장 ' + REC_W + ' px)' : '', tall ? '세로로 길어 카드가 아주 길어집니다' : '', heavy ? '2 MB 보다 커서 느리게 열릴 수 있습니다' : ''].filter(Boolean).join(' · '));
  }
  async function showPrev() {
    var v = g('lcImg').value.trim(), el = g('lcPrev'); if (!el) return;
    if (!v) { el.innerHTML = '<span class="hint">이미지 없음 — 글자만 있는 카드</span>'; return; }
    var m = v.match(/^bank:(\d+)$/), src = m ? await bankThumb(Number(m[1])) : (/^img\//.test(v) ? 'https://refatrix-platform.netlify.app/' + v : v);
    var meta = m ? ((LP.bank || []).filter(function (x) { return x.id === Number(m[1]); })[0] || LP.lastUp || null) : null;
    if (m) { var full = await bankFile(Number(m[1])); if (full) src = full; }
    el.innerHTML = '<div style="width:420px;max-width:100%;background:#f5f5f5;border:1px solid var(--line);border-radius:10px;overflow:hidden;display:flex;align-items:center;justify-content:center;' + (/^img\//.test(v) ? 'height:180px;padding:16px' : '') + '">'
      + (src ? '<img src="' + esc(src) + '" alt="" style="' + (/^img\//.test(v) ? 'max-width:100%;max-height:100%;object-fit:contain' : 'display:block;width:100%;height:auto') + '">' : '<span class="hint">미리보기 없음</span>') + '</div>'
      + '<div class="hint" style="margin-top:3px">카드에서 보이는 모양(미리보기)' + (meta && meta.width ? ' · ' + sizeNote(meta.width, meta.height, meta.size) : '') + '</div>';
  }
  async function openBank() {
    g('lcBankBox').classList.remove('hidden'); g('lcBankGrid').innerHTML = '<span class="hint">불러오는 중…</span>';
    try {
      var d = await api('GET', '/api/wa-promo/images'); LP.bank = d.items || []; renderBank();
    } catch (e) { g('lcBankGrid').innerHTML = '<span class="hint">' + esc(e.message === 'forbidden' || e.message === 'http_403' ? '이미지 뱅크(WhatsApp 마케팅) 화면 권한이 없습니다.' : errT(e)) + '</span>'; }
  }
  function renderBank() {
    var q = g('lcBankQ').value.trim().toLowerCase();
    var it = (LP.bank || []).filter(function (x) { return !q || ((x.name || '') + ' ' + (x.folder || '') + ' ' + (x.memo || '')).toLowerCase().indexOf(q) >= 0; }).slice(0, 120);
    g('lcBankSum').textContent = it.length + '장' + ((LP.bank || []).length > it.length ? ' / 전체 ' + LP.bank.length : '');
    g('lcBankGrid').innerHTML = it.map(function (x) {
      // 1106d · 이미지 전체가 보이게(잘림 없음 · 칸 크게) · 🔍 = 원본 크게 보기 · K0… = 키트 사진
      var kn = String((x.name || '') + ' ' + (x.memo || '')).match(/\bK0\d{2,5}\b/i);
      return '<div class="lc-bk" data-bk="' + x.id + '" title="눌러서 선택" style="position:relative;border:1px solid var(--line);border-radius:10px;background:#fff;padding:6px;cursor:pointer">'
        + '<div style="height:180px;background:#f5f5f5;border-radius:8px;overflow:hidden;display:flex;align-items:center;justify-content:center"><img data-bt="' + x.id + '" alt="" style="max-width:100%;max-height:100%;object-fit:contain"></div>'
        + '<button type="button" class="btn sm ghost" data-bz="' + x.id + '" title="원본 크게 보기" style="position:absolute;top:10px;right:10px;padding:3px 8px">🔍</button>'
        + (kn ? '<span class="tag" style="position:absolute;top:10px;left:10px;background:#111;color:#fff">🛒 ' + esc(kn[0].toUpperCase()) + '</span>' : '')
        + '<div style="font-size:12px;margin-top:5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(x.name || ('#' + x.id)) + '</div>'
        + '<div class="muted" style="font-size:11px">' + (x.width ? x.width + ' × ' + x.height + ' px' : '') + (x.folder ? ' · ' + esc(x.folder) : '') + '</div>'
        + (x.memo ? '<div class="muted" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc(x.memo) + '">' + esc(x.memo) + '</div>' : '') + '</div>';
    }).join('') || '<span class="hint">이미지가 없습니다.</span>';
    [].forEach.call(g('lcBankGrid').querySelectorAll('img[data-bt]'), function (im) { bankThumb(Number(im.dataset.bt)).then(function (u) { if (u) im.src = u; }); });
  }
  async function zoomBank(id) {
    var x = (LP.bank || []).filter(function (b) { return b.id === id; })[0] || {};
    LP.zoomId = id; g('lcZoomT').textContent = x.name || ('#' + id); g('lcZoomS').textContent = x.width ? ' · ' + x.width + ' × ' + x.height + ' px' : '';
    g('lcZoomM').textContent = x.memo || ''; g('lcZoomImg').src = await bankThumb(id) || ''; g('lcZoom').classList.remove('hidden');
    var u = await bankFile(id); if (u && LP.zoomId === id) g('lcZoomImg').src = u;
  }
  function pickBank(id) { g('lcImg').value = 'bank:' + id; g('lcBankBox').classList.add('hidden'); g('lcZoom').classList.add('hidden'); showPrev(); detectKit(id); }
  // 1106d · 키트 — 번호 확인 · 이미지에서 자동(키트 사진 연결 · 이름/설명 속 K0…)
  function kitInfoHTML(k) {
    var money = function (n) { return '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    return '<b>' + esc(k.kit_no) + '</b>' + (k.title ? ' · ' + esc(k.title) : '') + ' · 정가 ' + money(k.list) + ' · 지금 만들 수 있는 세트 ' + k.avail + (k.active ? '' : ' · <span class="warn-t">판매중단 구성품 있음</span>')
      + '<div style="margin-top:3px">' + (k.items || []).map(function (i) { return esc(i.category) + ' ' + esc(i.code) + (i.qty > 1 ? ' ×' + i.qty : ''); }).join(' · ') + '</div>';
  }
  async function checkKit(q) {
    var el = g('lcKitInfo'); if (!el) return;
    var v = String(g('lcKit').value || '').trim().toUpperCase();
    if (!q && !v) { el.innerHTML = '비우면 주문 버튼 없음 · 넣으면 포털 카드에 「🛒 Ordenar kit」(구성품 · 정가 · 할인가)'; return; }
    try {
      var d = await api('GET', '/api/lead-portal-admin/kit-lookup?' + (q || ('no=' + encodeURIComponent(v))));
      if (d.kit) {
        g('lcKit').value = d.kit.kit_no; el.innerHTML = '<span class="ok-t">✓</span> ' + kitInfoHTML(d.kit);
        // 1106d · 키트를 찾으면 종류 = 우리 제품, 제목이 비어 있으면 키트 이름으로
        if (!LP.cardEdit && g('lcKind').value !== 'producto') g('lcKind').value = 'producto';
        if (!g('lcTitle').value.trim()) g('lcTitle').value = 'Kit ' + (d.kit.title || d.kit.kit_no);
      }
      else if (!q) el.innerHTML = '<span class="warn-t">' + esc(v) + ' 키트를 찾지 못했습니다(VIO 프로모션에서 만든 키트 번호인지 확인).</span>';
    } catch (e) { el.innerHTML = '<span class="warn-t">' + esc(errT(e)) + '</span>'; }
  }
  function detectKit(imgId) { if (!String(g('lcKit').value || '').trim()) checkKit('image_id=' + imgId); }
  function readFile(f) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = rej; r.readAsDataURL(f); }); }
  function imgSize(url) { return new Promise(function (res) { var im = new Image(); im.onload = function () { res({ w: im.naturalWidth, h: im.naturalHeight, im: im }); }; im.onerror = function () { res(null); }; im.src = url; }); }
  async function uploadCardImage(f) {
    if (!f) return;
    if (!/^image\/(jpeg|png|webp)$/.test(f.type)) { say(false, 'JPG · PNG · WebP 만 올릴 수 있습니다.', 'lcMsg'); return; }
    if (f.size > 5 * 1024 * 1024) { say(false, '5 MB 보다 큽니다 — 줄여서 올려 주세요(권장 2 MB 이하).', 'lcMsg'); return; }
    var data = await readFile(f), sz = await imgSize(data);
    var thumb = null;
    if (sz && sz.im) { try { var cv = document.createElement('canvas'), k = Math.min(1, 480 / sz.w); cv.width = Math.round(sz.w * k); cv.height = Math.round(sz.h * k); cv.getContext('2d').drawImage(sz.im, 0, 0, cv.width, cv.height); thumb = cv.toDataURL('image/jpeg', 0.82); } catch (e) { thumb = null; } }
    say(true, '올리는 중… ' + (sz ? sz.w + ' × ' + sz.h + ' px' : ''), 'lcMsg');
    try {
      var r = await api('POST', '/api/wa-promo/images', { name: f.name, mime: f.type, image_b64: data, thumb_b64: thumb, width: sz && sz.w, height: sz && sz.h, folder: CARD_FOLDER });
      LP.lastUp = { id: r.id, width: sz && sz.w, height: sz && sz.h, size: f.size };
      if (LP.bank) LP.bank = null;
      g('lcImg').value = 'bank:' + r.id; delete LP.thumbs[r.id]; await showPrev(); detectKit(r.id);
      say(true, (r.duplicate ? '이미 이미지 뱅크에 있던 파일입니다 — 그 이미지를 씁니다. ' : '이미지 뱅크 「' + CARD_FOLDER + '」 폴더에 올렸습니다. ') + (sz ? '(' + sz.w + ' × ' + sz.h + ' px)' : ''), 'lcMsg');
    } catch (e) { say(false, e.message === 'image_too_large' ? '파일이 너무 큽니다(최대 5 MB).' : errT(e), 'lcMsg'); }
  }
  function cardForm(c) {
    LP.cardEdit = c ? c.id : null; g('lpCardForm').classList.remove('hidden');
    g('lcKind').value = c ? c.kind : 'capacitacion'; g('lcTitle').value = c ? c.title : ''; g('lcBody').value = c ? (c.body || '') : '';
    g('lcImg').value = c ? (c.image_url || '') : ''; g('lcCta').value = c ? (c.cta_text || '') : ''; g('lcUrl').value = c ? (c.cta_url || '') : '';
    g('lcBankBox').classList.add('hidden'); setTimeout(showPrev, 0);
    g('lcKit').value = c ? (c.kit_no || '') : ''; setTimeout(function () { checkKit(); }, 0);
    g('lcEvery').value = c ? c.every_n : 6; g('lcSort').value = c ? c.sort : 0; g('lcFrom').value = c ? (c.starts_on || '') : ''; g('lcTo').value = c ? (c.ends_on || '') : ''; g('lcActive').checked = c ? c.active : true;
    try { g('lcTitle').focus(); } catch (_) {}
  }
  async function saveCard() {
    var body = { kind: g('lcKind').value, title: g('lcTitle').value.trim(), body: g('lcBody').value.trim(), image_url: g('lcImg').value.trim(), cta_text: g('lcCta').value.trim(), cta_url: g('lcUrl').value.trim(),
      every_n: Number(g('lcEvery').value) || 6, sort: Number(g('lcSort').value) || 0, starts_on: g('lcFrom').value || null, ends_on: g('lcTo').value || null, active: g('lcActive').checked,
      kit_no: String(g('lcKit').value || '').trim().toUpperCase() || null };
    if (!body.title) { say(false, '제목을 쓰세요.', 'lcMsg'); return; }
    try {
      if (LP.cardEdit) await api('PATCH', '/api/lead-portal-admin/cards/' + LP.cardEdit, body); else await api('POST', '/api/lead-portal-admin/cards', body);
      g('lpCardForm').classList.add('hidden'); say(true, '저장했습니다 — 고객 포털에 바로 보입니다.', 'lcMsg'); loadCards();
    } catch (e) { say(false, e.message === 'bad_url' ? '주소는 https:// 로 시작해야 합니다(이미지는 img/… 도 가능).' : e.message === 'unknown_kit' || e.message === 'bad_kit' ? '키트 번호를 찾지 못했습니다(K0001 형식 · VIO 프로모션 키트).' : errT(e), 'lcMsg'); }
  }
  async function onCardAct(e) {
    var b = e.target.closest('[data-card]'); if (!b) return;
    var id = Number(b.dataset.id), c = (LP.cards || []).filter(function (x) { return x.id === id; })[0]; if (!c) return;
    if (b.dataset.card === 'edit') return cardForm(c);
    try {
      if (b.dataset.card === 'toggle') await api('PATCH', '/api/lead-portal-admin/cards/' + id, { active: !c.active });
      if (b.dataset.card === 'del') { if (!confirm('「' + c.title + '」 카드를 삭제할까요?')) return; await api('DELETE', '/api/lead-portal-admin/cards/' + id); }
      loadCards();
    } catch (e2) { say(false, errT(e2), 'lcMsg'); }
  }

  // 1105c · 개인정보 보호 확약서(전자서명) — 이 화면 접근 권한
  async function loadConsents() {
    if (!g('lpConsents')) return;
    try {
      var d = await api('GET', '/api/lead-portal-admin/consents'); LP.cons = d;
      g('lpConsSum').textContent = '서명 ' + d.items.filter(function (x) { return x.current; }).length + '건(현재 문안 ' + d.version + ') · 아직 서명 안 한 사용 중 코드 ' + d.pending.length + '개';
      g('lpConsents').innerHTML = (d.pending.length ? '<div class="hint" style="margin:6px 0">⏳ 아직 서명 안 함: ' + d.pending.map(function (p) { return esc(p.customer_name) + ' …' + esc(p.code_last4); }).join(' · ') + '</div>' : '')
        + (d.items.length ? '<table><thead><tr><th>서명 일시</th><th>고객</th><th>코드</th><th>이름</th><th>성</th><th>휴대폰</th><th>IP</th><th>문안</th><th></th></tr></thead><tbody>'
          + d.items.map(function (x) { return '<tr><td style="white-space:nowrap">' + esc(x.signed_mx) + '</td><td><b>' + esc(x.customer_name) + '</b><div class="muted">' + esc(x.customer_code) + '</div></td><td class="mono">…' + esc(x.code_last4) + '</td><td>' + esc(x.first_name) + '</td><td>' + esc(x.last_name) + '</td><td class="mono">' + esc(x.phone) + '</td><td class="muted">' + esc(x.ip || '') + '</td><td>' + (x.current ? esc(x.version) : '<span class="muted">' + esc(x.version) + ' (이전)</span>') + '</td><td><button type="button" class="btn sm ghost" data-cons="' + x.id + '">서명 보기</button></td></tr>'; }).join('') + '</tbody></table>'
          : '<div class="hint">아직 서명한 고객이 없습니다.</div>');
    } catch (e) { g('lpConsents').innerHTML = '<div class="hint">' + esc(e.message === 'migration_required' ? '확약서는 서버에 0318 마이그레이션 뒤부터 받습니다(Railway 콘솔 npm run migrate).' : errT(e)) + '</div>'; }
  }
  async function viewConsent(id) {
    try {
      var d = await api('GET', '/api/lead-portal-admin/consents/' + id);
      g('lpConsView').innerHTML = '<div class="aisum" style="margin-top:8px"><b>' + esc(d.first_name + ' ' + d.last_name) + '</b> · ' + esc(d.phone) + ' · ' + esc(d.signed_mx) + ' · IP ' + esc(d.ip || '—') + ' <button type="button" class="btn sm ghost" id="lpConsX">닫기</button>'
        + '<div style="margin:8px 0"><img alt="서명" src="' + esc(d.signature) + '" style="max-width:420px;width:100%;border:1px solid #ddd;border-radius:8px;background:#fff"></div>'
        + '<pre style="white-space:pre-wrap;font-size:12px;background:#fff;border:1px solid #eee;border-radius:8px;padding:8px">' + esc(d.text) + '</pre><div class="muted mono" style="font-size:11px">문안 ' + esc(d.version) + ' · sha256 ' + esc(d.text_hash) + '<br>' + esc(d.ua || '') + '</div></div>';
      g('lpConsX').onclick = function () { g('lpConsView').innerHTML = ''; };
    } catch (e) { say(false, errT(e)); }
  }

  // ── 발급 ──────────────────────────────────────────────
  function expHint() {
    var v = g('lpExp').value;
    g('lpExpHint').textContent = ymd(v) ? (v < today() ? '⚠ 오늘보다 앞입니다' : '오늘부터 ' + days(today(), v) + '일 · 만료일 23:59(멕시코시티)까지 열람') : '';
  }
  async function searchCust(qEl, listEl, onPick) {
    var q = g(qEl).value.trim(); var list = g(listEl);
    if (q.length < 2) { list.innerHTML = ''; return; }
    try {
      var d = await api('GET', '/api/lead-portal-admin/customers?q=' + encodeURIComponent(q));
      list.innerHTML = d.items.length ? d.items.map(function (c) { return '<div class="lp-opt" data-cid="' + c.id + '" data-name="' + esc(c.name) + '" data-code="' + esc(c.code) + '" data-disc="' + c.discount + '"><b>' + esc(c.code) + '</b> · ' + esc(c.name) + ' <span class="muted">' + c.discount + '%</span></div>'; }).join('')
        : '<div class="lp-opt muted">일치하는 고객이 없습니다(담당 고객만 보입니다)</div>';
      list.onclick = function (e) { var o = e.target.closest('[data-cid]'); if (!o) return; list.innerHTML = ''; onPick({ id: Number(o.dataset.cid), name: o.dataset.name, code: o.dataset.code, discount: Number(o.dataset.disc) }); };
    } catch (e) { list.innerHTML = '<div class="lp-opt muted">' + esc(errT(e)) + '</div>'; }
  }
  async function pickIssueCust(c) {
    LP.cust = c;
    g('lpCustQ').value = c.code + ' · ' + c.name;
    g('lpCustSel').textContent = '할인율 ' + c.discount + '% (포털 가격에 적용)';
    g('lpRef').innerHTML = '<span class="muted">매출 불러오는 중…</span>';
    try {
      var r = await api('GET', '/api/lead-portal-admin/customer-ref/' + c.id);
      g('lpRef').innerHTML = '<div class="lp-ref3"><div>최근 30일<b>' + money(r.d30) + '</b></div><div>최근 3개월<b>' + money(r.d90) + '</b></div><div>최근 12개월<b>' + money(r.d365) + '</b></div></div>'
        + '<div class="hint" style="margin-top:6px">' + (r.last_date ? '마지막 매출 ' + esc(r.last_date) + ' · ' + money(r.last_amount) : '매출 기록 없음')
        + ' — 참고용이며 기한은 자동으로 정하지 않습니다.' + (r.codes ? ' <b>이 고객은 이미 접속코드 ' + r.codes + '개가 있습니다.</b>' : '') + '</div>';
    } catch (e) { g('lpRef').innerHTML = '<span class="muted">' + esc(errT(e)) + '</span>'; }
  }
  async function issue() {
    if (!LP.cust) { say(false, ERRK.customer_required); return; }
    var scope = g('lpScopeMode').value === 'pick' ? [].map.call(g('lpScopeBox').querySelectorAll('input:checked'), function (i) { return i.value; }) : [];
    if (g('lpScopeMode').value === 'pick' && !scope.length) { say(false, '열람할 주를 하나 이상 고르세요(전체면 「전체 문의」).'); return; }
    g('lpIssue').disabled = true;
    try {
      var ads = g('lpAdMode').value === 'pick' ? [].map.call(g('lpAdBox').querySelectorAll('input:checked'), function (i) { return i.value; }) : [];
    if (g('lpAdMode').value === 'pick' && !ads.length) { say(false, '볼 수 있는 광고를 하나 이상 고르세요(전부면 「모든 광고」).'); g('lpIssue').disabled = false; return; }
    var d = await api('POST', '/api/lead-portal-admin/codes', { customer_id: LP.cust.id, expires_on: g('lpExp').value, basis_amount: g('lpAmt').value.trim(), memo: g('lpMemo').value.trim(), scope_states: scope, scope_ads: ads });
      showIssued(d, LP.cust.name, d.item.expires_on);
      say(true, '발급했습니다 — 코드는 지금 한 번만 보입니다.');
      LP.cust = null; g('lpCustQ').value = ''; g('lpCustSel').textContent = ''; g('lpRef').innerHTML = ''; g('lpAmt').value = ''; g('lpMemo').value = '';
      loadCodes();
    } catch (e) { say(false, errT(e)); }
    finally { g('lpIssue').disabled = false; }
  }
  function showIssued(d, name, exp) {
    g('lpIssued').innerHTML = '<div class="lp-issued"><div class="hint">발급됨 · ' + esc(name) + ' · ' + esc(exp) + '까지</div>'
      + '<div class="lp-big">' + esc(d.code) + '</div>'
      + '<label style="margin-top:8px">고객 안내문 (스페인어 · 복사해서 WhatsApp으로 전달)</label><pre class="lp-pre" id="lpInvite">' + esc(d.invite) + '</pre>'
      + '<div class="row"><button type="button" class="btn sm" id="lpCopyInv">📋 안내문 복사</button><button type="button" class="btn sm ghost" id="lpCopyCode">코드만 복사</button><button type="button" class="btn sm ghost" id="lpHideIss">닫기</button></div></div>';
    var copy = function (t) { try { navigator.clipboard.writeText(t).then(function () { say(true, '복사했습니다.'); }); } catch (e) { say(false, '복사하지 못했습니다 — 직접 선택해 복사하세요.'); } };
    g('lpCopyInv').onclick = function () { copy(d.invite); };
    g('lpCopyCode').onclick = function () { copy(d.code); };
    g('lpHideIss').onclick = function () { g('lpIssued').innerHTML = ''; };
  }

  // ── 목록 ──────────────────────────────────────────────
  async function loadCodes() {
    try { var d = await api('GET', '/api/lead-portal-admin/codes'); LP.codes = d.items || []; renderCodes(); }
    catch (e) { g('lpCodes').innerHTML = '<div class="hint">' + esc(errT(e)) + '</div>'; }
  }
  function renderCodes() {
    var f = g('lpFilter').value, q = g('lpFind').value.trim().toLowerCase();
    var cnt = { active: 0, soon: 0, expired: 0, paused: 0 };
    LP.codes.forEach(function (c) { cnt[c.state] = (cnt[c.state] || 0) + 1; });
    g('lpSum').textContent = '사용 중 ' + (cnt.active + cnt.soon) + ' · 7일 내 만료 ' + cnt.soon + ' · 만료 ' + cnt.expired + ' · 정지 ' + cnt.paused;
    var it = LP.codes.filter(function (c) {
      if (f === 'on' && !(c.state === 'active' || c.state === 'soon')) return false;
      if (f && f !== 'on' && c.state !== f) return false;
      if (q && (c.customer_name + ' ' + c.customer_code + ' ' + (c.memo || '')).toLowerCase().indexOf(q) < 0) return false;
      return true;
    });
    if (!it.length) { g('lpCodes').innerHTML = '<div class="hint" style="margin-top:8px">' + (LP.codes.length ? '조건에 맞는 코드가 없습니다.' : '아직 발급한 접속코드가 없습니다.') + '</div>'; return; }
    g('lpCodes').innerHTML = '<table><thead><tr><th>고객</th><th>코드</th><th class="num">기준 금액</th><th>조건 메모</th><th>범위</th><th>발급일</th><th>만료일</th><th>상태</th><th>마지막 접속</th><th class="num">연락처 공개</th><th class="num">주문(견적)</th><th></th></tr></thead><tbody>'
      + it.map(function (c) {
        var s = STATE[c.state] || [c.state, ''];
        var lab = c.state === 'active' ? s[0] + ' · ' + c.days_left + '일' : (c.state === 'soon' ? c.days_left + '일 남음' : s[0]);
        var isDir = c.kind === 'director';
        var act = '<button type="button" class="btn sm ' + (c.state === 'expired' || c.state === 'soon' ? 'lp-gold' : 'ghost') + '" data-act="ext" data-id="' + c.id + '">' + (c.state === 'expired' || c.state === 'soon' ? '연장' : '기한 변경') + '</button>'
          + (c.active ? '<button type="button" class="btn sm ghost" data-act="pause" data-id="' + c.id + '">정지</button>' : '<button type="button" class="btn sm ghost" data-act="resume" data-id="' + c.id + '">재개</button>')
          + '<button type="button" class="btn sm ghost" data-act="memo" data-id="' + c.id + '">메모</button>'
          + (isDir ? '' : '<button type="button" class="btn sm ghost" data-act="scope" data-id="' + c.id + '">범위</button>')
          + (isDir ? '' : '<button type="button" class="btn sm ghost" data-act="ads" data-id="' + c.id + '">광고</button>')
          + '<button type="button" class="btn sm ghost" data-act="access" data-id="' + c.id + '">접속 기록</button>'
          + '<button type="button" class="btn sm ghost" data-act="reissue" data-id="' + c.id + '">재발급</button>'
          + (isDir ? '' : '<button type="button" class="btn sm ghost" data-act="shelf" data-id="' + c.id + '">매장 재고</button>')
          + '<button type="button" class="btn sm ghost" data-act="log" data-id="' + c.id + '">이력</button>'
          + '<button type="button" class="btn sm lp-red" data-act="del" data-id="' + c.id + '">삭제</button>';
        return '<tr' + (isDir ? ' style="background:#fbf7ee"' : '') + '><td><b>' + (isDir ? '🔐 디렉터 전용' : esc(c.customer_name)) + '</b><div class="muted">' + (isDir ? '전체 문의 · 모든 메모' : esc(c.customer_code)) + '</div></td>'
          + '<td class="mono" style="white-space:nowrap">…' + esc(c.last4) + '</td><td class="num">' + money(c.basis_amount) + '</td><td class="muted lp-memo">' + esc(c.memo || '') + '</td>'
          + '<td>' + (c.scope_states && c.scope_states.length ? esc(c.scope_states.join(', ')) : '전체 주') + '<div class="muted">' + (c.scope_ads && c.scope_ads.length ? '광고: ' + esc(c.scope_ads.map(adLabel).join(', ')) : '모든 광고') + '</div></td>'
          + '<td style="white-space:nowrap">' + esc(c.created_on) + '</td><td style="white-space:nowrap">' + esc(c.expires_on) + '</td><td><span class="tag ' + s[1] + '">' + esc(lab) + '</span></td>'
          + '<td class="muted">' + (c.last_seen_at ? esc(fmtT(c.last_seen_at)) : '—') + '</td>'
          + '<td class="num">' + c.reveals + '</td><td class="num">' + (c.orders ? c.orders + '건<div class="muted">' + money2(c.orders_total) + '</div>' : '—') + '</td>'
          + '<td><div class="row lp-acts">' + act + '</div></td></tr>';
      }).join('') + '</tbody></table>';
  }
  async function patch(id, body, okT) {
    try { await api('PATCH', '/api/lead-portal-admin/codes/' + id, body); say(true, okT || '저장했습니다.'); loadCodes(); }
    catch (e) { say(false, errT(e)); }
  }
  async function onAct(e) {
    var b = e.target.closest('[data-act]'); if (!b) return;
    var id = Number(b.dataset.id); var c = LP.codes.filter(function (x) { return x.id === id; })[0]; if (!c) return;
    var a = b.dataset.act;
    if (a === 'ext') {
      var v = prompt(c.customer_name + ' — 새 만료일 (YYYY-MM-DD)\n지금: ' + c.expires_on, c.expires_on);
      if (v == null) return; v = v.trim();
      if (!ymd(v)) { say(false, '날짜 형식은 YYYY-MM-DD 입니다.'); return; }
      return patch(id, { expires_on: v }, '만료일을 ' + v + '로 바꿨습니다.');
    }
    if (a === 'memo') {
      var amt = prompt(c.customer_name + ' — 기준 금액 (MXN, 비우면 없음)', c.basis_amount == null ? '' : String(c.basis_amount)); if (amt == null) return;
      var memo = prompt('조건 메모 (고객에게 안 보임)', c.memo || ''); if (memo == null) return;
      return patch(id, { basis_amount: amt.trim(), memo: memo.trim() });
    }
    if (a === 'scope') {
      var cur = c.scope_states && c.scope_states.length ? c.scope_states.join(', ') : '전체';
      var s = prompt('열람 범위 — 주 이름을 쉼표로(예: Nuevo León, Tamaulipas). 「전체」면 모든 문의.\n사용 가능: ' + (LP.st.states || []).join(', '), cur);
      if (s == null) return; s = s.trim();
      var list = !s || s === '전체' ? [] : s.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
      var bad = list.filter(function (x) { return (LP.st.states || []).indexOf(x) < 0; });
      if (bad.length) { say(false, '없는 주: ' + bad.join(', ')); return; }
      return patch(id, { scope_states: list }, '열람 범위를 바꿨습니다.');
    }
    if (a === 'ads') {   // 1105 · 광고 범위
      var list2 = LP.st.ads || [];
      var cur2 = c.scope_ads && c.scope_ads.length ? c.scope_ads.map(function (x) { var i = -1; list2.forEach(function (a2, j) { if (a2.ad_id === x) i = j; }); return i >= 0 ? String(i + 1) : x; }).join(', ') : '전체';
      var v2 = prompt(c.customer_name + ' — 볼 수 있는 광고\n번호(또는 광고 ID)를 쉼표로 · 「전체」면 모든 광고\n\n' + list2.map(function (a2, j) { return (j + 1) + ') ' + adLabel(a2.ad_id) + ' · ' + a2.ad_id + ' · ' + a2.n + '건'; }).join('\n'), cur2);
      if (v2 == null) return; v2 = v2.trim();
      var ids = !v2 || v2 === '전체' ? [] : v2.split(',').map(function (x) { x = x.trim(); return /^\d{1,3}$/.test(x) && list2[Number(x) - 1] ? list2[Number(x) - 1].ad_id : x; }).filter(Boolean);
      var badA = ids.filter(function (x) { return !/^\d{5,25}$/.test(x); });
      if (badA.length) { say(false, '광고 번호 · ID 를 확인하세요: ' + badA.join(', ')); return; }
      return patch(id, { scope_ads: ids }, ids.length ? '광고 범위를 ' + ids.length + '개로 바꿨습니다.' : '모든 광고를 보게 했습니다.');
    }
    if (a === 'access') { g('lpAcQ').value = ''; loadAccess(id); try { g('lpAccessBox').scrollIntoView({ behavior: 'smooth' }); } catch (_) {} return; }
    if (a === 'pause') { if (!confirm(c.customer_name + ' 접속을 정지할까요? 열어 둔 화면도 다음 요청부터 막힙니다.')) return; return patch(id, { active: false }, '정지했습니다.'); }
    if (a === 'resume') return patch(id, { active: true }, '재개했습니다.');
    if (a === 'reissue') {
      if (!confirm(c.customer_name + ' 코드를 새로 발급할까요? 지금 코드(…' + c.last4 + ')는 바로 못 쓰게 됩니다.')) return;
      try { var d = await api('POST', '/api/lead-portal-admin/codes/' + id + '/reissue'); showIssued(d, c.customer_name, c.expires_on); say(true, '재발급했습니다 — 새 코드는 지금 한 번만 보입니다.'); loadCodes(); try { g('lpIssued').scrollIntoView({ behavior: 'smooth' }); } catch (_) {} }
      catch (e2) { say(false, errT(e2)); }
      return;
    }
    if (a === 'del') {
      if (!confirm(c.customer_name + ' 접속코드를 삭제할까요? 되돌릴 수 없습니다(공개 기록 · 주문은 남습니다).')) return;
      try { await api('DELETE', '/api/lead-portal-admin/codes/' + id); say(true, '삭제했습니다.'); loadCodes(); } catch (e3) { say(false, errT(e3)); }
      return;
    }
    if (a === 'shelf') { LP.shelfCust = { id: c.customer_id, name: c.customer_name, code: c.customer_code }; g('lpShelfQ').value = c.customer_code + ' · ' + c.customer_name; loadShelf(); try { g('lpShelfBox').scrollIntoView({ behavior: 'smooth' }); } catch (_) {} return; }
    if (a === 'log') {
      try {
        var lg = await api('GET', '/api/lead-portal-admin/codes/' + id + '/log');
        var AK = { issue: '발급', update: '수정', pause: '정지', resume: '재개', reissue: '재발급', delete: '삭제' };
        g('lpLog').innerHTML = '<h3>변경 이력 · ' + esc(c.customer_name) + ' <button type="button" class="btn sm ghost" id="lpLogX">닫기</button></h3><table><thead><tr><th>일시</th><th>내용</th><th>상세</th><th>누가</th></tr></thead><tbody>'
          + lg.items.map(function (x) { return '<tr><td>' + esc(x.at) + '</td><td>' + esc(AK[x.action] || x.action) + '</td><td class="muted">' + esc(logDetail(x.detail)) + '</td><td>' + esc(x.user_name || '') + '</td></tr>'; }).join('') + '</tbody></table>';
        g('lpLogX').onclick = function () { g('lpLog').innerHTML = ''; };
      } catch (e4) { say(false, errT(e4)); }
    }
  }
  function logDetail(d) {
    if (!d) return '';
    var o = [];
    if (d.expires_on) o.push('만료일 ' + (Array.isArray(d.expires_on) ? d.expires_on[0] + ' → ' + d.expires_on[1] : d.expires_on));
    if ('basis_amount' in d) o.push('기준 금액 ' + (Array.isArray(d.basis_amount) ? money(d.basis_amount[0]) + ' → ' + money(d.basis_amount[1]) : money(d.basis_amount)));
    if (d.memo) o.push('메모 수정');
    if ('scope_states' in d) { var s = Array.isArray(d.scope_states) && d.scope_states.length === 2 && (d.scope_states[0] === null || Array.isArray(d.scope_states[0])) ? d.scope_states[1] : d.scope_states; o.push('범위 ' + (s && s.length ? s.join(', ') : '전체')); }
    if ('scope_ads' in d) { var sa = Array.isArray(d.scope_ads) && d.scope_ads.length === 2 && (d.scope_ads[0] === null || Array.isArray(d.scope_ads[0])) ? d.scope_ads[1] : d.scope_ads; o.push('광고 ' + (sa && sa.length ? sa.map(adLabel).join(', ') : '전체')); }
    if ('active' in d) o.push(d.active ? '재개' : '정지');
    if (d.last4) o.push('새 코드 …' + d.last4);
    return o.join(' · ');
  }
  async function loadReveals() {
    try {
      var d = await api('GET', '/api/lead-portal-admin/reveals?limit=100');
      var ST = { nuevo: '신규', contactado: '연락함', derivado: '연결', venta: '판매', descartado: '제외' };
      var CHN = { whatsapp: 'WA', messenger: 'FB', instagram: 'IG' };
      g('lpReveals').innerHTML = d.items.length ? '<table><thead><tr><th>처음 본 일시</th><th>고객(코드)</th><th>문의</th><th>채널</th><th class="num">횟수</th><th>고객이 기록한 찾는 부품</th><th>문의 상태(ERP)</th></tr></thead><tbody>'
        + d.items.map(function (r) { return '<tr><td>' + esc(r.first_mx) + '</td><td>' + esc(r.customer_name) + ' <span class="muted">…' + esc(r.code_last4) + '</span></td><td>#' + r.thread_id + ' · ' + esc([r.vehicles, r.parts].filter(Boolean).join(' · ')) + '</td><td><span class="tag ch-' + esc(r.platform) + '">' + esc(CHN[r.platform] || r.platform) + '</span></td><td class="num">' + r.n + '</td><td class="mono">' + esc(r.wants || '—') + '</td><td>' + esc(ST[r.status] || r.status) + '</td></tr>'; }).join('') + '</tbody></table>'
        : '<div class="hint">아직 연락처를 본 고객이 없습니다.</div>';
    } catch (e) { g('lpReveals').innerHTML = '<div class="hint">' + esc(errT(e)) + '</div>'; }
  }

  // ── 0299 · 디렉터 전용 코드 · 문의 메모 ─────────────────────
  async function issueDirector() {
    var d0 = new Date(Date.UTC(+today().slice(0, 4), +today().slice(5, 7) - 1, +today().slice(8, 10) + 365)).toISOString().slice(0, 10);
    var v = prompt('디렉터 전용 코드 — 만료일 (YYYY-MM-DD)', d0); if (v == null) return; v = v.trim();
    if (!ymd(v)) { say(false, '날짜 형식은 YYYY-MM-DD 입니다.'); return; }
    try {
      var d = await api('POST', '/api/lead-portal-admin/codes', { kind: 'director', expires_on: v, memo: (session.user && session.user.name) || '' });
      showIssued(d, '🔐 디렉터 전용', v); say(true, '디렉터 코드를 발급했습니다 — 코드는 지금 한 번만 보입니다.'); loadCodes();
    } catch (e) { say(false, errT(e)); }
  }
  async function loadNotes() {
    var q = g('lpNotesQ') ? g('lpNotesQ').value.trim() : '';
    try {
      var d = await api('GET', '/api/lead-portal-admin/notes?limit=200' + (q ? '&q=' + encodeURIComponent(q) : ''));
      var CHN = { whatsapp: 'WA', messenger: 'FB', instagram: 'IG' };
      g('lpNotes').innerHTML = d.items.length ? '<table><thead><tr><th>작성 일시</th><th>누가</th><th>문의</th><th>메모</th><th>상태</th></tr></thead><tbody>'
        + d.items.map(function (n) {
          return '<tr' + (n.deleted_at ? ' style="opacity:.6"' : '') + '><td style="white-space:nowrap">' + esc(n.at) + '</td><td>' + esc(n.author) + ' <span class="muted">…' + esc(n.code_last4) + '</span></td>'
            + '<td>#' + n.thread_id + ' <span class="tag ch-' + esc(n.platform) + '">' + esc(CHN[n.platform] || n.platform) + '</span> ' + esc(n.vehicles || '') + '</td>'
            + '<td style="white-space:pre-wrap;max-width:420px">' + esc(n.body) + '</td><td>' + (n.deleted_at ? '<span class="tag s-exp">삭제됨 ' + esc(n.deleted_at) + '</span>' : '') + '</td></tr>';
        }).join('') + '</tbody></table>'
        : '<div class="hint">아직 메모가 없습니다.</div>';
    } catch (e) { g('lpNotes').innerHTML = '<div class="hint">' + esc(errT(e)) + '</div>'; }
  }

  // ── 0300 · Messenger 대화 선점 ─────────────────────────
  async function loadClaims() {
    if (!g('lpClaims')) return;
    try {
      var d = await api('GET', '/api/lead-portal-admin/claims');
      if (g('lpClaimDays') && document.activeElement !== g('lpClaimDays')) g('lpClaimDays').value = d.claim_days;
      g('lpClaims').innerHTML = d.items.length ? '<table><thead><tr><th>상태</th><th>고객(코드)</th><th>문의</th><th>선점 방법</th><th>선점</th><th>만료</th><th class="num">Messenger 보냄</th><th class="num">받음</th><th>마지막 메시지</th><th></th></tr></thead><tbody>'
        + d.items.map(function (c) {
          return '<tr' + (c.active ? '' : ' style="opacity:.6"') + '><td>' + (c.active ? '<span class="tag s-on">대화 중</span>' : (c.released_mx ? '<span class="tag s-exp">해제 ' + esc(c.released_mx) + '</span>' : '<span class="tag s-exp">만료</span>')) + '</td>'
            + '<td>' + esc(c.customer_name) + ' <span class="muted">…' + esc(c.code_last4 || '') + '</span></td><td>#' + c.thread_id + ' <span class="tag ch-' + esc(c.platform || '') + '">' + esc(({ whatsapp: 'WA', messenger: 'FB', instagram: 'IG' })[c.platform] || c.platform || '') + '</span> ' + esc([c.lead_name, c.vehicles].filter(Boolean).join(' · ')) + '</td>'
            + '<td>' + esc(({ note: '📝 연락 기록', messenger: '💬 Messenger', legacy: '(이전 방식)' })[c.via] || c.via || '') + '</td>'
            + '<td style="white-space:nowrap">' + esc(c.claimed_mx) + '</td><td style="white-space:nowrap">' + esc(c.expires_mx) + '</td><td class="num">' + c.sent + '</td><td class="num">' + c.received + '</td><td style="white-space:nowrap">' + esc(c.last_mx || '—') + '</td>'
            + '<td>' + (c.active ? '<div class="row lp-acts"><button type="button" class="btn sm ghost" data-cext="' + c.id + '">연장</button><button type="button" class="btn sm lp-red" data-crel="' + c.id + '">해제</button></div>' : '') + '</td></tr>';
        }).join('') + '</tbody></table>'
        : '<div class="hint">아직 선점된 문의가 없습니다.</div>';
    } catch (e) { g('lpClaims').innerHTML = '<div class="hint">' + esc(errT(e)) + '</div>'; }
  }
  async function saveClaimDays() {
    var v = Number(g('lpClaimDays').value);
    try { await api('PUT', '/api/lead-portal-admin/settings', { claim_days: v }); say(true, '선점 기본 일수를 ' + v + '일로 저장했습니다(새로 선점 · 메시지부터 적용).'); loadClaims(); }
    catch (e) { say(false, errT(e)); }
  }
  async function onClaimAct(e) {
    var b = e.target.closest('[data-cext],[data-crel]'); if (!b) return;
    try {
      if (b.dataset.crel) {
        if (!confirm('이 선점을 해제할까요? 그 고객의 대화창이 닫히고 다른 고객이 맡을 수 있게 됩니다.')) return;
        await api('POST', '/api/lead-portal-admin/claims/' + b.dataset.crel + '/release'); say(true, '해제했습니다.');
      } else {
        var dd = prompt('며칠 연장할까요? (1~60)', '3'); if (dd == null) return;
        var r = await api('POST', '/api/lead-portal-admin/claims/' + b.dataset.cext + '/extend', { days: Number(dd) }); say(true, '연장했습니다 — ' + r.expires_mx + '까지.');
      }
      loadClaims();
    } catch (e2) { say(false, errT(e2)); }
  }

  // ── 고객 매장 재고 ─────────────────────────────────────
  async function loadShelf() {
    var c = LP.shelfCust; if (!c) { g('lpShelf').innerHTML = ''; return; }
    g('lpShelf').innerHTML = '<div class="hint">불러오는 중…</div>';
    try {
      var d = await api('GET', '/api/lead-portal-admin/shelf?customer_id=' + c.id);
      var nC = d.items.filter(function (x) { return x.by.indexOf('고객') === 0; }).length;
      g('lpShelf').innerHTML = '<div class="hint" style="margin:6px 0">' + esc(c.name) + ' · 값 ' + d.items.length + '개 · 고객 입력 ' + nC + ' · Refatrix 입력 ' + (d.items.length - nC) + '</div>'
        + '<table><thead><tr><th>부품번호</th><th>품명</th><th class="num">고객 재고</th><th>마지막 입력</th><th class="num">구매 12개월</th><th class="num">우리 가용</th><th></th></tr></thead><tbody>'
        + d.items.map(function (x) {
          return '<tr><td class="mono">' + esc(x.code) + '</td><td>' + esc(x.name) + '</td><td class="num"><input class="lp-q" data-code="' + esc(x.code) + '" value="' + esc(x.qty) + '" inputmode="numeric"></td>'
            + '<td><span class="tag ' + (x.by.indexOf('고객') === 0 ? 's-on' : 's-soon') + '">' + esc(x.by) + '</span> ' + esc(x.at) + '</td><td class="num">' + x.bought12 + '</td><td class="num">' + (x.avail == null ? '—' : x.avail) + '</td>'
            + '<td><button type="button" class="btn sm ghost" data-hist="' + esc(x.code) + '">이력</button></td></tr>';
        }).join('')
        + '<tr><td><input id="lpShelfCode" placeholder="부품번호" style="width:120px"></td><td class="muted">새로 추가</td><td class="num"><input id="lpShelfQty" class="lp-q-new" inputmode="numeric" style="width:64px"></td><td colspan="4"><button type="button" class="btn sm" id="lpShelfAdd">+ 추가</button></td></tr>'
        + '</tbody></table><div class="hint" style="margin-top:6px">숫자를 고치고 칸을 벗어나면 바로 저장 · 비우면 지움 · 이력이 모두 남습니다.</div>';
      g('lpShelfAdd').onclick = function () { saveShelf(g('lpShelfCode').value.trim(), g('lpShelfQty').value.trim(), true); };
    } catch (e) { g('lpShelf').innerHTML = '<div class="hint">' + esc(errT(e)) + '</div>'; }
  }
  async function saveShelf(code, v, reload) {
    var c = LP.shelfCust; if (!c || !code) return;
    if (v !== '' && !/^\d{1,6}$/.test(v)) { say(false, ERRK.bad_qty, 'lpShelfMsg'); return; }
    try {
      await api('PUT', '/api/lead-portal-admin/shelf', { customer_id: c.id, code: code, qty: v === '' ? null : Number(v) });
      say(true, code + ' 저장했습니다.', 'lpShelfMsg');
      if (reload) loadShelf();
    } catch (e) { say(false, errT(e), 'lpShelfMsg'); }
  }
  async function shelfHist(code) {
    var c = LP.shelfCust; if (!c) return;
    try {
      var d = await api('GET', '/api/lead-portal-admin/shelf/log?customer_id=' + c.id + '&code=' + encodeURIComponent(code));
      g('lpShelfLog').innerHTML = '<h3>' + esc(code) + ' 이력 <button type="button" class="btn sm ghost" id="lpShelfLogX">닫기</button></h3>'
        + (d.items.length ? '<table><thead><tr><th>일시</th><th>변경</th><th>누가</th></tr></thead><tbody>' + d.items.map(function (x) { return '<tr><td>' + esc(x.at) + '</td><td>' + (x.old == null ? '—' : x.old) + ' → ' + (x.new == null ? '지움' : x.new) + '</td><td>' + esc(x.by) + '</td></tr>'; }).join('') + '</tbody></table>' : '<div class="hint">이력이 없습니다.</div>');
      g('lpShelfLogX').onclick = function () { g('lpShelfLog').innerHTML = ''; };
    } catch (e) { say(false, errT(e), 'lpShelfMsg'); }
  }

  function wire() {
    if (!g('p-lp')) return;
    g('lpCustQ').addEventListener('input', function () { LP.cust = null; clearTimeout(LP.timer); LP.timer = setTimeout(function () { searchCust('lpCustQ', 'lpCustList', pickIssueCust); }, 300); });
    g('lpShelfQ').addEventListener('input', function () { clearTimeout(LP.timer2); LP.timer2 = setTimeout(function () { searchCust('lpShelfQ', 'lpShelfList', function (c) { LP.shelfCust = c; g('lpShelfQ').value = c.code + ' · ' + c.name; loadShelf(); }); }, 300); });
    g('lpExp').addEventListener('input', expHint); g('lpExp').addEventListener('change', expHint);
    g('lpScopeMode').addEventListener('change', function () { g('lpScopeBox').classList.toggle('hidden', g('lpScopeMode').value !== 'pick'); });
    if (g('lpAdMode')) g('lpAdMode').addEventListener('change', function () { g('lpAdBox').classList.toggle('hidden', g('lpAdMode').value !== 'pick'); });
    if (g('lpAcGo')) g('lpAcGo').addEventListener('click', function () { loadAccess(); });
    if (g('lpConsGo')) g('lpConsGo').addEventListener('click', loadConsents);
    if (g('lcNew')) g('lcNew').addEventListener('click', function () { cardForm(null); });
    if (g('lcCancel')) g('lcCancel').addEventListener('click', function () { g('lpCardForm').classList.add('hidden'); });
    if (g('lcSave')) g('lcSave').addEventListener('click', saveCard);
    if (g('lcBank')) g('lcBank').addEventListener('click', openBank);
    if (g('lcBankX')) g('lcBankX').addEventListener('click', function () { g('lcBankBox').classList.add('hidden'); });
    if (g('lcBankQ')) g('lcBankQ').addEventListener('input', renderBank);
    if (g('lcBankGrid')) g('lcBankGrid').addEventListener('click', function (e) {
      var z = e.target.closest('[data-bz]'); if (z) { e.stopPropagation(); zoomBank(Number(z.dataset.bz)); return; }
      var b = e.target.closest('[data-bk]'); if (b) pickBank(Number(b.dataset.bk)); });
    if (g('lcZoom')) { g('lcZoom').addEventListener('click', function (e) { if (!e.target.closest('#lcZoomBox')) g('lcZoom').classList.add('hidden'); });   // 바깥을 누르면 닫힘 g('lcZoomX').addEventListener('click', function () { g('lcZoom').classList.add('hidden'); });
      g('lcZoomPick').addEventListener('click', function () { if (LP.zoomId) pickBank(LP.zoomId); }); }
    if (g('lcKitGo')) g('lcKitGo').addEventListener('click', function () { checkKit(); });
    if (g('lcKit')) g('lcKit').addEventListener('change', function () { checkKit(); });
    if (g('lcKitX')) g('lcKitX').addEventListener('click', function () { g('lcKit').value = ''; checkKit(); });
    if (g('lcFile')) g('lcFile').addEventListener('change', function () { var f = this.files && this.files[0]; uploadCardImage(f); this.value = ''; });
    if (g('lcImgX')) g('lcImgX').addEventListener('click', function () { g('lcImg').value = ''; showPrev(); });
    if (g('lcImg')) g('lcImg').addEventListener('change', showPrev);
    if (g('lpCards')) g('lpCards').addEventListener('click', onCardAct);
    if (g('lpConsents')) g('lpConsents').addEventListener('click', function (e) { var b = e.target.closest('[data-cons]'); if (b) viewConsent(Number(b.dataset.cons)); });
    if (g('lpAcQ')) g('lpAcQ').addEventListener('input', renderAccess);
    if (g('lpAccess')) g('lpAccess').addEventListener('click', function (e) { if (e.target.closest('#lpAcAll')) loadAccess(null); });
    g('lpIssue').addEventListener('click', issue);
    if (g('lpDirIssue')) g('lpDirIssue').addEventListener('click', issueDirector);
    if (g('lpClaimSave')) g('lpClaimSave').addEventListener('click', saveClaimDays);
    if (g('lpClaims')) g('lpClaims').addEventListener('click', onClaimAct);
    if (g('lpNotesGo')) g('lpNotesGo').addEventListener('click', loadNotes);
    if (g('lpNotesQ')) g('lpNotesQ').addEventListener('keydown', function (e) { if (e.key === 'Enter') loadNotes(); });
    g('lpCodes').addEventListener('click', onAct);
    g('lpFilter').addEventListener('change', renderCodes);
    g('lpFind').addEventListener('input', renderCodes);
    g('lpShelf').addEventListener('change', function (e) { var i = e.target.closest('input.lp-q'); if (i) saveShelf(i.dataset.code, i.value.trim(), false); });
    g('lpShelf').addEventListener('click', function (e) { var b = e.target.closest('[data-hist]'); if (b) shelfHist(b.dataset.hist); });
    var tabs = g('tabs');
    if (tabs) tabs.addEventListener('click', function (e) { var b = e.target.closest('.tab'); if (b && b.dataset.p === 'lp') { if (!LP.loaded) load(); else { if (LP.st && LP.st.director && LP.st.ready) { loadCodes(); loadReveals(); loadNotes(); loadClaims(); } if (LP.st && LP.st.access) loadAccess(); loadConsents(); } } });
  }
  var fmtT = function (t) { return new Date(t).toLocaleString('ko-KR', { timeZone: 'America/Mexico_City', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); };
  wire();
})();
